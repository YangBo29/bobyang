# 新增功能
	2021/09/02		新增SuperMapTerrainProvider和SuperMapImageryProvider插件

# S3MTilesLayer

该插件支持在Cesium中创建S3MTilesLayer图层，目前支持的功能有：

* 加载S3M/S3MBlock格式的数据
* 拾取
* 对象是否可见
* 压平
* 分层设色
* 裁剪分析
* 剖面分析
* 淹没分析

## 使用方式

* 将当前文件放到Cesium文件夹中，保持和Build文件夹同一目录
* 启动Cesium
* 以Http形式访问examples中的范例
