(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
    typeof define === 'function' && define.amd ? define(['exports'], factory) :
    (global = global || self, factory(global.SuperMap3D = Cesium));
}(this, (function (exports) { 'use strict';

    var _0x1115=['4GXOpWl','7CsQNJf','296CjjHHY','1415UYwCSS','end','168925azJawY','14324DsYYlE','prototype','begin','300183MlxjZE','DeveloperError','79RRzgUo','21035hoRjpR','281205brvFpX','37218XiLxhI'];var _0x30b0b3=_0x8cf3;function _0x8cf3(_0x1cc7a9,_0x16474b){_0x1cc7a9=_0x1cc7a9-0x181;var _0x1115f4=_0x1115[_0x1cc7a9];return _0x1115f4;}(function(_0x67b389,_0x28b854){var _0x63b01f=_0x8cf3;while(!![]){try{var _0x24e4c5=parseInt(_0x63b01f(0x18b))*parseInt(_0x63b01f(0x18a))+parseInt(_0x63b01f(0x18d))+parseInt(_0x63b01f(0x189))*parseInt(_0x63b01f(0x187))+parseInt(_0x63b01f(0x185))*-parseInt(_0x63b01f(0x188))+parseInt(_0x63b01f(0x182))+parseInt(_0x63b01f(0x186))+-parseInt(_0x63b01f(0x184))*parseInt(_0x63b01f(0x18e));if(_0x24e4c5===_0x28b854)break;else _0x67b389['push'](_0x67b389['shift']());}catch(_0x59a8ec){_0x67b389['push'](_0x67b389['shift']());}}}(_0x1115,0x343b7));function RenderTarget(){}RenderTarget['prototype'][_0x30b0b3(0x181)]=Cesium[_0x30b0b3(0x183)]['throwInstantiationError'],RenderTarget[_0x30b0b3(0x18f)][_0x30b0b3(0x18c)]=Cesium[_0x30b0b3(0x183)]['throwInstantiationError'];

    const _0x3d60=['TextureWrap','1715oIxyLb','depthTextureToCopy','pick','destroy','depth','BoundingRectangle','endFunc','create','clearCommand','isUpdate','renderState','prototype','view','constructor','fromCache','copyDepthCommand','ClearCommand','TextureMinificationFilter','createViewportQuadCommand','destroyObject','sceneFramebuffer','width','NEAREST','clone','isDestroyed','401470PDgZOx','358754cjlKww','Texture','passState','beginFunc','SceneFramebuffer','334499yKwDnm','Sampler','448468NpUyCG','_updateCopyCommand','depthStencilTexture','291567ywTrhX','passes','CLAMP_TO_EDGE','PassState','drawingBufferHeight','325543TbIDnT','Framebuffer','viewport','execute','vertexArray','271eOhpIQ','framebuffer','context','_hdr','height','frameState','1DxxkOj','getFramebuffer','depthTexture','equals','_updateFramebuffer'];const _0x2c5c63=_0x165b;function _0x165b(_0x2fa53a,_0x5954d3){_0x2fa53a=_0x2fa53a-0x1a7;let _0x3d60e9=_0x3d60[_0x2fa53a];return _0x3d60e9;}(function(_0x8397d3,_0x411615){const _0x5f2b95=_0x165b;while(!![]){try{const _0x408868=-parseInt(_0x5f2b95(0x1b7))+parseInt(_0x5f2b95(0x1cc))*-parseInt(_0x5f2b95(0x1d8))+parseInt(_0x5f2b95(0x1b8))+parseInt(_0x5f2b95(0x1c2))+parseInt(_0x5f2b95(0x1bd))+parseInt(_0x5f2b95(0x1d2))*-parseInt(_0x5f2b95(0x1c7))+parseInt(_0x5f2b95(0x1bf));if(_0x408868===_0x411615)break;else _0x8397d3['push'](_0x8397d3['shift']());}catch(_0x5ba06a){_0x8397d3['push'](_0x8397d3['shift']());}}}(_0x3d60,0x3af66));function DepthFramebuffer(_0x24ecb5){const _0x378ccd=_0x165b;this['context']=_0x24ecb5,this[_0x378ccd(0x1b2)]=new Cesium[(_0x378ccd(0x1bc))](),this[_0x378ccd(0x1ba)]=new Cesium[(_0x378ccd(0x1c5))](_0x24ecb5),this[_0x378ccd(0x1ba)][_0x378ccd(0x1c9)]=new Cesium[(_0x378ccd(0x1dd))](),this['environmentVisible']={'isSunVisible':![],'isMoonVisible':![],'isSkyAtmosphereVisible':![],'isSkyBoxVisible':![],'isGlobalVisible':!![],'isObjectVisible':!![]},this[_0x378ccd(0x1b3)]=0x0,this[_0x378ccd(0x1d0)]=0x0,this[_0x378ccd(0x1ad)]=undefined,this[_0x378ccd(0x1e0)]=undefined,this[_0x378ccd(0x1cd)]=undefined,this[_0x378ccd(0x1d9)]=undefined,this['rs']=undefined,this[_0x378ccd(0x1d4)]=undefined,this[_0x378ccd(0x1cd)]=undefined,this['isUpdate']=![];}DepthFramebuffer[_0x2c5c63(0x1a9)]=Object[_0x2c5c63(0x1df)](RenderTarget[_0x2c5c63(0x1a9)]),DepthFramebuffer['prototype'][_0x2c5c63(0x1ab)]=RenderTarget,DepthFramebuffer[_0x2c5c63(0x1a9)][_0x2c5c63(0x1d6)]=function(_0x35c698){const _0x244403=_0x2c5c63;let _0x255eac=_0x35c698['drawingBufferWidth'],_0x3f5bda=_0x35c698[_0x244403(0x1c6)];(!this[_0x244403(0x1cd)]||this[_0x244403(0x1b3)]!==_0x255eac||this[_0x244403(0x1d0)]!==_0x3f5bda)&&(this['width']=_0x255eac,this[_0x244403(0x1d0)]=_0x3f5bda,this[_0x244403(0x1d4)]=this[_0x244403(0x1d4)]&&!this['depthTexture'][_0x244403(0x1b6)]()&&this['depthTexture'][_0x244403(0x1db)](),this[_0x244403(0x1d4)]=new Cesium[(_0x244403(0x1b9))]({'context':_0x35c698,'width':_0x255eac,'height':_0x3f5bda,'pixelFormat':Cesium['PixelFormat']['RGBA'],'pixelDatatype':Cesium['PixelDatatype']['UNSIGNED_BYTE'],'sampler':new Cesium[(_0x244403(0x1be))]({'wrapS':Cesium[_0x244403(0x1d7)][_0x244403(0x1c4)],'wrapT':Cesium[_0x244403(0x1d7)][_0x244403(0x1c4)],'minificationFilter':Cesium[_0x244403(0x1af)]['NEAREST'],'magnificationFilter':Cesium['TextureMagnificationFilter'][_0x244403(0x1b4)]})}),this[_0x244403(0x1cd)]=this['framebuffer']&&!this[_0x244403(0x1cd)][_0x244403(0x1b6)]()&&this['framebuffer'][_0x244403(0x1db)](),this['framebuffer']=new Cesium[(_0x244403(0x1c8))]({'context':_0x35c698,'colorTextures':[this[_0x244403(0x1d4)]],'destroyAttachments':![]}));},DepthFramebuffer['prototype'][_0x2c5c63(0x1c0)]=function(_0x25e93c){const _0x591827=_0x2c5c63;(!this['rs']||!Cesium[_0x591827(0x1dd)][_0x591827(0x1d5)](this['passState'][_0x591827(0x1c9)],this['rs'][_0x591827(0x1c9)]))&&(this['rs']=Cesium['RenderState'][_0x591827(0x1ac)]({'viewport':this[_0x591827(0x1ba)][_0x591827(0x1c9)]}));if(!this[_0x591827(0x1ad)]){let _0xd2a378='\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20uniform\x20sampler2D\x20u_depthTexture;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20varying\x20vec2\x20v_textureCoordinates;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20void\x20main()\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20gl_FragColor\x20=\x20czm_packDepth(texture2D(u_depthTexture,\x20v_textureCoordinates).r);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20';this[_0x591827(0x1ad)]=_0x25e93c[_0x591827(0x1b0)](_0xd2a378,{'uniformMap':{'u_depthTexture':()=>{const _0x962ab4=_0x591827;return this[_0x962ab4(0x1d9)];}},'owner':this});}!this[_0x591827(0x1e0)]&&(this[_0x591827(0x1e0)]=new Cesium[(_0x591827(0x1ae))]({'color':new Cesium['Color'](0x0,0x0,0x0,0x0),'stencil':0x0,'depth':0x1,'owner':this})),this['copyDepthCommand'][_0x591827(0x1a8)]=this['rs'],this[_0x591827(0x1ad)][_0x591827(0x1cd)]=this[_0x591827(0x1cd)],this[_0x591827(0x1e0)]['framebuffer']=this[_0x591827(0x1cd)];},DepthFramebuffer[_0x2c5c63(0x1a9)]['begin']=function(_0x4319ad){const _0x37d03a=_0x2c5c63;this['sceneFramebuffer']['update'](_0x4319ad[_0x37d03a(0x1ce)],_0x4319ad[_0x37d03a(0x1aa)]['viewport'],_0x4319ad[_0x37d03a(0x1cf)]),this[_0x37d03a(0x1ba)][_0x37d03a(0x1cd)]=this[_0x37d03a(0x1b2)][_0x37d03a(0x1d3)](),Cesium[_0x37d03a(0x1dd)][_0x37d03a(0x1b5)](_0x4319ad[_0x37d03a(0x1aa)][_0x37d03a(0x1c9)],this[_0x37d03a(0x1ba)][_0x37d03a(0x1c9)]);let _0x59af39=_0x4319ad[_0x37d03a(0x1ce)];return this['_updateFramebuffer'](_0x59af39),this[_0x37d03a(0x1c0)](_0x59af39),this[_0x37d03a(0x1e0)][_0x37d03a(0x1ca)](_0x59af39,this[_0x37d03a(0x1ba)]),_0x4319ad[_0x37d03a(0x1d1)][_0x37d03a(0x1c3)][_0x37d03a(0x1dc)]=!![],this[_0x37d03a(0x1bb)]&&this[_0x37d03a(0x1bb)](_0x4319ad[_0x37d03a(0x1d1)]),this['passState'];},DepthFramebuffer[_0x2c5c63(0x1a9)]['end']=function(_0x4043af,_0x49e291){const _0x1c7ae2=_0x2c5c63;_0x4043af[_0x1c7ae2(0x1c3)][_0x1c7ae2(0x1da)]=![],_0x4043af['passes'][_0x1c7ae2(0x1dc)]=![],this[_0x1c7ae2(0x1de)]&&this['endFunc'](_0x4043af),this[_0x1c7ae2(0x1d9)]=_0x49e291[_0x1c7ae2(0x1cd)][_0x1c7ae2(0x1c1)],this[_0x1c7ae2(0x1ad)]&&this[_0x1c7ae2(0x1ad)][_0x1c7ae2(0x1ca)](_0x4043af[_0x1c7ae2(0x1ce)],_0x49e291);},DepthFramebuffer[_0x2c5c63(0x1a9)][_0x2c5c63(0x1b6)]=function(){return ![];},DepthFramebuffer[_0x2c5c63(0x1a9)][_0x2c5c63(0x1db)]=function(){const _0x2feba1=_0x2c5c63;this[_0x2feba1(0x1d4)]=this[_0x2feba1(0x1d4)]&&!this[_0x2feba1(0x1d4)]['isDestroyed']()&&this[_0x2feba1(0x1d4)][_0x2feba1(0x1db)](),this[_0x2feba1(0x1cd)]=this['framebuffer']&&!this['framebuffer'][_0x2feba1(0x1b6)]()&&this[_0x2feba1(0x1cd)][_0x2feba1(0x1db)]();if(this[_0x2feba1(0x1ad)]){let _0x5b3e99=this['copyDepthCommand']['sp'];_0x5b3e99=_0x5b3e99&&!_0x5b3e99['isDestroyed']()&&_0x5b3e99[_0x2feba1(0x1db)]();let _0x4485e9=this[_0x2feba1(0x1ad)][_0x2feba1(0x1cb)];_0x4485e9=_0x4485e9&&!_0x4485e9[_0x2feba1(0x1b6)]()&&_0x4485e9[_0x2feba1(0x1db)](),this['copyDepthCommand']=undefined;}return this[_0x2feba1(0x1e0)]=undefined,this[_0x2feba1(0x1d9)]=undefined,this[_0x2feba1(0x1a7)]=![],Cesium[_0x2feba1(0x1b1)](this);};

    var _0x450a=['5207WvXPsR','42214TcKopp','68898ukoKHC','7qYqnsg','14537czKgdj','239483xgYzdr','13nFdwPp','136754ldbmmd','\x0a\x20\x20\x20\x20attribute\x20vec4\x20aPosition;\x0a\x20\x20\x20\x20varying\x20vec4\x20vClipPos;\x0a\x20\x20\x20\x20void\x20main()\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20vClipPos\x20=\x20czm_modelViewProjection\x20*\x20vec4(aPosition.xyz,\x201.0);\x0a\x09\x20\x20\x20\x20gl_Position\x20=\x20vClipPos;\x0a\x20\x20\x20\x20}\x0a','22935qfdINx'];var _0x1643db=_0x20a9;(function(_0x8db803,_0x1cff45){var _0x3445d8=_0x20a9;while(!![]){try{var _0x103b5a=-parseInt(_0x3445d8(0xfb))+parseInt(_0x3445d8(0xf9))+-parseInt(_0x3445d8(0x100))+-parseInt(_0x3445d8(0xfe))*-parseInt(_0x3445d8(0xfa))+-parseInt(_0x3445d8(0xfd))+-parseInt(_0x3445d8(0xff))+parseInt(_0x3445d8(0xf8))*parseInt(_0x3445d8(0xf7));if(_0x103b5a===_0x1cff45)break;else _0x8db803['push'](_0x8db803['shift']());}catch(_0x2931a1){_0x8db803['push'](_0x8db803['shift']());}}}(_0x450a,0x21b94));function _0x20a9(_0x3f7e80,_0x28f6d5){_0x3f7e80=_0x3f7e80-0xf7;var _0x450aaf=_0x450a[_0x3f7e80];return _0x450aaf;}var _0x27a0be = _0x1643db(0xfc);

    var _0x281e=['958197PwnwKT','\x0a#ifdef\x20GL_EXT_frag_depth\x0a#extension\x20GL_EXT_frag_depth\x20:\x20enable\x0a#endif\x0a#ifdef\x20GL_OES_standard_derivatives\x0a#extension\x20GL_OES_standard_derivatives\x20:\x20enable\x0a#endif\x0a\x0auniform\x20vec4\x20uVisibleAreaColor;\x0auniform\x20vec4\x20uHiddenAreaColor;\x0auniform\x20vec2\x20uTextureSize;\x0auniform\x20sampler2D\x20uGlobalDepthTexture;\x0auniform\x20sampler2D\x20uTexture;\x0auniform\x20mat4\x20uRenderTextureMatrix;\x0avarying\x20vec4\x20vClipPos;\x0a\x0afloat\x20getDepth(in\x20vec4\x20depth)\x0a{\x0a\x20\x20\x20\x20float\x20z_window\x20=\x20czm_unpackDepth(depth);\x0a\x20\x20\x20\x20return\x20z_window;\x0a}\x0a\x0afloat\x20getDepthFromShadowMap(in\x20sampler2D\x20viewShedTexture,\x20in\x20vec4\x20texCoord)\x0a{\x0a\x09vec2\x20tCoord;\x0a\x20\x20\x20\x20tCoord\x20=\x20texCoord.xy\x20*\x20uTextureSize\x20-\x200.5;\x0a\x09float\x20x0\x20=\x20floor(tCoord.x);\x0a\x09float\x20x1\x20=\x20ceil(tCoord.x);\x0a\x09float\x20y0\x20=\x20floor(tCoord.y);\x0a\x09float\x20y1\x20=\x20ceil(tCoord.y);\x0a\x09vec2\x20invTexSize\x20=\x201.0\x20/\x20uTextureSize;\x0a\x09vec2\x20t00\x20=\x20vec2((x0\x20+\x200.5)\x20*\x20invTexSize.x,\x20(y0\x20+\x200.5)\x20*\x20invTexSize.y);\x0a\x09vec2\x20t10\x20=\x20vec2((x1\x20+\x200.5)\x20*\x20invTexSize.x,\x20(y0\x20+\x200.5)\x20*\x20invTexSize.y);\x0a\x09vec2\x20t01\x20=\x20vec2((x0\x20+\x200.5)\x20*\x20invTexSize.x,\x20(y1\x20+\x200.5)\x20*\x20invTexSize.y);\x0a\x09vec2\x20t11\x20=\x20vec2((x1\x20+\x200.5)\x20*\x20invTexSize.x,\x20(y1\x20+\x200.5)\x20*\x20invTexSize.y);\x0a\x09float\x20z00\x20=\x20getDepth(texture2D(uTexture,\x20t00));\x0a\x09float\x20z10\x20=\x20getDepth(texture2D(uTexture,\x20t01));\x0a\x09float\x20z01\x20=\x20getDepth(texture2D(uTexture,\x20t10));\x0a\x09float\x20z11\x20=\x20getDepth(texture2D(uTexture,\x20t11));\x0a\x09float\x20depth\x20=\x20max(max(z00,\x20z01),\x20max(z10,\x20z11));\x0a\x09return\x20depth;\x0a}\x0a\x0avoid\x20main()\x0a{\x0a\x09vec4\x20depthTexCoord\x20=\x20vClipPos\x20/\x20vClipPos.w;\x0a\x09depthTexCoord.xy\x20=\x20depthTexCoord.xy\x20*\x200.5\x20+\x200.5;\x0a\x09float\x20sceneDepth\x20=\x20czm_unpackDepth(texture2D(uGlobalDepthTexture,\x20depthTexCoord.xy));\x0a\x09sceneDepth\x20=\x20sceneDepth\x20*\x202.0\x20-\x201.0;\x0a\x09vec4\x20pos\x20=\x20vClipPos;\x0a\x09pos.z\x20=\x20sceneDepth\x20*\x20pos.w;\x0a\x09vec4\x20renderTextureCoord\x20=\x20uRenderTextureMatrix\x20*\x20pos;\x0a\x09vec4\x20texCoord\x20=\x20renderTextureCoord\x20/\x20renderTextureCoord.w;\x0a\x09texCoord.xyz\x20=\x20texCoord.xyz\x20*\x200.5\x20+\x200.5;\x0a\x09float\x20depth\x20=\x20getDepthFromShadowMap(uTexture,\x20texCoord);\x0a\x09float\x20dxc\x20=\x20abs(dFdx(texCoord.z));\x0a\x09float\x20dyc\x20=\x20abs(dFdy(texCoord.z));\x0a\x09float\x20dF\x20=\x20max(dxc,\x20dyc)\x20*\x203.0;\x0a\x09float\x20bias\x20=\x201.0e-6\x20+\x20dF;\x0a\x09float\x20c\x20=\x20float(depth\x20+\x20bias\x20<\x20texCoord.z);\x0a\x09vec4\x20finalColor\x20=\x20mix(uVisibleAreaColor,\x20uHiddenAreaColor,\x20vec4(c));\x0a\x09if(finalColor.a\x20<\x200.1)\x0a\x09{\x0a\x09\x09discard;\x0a\x09}\x0a\x09gl_FragColor\x20=\x20czm_gammaCorrect(finalColor);\x0a}\x0a','818840ofBHgf','4739iGbQLV','528806xGMLQy','3QwGcyA','1YhiIfy','783999acbBdW','1EeTNRi','14608zSEotn','247534phBZTi','46EgizGC'];function _0x3383(_0x5e3f0a,_0x1be0f1){_0x5e3f0a=_0x5e3f0a-0x85;var _0x281e4a=_0x281e[_0x5e3f0a];return _0x281e4a;}var _0x1c3d69=_0x3383;(function(_0x49153a,_0x5be1ff){var _0x52fe7a=_0x3383;while(!![]){try{var _0x41fb25=-parseInt(_0x52fe7a(0x86))+-parseInt(_0x52fe7a(0x87))*-parseInt(_0x52fe7a(0x8f))+parseInt(_0x52fe7a(0x8a))*-parseInt(_0x52fe7a(0x88))+parseInt(_0x52fe7a(0x8d))+parseInt(_0x52fe7a(0x8c))*parseInt(_0x52fe7a(0x8e))+-parseInt(_0x52fe7a(0x90))+parseInt(_0x52fe7a(0x89))*parseInt(_0x52fe7a(0x8b));if(_0x41fb25===_0x5be1ff)break;else _0x49153a['push'](_0x49153a['shift']());}catch(_0x52849b){_0x49153a['push'](_0x49153a['shift']());}}}(_0x281e,0x807d2));var _0x4b05a7 = _0x1c3d69(0x85);

    var _0x1829=['47614lFVnhc','4194568OBsfaK','1OvFfWE','1OIYGHY','190803HTEUYf','97WNnmtv','13142mquRwY','195233RwEleh','attribute\x20vec4\x20aPosition;\x0avarying\x20vec4\x20vClipVertex;\x0avarying\x20float\x20fWindowZ;\x0avec4\x20depthClampFarPlane(vec4\x20clipPos)\x0a{\x0a\x09fWindowZ\x20=\x20(0.5\x20*\x20(clipPos.z\x20/\x20clipPos.w)\x20+\x200.5)\x20*\x20clipPos.w;\x0a\x09clipPos.z\x20=\x20min(clipPos.z,\x20clipPos.w);\x0a\x09return\x20clipPos;\x0a}\x0avoid\x20main()\x0a{\x0a\x20\x20\x20vec4\x20pos\x20=\x20czm_modelViewProjection\x20*\x20vec4(aPosition.xyz,\x201.0);\x0a\x20\x20\x20gl_Position\x20=\x20depthClampFarPlane(pos);\x0a}\x0a','1234859RHlNwp','2bvDVBZ','1225111gZmtBf'];var _0x495954=_0x5ef7;function _0x5ef7(_0x3b7924,_0x2c2d32){_0x3b7924=_0x3b7924-0x156;var _0x182996=_0x1829[_0x3b7924];return _0x182996;}(function(_0x10524d,_0x50ea32){var _0x3dd061=_0x5ef7;while(!![]){try{var _0x2e099b=parseInt(_0x3dd061(0x156))*-parseInt(_0x3dd061(0x15e))+-parseInt(_0x3dd061(0x15f))*-parseInt(_0x3dd061(0x159))+-parseInt(_0x3dd061(0x160))*parseInt(_0x3dd061(0x161))+parseInt(_0x3dd061(0x15d))*-parseInt(_0x3dd061(0x158))+parseInt(_0x3dd061(0x15b))+-parseInt(_0x3dd061(0x15a))+parseInt(_0x3dd061(0x15c));if(_0x2e099b===_0x50ea32)break;else _0x10524d['push'](_0x10524d['shift']());}catch(_0x5bb166){_0x10524d['push'](_0x10524d['shift']());}}}(_0x1829,0xa9633));var _0x521c0a = _0x495954(0x157);

    var _0x27e9=['55483uqzTrH','1930824lUwGTW','1837063bRnUQq','1240303norAyI','663173ZadBBD','7IRYQQg','5PBiKkN','1749438NyoOVE','95781jwhxLI','\x0a#ifdef\x20GL_EXT_frag_depth\x0a#extension\x20GL_EXT_frag_depth\x20:\x20enable\x0a#endif\x0auniform\x20vec4\x20uColor;\x0avarying\x20float\x20fWindowZ;\x0avoid\x20main()\x0a{\x0a#ifdef\x20GL_EXT_frag_depth\x0a\x09gl_FragDepthEXT\x20=\x20min(fWindowZ\x20*\x20gl_FragCoord.w,\x201.0);\x0a#endif\x0a\x20\x20\x20gl_FragColor\x20=\x20uColor;\x0a}'];function _0x3720(_0x491144,_0x1d6485){_0x491144=_0x491144-0x18a;var _0x27e95d=_0x27e9[_0x491144];return _0x27e95d;}var _0x41e549=_0x3720;(function(_0x4afe39,_0x2b6a99){var _0x4da96e=_0x3720;while(!![]){try{var _0x1dfe63=-parseInt(_0x4da96e(0x193))*-parseInt(_0x4da96e(0x191))+-parseInt(_0x4da96e(0x18f))+-parseInt(_0x4da96e(0x18e))+parseInt(_0x4da96e(0x18d))+-parseInt(_0x4da96e(0x192))+parseInt(_0x4da96e(0x18c))+parseInt(_0x4da96e(0x190))*parseInt(_0x4da96e(0x18b));if(_0x1dfe63===_0x2b6a99)break;else _0x4afe39['push'](_0x4afe39['shift']());}catch(_0x19ce8e){_0x4afe39['push'](_0x4afe39['shift']());}}}(_0x27e9,0xefcf3));var _0x2f5c96 = _0x41e549(0x18a);

    const _0x1377=['OPAQUE','RADIANS_PER_DEGREE','magnitude','fromDegreesArrayHeights','add','ShaderSource','DECREMENT_WRAP','NOT_EQUAL','_verticalFov','Buffer','createIndexBuffer','view','destroy','createTypedArray','pitch','isUpdate','center','max','radius','_horizontalFov','344948anteOz','_context','viewMatrix','Math','ALPHA_BLEND','Cartesian3','width','pick','vertexArray','StencilOperation','StencilFunction','_updateCamera','cameraDepthBuffer','near','ComponentDatatype','name','scene','setView','isDestroyed','LINES','direction','INCREMENT_WRAP','_pitch','43wYDNNd','STATIC_DRAW','KEEP','camera','passes','prototype','height','farToNearRatio','transform','Matrix4','update','projectionMatrix','context','segmentCount','depthTexture','aspectRatio','_destroyCommand','BlendingState','_hintLineColor','BufferUsage','8721IHdmps','dirty','78OdSUQo','BoundingSphere','VertexArray','endFunc','_createCommand','inverse','Color','_viewPosition','shallowClone','fromCache','viewProjectionMatrix','beginFunc','IndexDatatype','abs','UNIT_Y','distance','fov','cos','Pass','2271ygIBVA','9361VYMSUp','RenderState','boundingSphere','_direction','stencilCommand','DrawCommand','subtract','roll','colorCommand','fbo','_hiddenAreaColor','tan','multiply','2311XAfqBR','_removeRenderTarget','remove','position','commandList','normalize','FLOAT','DepthFunction','logarithmicDepthFarToNearRatio','_global','sin','push','depth','ALWAYS','DEGREES_PER_RADIAN','useLogDepth','inverseViewMatrix','frustum','far','invViewMatrix','primitives','ZERO','createVertexBuffer','19NlQqKi','renderTextureMatrix','globalName','286349BXJZdL','renderState','length','uniformMap','heading','clone','_renderTargets','UNSIGNED_SHORT','_setRenderTarget','lineCommand','_visibleAreaColor','cross','build','setDistDirByPoint','globalDepthBuffer','_distance','frustumCommandsList','shaderProgram','dot','369483dhyciw'];const _0x4f9d16=_0x5abe;(function(_0xf3e0c8,_0x311dab){const _0x26d102=_0x5abe;while(!![]){try{const _0x2706ee=parseInt(_0x26d102(0x16a))+parseInt(_0x26d102(0x156))*-parseInt(_0x26d102(0x169))+parseInt(_0x26d102(0x140))*-parseInt(_0x26d102(0x177))+parseInt(_0x26d102(0x191))+-parseInt(_0x26d102(0x154))*-parseInt(_0x26d102(0x18e))+parseInt(_0x26d102(0x1a4))+-parseInt(_0x26d102(0x1b9));if(_0x2706ee===_0x311dab)break;else _0xf3e0c8['push'](_0xf3e0c8['shift']());}catch(_0x3e5cbe){_0xf3e0c8['push'](_0xf3e0c8['shift']());}}}(_0x1377,0x33219));function _0x5abe(_0x1031a4,_0x2614d6){_0x1031a4=_0x1031a4-0x13f;let _0x137754=_0x1377[_0x1031a4];return _0x137754;}function ViewShed3D(_0x1e3c8c){const _0x2cd235=_0x5abe;this[_0x2cd235(0x1c9)]=_0x1e3c8c,this[_0x2cd235(0x1c5)]=new DepthFramebuffer(_0x1e3c8c[_0x2cd235(0x1ba)]),this[_0x2cd235(0x19f)]=new DepthFramebuffer(_0x1e3c8c['_context']),this[_0x2cd235(0x1c8)]='',this[_0x2cd235(0x190)]='',this[_0x2cd235(0x14d)]=0x14,this[_0x2cd235(0x15d)]=[0x0,0x0,0x0],this[_0x2cd235(0x16d)]=0x0,this[_0x2cd235(0x13f)]=0x0,this[_0x2cd235(0x1b8)]=0x5a,this[_0x2cd235(0x1ad)]=0x3c,this[_0x2cd235(0x1a0)]=0x64,this[_0x2cd235(0x19b)]=new Cesium[(_0x2cd235(0x15c))](0x0,0x1,0x0,0.5),this[_0x2cd235(0x174)]=new Cesium[(_0x2cd235(0x15c))](0x1,0x0,0x0,0.5),this[_0x2cd235(0x152)]=new Cesium[(_0x2cd235(0x15c))](0x1,0x1,0x1,0x1),this[_0x2cd235(0x16c)]=new Cesium[(_0x2cd235(0x157))](),this[_0x2cd235(0x160)]=new Cesium[(_0x2cd235(0x149))](),this[_0x2cd235(0x18a)]=new Cesium[(_0x2cd235(0x149))](),this[_0x2cd235(0x18f)]=new Cesium[(_0x2cd235(0x149))](),this[_0x2cd235(0x172)]=undefined,this[_0x2cd235(0x16e)]=undefined,this['lineCommand']=undefined,this[_0x2cd235(0x155)]=![];}Object['defineProperties'](ViewShed3D[_0x4f9d16(0x145)],{'viewPosition':{'get':function(){return this['_viewPosition'];},'set':function(_0xe87fb6){const _0x400692=_0x4f9d16;this[_0x400692(0x15d)]=_0xe87fb6;}},'direction':{'get':function(){const _0x256fa4=_0x4f9d16;return this[_0x256fa4(0x16d)];},'set':function(_0x3da7dc){const _0x1b8da4=_0x4f9d16;this[_0x1b8da4(0x16d)]=_0x3da7dc,this[_0x1b8da4(0x155)]=!![];}},'pitch':{'get':function(){const _0x43724e=_0x4f9d16;return this[_0x43724e(0x13f)];},'set':function(_0x96979f){const _0x34c785=_0x4f9d16;this['_pitch']=_0x96979f,this[_0x34c785(0x155)]=!![];}},'horizontalFov':{'get':function(){const _0x2279df=_0x4f9d16;return this[_0x2279df(0x1b8)];},'set':function(_0x59afe8){const _0x36d227=_0x4f9d16;this[_0x36d227(0x1b8)]=_0x59afe8,this[_0x36d227(0x155)]=!![];}},'verticalFov':{'get':function(){const _0x53fdc5=_0x4f9d16;return this[_0x53fdc5(0x1ad)];},'set':function(_0x4c7946){const _0x44aa76=_0x4f9d16;this[_0x44aa76(0x1ad)]=_0x4c7946,this[_0x44aa76(0x155)]=!![];}},'distance':{'get':function(){const _0x38e8b9=_0x4f9d16;return this[_0x38e8b9(0x1a0)];},'set':function(_0x63dd3d){const _0x493c9c=_0x4f9d16;this[_0x493c9c(0x1a0)]=Math[_0x493c9c(0x1b6)](_0x63dd3d,0x0),this[_0x493c9c(0x155)]=!![];}}}),ViewShed3D['prototype'][_0x4f9d16(0x1c4)]=function(_0x10ce33){const _0x4d9ea7=_0x4f9d16;let _0x4dedeb=_0x10ce33[_0x4d9ea7(0x143)],_0x3977bc=this['_horizontalFov']*Cesium[_0x4d9ea7(0x1bc)][_0x4d9ea7(0x1a6)],_0x144663=this[_0x4d9ea7(0x1ad)]*Cesium[_0x4d9ea7(0x1bc)][_0x4d9ea7(0x1a6)],_0x31d2e5=Math[_0x4d9ea7(0x175)](_0x3977bc*0.5),_0xa57620=Math[_0x4d9ea7(0x175)](_0x144663*0.5),_0x568099=_0x31d2e5/_0xa57620,_0x39908b=this['_distance']*0.001,_0x1cb8bc=Math['max'](this[_0x4d9ea7(0x1a0)],0xa),_0x36751d=this[_0x4d9ea7(0x16d)]*Cesium[_0x4d9ea7(0x1bc)][_0x4d9ea7(0x1a6)],_0x25c56a=this['_pitch']*Cesium[_0x4d9ea7(0x1bc)][_0x4d9ea7(0x1a6)],_0x142b7b=Cesium['Cartesian3'][_0x4d9ea7(0x1a8)](this[_0x4d9ea7(0x15d)])[0x0],_0x34549d=_0x4dedeb[_0x4d9ea7(0x188)][_0x4d9ea7(0x14f)],_0x8475d8=_0x4dedeb[_0x4d9ea7(0x188)][_0x4d9ea7(0x166)],_0x1987f7=_0x4dedeb[_0x4d9ea7(0x188)][_0x4d9ea7(0x1c6)],_0x1dd286=_0x4dedeb[_0x4d9ea7(0x188)][_0x4d9ea7(0x189)],_0x337b45=new Cesium[(_0x4d9ea7(0x1be))](),_0x1b47a9=_0x4dedeb[_0x4d9ea7(0x195)],_0x1cdb50=_0x4dedeb['pitch'];Cesium['Cartesian3'][_0x4d9ea7(0x196)](_0x4dedeb[_0x4d9ea7(0x17a)],_0x337b45);let _0xa9ce07=_0x10ce33[_0x4d9ea7(0x186)],_0x2e53d9=this[_0x4d9ea7(0x1c9)][_0x4d9ea7(0x147)];this[_0x4d9ea7(0x1c5)][_0x4d9ea7(0x1b4)]=!![],this[_0x4d9ea7(0x1c5)][_0x4d9ea7(0x161)]=_0x5511c2=>{const _0x4a6a22=_0x4d9ea7;_0x5511c2[_0x4a6a22(0x186)]=![],_0x34549d=_0x4dedeb[_0x4a6a22(0x188)][_0x4a6a22(0x14f)],_0x8475d8=_0x4dedeb[_0x4a6a22(0x188)][_0x4a6a22(0x166)],_0x1987f7=_0x4dedeb[_0x4a6a22(0x188)][_0x4a6a22(0x1c6)],_0x1dd286=_0x4dedeb[_0x4a6a22(0x188)]['far'],_0x1b47a9=_0x4dedeb[_0x4a6a22(0x195)],_0x1cdb50=_0x4dedeb[_0x4a6a22(0x1b3)],Cesium['Cartesian3'][_0x4a6a22(0x196)](_0x4dedeb[_0x4a6a22(0x17a)],_0x337b45),_0x4dedeb[_0x4a6a22(0x188)][_0x4a6a22(0x14f)]=_0x568099,_0x4dedeb[_0x4a6a22(0x188)][_0x4a6a22(0x166)]=_0x3977bc,_0x4dedeb[_0x4a6a22(0x188)][_0x4a6a22(0x1c6)]=0x1,_0x4dedeb[_0x4a6a22(0x188)][_0x4a6a22(0x189)]=_0x1cb8bc+0x1,_0x4dedeb['setView']({'destination':_0x142b7b,'orientation':{'heading':_0x36751d,'pitch':_0x25c56a,'roll':_0x4dedeb['roll']}}),Cesium['Matrix4'][_0x4a6a22(0x176)](_0x4dedeb[_0x4a6a22(0x188)][_0x4a6a22(0x14b)],_0x4dedeb[_0x4a6a22(0x1bb)],this[_0x4a6a22(0x160)]),Cesium[_0x4a6a22(0x149)][_0x4a6a22(0x196)](_0x4dedeb[_0x4a6a22(0x187)],this[_0x4a6a22(0x18a)]),Cesium[_0x4a6a22(0x1be)][_0x4a6a22(0x196)](Cesium[_0x4a6a22(0x1be)][_0x4a6a22(0x18c)],this['boundingSphere'][_0x4a6a22(0x1b5)]),this[_0x4a6a22(0x16c)][_0x4a6a22(0x1b7)]=this[_0x4a6a22(0x1a0)],Cesium['BoundingSphere'][_0x4a6a22(0x148)](this[_0x4a6a22(0x16c)],this[_0x4a6a22(0x18a)],this[_0x4a6a22(0x16c)]);},this[_0x4d9ea7(0x1c5)][_0x4d9ea7(0x159)]=_0x4b52b4=>{const _0x167872=_0x4d9ea7;_0x4dedeb['setView']({'destination':_0x337b45,'orientation':{'heading':_0x1b47a9,'pitch':_0x1cdb50,'roll':_0x4dedeb[_0x167872(0x171)]},'convert':![]}),_0x4dedeb[_0x167872(0x188)][_0x167872(0x14f)]=_0x34549d,_0x4dedeb['frustum'][_0x167872(0x166)]=_0x8475d8,_0x4dedeb[_0x167872(0x188)]['near']=_0x1987f7,_0x4dedeb[_0x167872(0x188)][_0x167872(0x189)]=_0x1dd286,this[_0x167872(0x1c5)]['isUpdate']=![],_0x4b52b4[_0x167872(0x186)]=_0xa9ce07;},this[_0x4d9ea7(0x19f)][_0x4d9ea7(0x1b4)]=!![],this[_0x4d9ea7(0x19f)][_0x4d9ea7(0x161)]=_0x58b908=>{const _0x4f4522=_0x4d9ea7;_0x58b908[_0x4f4522(0x186)]=![],_0x4dedeb[_0x4f4522(0x188)][_0x4f4522(0x1c6)]=0xa,this['scene'][_0x4f4522(0x147)]=this[_0x4f4522(0x1c9)][_0x4f4522(0x17f)];},this[_0x4d9ea7(0x19f)][_0x4d9ea7(0x159)]=_0x56c035=>{const _0x4c0823=_0x4d9ea7;if(this[_0x4c0823(0x1c9)][_0x4c0823(0x1b0)][_0x4c0823(0x1a1)][_0x4c0823(0x193)]>0x0){let _0x59228c=this[_0x4c0823(0x1c9)]['view'][_0x4c0823(0x1a1)][0x0];_0x4dedeb['frustum']['near']=_0x59228c[_0x4c0823(0x1c6)],_0x4dedeb[_0x4c0823(0x188)][_0x4c0823(0x189)]=_0x59228c[_0x4c0823(0x189)];}let _0x439438=Cesium['Matrix4'][_0x4c0823(0x15b)](_0x4dedeb[_0x4c0823(0x188)][_0x4c0823(0x14b)],new Cesium[(_0x4c0823(0x149))]()),_0x4f9748=Cesium['Matrix4'][_0x4c0823(0x176)](_0x4dedeb[_0x4c0823(0x187)],_0x439438,new Cesium[(_0x4c0823(0x149))]());Cesium['Matrix4'][_0x4c0823(0x176)](this[_0x4c0823(0x160)],_0x4f9748,this[_0x4c0823(0x18f)]),_0x56c035[_0x4c0823(0x186)]=_0xa9ce07,this['scene'][_0x4c0823(0x147)]=_0x2e53d9,_0x4dedeb[_0x4c0823(0x188)][_0x4c0823(0x1c6)]=_0x1987f7,_0x4dedeb[_0x4c0823(0x188)][_0x4c0823(0x189)]=_0x1dd286;};};function createVertices(_0x2a1f05){const _0x4c1c8a=_0x4f9d16,_0x41bf9a=_0x2a1f05[_0x4c1c8a(0x14d)],_0x99a32d=_0x2a1f05[_0x4c1c8a(0x14d)]+0x1,_0x5d5089=_0x2a1f05[_0x4c1c8a(0x1a0)];let _0x37d302=_0x99a32d*_0x99a32d+0x1,_0x2eb697=Cesium[_0x4c1c8a(0x1c7)]['createTypedArray'](Cesium[_0x4c1c8a(0x1c7)][_0x4c1c8a(0x17d)],_0x37d302*0x3),_0x1aaeea=_0x2a1f05['_horizontalFov']*Cesium['Math']['RADIANS_PER_DEGREE'],_0x224b95=_0x2a1f05['_verticalFov']*Cesium[_0x4c1c8a(0x1bc)]['RADIANS_PER_DEGREE'],_0xb85268=Math[_0x4c1c8a(0x175)](_0x1aaeea*0.5),_0x4d014c=Math['tan'](_0x224b95*0.5),_0x170fb8=Math['PI']-_0x1aaeea*0.5,_0x1587a0=_0x5d5089*_0x4d014c,_0x4dea40=0x0,_0xc2f79=0x0,_0x287821=_0x1aaeea/_0x41bf9a,_0x335a9b=0x3;for(let _0x29eb57=0x0;_0x29eb57<_0x99a32d;_0x29eb57++){_0x4dea40=_0x170fb8+_0x29eb57*_0x287821;let _0x458fcc=_0x1587a0/(_0x5d5089/Math[_0x4c1c8a(0x167)](_0x4dea40)),_0x16539f=Math['atan'](_0x458fcc),_0x333655=-_0x16539f,_0x47fe7e=_0x16539f*0x2/_0x41bf9a;for(let _0x106fac=0x0;_0x106fac<_0x99a32d;_0x106fac++){_0xc2f79=_0x333655+_0x106fac*_0x47fe7e;let _0xc344b9=_0x5d5089*Math[_0x4c1c8a(0x167)](_0xc2f79)*Math[_0x4c1c8a(0x181)](_0x4dea40),_0x5b06e2=_0x5d5089*Math['sin'](_0xc2f79),_0x58ffeb=_0x5d5089*Math[_0x4c1c8a(0x167)](_0xc2f79)*Math['cos'](_0x4dea40);_0x2eb697[_0x335a9b++]=_0xc344b9,_0x2eb697[_0x335a9b++]=_0x5b06e2,_0x2eb697[_0x335a9b++]=_0x58ffeb;}}return _0x2eb697;}function createFaceIndices(_0x59e97f){const _0xe680d3=_0x4f9d16,_0x22c360=_0x59e97f[_0xe680d3(0x14d)],_0x2016e7=_0x22c360+0x1;let _0x29f6de=_0x22c360*_0x22c360*0x3*0x2+_0x22c360*0x3*0x4,_0x35b8e2=Cesium[_0xe680d3(0x1c7)][_0xe680d3(0x1b2)](Cesium[_0xe680d3(0x1c7)][_0xe680d3(0x198)],_0x29f6de),_0x4f3e40=0x0,_0x2e7233=0x1;for(let _0x165047=0x0;_0x165047<_0x22c360;_0x165047++){for(let _0x186c79=0x0;_0x186c79<_0x22c360;_0x186c79++){_0x35b8e2[_0x4f3e40++]=_0x2e7233+_0x165047+_0x186c79*_0x2016e7,_0x35b8e2[_0x4f3e40++]=_0x2e7233+_0x165047+0x1+_0x186c79*_0x2016e7,_0x35b8e2[_0x4f3e40++]=_0x2e7233+_0x165047+(_0x186c79+0x1)*_0x2016e7,_0x35b8e2[_0x4f3e40++]=_0x2e7233+_0x165047+0x1+_0x186c79*_0x2016e7,_0x35b8e2[_0x4f3e40++]=_0x2e7233+_0x165047+0x1+(_0x186c79+0x1)*_0x2016e7,_0x35b8e2[_0x4f3e40++]=_0x2e7233+_0x165047+(_0x186c79+0x1)*_0x2016e7;}}for(let _0x31f250=0x0;_0x31f250<_0x22c360;_0x31f250++){_0x35b8e2[_0x4f3e40++]=_0x31f250+0x1+_0x2e7233,_0x35b8e2[_0x4f3e40++]=_0x31f250+_0x2e7233,_0x35b8e2[_0x4f3e40++]=0x0,_0x35b8e2[_0x4f3e40++]=0x0,_0x35b8e2[_0x4f3e40++]=_0x31f250+_0x22c360*_0x2016e7+_0x2e7233,_0x35b8e2[_0x4f3e40++]=_0x31f250+0x1+_0x22c360*_0x2016e7+_0x2e7233;}for(let _0x1ae34b=0x0;_0x1ae34b<_0x22c360;_0x1ae34b++){_0x35b8e2[_0x4f3e40++]=0x0,_0x35b8e2[_0x4f3e40++]=_0x1ae34b*_0x2016e7+_0x2e7233,_0x35b8e2[_0x4f3e40++]=(_0x1ae34b+0x1)*_0x2016e7+_0x2e7233,_0x35b8e2[_0x4f3e40++]=_0x22c360+(_0x1ae34b+0x1)*_0x2016e7+_0x2e7233,_0x35b8e2[_0x4f3e40++]=_0x22c360+_0x1ae34b*_0x2016e7+_0x2e7233,_0x35b8e2[_0x4f3e40++]=0x0;}return _0x35b8e2;}function createLineIndices(_0x37cc90){const _0x154de9=_0x4f9d16,_0x44bc98=_0x37cc90[_0x154de9(0x14d)],_0xf0c5da=_0x44bc98+0x1,_0x57b19c=(0x4+_0x44bc98*0x5+_0x44bc98*0x2*0x3)*0x2;let _0x47bbc1=Cesium[_0x154de9(0x1c7)][_0x154de9(0x1b2)](Cesium[_0x154de9(0x1c7)][_0x154de9(0x198)],_0x57b19c),_0x5c428c=0x0;_0x47bbc1[_0x5c428c++]=0x0,_0x47bbc1[_0x5c428c++]=0x1,_0x47bbc1[_0x5c428c++]=0x0,_0x47bbc1[_0x5c428c++]=_0xf0c5da,_0x47bbc1[_0x5c428c++]=0x0,_0x47bbc1[_0x5c428c++]=_0x44bc98*_0xf0c5da+0x1,_0x47bbc1[_0x5c428c++]=0x0,_0x47bbc1[_0x5c428c++]=_0xf0c5da*_0xf0c5da;for(let _0x5a9967=0x0;_0x5a9967<0x5;_0x5a9967++){for(let _0x3f36a5=0x0;_0x3f36a5<_0x44bc98;_0x3f36a5++){_0x47bbc1[_0x5c428c++]=0x1+_0x3f36a5+_0xf0c5da*0x5*_0x5a9967,_0x47bbc1[_0x5c428c++]=0x1+(_0x3f36a5+0x1)+_0xf0c5da*0x5*_0x5a9967;}}for(let _0x47170c=0x0;_0x47170c<0x5;_0x47170c++){for(let _0x2202fc=0x0;_0x2202fc<_0x44bc98;_0x2202fc++){_0x47bbc1[_0x5c428c++]=0x1+_0xf0c5da*_0x2202fc+_0x47170c*0x5,_0x47bbc1[_0x5c428c++]=0x1+_0xf0c5da*(_0x2202fc+0x1)+_0x47170c*0x5;}}return _0x47bbc1;}ViewShed3D[_0x4f9d16(0x145)][_0x4f9d16(0x15a)]=function(_0x5f2572){const _0x3da3c5=_0x4f9d16;let _0x537ed1=createVertices(this),_0x5a296b=createFaceIndices(this),_0x4d196b=createLineIndices(this),_0x2d890d=_0x5f2572[_0x3da3c5(0x14c)],_0x5bd2a8=Cesium[_0x3da3c5(0x1ae)][_0x3da3c5(0x18d)]({'context':_0x2d890d,'typedArray':_0x537ed1,'usage':Cesium[_0x3da3c5(0x153)][_0x3da3c5(0x141)]}),_0x4accac=Cesium['Buffer'][_0x3da3c5(0x1af)]({'context':_0x2d890d,'typedArray':_0x5a296b,'usage':Cesium[_0x3da3c5(0x153)][_0x3da3c5(0x141)],'indexDatatype':Cesium[_0x3da3c5(0x162)][_0x3da3c5(0x198)]}),_0x59dfdb=[{'index':0x0,'vertexBuffer':_0x5bd2a8,'componentsPerAttribute':0x3,'componentDatatype':Cesium['ComponentDatatype'][_0x3da3c5(0x17d)],'offsetInBytes':0x0,'strideInBytes':0x3*0x4,'normalize':![]}],_0x1bd44a={'aPosition':0x0},_0x2b4465=new Cesium[(_0x3da3c5(0x158))]({'context':_0x2d890d,'attributes':_0x59dfdb,'indexBuffer':_0x4accac}),_0x3adb84=new Cesium[(_0x3da3c5(0x1aa))]({'sources':[_0x27a0be]}),_0x2bbb19=new Cesium['ShaderSource']({'sources':[_0x4b05a7]}),_0x49f86a=Cesium['ShaderProgram'][_0x3da3c5(0x15f)]({'context':_0x2d890d,'vertexShaderSource':_0x3adb84,'fragmentShaderSource':_0x2bbb19,'attributeLocations':_0x1bd44a}),_0x503bb5=Cesium[_0x3da3c5(0x16b)]['fromCache']({'cull':{'enabled':![]},'depthTest':{'enabled':![]},'depthMask':![],'stencilTest':{'enabled':!![],'frontFunction':Cesium[_0x3da3c5(0x1c3)][_0x3da3c5(0x1ac)],'frontOperation':{'fail':Cesium[_0x3da3c5(0x1c2)][_0x3da3c5(0x142)],'zFail':Cesium[_0x3da3c5(0x1c2)][_0x3da3c5(0x142)],'zPass':Cesium[_0x3da3c5(0x1c2)][_0x3da3c5(0x1ab)]},'backFunction':Cesium[_0x3da3c5(0x1c3)][_0x3da3c5(0x1ac)],'backOperation':{'fail':Cesium[_0x3da3c5(0x1c2)]['KEEP'],'zFail':Cesium[_0x3da3c5(0x1c2)][_0x3da3c5(0x142)],'zPass':Cesium[_0x3da3c5(0x1c2)][_0x3da3c5(0x1ab)]},'reference':0x0,'mask':~0x0},'blending':Cesium[_0x3da3c5(0x151)][_0x3da3c5(0x1bd)]});this[_0x3da3c5(0x172)]=new Cesium[(_0x3da3c5(0x16f))]({'primitiveType':Cesium['PrimitiveType']['TRIANGLES'],'modelMatrix':this[_0x3da3c5(0x18a)],'boundingVolume':this[_0x3da3c5(0x16c)],'pass':Cesium[_0x3da3c5(0x168)][_0x3da3c5(0x1a5)],'shaderProgram':_0x49f86a,'vertexArray':_0x2b4465,'renderState':_0x503bb5,'owner':this,'cull':!![]}),this['colorCommand']['uniformMap']={'uVisibleAreaColor':()=>{const _0x35c1db=_0x3da3c5;return this[_0x35c1db(0x19b)];},'uHiddenAreaColor':()=>{const _0x147c50=_0x3da3c5;return this[_0x147c50(0x174)];},'uRenderTextureMatrix':()=>{const _0x5a9f83=_0x3da3c5;return this[_0x5a9f83(0x18f)];},'uTextureSize':()=>{const _0x372f12=_0x3da3c5;let _0x52f40c=this[_0x372f12(0x1c5)][_0x372f12(0x14e)];return new Cesium['Cartesian2'](_0x52f40c[_0x372f12(0x1bf)],_0x52f40c[_0x372f12(0x146)]);},'uTexture':()=>{const _0x17ca9b=_0x3da3c5;return this[_0x17ca9b(0x1c5)][_0x17ca9b(0x14e)];},'uGlobalDepthTexture':()=>{const _0x4c120d=_0x3da3c5;return this[_0x4c120d(0x19f)][_0x4c120d(0x14e)];}};let _0x22d023=Cesium['DrawCommand'][_0x3da3c5(0x15e)](this[_0x3da3c5(0x172)]);_0x22d023[_0x3da3c5(0x192)]=Cesium[_0x3da3c5(0x16b)][_0x3da3c5(0x15f)]({'depthMask':![],'colorMask':{'red':![],'green':![],'blue':![],'alpha':![]},'depthTest':{'enabled':!![],'func':Cesium[_0x3da3c5(0x17e)]['GREATER']},'stencilTest':{'enabled':!![],'frontFunction':Cesium['StencilFunction'][_0x3da3c5(0x184)],'frontOperation':{'fail':Cesium[_0x3da3c5(0x1c2)][_0x3da3c5(0x142)],'zFail':Cesium[_0x3da3c5(0x1c2)][_0x3da3c5(0x142)],'zPass':Cesium[_0x3da3c5(0x1c2)][_0x3da3c5(0x1ce)]},'backFunction':Cesium[_0x3da3c5(0x1c3)][_0x3da3c5(0x184)],'backOperation':{'fail':Cesium[_0x3da3c5(0x1c2)]['KEEP'],'zFail':Cesium[_0x3da3c5(0x1c2)]['KEEP'],'zPass':Cesium[_0x3da3c5(0x1c2)][_0x3da3c5(0x1ab)]},'reference':0x0,'mask':~0x0}}),this[_0x3da3c5(0x16e)]=_0x22d023;let _0x22f5e3=Cesium[_0x3da3c5(0x1ae)][_0x3da3c5(0x1af)]({'context':_0x2d890d,'typedArray':_0x4d196b,'usage':Cesium[_0x3da3c5(0x153)][_0x3da3c5(0x141)],'indexDatatype':Cesium[_0x3da3c5(0x162)]['UNSIGNED_SHORT']});this[_0x3da3c5(0x19a)]=new Cesium['DrawCommand']({'primitiveType':Cesium['PrimitiveType'][_0x3da3c5(0x1cc)],'modelMatrix':this[_0x3da3c5(0x18a)],'boundingVolume':this[_0x3da3c5(0x16c)],'pass':Cesium[_0x3da3c5(0x168)][_0x3da3c5(0x1a5)],'owner':this,'cull':!![]}),this['lineCommand'][_0x3da3c5(0x1c1)]=new Cesium[(_0x3da3c5(0x158))]({'context':_0x2d890d,'attributes':_0x59dfdb,'indexBuffer':_0x22f5e3}),this['lineCommand'][_0x3da3c5(0x1a2)]=Cesium['ShaderProgram'][_0x3da3c5(0x15f)]({'context':_0x2d890d,'vertexShaderSource':_0x521c0a,'fragmentShaderSource':_0x2f5c96,'attributeLocations':_0x1bd44a}),this[_0x3da3c5(0x19a)]['renderState']=Cesium[_0x3da3c5(0x16b)][_0x3da3c5(0x15f)]({'cull':{'enabled':![]},'depthTest':{'enabled':!![]},'blending':Cesium[_0x3da3c5(0x151)][_0x3da3c5(0x1bd)]}),this[_0x3da3c5(0x19a)][_0x3da3c5(0x194)]={'uColor':()=>{const _0x4dd90d=_0x3da3c5;return this[_0x4dd90d(0x152)];}};},ViewShed3D[_0x4f9d16(0x145)][_0x4f9d16(0x19e)]=function(_0x226e59){const _0x276158=_0x4f9d16;let _0x5f4bfd=this[_0x276158(0x1c9)][_0x276158(0x143)],_0x2c641a=_0x5f4bfd['_projection'],_0xce4887=Cesium[_0x276158(0x1be)]['fromDegreesArrayHeights'](_0x226e59)[0x0],_0x396513=Cesium['Cartesian3'][_0x276158(0x1a8)](this['_viewPosition'])[0x0],_0x4779a8=new Cesium['Cartesian3']();Cesium[_0x276158(0x1be)][_0x276158(0x170)](_0xce4887,_0x396513,_0x4779a8);let _0x220677=Cesium[_0x276158(0x1be)][_0x276158(0x1a7)](_0x4779a8);Cesium['Cartesian3']['normalize'](_0x4779a8,_0x4779a8),this[_0x276158(0x165)]=_0x220677;let _0x210c5c=_0x5f4bfd[_0x276158(0x195)],_0x4e5814=_0x5f4bfd[_0x276158(0x1b3)],_0x5a2ab7=_0x5f4bfd['roll'],_0x15c59d=new Cesium['Cartesian3']();Cesium['Cartesian3'][_0x276158(0x196)](_0x5f4bfd[_0x276158(0x17a)],_0x15c59d);let _0x25d44e=_0x4779a8[_0x276158(0x196)](),_0x147252=_0x396513['clone']();_0x147252=Cesium[_0x276158(0x1be)][_0x276158(0x17c)](_0x147252,_0x147252);Math[_0x276158(0x163)](Cesium[_0x276158(0x1be)]['dot'](_0x147252,_0x25d44e))>=0x1&&(Math['abs'](Cesium[_0x276158(0x1be)][_0x276158(0x1a3)](_0x25d44e,Cesium['Cartesian3'][_0x276158(0x164)]))<0x1?_0x147252=Cesium[_0x276158(0x1be)]['clone'](Cartesian3[_0x276158(0x164)],_0x147252):_0x147252=Cesium[_0x276158(0x1be)]['clone'](Cartesian3['UNIT_Z'],_0x147252));let _0x432045=new Cesium[(_0x276158(0x1be))]();Cesium['Cartesian3'][_0x276158(0x19c)](_0x147252,_0x25d44e,_0x432045),_0x432045=Cesium[_0x276158(0x1be)][_0x276158(0x17c)](_0x432045,_0x432045),Cesium[_0x276158(0x1be)][_0x276158(0x19c)](_0x25d44e,_0x432045,_0x147252),_0x147252=Cesium[_0x276158(0x1be)][_0x276158(0x17c)](_0x147252,_0x147252),_0x5f4bfd['setView']({'destination':_0x396513,'orientation':{'direction':_0x25d44e,'up':_0x147252},'convert':![]}),this[_0x276158(0x1cd)]=_0x5f4bfd[_0x276158(0x195)]*Cesium[_0x276158(0x1bc)][_0x276158(0x185)],this['pitch']=_0x5f4bfd[_0x276158(0x1b3)]*Cesium[_0x276158(0x1bc)][_0x276158(0x185)],_0x5f4bfd[_0x276158(0x1ca)]({'destination':_0x15c59d,'orientation':{'heading':_0x210c5c,'pitch':_0x4e5814,'roll':_0x5a2ab7},'convert':![]});},ViewShed3D[_0x4f9d16(0x145)]['_destroyCommand']=function(){const _0xd3ff75=_0x4f9d16;this[_0xd3ff75(0x172)]&&(this[_0xd3ff75(0x172)][_0xd3ff75(0x1c1)]=this['colorCommand'][_0xd3ff75(0x1c1)]&&!this[_0xd3ff75(0x172)][_0xd3ff75(0x1c1)][_0xd3ff75(0x1cb)]()&&this[_0xd3ff75(0x172)][_0xd3ff75(0x1c1)][_0xd3ff75(0x1b1)](),this['colorCommand'][_0xd3ff75(0x1a2)]=this[_0xd3ff75(0x172)]['shaderProgram']&&!this[_0xd3ff75(0x172)][_0xd3ff75(0x1a2)]['isDestroyed']()&&this['colorCommand'][_0xd3ff75(0x1a2)][_0xd3ff75(0x1b1)](),this[_0xd3ff75(0x172)]=undefined),this[_0xd3ff75(0x16e)]&&(this[_0xd3ff75(0x16e)][_0xd3ff75(0x1c1)]=this['stencilCommand'][_0xd3ff75(0x1c1)]&&!this['stencilCommand'][_0xd3ff75(0x1c1)]['isDestroyed']()&&this[_0xd3ff75(0x16e)]['vertexArray'][_0xd3ff75(0x1b1)](),this[_0xd3ff75(0x16e)][_0xd3ff75(0x1a2)]=this[_0xd3ff75(0x16e)][_0xd3ff75(0x1a2)]&&!this['stencilCommand'][_0xd3ff75(0x1a2)]['isDestroyed']()&&this[_0xd3ff75(0x16e)]['shaderProgram'][_0xd3ff75(0x1b1)](),this['stencilCommand']=undefined),this[_0xd3ff75(0x19a)]&&(this[_0xd3ff75(0x19a)][_0xd3ff75(0x1c1)]=this[_0xd3ff75(0x19a)][_0xd3ff75(0x1c1)]&&!this['lineCommand'][_0xd3ff75(0x1c1)][_0xd3ff75(0x1cb)]()&&this[_0xd3ff75(0x19a)][_0xd3ff75(0x1c1)][_0xd3ff75(0x1b1)](),this[_0xd3ff75(0x19a)]['shaderProgram']=this[_0xd3ff75(0x19a)][_0xd3ff75(0x1a2)]&&!this[_0xd3ff75(0x19a)][_0xd3ff75(0x1a2)]['isDestroyed']()&&this[_0xd3ff75(0x19a)][_0xd3ff75(0x1a2)][_0xd3ff75(0x1b1)](),this[_0xd3ff75(0x19a)]=undefined);},ViewShed3D[_0x4f9d16(0x145)][_0x4f9d16(0x14a)]=function(_0x446f20){const _0x13ffd2=_0x4f9d16;if(_0x446f20[_0x13ffd2(0x173)]||_0x446f20[_0x13ffd2(0x144)][_0x13ffd2(0x1c0)]||_0x446f20[_0x13ffd2(0x144)][_0x13ffd2(0x183)])return;this[_0x13ffd2(0x155)]&&(this['dirty']=![],this[_0x13ffd2(0x150)](),this[_0x13ffd2(0x1c4)](_0x446f20),this[_0x13ffd2(0x15a)](_0x446f20)),this[_0x13ffd2(0x16e)]&&_0x446f20[_0x13ffd2(0x17b)][_0x13ffd2(0x182)](this['stencilCommand']),this['colorCommand']&&_0x446f20[_0x13ffd2(0x17b)][_0x13ffd2(0x182)](this[_0x13ffd2(0x172)]),this[_0x13ffd2(0x19a)]&&_0x446f20[_0x13ffd2(0x17b)][_0x13ffd2(0x182)](this['lineCommand']);},ViewShed3D['prototype'][_0x4f9d16(0x19d)]=function(){const _0x508166=_0x4f9d16;this[_0x508166(0x1c8)]='viewshed3d'+this[_0x508166(0x1c9)][_0x508166(0x197)]['length'],this['globalName']=this[_0x508166(0x1c8)]+_0x508166(0x180),this[_0x508166(0x1c9)][_0x508166(0x199)](this['name'],this[_0x508166(0x1c5)]),this[_0x508166(0x1c9)]['_setRenderTarget'](this[_0x508166(0x190)],this[_0x508166(0x19f)]),this[_0x508166(0x1c9)][_0x508166(0x18b)][_0x508166(0x1a9)](this);},ViewShed3D['prototype']['clear']=function(){const _0x3cfeb0=_0x4f9d16;this[_0x3cfeb0(0x1c9)][_0x3cfeb0(0x178)](this[_0x3cfeb0(0x1c8)]),this[_0x3cfeb0(0x1c9)][_0x3cfeb0(0x178)](this[_0x3cfeb0(0x190)]),this[_0x3cfeb0(0x1c9)][_0x3cfeb0(0x18b)][_0x3cfeb0(0x179)](this);},ViewShed3D[_0x4f9d16(0x145)][_0x4f9d16(0x1cb)]=function(){return ![];},ViewShed3D[_0x4f9d16(0x145)]['destroy']=function(){const _0x516707=_0x4f9d16;this[_0x516707(0x1c5)]=this['cameraDepthBuffer'][_0x516707(0x1b1)](),this[_0x516707(0x19f)]=this['globalDepthBuffer'][_0x516707(0x1b1)]();if(this[_0x516707(0x172)]){let _0x1d4be6=this['colorCommand'][_0x516707(0x1c1)],_0x5ad8ad=this[_0x516707(0x172)][_0x516707(0x1a2)];_0x1d4be6=_0x1d4be6&&!_0x1d4be6[_0x516707(0x1cb)]()&&_0x1d4be6['destroy'](),_0x5ad8ad=_0x5ad8ad&&!_0x5ad8ad['isDestroyed']()&&_0x5ad8ad[_0x516707(0x1b1)](),this[_0x516707(0x172)]=undefined;}if(this['stencilCommand']){let _0x1d9db7=this['stencilCommand']['vertexArray'],_0x2df174=this[_0x516707(0x16e)][_0x516707(0x1a2)];_0x1d9db7=_0x1d9db7&&!_0x1d9db7[_0x516707(0x1cb)]()&&_0x1d9db7[_0x516707(0x1b1)](),_0x2df174=_0x2df174&&!_0x2df174['isDestroyed']()&&_0x2df174[_0x516707(0x1b1)](),this[_0x516707(0x16e)]=undefined;}if(this[_0x516707(0x19a)]){let _0x4ac243=this[_0x516707(0x19a)][_0x516707(0x1c1)],_0x1caa23=this[_0x516707(0x19a)][_0x516707(0x1a2)];_0x4ac243=_0x4ac243&&!_0x4ac243[_0x516707(0x1cb)]()&&_0x4ac243[_0x516707(0x1b1)](),_0x1caa23=_0x1caa23&&!_0x1caa23[_0x516707(0x1cb)]()&&_0x1caa23[_0x516707(0x1b1)](),this[_0x516707(0x19a)]=undefined;}};

    const _0x312c=['1017931flicCj','70EtAsxW','localName','2991072eOTOKI','nextSibling','loadXML','namespaceURI','push','getElementsByTagNameNS','getChildValue','13PWUlVI','queryNodes','false','getElementsByTagName','queryNumericValue','toLowerCase','1TEFLsk','249087XdDNVr','1vgRHGK','read','prefix','queryFirstNode','length','xmldom','queryChildNodes','queryStringValue','text/xml','23767sgVkzV','570720MlUJSH','firstChild','getAttributeNodeNS','nodeType','11205MAJeoC','getAttribute','queryNumericAttribute','textContent','true','test','parseFromString','Microsoft.XMLDOM','nodeValue','childNodes','502739KsOXCF','queryBooleanValue','trim','indexOf','substring'];const _0x1f5d65=_0x1d6e;(function(_0x224835,_0x2c09b3){const _0x1bd954=_0x1d6e;while(!![]){try{const _0x4677c5=-parseInt(_0x1bd954(0x7f))+parseInt(_0x1bd954(0x9a))*parseInt(_0x1bd954(0x89))+parseInt(_0x1bd954(0x7a))*-parseInt(_0x1bd954(0x8f))+-parseInt(_0x1bd954(0x90))*-parseInt(_0x1bd954(0x91))+parseInt(_0x1bd954(0x9f))*-parseInt(_0x1bd954(0x80))+-parseInt(_0x1bd954(0x9b))+parseInt(_0x1bd954(0x82));if(_0x4677c5===_0x2c09b3)break;else _0x224835['push'](_0x224835['shift']());}catch(_0x4296ca){_0x224835['push'](_0x224835['shift']());}}}(_0x312c,0xa466e));function XMLParser(){}function _0x1d6e(_0x5216df,_0x2214a9){_0x5216df=_0x5216df-0x71;let _0x312c4a=_0x312c[_0x5216df];return _0x312c4a;}XMLParser[_0x1f5d65(0x92)]=function(_0x36b828){const _0x57d29b=_0x1f5d65;let _0x4bfff3=_0x36b828[_0x57d29b(0x7d)]('<');_0x4bfff3>0x0&&(_0x36b828=_0x36b828[_0x57d29b(0x7e)](_0x4bfff3));if(DOMParser)return !XMLParser[_0x57d29b(0x96)]&&(XMLParser['xmldom']=new DOMParser()),XMLParser[_0x57d29b(0x96)][_0x57d29b(0x76)](_0x36b828,_0x57d29b(0x99));return !XMLParser[_0x57d29b(0x96)]&&(XMLParser[_0x57d29b(0x96)]=new ActiveXObject(_0x57d29b(0x77))),XMLParser['xmldom'][_0x57d29b(0x84)](_0x36b828);},XMLParser['getElementsByTagNameNS']=function(_0x554c15,_0x140dac,_0x4d05d9){const _0x473c97=_0x1f5d65;let _0x135642=[];if(_0x554c15[_0x473c97(0x87)])_0x135642=_0x554c15['getElementsByTagNameNS'](_0x140dac,_0x4d05d9);else {let _0x543b3e=_0x554c15[_0x473c97(0x8c)]('*'),_0x1c967e,_0x5d7f54;for(let _0x315ea7=0x0,_0x5a5bc0=_0x543b3e[_0x473c97(0x95)];_0x315ea7<_0x5a5bc0;++_0x315ea7){_0x1c967e=_0x543b3e[_0x315ea7],_0x5d7f54=_0x1c967e[_0x473c97(0x93)]?_0x1c967e['prefix']+':'+_0x4d05d9:_0x4d05d9,(_0x4d05d9==='*'||_0x5d7f54===_0x1c967e['nodeName'])&&((_0x140dac==='*'||_0x140dac===_0x1c967e[_0x473c97(0x85)])&&_0x135642['push'](_0x1c967e));}}return _0x135642;},XMLParser[_0x1f5d65(0x9d)]=function(_0x1f0c47,_0x296f68,_0x49687d){const _0x252b82=_0x1f5d65;let _0x6d85bc=null;if(_0x1f0c47[_0x252b82(0x9d)])_0x6d85bc=_0x1f0c47['getAttributeNodeNS'](_0x296f68,_0x49687d);else {let _0x48905d=_0x1f0c47['attributes'],_0x4b4644,_0x45aeb9;for(let _0x21c8e4=0x0,_0x3545bc=_0x48905d[_0x252b82(0x95)];_0x21c8e4<_0x3545bc;++_0x21c8e4){_0x4b4644=_0x48905d[_0x21c8e4];if(_0x4b4644[_0x252b82(0x85)]===_0x296f68){_0x45aeb9=_0x4b4644[_0x252b82(0x93)]?_0x4b4644['prefix']+':'+_0x49687d:_0x49687d;if(_0x45aeb9===_0x4b4644['nodeName']){_0x6d85bc=_0x4b4644;break;}}}}return _0x6d85bc;},XMLParser[_0x1f5d65(0x88)]=function(_0x58542f,_0x1a88f6){const _0x10a915=_0x1f5d65;let _0x26b9e2=_0x1a88f6||'';if(_0x58542f)for(let _0x1e88a4=_0x58542f[_0x10a915(0x9c)];_0x1e88a4;_0x1e88a4=_0x1e88a4[_0x10a915(0x83)]){switch(_0x1e88a4[_0x10a915(0x9e)]){case 0x3:case 0x4:_0x26b9e2+=_0x1e88a4[_0x10a915(0x78)];}}return _0x26b9e2;},XMLParser[_0x1f5d65(0x72)]=function(_0x10ee60,_0x4f9c49){if(!_0x10ee60)return undefined;let _0xa1366c=_0x10ee60['getAttribute'](_0x4f9c49);if(_0xa1366c!==null){let _0x2b5a94=parseFloat(_0xa1366c);return !isNaN(_0x2b5a94)?_0x2b5a94:undefined;}return undefined;},XMLParser['queryStringAttribute']=function(_0x435e5d,_0x4ed7a9){if(!_0x435e5d)return undefined;let _0x5f4fdd=_0x435e5d['getAttribute'](_0x4ed7a9);return _0x5f4fdd!==null?_0x5f4fdd:undefined;},XMLParser['queryBooleanAttribute']=function(_0x11b535,_0x9f1138){const _0x1f5485=_0x1f5d65;if(!_0x11b535)return undefined;let _0x5a99b7=_0x11b535[_0x1f5485(0x71)](_0x9f1138);_0x5a99b7=_0x5a99b7[_0x1f5485(0x8e)]();if(_0x1f5485(0x8b)===_0x5a99b7)return ![];if(_0x1f5485(0x74)===_0x5a99b7)return !![];return undefined;},XMLParser['queryFirstNode']=function(_0x1e809e,_0x59213c,_0x4279a3){const _0xfa3ac8=_0x1f5d65;if(!_0x1e809e)return undefined;let _0x51a915=_0x1e809e[_0xfa3ac8(0x79)],_0x4432f2=_0x51a915[_0xfa3ac8(0x95)];for(let _0x5ccd5d=0x0;_0x5ccd5d<_0x4432f2;_0x5ccd5d++){let _0x9922b5=_0x51a915[_0x5ccd5d];if(_0x4279a3){if(_0x9922b5[_0xfa3ac8(0x81)]===_0x59213c&&_0x4279a3['indexOf'](_0x9922b5['namespaceURI'])!==-0x1)return _0x9922b5;}else {if(_0x9922b5[_0xfa3ac8(0x81)]===_0x59213c)return _0x9922b5;}}return undefined;},XMLParser[_0x1f5d65(0x8a)]=function(_0x500518,_0x477339,_0x3dcc10){const _0x44c499=_0x1f5d65;if(!_0x500518)return undefined;let _0xd2ada3=[],_0x1d1ec0=_0x500518[_0x44c499(0x87)]('*',_0x477339),_0x4b9c8c=_0x1d1ec0[_0x44c499(0x95)];for(let _0xa000ec=0x0;_0xa000ec<_0x4b9c8c;_0xa000ec++){let _0x360620=_0x1d1ec0[_0xa000ec];_0x3dcc10?_0x360620[_0x44c499(0x81)]===_0x477339&&_0x3dcc10[_0x44c499(0x7d)](_0x360620[_0x44c499(0x85)])!==-0x1&&_0xd2ada3[_0x44c499(0x86)](_0x360620):_0x360620['localName']===_0x477339&&_0xd2ada3['push'](_0x360620);}return _0xd2ada3;},XMLParser[_0x1f5d65(0x97)]=function(_0xa03ce7,_0x3be035,_0x3a2371){const _0x15aa1c=_0x1f5d65;if(!_0xa03ce7)return [];let _0x5971f4=[],_0x2622fc=_0xa03ce7[_0x15aa1c(0x79)],_0x309650=_0x2622fc['length'];for(let _0x24b329=0x0;_0x24b329<_0x309650;_0x24b329++){let _0x32cebf=_0x2622fc[_0x24b329];_0x3a2371?_0x32cebf['localName']===_0x3be035&&_0x3a2371[_0x15aa1c(0x7d)](_0x32cebf['namespaceURI'])!==-0x1&&_0x5971f4[_0x15aa1c(0x86)](_0x32cebf):_0x32cebf[_0x15aa1c(0x81)]===_0x3be035&&_0x5971f4[_0x15aa1c(0x86)](_0x32cebf);}return _0x5971f4;},XMLParser[_0x1f5d65(0x8d)]=function(_0x2a862b,_0x3dfb90,_0x9c0695){const _0x17a1d8=_0x1f5d65;let _0x134af5=XMLParser[_0x17a1d8(0x94)](_0x2a862b,_0x3dfb90,_0x9c0695);if(_0x134af5){let _0x12bb9c=parseFloat(_0x134af5[_0x17a1d8(0x73)]);return !isNaN(_0x12bb9c)?_0x12bb9c:undefined;}return undefined;},XMLParser[_0x1f5d65(0x98)]=function(_0x4d90c4,_0x416b95,_0x2401ca){const _0x58378f=_0x1f5d65;let _0x23d4db=XMLParser[_0x58378f(0x94)](_0x4d90c4,_0x416b95,_0x2401ca);if(_0x23d4db)return _0x23d4db[_0x58378f(0x73)]['trim']();return undefined;},XMLParser[_0x1f5d65(0x7b)]=function(_0x4491ab,_0x5cd5d3,_0x48433c){const _0x22f02a=_0x1f5d65;let _0x332a2e=XMLParser[_0x22f02a(0x94)](_0x4491ab,_0x5cd5d3,_0x48433c);if(_0x332a2e){let _0x1344af=_0x332a2e[_0x22f02a(0x73)][_0x22f02a(0x7c)]();return _0x1344af==='1'||/^true$/i[_0x22f02a(0x75)](_0x1344af);}return undefined;};

    const _0x14c7=['19462HjocCb','1PcKKDN','1641010gPsWgG','freeze','49466HVZpcc','82682HhkLPk','108761xdHVcv','232144JSBiQr','7LpSYli','5wfKtMX','23OPIbhx','2168579YjGLZH'];const _0x4bbec6=_0x3f3f;(function(_0x31b7eb,_0x4f04da){const _0x53f30c=_0x3f3f;while(!![]){try{const _0x2d8826=-parseInt(_0x53f30c(0x117))*-parseInt(_0x53f30c(0x120))+parseInt(_0x53f30c(0x119))+-parseInt(_0x53f30c(0x11d))*parseInt(_0x53f30c(0x11f))+-parseInt(_0x53f30c(0x11c))*parseInt(_0x53f30c(0x121))+-parseInt(_0x53f30c(0x11b))+-parseInt(_0x53f30c(0x11e))+parseInt(_0x53f30c(0x118))*parseInt(_0x53f30c(0x116));if(_0x2d8826===_0x4f04da)break;else _0x31b7eb['push'](_0x31b7eb['shift']());}catch(_0x2042ea){_0x31b7eb['push'](_0x31b7eb['shift']());}}}(_0x14c7,0xeaee4));function _0x3f3f(_0x1da686,_0x2f688a){_0x1da686=_0x1da686-0x116;let _0x14c7b2=_0x14c7[_0x1da686];return _0x14c7b2;}const FillStyle={'Fill':0x0,'WireFrame':0x1,'Fill_And_WireFrame':0x2};var _0x1b29d4 = Object[_0x4bbec6(0x11a)](FillStyle);

    const _0x3662=['3785EpPJVh','614257TUJrdj','1tiwSyG','1675951REDOiR','1hRfGvd','1013352fsKlxX','1094964HzpfKb','75CEWDlr','209068MLbAIp','400666pMNYUf','freeze','1KLFqeO'];const _0x442ebe=_0x2b4e;function _0x2b4e(_0x1ff0e7,_0x14374d){_0x1ff0e7=_0x1ff0e7-0xaf;let _0x36627f=_0x3662[_0x1ff0e7];return _0x36627f;}(function(_0x24accb,_0x432ed5){const _0x11983c=_0x2b4e;while(!![]){try{const _0x4636e6=-parseInt(_0x11983c(0xb5))+-parseInt(_0x11983c(0xb0))*-parseInt(_0x11983c(0xb1))+-parseInt(_0x11983c(0xb4))*-parseInt(_0x11983c(0xb7))+parseInt(_0x11983c(0xb2))+parseInt(_0x11983c(0xb9))*parseInt(_0x11983c(0xba))+parseInt(_0x11983c(0xb3))*-parseInt(_0x11983c(0xb8))+-parseInt(_0x11983c(0xaf));if(_0x4636e6===_0x432ed5)break;else _0x24accb['push'](_0x24accb['shift']());}catch(_0x449eb6){_0x24accb['push'](_0x24accb['shift']());}}}(_0x3662,0x8b70d));const BillboardMode={'None':0x0,'FixedZ':0x1,'FixedXYZ':0x2};var _0x46b65c = Object[_0x442ebe(0xb6)](BillboardMode);

    const _0x16b5=['752tctFNp','_lineColor','2318dURIar','_fillStyle','HeightReference','NONE','clone','385dtLgpw','_loadImage','_calloutColor','655757BOOipV','_lineWidth','_fillForeColor','defineProperties','459226aASipN','_pointSize','948968fTsDSc','line\x20color','_image','755fEawnp','number','484539fdmtNM','Color','Check','_bottomAltitude','typeOf','_billboardMode','_owner','RED','fillStyle\x20value','fillForeColor\x20value','bottomAltitude\x20value','_calloutWidth','324296gjoNyr','_emissionColor','point\x20size','line\x20width','object','altitudeMode\x20value','_imageReady','1GGFrDF','_pointColor','string','Fill','fillStyleChange','_altitudeMode','_dirty','SCREEN_ALIGNED','prototype','emission\x20color'];const _0x1499c8=_0x3e0d;(function(_0x479da3,_0x67745d){const _0x920d74=_0x3e0d;while(!![]){try{const _0x5970a6=-parseInt(_0x920d74(0x1d1))+parseInt(_0x920d74(0x1e2))+-parseInt(_0x920d74(0x1fa))*-parseInt(_0x920d74(0x1f5))+-parseInt(_0x920d74(0x1fd))*-parseInt(_0x920d74(0x1e9))+-parseInt(_0x920d74(0x1d6))+-parseInt(_0x920d74(0x201))+-parseInt(_0x920d74(0x1d4))*-parseInt(_0x920d74(0x1f3));if(_0x5970a6===_0x67745d)break;else _0x479da3['push'](_0x479da3['shift']());}catch(_0x1936e2){_0x479da3['push'](_0x479da3['shift']());}}}(_0x16b5,0x85ab6));function _0x3e0d(_0x9cba5a,_0x2bd9d2){_0x9cba5a=_0x9cba5a-0x1d0;let _0x16b591=_0x16b5[_0x9cba5a];return _0x16b591;}function Style3D(){const _0x216a6b=_0x3e0d;this[_0x216a6b(0x1ff)]=new Cesium[(_0x216a6b(0x1d7))](),this[_0x216a6b(0x1f6)]=_0x1b29d4[_0x216a6b(0x1ec)],this['_lineColor']=new Cesium[(_0x216a6b(0x1d7))](),this[_0x216a6b(0x1fe)]=0x1,this[_0x216a6b(0x1d9)]=0x0,this[_0x216a6b(0x1d0)]=0x1,this['_pointColor']=new Cesium[(_0x216a6b(0x1d7))](),this[_0x216a6b(0x1ee)]=Cesium[_0x216a6b(0x1f7)][_0x216a6b(0x1f8)],this['_emissionColor']=new Cesium['Color'](0x1,0x1,0x1,0x1),this[_0x216a6b(0x1dc)]=undefined,this[_0x216a6b(0x1ef)]=![],this[_0x216a6b(0x1d3)]=undefined,this[_0x216a6b(0x1e8)]=!![],this['_calloutColor']=Cesium[_0x216a6b(0x1d7)][_0x216a6b(0x1dd)],this[_0x216a6b(0x1e1)]=0x1,this[_0x216a6b(0x1db)]=_0x46b65c[_0x216a6b(0x1f0)];}Object[_0x1499c8(0x200)](Style3D[_0x1499c8(0x1f1)],{'fillForeColor':{'get':function(){const _0x5f53c2=_0x1499c8;return this[_0x5f53c2(0x1ff)];},'set':function(_0x148844){const _0x6a0fa1=_0x1499c8;Cesium[_0x6a0fa1(0x1d8)][_0x6a0fa1(0x1da)]['object'](_0x6a0fa1(0x1df),_0x148844),Cesium[_0x6a0fa1(0x1d7)][_0x6a0fa1(0x1f9)](_0x148844,this[_0x6a0fa1(0x1ff)]);}},'bottomAltitude':{'get':function(){const _0x1c3aa6=_0x1499c8;return this[_0x1c3aa6(0x1d9)];},'set':function(_0x3b9f54){const _0x3aedd5=_0x1499c8;Cesium[_0x3aedd5(0x1d8)][_0x3aedd5(0x1da)][_0x3aedd5(0x1d5)](_0x3aedd5(0x1e0),_0x3b9f54),this[_0x3aedd5(0x1d9)]!==_0x3b9f54&&(this[_0x3aedd5(0x1d9)]=_0x3b9f54,this['_dirty']=!![]);}},'altitudeMode':{'get':function(){const _0x17ff19=_0x1499c8;return this[_0x17ff19(0x1ee)];},'set':function(_0x2b50c8){const _0x2cda30=_0x1499c8;Cesium[_0x2cda30(0x1d8)]['typeOf']['number'](_0x2cda30(0x1e7),_0x2b50c8),this['_altitudeMode']=_0x2b50c8;}},'fillStyle':{'get':function(){const _0x20a177=_0x1499c8;return this[_0x20a177(0x1f6)];},'set':function(_0x4bdebf){const _0x4f9183=_0x1499c8;Cesium[_0x4f9183(0x1d8)][_0x4f9183(0x1da)][_0x4f9183(0x1d5)](_0x4f9183(0x1de),_0x4bdebf);let _0x65d76c=this[_0x4f9183(0x1f6)];this[_0x4f9183(0x1f6)]=_0x4bdebf,_0x4bdebf!==_0x65d76c&&this['_owner']&&this[_0x4f9183(0x1dc)][_0x4f9183(0x1ed)]();}},'lineColor':{'get':function(){const _0x11b5ee=_0x1499c8;return this[_0x11b5ee(0x1f4)];},'set':function(_0x478a2f){const _0x5b40c2=_0x1499c8;Cesium[_0x5b40c2(0x1d8)][_0x5b40c2(0x1da)][_0x5b40c2(0x1e6)](_0x5b40c2(0x1d2),_0x478a2f),Cesium[_0x5b40c2(0x1d7)][_0x5b40c2(0x1f9)](_0x478a2f,this[_0x5b40c2(0x1f4)]);}},'lineWidth':{'get':function(){return this['_lineWidth'];},'set':function(_0x40608b){const _0x367055=_0x1499c8;Cesium[_0x367055(0x1d8)]['typeOf'][_0x367055(0x1d5)](_0x367055(0x1e5),_0x40608b),this['_lineWidth']=_0x40608b;}},'pointSize':{'get':function(){return this['_pointSize'];},'set':function(_0x513455){const _0x3c319d=_0x1499c8;Cesium[_0x3c319d(0x1d8)][_0x3c319d(0x1da)]['number'](_0x3c319d(0x1e4),_0x513455),this[_0x3c319d(0x1d0)]=_0x513455;}},'pointColor':{'get':function(){const _0x170a51=_0x1499c8;return this[_0x170a51(0x1ea)];},'set':function(_0x2dcb3c){const _0x4438f3=_0x1499c8;Cesium['Check'][_0x4438f3(0x1da)][_0x4438f3(0x1e6)]('point\x20color',_0x2dcb3c),Cesium[_0x4438f3(0x1d7)]['clone'](_0x2dcb3c,this[_0x4438f3(0x1ea)]);}},'emissionColor':{'get':function(){const _0xaf49fc=_0x1499c8;return this[_0xaf49fc(0x1e3)];},'set':function(_0x14fa62){const _0x327a6d=_0x1499c8;Cesium['Check'][_0x327a6d(0x1da)][_0x327a6d(0x1e6)](_0x327a6d(0x1f2),_0x14fa62),Cesium[_0x327a6d(0x1d7)][_0x327a6d(0x1f9)](_0x14fa62,this[_0x327a6d(0x1e3)]);}},'image':{'get':function(){return this['_image'];},'set':function(_0x1f26bc){const _0x7c2ca9=_0x1499c8;this[_0x7c2ca9(0x1e8)]=![],this['_image']=_0x1f26bc,typeof _0x1f26bc===_0x7c2ca9(0x1eb)?this[_0x7c2ca9(0x1fb)]():this[_0x7c2ca9(0x1e8)]=!![];}},'imageReady':{'get':function(){const _0xcb4156=_0x1499c8;return this[_0xcb4156(0x1e8)];}},'calloutColor':{'get':function(){const _0x56d4f0=_0x1499c8;return this[_0x56d4f0(0x1fc)];},'set':function(_0x411144){const _0x5ecf90=_0x1499c8;this[_0x5ecf90(0x1fc)]!==_0x411144&&(this[_0x5ecf90(0x1fc)]=_0x411144);}},'calloutWidth':{'get':function(){const _0x39fa9d=_0x1499c8;return this[_0x39fa9d(0x1e1)];},'set':function(_0x44cb8a){const _0x2440cd=_0x1499c8;this['_calloutWidth']!==_0x44cb8a&&(this[_0x2440cd(0x1e1)]=_0x44cb8a);}},'billboardMode':{'get':function(){const _0x421b2a=_0x1499c8;return this[_0x421b2a(0x1db)];},'set':function(_0x52abcc){const _0x4b445d=_0x1499c8;this[_0x4b445d(0x1db)]!==_0x52abcc&&(this['_billboardMode']=_0x52abcc);}}});

    const _0xf3cc=['81uTGQtn','11cTnciL','741516yxRWaS','3020488OAiAQr','1244UEkUTL','14078OfYkVn','freeze','95WuZrqv','7oaFzMr','265673SAEWZF','7747rQDKQY','2029HytPik','678KkPNSG'];const _0x156890=_0x3772;function _0x3772(_0x47801f,_0x19e003){_0x47801f=_0x47801f-0x198;let _0xf3ccac=_0xf3cc[_0x47801f];return _0xf3ccac;}(function(_0x365765,_0x1f0d3a){const _0x154430=_0x3772;while(!![]){try{const _0x3c00b5=parseInt(_0x154430(0x19f))*parseInt(_0x154430(0x19d))+parseInt(_0x154430(0x1a2))*-parseInt(_0x154430(0x199))+-parseInt(_0x154430(0x19a))+-parseInt(_0x154430(0x1a4))*parseInt(_0x154430(0x19c))+-parseInt(_0x154430(0x198))*-parseInt(_0x154430(0x1a3))+parseInt(_0x154430(0x1a0))*-parseInt(_0x154430(0x1a1))+parseInt(_0x154430(0x19b));if(_0x3c00b5===_0x1f0d3a)break;else _0x365765['push'](_0x365765['shift']());}catch(_0x29a339){_0x365765['push'](_0x365765['shift']());}}}(_0xf3cc,0xf2473));const ContentState={'UNLOADED':0x0,'LOADING':0x1,'PARSING':0x2,'READY':0x3,'FAILED':0x4};var _0x1acc80 = Object[_0x156890(0x19e)](ContentState);

    const _0x21be=['703554KQOkjv','242659kesShe','2zxGQkH','32ahQzMx','1SZYPuN','363490sDANnX','1tQaLPP','399941dhFLqL','freeze','37115mGxlyY','240199AImste','23199KYKngJ'];const _0x5ec4d4=_0x1874;(function(_0x2c2779,_0x3bc80d){const _0x6324b7=_0x1874;while(!![]){try{const _0x524837=parseInt(_0x6324b7(0xfd))+parseInt(_0x6324b7(0xfe))*parseInt(_0x6324b7(0xf6))+-parseInt(_0x6324b7(0xff))*-parseInt(_0x6324b7(0xf9))+-parseInt(_0x6324b7(0xfc))+-parseInt(_0x6324b7(0xf8))+parseInt(_0x6324b7(0x101))*-parseInt(_0x6324b7(0x100))+-parseInt(_0x6324b7(0xfa))*parseInt(_0x6324b7(0xf7));if(_0x524837===_0x3bc80d)break;else _0x2c2779['push'](_0x2c2779['shift']());}catch(_0x5df370){_0x2c2779['push'](_0x2c2779['shift']());}}}(_0x21be,0x61b81));function _0x1874(_0x1ab5c7,_0x3aa896){_0x1ab5c7=_0x1ab5c7-0xf6;let _0x21bebd=_0x21be[_0x1ab5c7];return _0x21bebd;}const S3MPixelFormat={'LUMINANCE_8':0x1,'LUMINANCE_16':0x2,'ALPHA':0x3,'ALPHA_4_LUMINANCE_4':0x4,'LUMINANCE_ALPHA':0x5,'RGB_565':0x6,'BGR565':0x7,'RGB':0xa,'BGR':0xb,'ARGB':0xc,'ABGR':0xd,'BGRA':0xe,'WEBP':0x19,'RGBA':0x1c,'DXT1':0x11,'DXT2':0x12,'DXT3':0x13,'DXT4':0x14,'DXT5':0x15,'CRN_DXT5':0x1a,'STANDARD_CRN':0x1b};var _0xaa1cd8 = Object[_0x5ec4d4(0xfb)](S3MPixelFormat);

    const _0x9629=['2236WrioCo','644041ufgMRn','555KaUXbZ','1dnHqMx','290697VbZfjt','1jHFnrX','1pysvBy','928481BZdMIk','374867etiGAV','23935cXPxij','500751jVpxEY'];function _0x2ad6(_0x2cb863,_0x44deff){_0x2cb863=_0x2cb863-0x8d;let _0x962950=_0x9629[_0x2cb863];return _0x962950;}(function(_0x26463f,_0x264274){const _0x478173=_0x2ad6;while(!![]){try{const _0x16b83a=-parseInt(_0x478173(0x97))+-parseInt(_0x478173(0x91))+-parseInt(_0x478173(0x8e))*parseInt(_0x478173(0x96))+parseInt(_0x478173(0x94))+parseInt(_0x478173(0x93))*parseInt(_0x478173(0x8d))+-parseInt(_0x478173(0x95))*-parseInt(_0x478173(0x8f))+-parseInt(_0x478173(0x92))*-parseInt(_0x478173(0x90));if(_0x16b83a===_0x264274)break;else _0x26463f['push'](_0x26463f['shift']());}catch(_0x4a7777){_0x26463f['push'](_0x26463f['shift']());}}}(_0x9629,0xc5f56));const S3MCompressType={'encNONE':0x0,'enrS3TCDXTN':0xe,'enrPVRTPF_PVRTC2':0x13,'enrPVRTPF_PVRTC':0x14,'enrPVRTPF_PVRTC_4bpp':0x15,'enrPVRTPF_ETC1':0x16};var S3MCompressType$1 = Object['freeze'](S3MCompressType);

    const _0x374a=['9235KaFEoE','1MeUxiG','71IsoTAE','71ewOQdx','211151BNweVR','1AKIgua','558391GdIsli','17921gxbrXQ','11FCrZcR','128399CHEbSn','1435392IboBVb','1129705bRIZkr'];(function(_0x2417a8,_0x1080a0){const _0x53d795=_0x4ee3;while(!![]){try{const _0x32c92b=parseInt(_0x53d795(0x1f3))*-parseInt(_0x53d795(0x1ee))+-parseInt(_0x53d795(0x1f2))*-parseInt(_0x53d795(0x1f1))+parseInt(_0x53d795(0x1f7))+parseInt(_0x53d795(0x1ed))*parseInt(_0x53d795(0x1ef))+-parseInt(_0x53d795(0x1f4))*parseInt(_0x53d795(0x1f0))+-parseInt(_0x53d795(0x1f8))+-parseInt(_0x53d795(0x1f6))*-parseInt(_0x53d795(0x1f5));if(_0x32c92b===_0x1080a0)break;else _0x2417a8['push'](_0x2417a8['shift']());}catch(_0x13ff2c){_0x2417a8['push'](_0x2417a8['shift']());}}}(_0x374a,0xb81d2));function _0x4ee3(_0x45687e,_0x3dfb78){_0x45687e=_0x45687e-0x1ed;let _0x374af4=_0x374a[_0x45687e];return _0x374af4;}const VertexCompressOptions={'SVC_Vertex':0x1,'SVC_Normal':0x2,'SVC_VertexColor':0x4,'SVC_SecondColor':0x8,'SVC_TexutreCoord':0x10,'SVC_TexutreCoordIsW':0x20};var _0x6ea6a9 = Object['freeze'](VertexCompressOptions);

    var tmp = {};

    /* pako 1.0.4 nodeca/pako */(function(f){tmp = f();})(function(){return (function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r);}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){


        var TYPED_OK =  (typeof Uint8Array !== 'undefined') &&
                        (typeof Uint16Array !== 'undefined') &&
                        (typeof Int32Array !== 'undefined');


        exports.assign = function (obj /*from1, from2, from3, ...*/) {
            var sources = Array.prototype.slice.call(arguments, 1);
            while (sources.length) {
                var source = sources.shift();
                if (!source) { continue; }

                if (typeof source !== 'object') {
                    throw new TypeError(source + 'must be non-object');
                }

                for (var p in source) {
                    if (source.hasOwnProperty(p)) {
                        obj[p] = source[p];
                    }
                }
            }

            return obj;
        };


    // reduce buffer size, avoiding mem copy
        exports.shrinkBuf = function (buf, size) {
            if (buf.length === size) { return buf; }
            if (buf.subarray) { return buf.subarray(0, size); }
            buf.length = size;
            return buf;
        };


        var fnTyped = {
            arraySet: function (dest, src, src_offs, len, dest_offs) {
                if (src.subarray && dest.subarray) {
                    dest.set(src.subarray(src_offs, src_offs + len), dest_offs);
                    return;
                }
                // Fallback to ordinary array
                for (var i = 0; i < len; i++) {
                    dest[dest_offs + i] = src[src_offs + i];
                }
            },
            // Join array of chunks to single array.
            flattenChunks: function (chunks) {
                var i, l, len, pos, chunk, result;

                // calculate data length
                len = 0;
                for (i = 0, l = chunks.length; i < l; i++) {
                    len += chunks[i].length;
                }

                // join chunks
                result = new Uint8Array(len);
                pos = 0;
                for (i = 0, l = chunks.length; i < l; i++) {
                    chunk = chunks[i];
                    result.set(chunk, pos);
                    pos += chunk.length;
                }

                return result;
            }
        };

        var fnUntyped = {
            arraySet: function (dest, src, src_offs, len, dest_offs) {
                for (var i = 0; i < len; i++) {
                    dest[dest_offs + i] = src[src_offs + i];
                }
            },
            // Join array of chunks to single array.
            flattenChunks: function (chunks) {
                return [].concat.apply([], chunks);
            }
        };


    // Enable/Disable typed arrays use, for testing
    //
        exports.setTyped = function (on) {
            if (on) {
                exports.Buf8  = Uint8Array;
                exports.Buf16 = Uint16Array;
                exports.Buf32 = Int32Array;
                exports.assign(exports, fnTyped);
            } else {
                exports.Buf8  = Array;
                exports.Buf16 = Array;
                exports.Buf32 = Array;
                exports.assign(exports, fnUntyped);
            }
        };

        exports.setTyped(TYPED_OK);

    },{}],2:[function(require,module,exports){


        var utils = require('./common');


    // Quick check if we can use fast array to bin string conversion
    //
    // - apply(Array) can fail on Android 2.2
    // - apply(Uint8Array) can fail on iOS 5.1 Safary
    //
        var STR_APPLY_OK = true;
        var STR_APPLY_UIA_OK = true;

        try { String.fromCharCode.apply(null, [ 0 ]); } catch (__) { STR_APPLY_OK = false; }
        try { String.fromCharCode.apply(null, new Uint8Array(1)); } catch (__) { STR_APPLY_UIA_OK = false; }


    // Table with utf8 lengths (calculated by first byte of sequence)
    // Note, that 5 & 6-byte values and some 4-byte values can not be represented in JS,
    // because max possible codepoint is 0x10ffff
        var _utf8len = new utils.Buf8(256);
        for (var q = 0; q < 256; q++) {
            _utf8len[q] = (q >= 252 ? 6 : q >= 248 ? 5 : q >= 240 ? 4 : q >= 224 ? 3 : q >= 192 ? 2 : 1);
        }
        _utf8len[254] = _utf8len[254] = 1; // Invalid sequence start


    // convert string to array (typed, when possible)
        exports.string2buf = function (str) {
            var buf, c, c2, m_pos, i, str_len = str.length, buf_len = 0;

            // count binary size
            for (m_pos = 0; m_pos < str_len; m_pos++) {
                c = str.charCodeAt(m_pos);
                if ((c & 0xfc00) === 0xd800 && (m_pos + 1 < str_len)) {
                    c2 = str.charCodeAt(m_pos + 1);
                    if ((c2 & 0xfc00) === 0xdc00) {
                        c = 0x10000 + ((c - 0xd800) << 10) + (c2 - 0xdc00);
                        m_pos++;
                    }
                }
                buf_len += c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
            }

            // allocate buffer
            buf = new utils.Buf8(buf_len);

            // convert
            for (i = 0, m_pos = 0; i < buf_len; m_pos++) {
                c = str.charCodeAt(m_pos);
                if ((c & 0xfc00) === 0xd800 && (m_pos + 1 < str_len)) {
                    c2 = str.charCodeAt(m_pos + 1);
                    if ((c2 & 0xfc00) === 0xdc00) {
                        c = 0x10000 + ((c - 0xd800) << 10) + (c2 - 0xdc00);
                        m_pos++;
                    }
                }
                if (c < 0x80) {
                    /* one byte */
                    buf[i++] = c;
                } else if (c < 0x800) {
                    /* two bytes */
                    buf[i++] = 0xC0 | (c >>> 6);
                    buf[i++] = 0x80 | (c & 0x3f);
                } else if (c < 0x10000) {
                    /* three bytes */
                    buf[i++] = 0xE0 | (c >>> 12);
                    buf[i++] = 0x80 | (c >>> 6 & 0x3f);
                    buf[i++] = 0x80 | (c & 0x3f);
                } else {
                    /* four bytes */
                    buf[i++] = 0xf0 | (c >>> 18);
                    buf[i++] = 0x80 | (c >>> 12 & 0x3f);
                    buf[i++] = 0x80 | (c >>> 6 & 0x3f);
                    buf[i++] = 0x80 | (c & 0x3f);
                }
            }

            return buf;
        };

    // Helper (used in 2 places)
        function buf2binstring(buf, len) {
            // use fallback for big arrays to avoid stack overflow
            if (len < 65537) {
                if ((buf.subarray && STR_APPLY_UIA_OK) || (!buf.subarray && STR_APPLY_OK)) {
                    return String.fromCharCode.apply(null, utils.shrinkBuf(buf, len));
                }
            }

            var result = '';
            for (var i = 0; i < len; i++) {
                result += String.fromCharCode(buf[i]);
            }
            return result;
        }


    // Convert byte array to binary string
        exports.buf2binstring = function (buf) {
            return buf2binstring(buf, buf.length);
        };


    // Convert binary string (typed, when possible)
        exports.binstring2buf = function (str) {
            var buf = new utils.Buf8(str.length);
            for (var i = 0, len = buf.length; i < len; i++) {
                buf[i] = str.charCodeAt(i);
            }
            return buf;
        };


    // convert array to string
        exports.buf2string = function (buf, max) {
            var i, out, c, c_len;
            var len = max || buf.length;

            // Reserve max possible length (2 words per char)
            // NB: by unknown reasons, Array is significantly faster for
            //     String.fromCharCode.apply than Uint16Array.
            var utf16buf = new Array(len * 2);

            for (out = 0, i = 0; i < len;) {
                c = buf[i++];
                // quick process ascii
                if (c < 0x80) { utf16buf[out++] = c; continue; }

                c_len = _utf8len[c];
                // skip 5 & 6 byte codes
                if (c_len > 4) { utf16buf[out++] = 0xfffd; i += c_len - 1; continue; }

                // apply mask on first byte
                c &= c_len === 2 ? 0x1f : c_len === 3 ? 0x0f : 0x07;
                // join the rest
                while (c_len > 1 && i < len) {
                    c = (c << 6) | (buf[i++] & 0x3f);
                    c_len--;
                }

                // terminated by end of string?
                if (c_len > 1) { utf16buf[out++] = 0xfffd; continue; }

                if (c < 0x10000) {
                    utf16buf[out++] = c;
                } else {
                    c -= 0x10000;
                    utf16buf[out++] = 0xd800 | ((c >> 10) & 0x3ff);
                    utf16buf[out++] = 0xdc00 | (c & 0x3ff);
                }
            }

            return buf2binstring(utf16buf, out);
        };


    // Calculate max possible position in utf8 buffer,
    // that will not break sequence. If that's not possible
    // - (very small limits) return max size as is.
    //
    // buf[] - utf8 bytes array
    // max   - length limit (mandatory);
        exports.utf8border = function (buf, max) {
            var pos;

            max = max || buf.length;
            if (max > buf.length) { max = buf.length; }

            // go back from last position, until start of sequence found
            pos = max - 1;
            while (pos >= 0 && (buf[pos] & 0xC0) === 0x80) { pos--; }

            // Fuckup - very small and broken sequence,
            // return max, because we should return something anyway.
            if (pos < 0) { return max; }

            // If we came to start of buffer - that means vuffer is too small,
            // return max too.
            if (pos === 0) { return max; }

            return (pos + _utf8len[buf[pos]] > max) ? pos : max;
        };

    },{"./common":1}],3:[function(require,module,exports){

    // Note: adler32 takes 12% for level 0 and 2% for level 6.
    // It doesn't worth to make additional optimizationa as in original.
    // Small size is preferable.

        function adler32(adler, buf, len, pos) {
            var s1 = (adler & 0xffff) |0,
                s2 = ((adler >>> 16) & 0xffff) |0,
                n = 0;

            while (len !== 0) {
                // Set limit ~ twice less than 5552, to keep
                // s2 in 31-bits, because we force signed ints.
                // in other case %= will fail.
                n = len > 2000 ? 2000 : len;
                len -= n;

                do {
                    s1 = (s1 + buf[pos++]) |0;
                    s2 = (s2 + s1) |0;
                } while (--n);

                s1 %= 65521;
                s2 %= 65521;
            }

            return (s1 | (s2 << 16)) |0;
        }


        module.exports = adler32;

    },{}],4:[function(require,module,exports){


        module.exports = {

            /* Allowed flush values; see deflate() and inflate() below for details */
            Z_NO_FLUSH:         0,
            Z_PARTIAL_FLUSH:    1,
            Z_SYNC_FLUSH:       2,
            Z_FULL_FLUSH:       3,
            Z_FINISH:           4,
            Z_BLOCK:            5,
            Z_TREES:            6,

            /* Return codes for the compression/decompression functions. Negative values
             * are errors, positive values are used for special but normal events.
             */
            Z_OK:               0,
            Z_STREAM_END:       1,
            Z_NEED_DICT:        2,
            Z_ERRNO:           -1,
            Z_STREAM_ERROR:    -2,
            Z_DATA_ERROR:      -3,
            //Z_MEM_ERROR:     -4,
            Z_BUF_ERROR:       -5,
            //Z_VERSION_ERROR: -6,

            /* compression levels */
            Z_NO_COMPRESSION:         0,
            Z_BEST_SPEED:             1,
            Z_BEST_COMPRESSION:       9,
            Z_DEFAULT_COMPRESSION:   -1,


            Z_FILTERED:               1,
            Z_HUFFMAN_ONLY:           2,
            Z_RLE:                    3,
            Z_FIXED:                  4,
            Z_DEFAULT_STRATEGY:       0,

            /* Possible values of the data_type field (though see inflate()) */
            Z_BINARY:                 0,
            Z_TEXT:                   1,
            //Z_ASCII:                1, // = Z_TEXT (deprecated)
            Z_UNKNOWN:                2,

            /* The deflate compression method */
            Z_DEFLATED:               8
            //Z_NULL:                 null // Use -1 or null inline, depending on var type
        };

    },{}],5:[function(require,module,exports){

    // Note: we can't get significant speed boost here.
    // So write code to minimize size - no pregenerated tables
    // and array tools dependencies.


    // Use ordinary array, since untyped makes no boost here
        function makeTable() {
            var c, table = [];

            for (var n = 0; n < 256; n++) {
                c = n;
                for (var k = 0; k < 8; k++) {
                    c = ((c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1));
                }
                table[n] = c;
            }

            return table;
        }

    // Create table on load. Just 255 signed longs. Not a problem.
        var crcTable = makeTable();


        function crc32(crc, buf, len, pos) {
            var t = crcTable,
                end = pos + len;

            crc ^= -1;

            for (var i = pos; i < end; i++) {
                crc = (crc >>> 8) ^ t[(crc ^ buf[i]) & 0xFF];
            }

            return (crc ^ (-1)); // >>> 0;
        }


        module.exports = crc32;

    },{}],6:[function(require,module,exports){


        function GZheader() {
            /* true if compressed data believed to be text */
            this.text       = 0;
            /* modification time */
            this.time       = 0;
            /* extra flags (not used when writing a gzip file) */
            this.xflags     = 0;
            /* operating system */
            this.os         = 0;
            /* pointer to extra field or Z_NULL if none */
            this.extra      = null;
            /* extra field length (valid if extra != Z_NULL) */
            this.extra_len  = 0; // Actually, we don't need it in JS,
                                 // but leave for few code modifications

            //
            // Setup limits is not necessary because in js we should not preallocate memory
            // for inflate use constant limit in 65536 bytes
            //

            /* space at extra (only when reading header) */
            // this.extra_max  = 0;
            /* pointer to zero-terminated file name or Z_NULL */
            this.name       = '';
            /* space at name (only when reading header) */
            // this.name_max   = 0;
            /* pointer to zero-terminated comment or Z_NULL */
            this.comment    = '';
            /* space at comment (only when reading header) */
            // this.comm_max   = 0;
            /* true if there was or will be a header crc */
            this.hcrc       = 0;
            /* true when done reading gzip header (not used when writing a gzip file) */
            this.done       = false;
        }

        module.exports = GZheader;

    },{}],7:[function(require,module,exports){

    // See state defs from inflate.js
        var BAD = 30;       /* got a data error -- remain here until reset */
        var TYPE = 12;      /* i: waiting for type bits, including last-flag bit */

        /*
         Decode literal, length, and distance codes and write out the resulting
         literal and match bytes until either not enough input or output is
         available, an end-of-block is encountered, or a data error is encountered.
         When large enough input and output buffers are supplied to inflate(), for
         example, a 16K input buffer and a 64K output buffer, more than 95% of the
         inflate execution time is spent in this routine.

         Entry assumptions:

         state.mode === LEN
         strm.avail_in >= 6
         strm.avail_out >= 258
         start >= strm.avail_out
         state.bits < 8

         On return, state.mode is one of:

         LEN -- ran out of enough output space or enough available input
         TYPE -- reached end of block code, inflate() to interpret next block
         BAD -- error in block data

         Notes:

         - The maximum input bits used by a length/distance pair is 15 bits for the
         length code, 5 bits for the length extra, 15 bits for the distance code,
         and 13 bits for the distance extra.  This totals 48 bits, or six bytes.
         Therefore if strm.avail_in >= 6, then there is enough input to avoid
         checking for available input while decoding.

         - The maximum bytes that a single length/distance pair can output is 258
         bytes, which is the maximum length that can be coded.  inflate_fast()
         requires strm.avail_out >= 258 for each loop to avoid checking for
         output space.
         */
        module.exports = function inflate_fast(strm, start) {
            var state;
            var _in;                    /* local strm.input */
            var last;                   /* have enough input while in < last */
            var _out;                   /* local strm.output */
            var beg;                    /* inflate()'s initial strm.output */
            var end;                    /* while out < end, enough space available */
    //#ifdef INFLATE_STRICT
            var dmax;                   /* maximum distance from zlib header */
    //#endif
            var wsize;                  /* window size or zero if not using window */
            var whave;                  /* valid bytes in the window */
            var wnext;                  /* window write index */
            // Use `s_window` instead `window`, avoid conflict with instrumentation tools
            var s_window;               /* allocated sliding window, if wsize != 0 */
            var hold;                   /* local strm.hold */
            var bits;                   /* local strm.bits */
            var lcode;                  /* local strm.lencode */
            var dcode;                  /* local strm.distcode */
            var lmask;                  /* mask for first level of length codes */
            var dmask;                  /* mask for first level of distance codes */
            var here;                   /* retrieved table entry */
            var op;                     /* code bits, operation, extra bits, or */
            /*  window position, window bytes to copy */
            var len;                    /* match length, unused bytes */
            var dist;                   /* match distance */
            var from;                   /* where to copy match from */
            var from_source;


            var input, output; // JS specific, because we have no pointers

            /* copy state to local variables */
            state = strm.state;
            //here = state.here;
            _in = strm.next_in;
            input = strm.input;
            last = _in + (strm.avail_in - 5);
            _out = strm.next_out;
            output = strm.output;
            beg = _out - (start - strm.avail_out);
            end = _out + (strm.avail_out - 257);
    //#ifdef INFLATE_STRICT
            dmax = state.dmax;
    //#endif
            wsize = state.wsize;
            whave = state.whave;
            wnext = state.wnext;
            s_window = state.window;
            hold = state.hold;
            bits = state.bits;
            lcode = state.lencode;
            dcode = state.distcode;
            lmask = (1 << state.lenbits) - 1;
            dmask = (1 << state.distbits) - 1;


            /* decode literals and length/distances until end-of-block or not enough
             input data or output space */

            top:
                do {
                    if (bits < 15) {
                        hold += input[_in++] << bits;
                        bits += 8;
                        hold += input[_in++] << bits;
                        bits += 8;
                    }

                    here = lcode[hold & lmask];

                    dolen:
                        for (;;) { // Goto emulation
                            op = here >>> 24/*here.bits*/;
                            hold >>>= op;
                            bits -= op;
                            op = (here >>> 16) & 0xff/*here.op*/;
                            if (op === 0) {                          /* literal */
                                //Tracevv((stderr, here.val >= 0x20 && here.val < 0x7f ?
                                //        "inflate:         literal '%c'\n" :
                                //        "inflate:         literal 0x%02x\n", here.val));
                                output[_out++] = here & 0xffff/*here.val*/;
                            }
                            else if (op & 16) {                     /* length base */
                                len = here & 0xffff/*here.val*/;
                                op &= 15;                           /* number of extra bits */
                                if (op) {
                                    if (bits < op) {
                                        hold += input[_in++] << bits;
                                        bits += 8;
                                    }
                                    len += hold & ((1 << op) - 1);
                                    hold >>>= op;
                                    bits -= op;
                                }
                                //Tracevv((stderr, "inflate:         length %u\n", len));
                                if (bits < 15) {
                                    hold += input[_in++] << bits;
                                    bits += 8;
                                    hold += input[_in++] << bits;
                                    bits += 8;
                                }
                                here = dcode[hold & dmask];

                                dodist:
                                    for (;;) { // goto emulation
                                        op = here >>> 24/*here.bits*/;
                                        hold >>>= op;
                                        bits -= op;
                                        op = (here >>> 16) & 0xff/*here.op*/;

                                        if (op & 16) {                      /* distance base */
                                            dist = here & 0xffff/*here.val*/;
                                            op &= 15;                       /* number of extra bits */
                                            if (bits < op) {
                                                hold += input[_in++] << bits;
                                                bits += 8;
                                                if (bits < op) {
                                                    hold += input[_in++] << bits;
                                                    bits += 8;
                                                }
                                            }
                                            dist += hold & ((1 << op) - 1);
    //#ifdef INFLATE_STRICT
                                            if (dist > dmax) {
                                                strm.msg = 'invalid distance too far back';
                                                state.mode = BAD;
                                                break top;
                                            }
    //#endif
                                            hold >>>= op;
                                            bits -= op;
                                            //Tracevv((stderr, "inflate:         distance %u\n", dist));
                                            op = _out - beg;                /* max distance in output */
                                            if (dist > op) {                /* see if copy from window */
                                                op = dist - op;               /* distance back in window */
                                                if (op > whave) {
                                                    if (state.sane) {
                                                        strm.msg = 'invalid distance too far back';
                                                        state.mode = BAD;
                                                        break top;
                                                    }

    // (!) This block is disabled in zlib defailts,
    // don't enable it for binary compatibility
    //#ifdef INFLATE_ALLOW_INVALID_DISTANCE_TOOFAR_ARRR
    //                if (len <= op - whave) {
    //                  do {
    //                    output[_out++] = 0;
    //                  } while (--len);
    //                  continue top;
    //                }
    //                len -= op - whave;
    //                do {
    //                  output[_out++] = 0;
    //                } while (--op > whave);
    //                if (op === 0) {
    //                  from = _out - dist;
    //                  do {
    //                    output[_out++] = output[from++];
    //                  } while (--len);
    //                  continue top;
    //                }
    //#endif
                                                }
                                                from = 0; // window index
                                                from_source = s_window;
                                                if (wnext === 0) {           /* very common case */
                                                    from += wsize - op;
                                                    if (op < len) {         /* some from window */
                                                        len -= op;
                                                        do {
                                                            output[_out++] = s_window[from++];
                                                        } while (--op);
                                                        from = _out - dist;  /* rest from output */
                                                        from_source = output;
                                                    }
                                                }
                                                else if (wnext < op) {      /* wrap around window */
                                                    from += wsize + wnext - op;
                                                    op -= wnext;
                                                    if (op < len) {         /* some from end of window */
                                                        len -= op;
                                                        do {
                                                            output[_out++] = s_window[from++];
                                                        } while (--op);
                                                        from = 0;
                                                        if (wnext < len) {  /* some from start of window */
                                                            op = wnext;
                                                            len -= op;
                                                            do {
                                                                output[_out++] = s_window[from++];
                                                            } while (--op);
                                                            from = _out - dist;      /* rest from output */
                                                            from_source = output;
                                                        }
                                                    }
                                                }
                                                else {                      /* contiguous in window */
                                                    from += wnext - op;
                                                    if (op < len) {         /* some from window */
                                                        len -= op;
                                                        do {
                                                            output[_out++] = s_window[from++];
                                                        } while (--op);
                                                        from = _out - dist;  /* rest from output */
                                                        from_source = output;
                                                    }
                                                }
                                                while (len > 2) {
                                                    output[_out++] = from_source[from++];
                                                    output[_out++] = from_source[from++];
                                                    output[_out++] = from_source[from++];
                                                    len -= 3;
                                                }
                                                if (len) {
                                                    output[_out++] = from_source[from++];
                                                    if (len > 1) {
                                                        output[_out++] = from_source[from++];
                                                    }
                                                }
                                            }
                                            else {
                                                from = _out - dist;          /* copy direct from output */
                                                do {                        /* minimum length is three */
                                                    output[_out++] = output[from++];
                                                    output[_out++] = output[from++];
                                                    output[_out++] = output[from++];
                                                    len -= 3;
                                                } while (len > 2);
                                                if (len) {
                                                    output[_out++] = output[from++];
                                                    if (len > 1) {
                                                        output[_out++] = output[from++];
                                                    }
                                                }
                                            }
                                        }
                                        else if ((op & 64) === 0) {          /* 2nd level distance code */
                                            here = dcode[(here & 0xffff)/*here.val*/ + (hold & ((1 << op) - 1))];
                                            continue dodist;
                                        }
                                        else {
                                            strm.msg = 'invalid distance code';
                                            state.mode = BAD;
                                            break top;
                                        }

                                        break; // need to emulate goto via "continue"
                                    }
                            }
                            else if ((op & 64) === 0) {              /* 2nd level length code */
                                here = lcode[(here & 0xffff)/*here.val*/ + (hold & ((1 << op) - 1))];
                                continue dolen;
                            }
                            else if (op & 32) {                     /* end-of-block */
                                //Tracevv((stderr, "inflate:         end of block\n"));
                                state.mode = TYPE;
                                break top;
                            }
                            else {
                                strm.msg = 'invalid literal/length code';
                                state.mode = BAD;
                                break top;
                            }

                            break; // need to emulate goto via "continue"
                        }
                } while (_in < last && _out < end);

            /* return unused bytes (on entry, bits < 8, so in won't go too far back) */
            len = bits >> 3;
            _in -= len;
            bits -= len << 3;
            hold &= (1 << bits) - 1;

            /* update state and return */
            strm.next_in = _in;
            strm.next_out = _out;
            strm.avail_in = (_in < last ? 5 + (last - _in) : 5 - (_in - last));
            strm.avail_out = (_out < end ? 257 + (end - _out) : 257 - (_out - end));
            state.hold = hold;
            state.bits = bits;
            return;
        };

    },{}],8:[function(require,module,exports){


        var utils         = require('../utils/common');
        var adler32       = require('./adler32');
        var crc32         = require('./crc32');
        var inflate_fast  = require('./inffast');
        var inflate_table = require('./inftrees');

        var CODES = 0;
        var LENS = 1;
        var DISTS = 2;

        /* Public constants ==========================================================*/
        /* ===========================================================================*/


        /* Allowed flush values; see deflate() and inflate() below for details */
    //var Z_NO_FLUSH      = 0;
    //var Z_PARTIAL_FLUSH = 1;
    //var Z_SYNC_FLUSH    = 2;
    //var Z_FULL_FLUSH    = 3;
        var Z_FINISH        = 4;
        var Z_BLOCK         = 5;
        var Z_TREES         = 6;


        /* Return codes for the compression/decompression functions. Negative values
         * are errors, positive values are used for special but normal events.
         */
        var Z_OK            = 0;
        var Z_STREAM_END    = 1;
        var Z_NEED_DICT     = 2;
    //var Z_ERRNO         = -1;
        var Z_STREAM_ERROR  = -2;
        var Z_DATA_ERROR    = -3;
        var Z_MEM_ERROR     = -4;
        var Z_BUF_ERROR     = -5;
    //var Z_VERSION_ERROR = -6;

        /* The deflate compression method */
        var Z_DEFLATED  = 8;


        /* STATES ====================================================================*/
        /* ===========================================================================*/


        var    HEAD = 1;       /* i: waiting for magic header */
        var    FLAGS = 2;      /* i: waiting for method and flags (gzip) */
        var    TIME = 3;       /* i: waiting for modification time (gzip) */
        var    OS = 4;         /* i: waiting for extra flags and operating system (gzip) */
        var    EXLEN = 5;      /* i: waiting for extra length (gzip) */
        var    EXTRA = 6;      /* i: waiting for extra bytes (gzip) */
        var    NAME = 7;       /* i: waiting for end of file name (gzip) */
        var    COMMENT = 8;    /* i: waiting for end of comment (gzip) */
        var    HCRC = 9;       /* i: waiting for header crc (gzip) */
        var    DICTID = 10;    /* i: waiting for dictionary check value */
        var    DICT = 11;      /* waiting for inflateSetDictionary() call */
        var        TYPE = 12;      /* i: waiting for type bits, including last-flag bit */
        var        TYPEDO = 13;    /* i: same, but skip check to exit inflate on new block */
        var        STORED = 14;    /* i: waiting for stored size (length and complement) */
        var        COPY_ = 15;     /* i/o: same as COPY below, but only first time in */
        var        COPY = 16;      /* i/o: waiting for input or output to copy stored block */
        var        TABLE = 17;     /* i: waiting for dynamic block table lengths */
        var        LENLENS = 18;   /* i: waiting for code length code lengths */
        var        CODELENS = 19;  /* i: waiting for length/lit and distance code lengths */
        var            LEN_ = 20;      /* i: same as LEN below, but only first time in */
        var            LEN = 21;       /* i: waiting for length/lit/eob code */
        var            LENEXT = 22;    /* i: waiting for length extra bits */
        var            DIST = 23;      /* i: waiting for distance code */
        var            DISTEXT = 24;   /* i: waiting for distance extra bits */
        var            MATCH = 25;     /* o: waiting for output space to copy string */
        var            LIT = 26;       /* o: waiting for output space to write literal */
        var    CHECK = 27;     /* i: waiting for 32-bit check value */
        var    LENGTH = 28;    /* i: waiting for 32-bit length (gzip) */
        var    DONE = 29;      /* finished check, done -- remain here until reset */
        var    BAD = 30;       /* got a data error -- remain here until reset */
        var    MEM = 31;       /* got an inflate() memory error -- remain here until reset */
        var    SYNC = 32;      /* looking for synchronization bytes to restart inflate() */

        /* ===========================================================================*/



        var ENOUGH_LENS = 852;
        var ENOUGH_DISTS = 592;
    //var ENOUGH =  (ENOUGH_LENS+ENOUGH_DISTS);

        var MAX_WBITS = 15;
        /* 32K LZ77 window */
        var DEF_WBITS = MAX_WBITS;


        function zswap32(q) {
            return  (((q >>> 24) & 0xff) +
                     ((q >>> 8) & 0xff00) +
                     ((q & 0xff00) << 8) +
                     ((q & 0xff) << 24));
        }


        function InflateState() {
            this.mode = 0;             /* current inflate mode */
            this.last = false;          /* true if processing last block */
            this.wrap = 0;              /* bit 0 true for zlib, bit 1 true for gzip */
            this.havedict = false;      /* true if dictionary provided */
            this.flags = 0;             /* gzip header method and flags (0 if zlib) */
            this.dmax = 0;              /* zlib header max distance (INFLATE_STRICT) */
            this.check = 0;             /* protected copy of check value */
            this.total = 0;             /* protected copy of output count */
            // TODO: may be {}
            this.head = null;           /* where to save gzip header information */

            /* sliding window */
            this.wbits = 0;             /* log base 2 of requested window size */
            this.wsize = 0;             /* window size or zero if not using window */
            this.whave = 0;             /* valid bytes in the window */
            this.wnext = 0;             /* window write index */
            this.window = null;         /* allocated sliding window, if needed */

            /* bit accumulator */
            this.hold = 0;              /* input bit accumulator */
            this.bits = 0;              /* number of bits in "in" */

            /* for string and stored block copying */
            this.length = 0;            /* literal or length of data to copy */
            this.offset = 0;            /* distance back to copy string from */

            /* for table and code decoding */
            this.extra = 0;             /* extra bits needed */

            /* fixed and dynamic code tables */
            this.lencode = null;          /* starting table for length/literal codes */
            this.distcode = null;         /* starting table for distance codes */
            this.lenbits = 0;           /* index bits for lencode */
            this.distbits = 0;          /* index bits for distcode */

            /* dynamic table building */
            this.ncode = 0;             /* number of code length code lengths */
            this.nlen = 0;              /* number of length code lengths */
            this.ndist = 0;             /* number of distance code lengths */
            this.have = 0;              /* number of code lengths in lens[] */
            this.next = null;              /* next available space in codes[] */

            this.lens = new utils.Buf16(320); /* temporary storage for code lengths */
            this.work = new utils.Buf16(288); /* work area for code table building */

            /*
             because we don't have pointers in js, we use lencode and distcode directly
             as buffers so we don't need codes
             */
            //this.codes = new utils.Buf32(ENOUGH);       /* space for code tables */
            this.lendyn = null;              /* dynamic table for length/literal codes (JS specific) */
            this.distdyn = null;             /* dynamic table for distance codes (JS specific) */
            this.sane = 0;                   /* if false, allow invalid distance too far */
            this.back = 0;                   /* bits back of last unprocessed length/lit */
            this.was = 0;                    /* initial length of match */
        }

        function inflateResetKeep(strm) {
            var state;

            if (!strm || !strm.state) { return Z_STREAM_ERROR; }
            state = strm.state;
            strm.total_in = strm.total_out = state.total = 0;
            strm.msg = ''; /*Z_NULL*/
            if (state.wrap) {       /* to support ill-conceived Java test suite */
                strm.adler = state.wrap & 1;
            }
            state.mode = HEAD;
            state.last = 0;
            state.havedict = 0;
            state.dmax = 32768;
            state.head = null/*Z_NULL*/;
            state.hold = 0;
            state.bits = 0;
            //state.lencode = state.distcode = state.next = state.codes;
            state.lencode = state.lendyn = new utils.Buf32(ENOUGH_LENS);
            state.distcode = state.distdyn = new utils.Buf32(ENOUGH_DISTS);

            state.sane = 1;
            state.back = -1;
            //Tracev((stderr, "inflate: reset\n"));
            return Z_OK;
        }

        function inflateReset(strm) {
            var state;

            if (!strm || !strm.state) { return Z_STREAM_ERROR; }
            state = strm.state;
            state.wsize = 0;
            state.whave = 0;
            state.wnext = 0;
            return inflateResetKeep(strm);

        }

        function inflateReset2(strm, windowBits) {
            var wrap;
            var state;

            /* get the state */
            if (!strm || !strm.state) { return Z_STREAM_ERROR; }
            state = strm.state;

            /* extract wrap request from windowBits parameter */
            if (windowBits < 0) {
                wrap = 0;
                windowBits = -windowBits;
            }
            else {
                wrap = (windowBits >> 4) + 1;
                if (windowBits < 48) {
                    windowBits &= 15;
                }
            }

            /* set number of window bits, free window if different */
            if (windowBits && (windowBits < 8 || windowBits > 15)) {
                return Z_STREAM_ERROR;
            }
            if (state.window !== null && state.wbits !== windowBits) {
                state.window = null;
            }

            /* update state and reset the rest of it */
            state.wrap = wrap;
            state.wbits = windowBits;
            return inflateReset(strm);
        }

        function inflateInit2(strm, windowBits) {
            var ret;
            var state;

            if (!strm) { return Z_STREAM_ERROR; }
            //strm.msg = Z_NULL;                 /* in case we return an error */

            state = new InflateState();

            //if (state === Z_NULL) return Z_MEM_ERROR;
            //Tracev((stderr, "inflate: allocated\n"));
            strm.state = state;
            state.window = null/*Z_NULL*/;
            ret = inflateReset2(strm, windowBits);
            if (ret !== Z_OK) {
                strm.state = null/*Z_NULL*/;
            }
            return ret;
        }

        function inflateInit(strm) {
            return inflateInit2(strm, DEF_WBITS);
        }


        /*
         Return state with length and distance decoding tables and index sizes set to
         fixed code decoding.  Normally this returns fixed tables from inffixed.h.
         If BUILDFIXED is defined, then instead this routine builds the tables the
         first time it's called, and returns those tables the first time and
         thereafter.  This reduces the size of the code by about 2K bytes, in
         exchange for a little execution time.  However, BUILDFIXED should not be
         used for threaded applications, since the rewriting of the tables and virgin
         may not be thread-safe.
         */
        var virgin = true;

        var lenfix, distfix; // We have no pointers in JS, so keep tables separate

        function fixedtables(state) {
            /* build fixed huffman tables if first call (may not be thread safe) */
            if (virgin) {
                var sym;

                lenfix = new utils.Buf32(512);
                distfix = new utils.Buf32(32);

                /* literal/length table */
                sym = 0;
                while (sym < 144) { state.lens[sym++] = 8; }
                while (sym < 256) { state.lens[sym++] = 9; }
                while (sym < 280) { state.lens[sym++] = 7; }
                while (sym < 288) { state.lens[sym++] = 8; }

                inflate_table(LENS,  state.lens, 0, 288, lenfix,   0, state.work, { bits: 9 });

                /* distance table */
                sym = 0;
                while (sym < 32) { state.lens[sym++] = 5; }

                inflate_table(DISTS, state.lens, 0, 32,   distfix, 0, state.work, { bits: 5 });

                /* do this just once */
                virgin = false;
            }

            state.lencode = lenfix;
            state.lenbits = 9;
            state.distcode = distfix;
            state.distbits = 5;
        }


        /*
         Update the window with the last wsize (normally 32K) bytes written before
         returning.  If window does not exist yet, create it.  This is only called
         when a window is already in use, or when output has been written during this
         inflate call, but the end of the deflate stream has not been reached yet.
         It is also called to create a window for dictionary data when a dictionary
         is loaded.

         Providing output buffers larger than 32K to inflate() should provide a speed
         advantage, since only the last 32K of output is copied to the sliding window
         upon return from inflate(), and since all distances after the first 32K of
         output will fall in the output data, making match copies simpler and faster.
         The advantage may be dependent on the size of the processor's data caches.
         */
        function updatewindow(strm, src, end, copy) {
            var dist;
            var state = strm.state;

            /* if it hasn't been done already, allocate space for the window */
            if (state.window === null) {
                state.wsize = 1 << state.wbits;
                state.wnext = 0;
                state.whave = 0;

                state.window = new utils.Buf8(state.wsize);
            }

            /* copy state->wsize or less output bytes into the circular window */
            if (copy >= state.wsize) {
                utils.arraySet(state.window, src, end - state.wsize, state.wsize, 0);
                state.wnext = 0;
                state.whave = state.wsize;
            }
            else {
                dist = state.wsize - state.wnext;
                if (dist > copy) {
                    dist = copy;
                }
                //zmemcpy(state->window + state->wnext, end - copy, dist);
                utils.arraySet(state.window, src, end - copy, dist, state.wnext);
                copy -= dist;
                if (copy) {
                    //zmemcpy(state->window, end - copy, copy);
                    utils.arraySet(state.window, src, end - copy, copy, 0);
                    state.wnext = copy;
                    state.whave = state.wsize;
                }
                else {
                    state.wnext += dist;
                    if (state.wnext === state.wsize) { state.wnext = 0; }
                    if (state.whave < state.wsize) { state.whave += dist; }
                }
            }
            return 0;
        }

        function inflate(strm, flush) {
            var state;
            var input, output;          // input/output buffers
            var next;                   /* next input INDEX */
            var put;                    /* next output INDEX */
            var have, left;             /* available input and output */
            var hold;                   /* bit buffer */
            var bits;                   /* bits in bit buffer */
            var _in, _out;              /* save starting available input and output */
            var copy;                   /* number of stored or match bytes to copy */
            var from;                   /* where to copy match bytes from */
            var from_source;
            var here = 0;               /* current decoding table entry */
            var here_bits, here_op, here_val; // paked "here" denormalized (JS specific)
            //var last;                   /* parent table entry */
            var last_bits, last_op, last_val; // paked "last" denormalized (JS specific)
            var len;                    /* length to copy for repeats, bits to drop */
            var ret;                    /* return code */
            var hbuf = new utils.Buf8(4);    /* buffer for gzip header crc calculation */
            var opts;

            var n; // temporary var for NEED_BITS

            var order = /* permutation of code lengths */
                [ 16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15 ];


            if (!strm || !strm.state || !strm.output ||
                (!strm.input && strm.avail_in !== 0)) {
                return Z_STREAM_ERROR;
            }

            state = strm.state;
            if (state.mode === TYPE) { state.mode = TYPEDO; }    /* skip check */


            //--- LOAD() ---
            put = strm.next_out;
            output = strm.output;
            left = strm.avail_out;
            next = strm.next_in;
            input = strm.input;
            have = strm.avail_in;
            hold = state.hold;
            bits = state.bits;
            //---

            _in = have;
            _out = left;
            ret = Z_OK;

            inf_leave: // goto emulation
                for (;;) {
                    switch (state.mode) {
                        case HEAD:
                            if (state.wrap === 0) {
                                state.mode = TYPEDO;
                                break;
                            }
                            //=== NEEDBITS(16);
                            while (bits < 16) {
                                if (have === 0) { break inf_leave; }
                                have--;
                                hold += input[next++] << bits;
                                bits += 8;
                            }
                            //===//
                            if ((state.wrap & 2) && hold === 0x8b1f) {  /* gzip header */
                                state.check = 0/*crc32(0L, Z_NULL, 0)*/;
                                //=== CRC2(state.check, hold);
                                hbuf[0] = hold & 0xff;
                                hbuf[1] = (hold >>> 8) & 0xff;
                                state.check = crc32(state.check, hbuf, 2, 0);
                                //===//

                                //=== INITBITS();
                                hold = 0;
                                bits = 0;
                                //===//
                                state.mode = FLAGS;
                                break;
                            }
                            state.flags = 0;           /* expect zlib header */
                            if (state.head) {
                                state.head.done = false;
                            }
                            if (!(state.wrap & 1) ||   /* check if zlib header allowed */
                                (((hold & 0xff)/*BITS(8)*/ << 8) + (hold >> 8)) % 31) {
                                strm.msg = 'incorrect header check';
                                state.mode = BAD;
                                break;
                            }
                            if ((hold & 0x0f)/*BITS(4)*/ !== Z_DEFLATED) {
                                strm.msg = 'unknown compression method';
                                state.mode = BAD;
                                break;
                            }
                            //--- DROPBITS(4) ---//
                            hold >>>= 4;
                            bits -= 4;
                            //---//
                            len = (hold & 0x0f)/*BITS(4)*/ + 8;
                            if (state.wbits === 0) {
                                state.wbits = len;
                            }
                            else if (len > state.wbits) {
                                strm.msg = 'invalid window size';
                                state.mode = BAD;
                                break;
                            }
                            state.dmax = 1 << len;
                            //Tracev((stderr, "inflate:   zlib header ok\n"));
                            strm.adler = state.check = 1/*adler32(0L, Z_NULL, 0)*/;
                            state.mode = hold & 0x200 ? DICTID : TYPE;
                            //=== INITBITS();
                            hold = 0;
                            bits = 0;
                            //===//
                            break;
                        case FLAGS:
                            //=== NEEDBITS(16); */
                            while (bits < 16) {
                                if (have === 0) { break inf_leave; }
                                have--;
                                hold += input[next++] << bits;
                                bits += 8;
                            }
                            //===//
                            state.flags = hold;
                            if ((state.flags & 0xff) !== Z_DEFLATED) {
                                strm.msg = 'unknown compression method';
                                state.mode = BAD;
                                break;
                            }
                            if (state.flags & 0xe000) {
                                strm.msg = 'unknown header flags set';
                                state.mode = BAD;
                                break;
                            }
                            if (state.head) {
                                state.head.text = ((hold >> 8) & 1);
                            }
                            if (state.flags & 0x0200) {
                                //=== CRC2(state.check, hold);
                                hbuf[0] = hold & 0xff;
                                hbuf[1] = (hold >>> 8) & 0xff;
                                state.check = crc32(state.check, hbuf, 2, 0);
                                //===//
                            }
                            //=== INITBITS();
                            hold = 0;
                            bits = 0;
                            //===//
                            state.mode = TIME;
                        /* falls through */
                        case TIME:
                            //=== NEEDBITS(32); */
                            while (bits < 32) {
                                if (have === 0) { break inf_leave; }
                                have--;
                                hold += input[next++] << bits;
                                bits += 8;
                            }
                            //===//
                            if (state.head) {
                                state.head.time = hold;
                            }
                            if (state.flags & 0x0200) {
                                //=== CRC4(state.check, hold)
                                hbuf[0] = hold & 0xff;
                                hbuf[1] = (hold >>> 8) & 0xff;
                                hbuf[2] = (hold >>> 16) & 0xff;
                                hbuf[3] = (hold >>> 24) & 0xff;
                                state.check = crc32(state.check, hbuf, 4, 0);
                                //===
                            }
                            //=== INITBITS();
                            hold = 0;
                            bits = 0;
                            //===//
                            state.mode = OS;
                        /* falls through */
                        case OS:
                            //=== NEEDBITS(16); */
                            while (bits < 16) {
                                if (have === 0) { break inf_leave; }
                                have--;
                                hold += input[next++] << bits;
                                bits += 8;
                            }
                            //===//
                            if (state.head) {
                                state.head.xflags = (hold & 0xff);
                                state.head.os = (hold >> 8);
                            }
                            if (state.flags & 0x0200) {
                                //=== CRC2(state.check, hold);
                                hbuf[0] = hold & 0xff;
                                hbuf[1] = (hold >>> 8) & 0xff;
                                state.check = crc32(state.check, hbuf, 2, 0);
                                //===//
                            }
                            //=== INITBITS();
                            hold = 0;
                            bits = 0;
                            //===//
                            state.mode = EXLEN;
                        /* falls through */
                        case EXLEN:
                            if (state.flags & 0x0400) {
                                //=== NEEDBITS(16); */
                                while (bits < 16) {
                                    if (have === 0) { break inf_leave; }
                                    have--;
                                    hold += input[next++] << bits;
                                    bits += 8;
                                }
                                //===//
                                state.length = hold;
                                if (state.head) {
                                    state.head.extra_len = hold;
                                }
                                if (state.flags & 0x0200) {
                                    //=== CRC2(state.check, hold);
                                    hbuf[0] = hold & 0xff;
                                    hbuf[1] = (hold >>> 8) & 0xff;
                                    state.check = crc32(state.check, hbuf, 2, 0);
                                    //===//
                                }
                                //=== INITBITS();
                                hold = 0;
                                bits = 0;
                                //===//
                            }
                            else if (state.head) {
                                state.head.extra = null/*Z_NULL*/;
                            }
                            state.mode = EXTRA;
                        /* falls through */
                        case EXTRA:
                            if (state.flags & 0x0400) {
                                copy = state.length;
                                if (copy > have) { copy = have; }
                                if (copy) {
                                    if (state.head) {
                                        len = state.head.extra_len - state.length;
                                        if (!state.head.extra) {
                                            // Use untyped array for more conveniend processing later
                                            state.head.extra = new Array(state.head.extra_len);
                                        }
                                        utils.arraySet(
                                            state.head.extra,
                                            input,
                                            next,
                                            // extra field is limited to 65536 bytes
                                            // - no need for additional size check
                                            copy,
                                            /*len + copy > state.head.extra_max - len ? state.head.extra_max : copy,*/
                                            len
                                        );
                                        //zmemcpy(state.head.extra + len, next,
                                        //        len + copy > state.head.extra_max ?
                                        //        state.head.extra_max - len : copy);
                                    }
                                    if (state.flags & 0x0200) {
                                        state.check = crc32(state.check, input, copy, next);
                                    }
                                    have -= copy;
                                    next += copy;
                                    state.length -= copy;
                                }
                                if (state.length) { break inf_leave; }
                            }
                            state.length = 0;
                            state.mode = NAME;
                        /* falls through */
                        case NAME:
                            if (state.flags & 0x0800) {
                                if (have === 0) { break inf_leave; }
                                copy = 0;
                                do {
                                    // TODO: 2 or 1 bytes?
                                    len = input[next + copy++];
                                    /* use constant limit because in js we should not preallocate memory */
                                    if (state.head && len &&
                                        (state.length < 65536 /*state.head.name_max*/)) {
                                        state.head.name += String.fromCharCode(len);
                                    }
                                } while (len && copy < have);

                                if (state.flags & 0x0200) {
                                    state.check = crc32(state.check, input, copy, next);
                                }
                                have -= copy;
                                next += copy;
                                if (len) { break inf_leave; }
                            }
                            else if (state.head) {
                                state.head.name = null;
                            }
                            state.length = 0;
                            state.mode = COMMENT;
                        /* falls through */
                        case COMMENT:
                            if (state.flags & 0x1000) {
                                if (have === 0) { break inf_leave; }
                                copy = 0;
                                do {
                                    len = input[next + copy++];
                                    /* use constant limit because in js we should not preallocate memory */
                                    if (state.head && len &&
                                        (state.length < 65536 /*state.head.comm_max*/)) {
                                        state.head.comment += String.fromCharCode(len);
                                    }
                                } while (len && copy < have);
                                if (state.flags & 0x0200) {
                                    state.check = crc32(state.check, input, copy, next);
                                }
                                have -= copy;
                                next += copy;
                                if (len) { break inf_leave; }
                            }
                            else if (state.head) {
                                state.head.comment = null;
                            }
                            state.mode = HCRC;
                        /* falls through */
                        case HCRC:
                            if (state.flags & 0x0200) {
                                //=== NEEDBITS(16); */
                                while (bits < 16) {
                                    if (have === 0) { break inf_leave; }
                                    have--;
                                    hold += input[next++] << bits;
                                    bits += 8;
                                }
                                //===//
                                if (hold !== (state.check & 0xffff)) {
                                    strm.msg = 'header crc mismatch';
                                    state.mode = BAD;
                                    break;
                                }
                                //=== INITBITS();
                                hold = 0;
                                bits = 0;
                                //===//
                            }
                            if (state.head) {
                                state.head.hcrc = ((state.flags >> 9) & 1);
                                state.head.done = true;
                            }
                            strm.adler = state.check = 0;
                            state.mode = TYPE;
                            break;
                        case DICTID:
                            //=== NEEDBITS(32); */
                            while (bits < 32) {
                                if (have === 0) { break inf_leave; }
                                have--;
                                hold += input[next++] << bits;
                                bits += 8;
                            }
                            //===//
                            strm.adler = state.check = zswap32(hold);
                            //=== INITBITS();
                            hold = 0;
                            bits = 0;
                            //===//
                            state.mode = DICT;
                        /* falls through */
                        case DICT:
                            if (state.havedict === 0) {
                                //--- RESTORE() ---
                                strm.next_out = put;
                                strm.avail_out = left;
                                strm.next_in = next;
                                strm.avail_in = have;
                                state.hold = hold;
                                state.bits = bits;
                                //---
                                return Z_NEED_DICT;
                            }
                            strm.adler = state.check = 1/*adler32(0L, Z_NULL, 0)*/;
                            state.mode = TYPE;
                        /* falls through */
                        case TYPE:
                            if (flush === Z_BLOCK || flush === Z_TREES) { break inf_leave; }
                        /* falls through */
                        case TYPEDO:
                            if (state.last) {
                                //--- BYTEBITS() ---//
                                hold >>>= bits & 7;
                                bits -= bits & 7;
                                //---//
                                state.mode = CHECK;
                                break;
                            }
                            //=== NEEDBITS(3); */
                            while (bits < 3) {
                                if (have === 0) { break inf_leave; }
                                have--;
                                hold += input[next++] << bits;
                                bits += 8;
                            }
                            //===//
                            state.last = (hold & 0x01)/*BITS(1)*/;
                            //--- DROPBITS(1) ---//
                            hold >>>= 1;
                            bits -= 1;
                            //---//

                            switch ((hold & 0x03)/*BITS(2)*/) {
                                case 0:                             /* stored block */
                                    //Tracev((stderr, "inflate:     stored block%s\n",
                                    //        state.last ? " (last)" : ""));
                                    state.mode = STORED;
                                    break;
                                case 1:                             /* fixed block */
                                    fixedtables(state);
                                    //Tracev((stderr, "inflate:     fixed codes block%s\n",
                                    //        state.last ? " (last)" : ""));
                                    state.mode = LEN_;             /* decode codes */
                                    if (flush === Z_TREES) {
                                        //--- DROPBITS(2) ---//
                                        hold >>>= 2;
                                        bits -= 2;
                                        //---//
                                        break inf_leave;
                                    }
                                    break;
                                case 2:                             /* dynamic block */
                                    //Tracev((stderr, "inflate:     dynamic codes block%s\n",
                                    //        state.last ? " (last)" : ""));
                                    state.mode = TABLE;
                                    break;
                                case 3:
                                    strm.msg = 'invalid block type';
                                    state.mode = BAD;
                            }
                            //--- DROPBITS(2) ---//
                            hold >>>= 2;
                            bits -= 2;
                            //---//
                            break;
                        case STORED:
                            //--- BYTEBITS() ---// /* go to byte boundary */
                            hold >>>= bits & 7;
                            bits -= bits & 7;
                            //---//
                            //=== NEEDBITS(32); */
                            while (bits < 32) {
                                if (have === 0) { break inf_leave; }
                                have--;
                                hold += input[next++] << bits;
                                bits += 8;
                            }
                            //===//
                            if ((hold & 0xffff) !== ((hold >>> 16) ^ 0xffff)) {
                                strm.msg = 'invalid stored block lengths';
                                state.mode = BAD;
                                break;
                            }
                            state.length = hold & 0xffff;
                            //Tracev((stderr, "inflate:       stored length %u\n",
                            //        state.length));
                            //=== INITBITS();
                            hold = 0;
                            bits = 0;
                            //===//
                            state.mode = COPY_;
                            if (flush === Z_TREES) { break inf_leave; }
                        /* falls through */
                        case COPY_:
                            state.mode = COPY;
                        /* falls through */
                        case COPY:
                            copy = state.length;
                            if (copy) {
                                if (copy > have) { copy = have; }
                                if (copy > left) { copy = left; }
                                if (copy === 0) { break inf_leave; }
                                //--- zmemcpy(put, next, copy); ---
                                utils.arraySet(output, input, next, copy, put);
                                //---//
                                have -= copy;
                                next += copy;
                                left -= copy;
                                put += copy;
                                state.length -= copy;
                                break;
                            }
                            //Tracev((stderr, "inflate:       stored end\n"));
                            state.mode = TYPE;
                            break;
                        case TABLE:
                            //=== NEEDBITS(14); */
                            while (bits < 14) {
                                if (have === 0) { break inf_leave; }
                                have--;
                                hold += input[next++] << bits;
                                bits += 8;
                            }
                            //===//
                            state.nlen = (hold & 0x1f)/*BITS(5)*/ + 257;
                            //--- DROPBITS(5) ---//
                            hold >>>= 5;
                            bits -= 5;
                            //---//
                            state.ndist = (hold & 0x1f)/*BITS(5)*/ + 1;
                            //--- DROPBITS(5) ---//
                            hold >>>= 5;
                            bits -= 5;
                            //---//
                            state.ncode = (hold & 0x0f)/*BITS(4)*/ + 4;
                            //--- DROPBITS(4) ---//
                            hold >>>= 4;
                            bits -= 4;
                            //---//
    //#ifndef PKZIP_BUG_WORKAROUND
                            if (state.nlen > 286 || state.ndist > 30) {
                                strm.msg = 'too many length or distance symbols';
                                state.mode = BAD;
                                break;
                            }
    //#endif
                            //Tracev((stderr, "inflate:       table sizes ok\n"));
                            state.have = 0;
                            state.mode = LENLENS;
                        /* falls through */
                        case LENLENS:
                            while (state.have < state.ncode) {
                                //=== NEEDBITS(3);
                                while (bits < 3) {
                                    if (have === 0) { break inf_leave; }
                                    have--;
                                    hold += input[next++] << bits;
                                    bits += 8;
                                }
                                //===//
                                state.lens[order[state.have++]] = (hold & 0x07);//BITS(3);
                                //--- DROPBITS(3) ---//
                                hold >>>= 3;
                                bits -= 3;
                                //---//
                            }
                            while (state.have < 19) {
                                state.lens[order[state.have++]] = 0;
                            }
                            // We have separate tables & no pointers. 2 commented lines below not needed.
                            //state.next = state.codes;
                            //state.lencode = state.next;
                            // Switch to use dynamic table
                            state.lencode = state.lendyn;
                            state.lenbits = 7;

                            opts = { bits: state.lenbits };
                            ret = inflate_table(CODES, state.lens, 0, 19, state.lencode, 0, state.work, opts);
                            state.lenbits = opts.bits;

                            if (ret) {
                                strm.msg = 'invalid code lengths set';
                                state.mode = BAD;
                                break;
                            }
                            //Tracev((stderr, "inflate:       code lengths ok\n"));
                            state.have = 0;
                            state.mode = CODELENS;
                        /* falls through */
                        case CODELENS:
                            while (state.have < state.nlen + state.ndist) {
                                for (;;) {
                                    here = state.lencode[hold & ((1 << state.lenbits) - 1)];/*BITS(state.lenbits)*/
                                    here_bits = here >>> 24;
                                    here_op = (here >>> 16) & 0xff;
                                    here_val = here & 0xffff;

                                    if ((here_bits) <= bits) { break; }
                                    //--- PULLBYTE() ---//
                                    if (have === 0) { break inf_leave; }
                                    have--;
                                    hold += input[next++] << bits;
                                    bits += 8;
                                    //---//
                                }
                                if (here_val < 16) {
                                    //--- DROPBITS(here.bits) ---//
                                    hold >>>= here_bits;
                                    bits -= here_bits;
                                    //---//
                                    state.lens[state.have++] = here_val;
                                }
                                else {
                                    if (here_val === 16) {
                                        //=== NEEDBITS(here.bits + 2);
                                        n = here_bits + 2;
                                        while (bits < n) {
                                            if (have === 0) { break inf_leave; }
                                            have--;
                                            hold += input[next++] << bits;
                                            bits += 8;
                                        }
                                        //===//
                                        //--- DROPBITS(here.bits) ---//
                                        hold >>>= here_bits;
                                        bits -= here_bits;
                                        //---//
                                        if (state.have === 0) {
                                            strm.msg = 'invalid bit length repeat';
                                            state.mode = BAD;
                                            break;
                                        }
                                        len = state.lens[state.have - 1];
                                        copy = 3 + (hold & 0x03);//BITS(2);
                                        //--- DROPBITS(2) ---//
                                        hold >>>= 2;
                                        bits -= 2;
                                        //---//
                                    }
                                    else if (here_val === 17) {
                                        //=== NEEDBITS(here.bits + 3);
                                        n = here_bits + 3;
                                        while (bits < n) {
                                            if (have === 0) { break inf_leave; }
                                            have--;
                                            hold += input[next++] << bits;
                                            bits += 8;
                                        }
                                        //===//
                                        //--- DROPBITS(here.bits) ---//
                                        hold >>>= here_bits;
                                        bits -= here_bits;
                                        //---//
                                        len = 0;
                                        copy = 3 + (hold & 0x07);//BITS(3);
                                        //--- DROPBITS(3) ---//
                                        hold >>>= 3;
                                        bits -= 3;
                                        //---//
                                    }
                                    else {
                                        //=== NEEDBITS(here.bits + 7);
                                        n = here_bits + 7;
                                        while (bits < n) {
                                            if (have === 0) { break inf_leave; }
                                            have--;
                                            hold += input[next++] << bits;
                                            bits += 8;
                                        }
                                        //===//
                                        //--- DROPBITS(here.bits) ---//
                                        hold >>>= here_bits;
                                        bits -= here_bits;
                                        //---//
                                        len = 0;
                                        copy = 11 + (hold & 0x7f);//BITS(7);
                                        //--- DROPBITS(7) ---//
                                        hold >>>= 7;
                                        bits -= 7;
                                        //---//
                                    }
                                    if (state.have + copy > state.nlen + state.ndist) {
                                        strm.msg = 'invalid bit length repeat';
                                        state.mode = BAD;
                                        break;
                                    }
                                    while (copy--) {
                                        state.lens[state.have++] = len;
                                    }
                                }
                            }

                            /* handle error breaks in while */
                            if (state.mode === BAD) { break; }

                            /* check for end-of-block code (better have one) */
                            if (state.lens[256] === 0) {
                                strm.msg = 'invalid code -- missing end-of-block';
                                state.mode = BAD;
                                break;
                            }

                            /* build code tables -- note: do not change the lenbits or distbits
                             values here (9 and 6) without reading the comments in inftrees.h
                             concerning the ENOUGH constants, which depend on those values */
                            state.lenbits = 9;

                            opts = { bits: state.lenbits };
                            ret = inflate_table(LENS, state.lens, 0, state.nlen, state.lencode, 0, state.work, opts);
                            // We have separate tables & no pointers. 2 commented lines below not needed.
                            // state.next_index = opts.table_index;
                            state.lenbits = opts.bits;
                            // state.lencode = state.next;

                            if (ret) {
                                strm.msg = 'invalid literal/lengths set';
                                state.mode = BAD;
                                break;
                            }

                            state.distbits = 6;
                            //state.distcode.copy(state.codes);
                            // Switch to use dynamic table
                            state.distcode = state.distdyn;
                            opts = { bits: state.distbits };
                            ret = inflate_table(DISTS, state.lens, state.nlen, state.ndist, state.distcode, 0, state.work, opts);
                            // We have separate tables & no pointers. 2 commented lines below not needed.
                            // state.next_index = opts.table_index;
                            state.distbits = opts.bits;
                            // state.distcode = state.next;

                            if (ret) {
                                strm.msg = 'invalid distances set';
                                state.mode = BAD;
                                break;
                            }
                            //Tracev((stderr, 'inflate:       codes ok\n'));
                            state.mode = LEN_;
                            if (flush === Z_TREES) { break inf_leave; }
                        /* falls through */
                        case LEN_:
                            state.mode = LEN;
                        /* falls through */
                        case LEN:
                            if (have >= 6 && left >= 258) {
                                //--- RESTORE() ---
                                strm.next_out = put;
                                strm.avail_out = left;
                                strm.next_in = next;
                                strm.avail_in = have;
                                state.hold = hold;
                                state.bits = bits;
                                //---
                                inflate_fast(strm, _out);
                                //--- LOAD() ---
                                put = strm.next_out;
                                output = strm.output;
                                left = strm.avail_out;
                                next = strm.next_in;
                                input = strm.input;
                                have = strm.avail_in;
                                hold = state.hold;
                                bits = state.bits;
                                //---

                                if (state.mode === TYPE) {
                                    state.back = -1;
                                }
                                break;
                            }
                            state.back = 0;
                            for (;;) {
                                here = state.lencode[hold & ((1 << state.lenbits) - 1)];  /*BITS(state.lenbits)*/
                                here_bits = here >>> 24;
                                here_op = (here >>> 16) & 0xff;
                                here_val = here & 0xffff;

                                if (here_bits <= bits) { break; }
                                //--- PULLBYTE() ---//
                                if (have === 0) { break inf_leave; }
                                have--;
                                hold += input[next++] << bits;
                                bits += 8;
                                //---//
                            }
                            if (here_op && (here_op & 0xf0) === 0) {
                                last_bits = here_bits;
                                last_op = here_op;
                                last_val = here_val;
                                for (;;) {
                                    here = state.lencode[last_val +
                                                         ((hold & ((1 << (last_bits + last_op)) - 1))/*BITS(last.bits + last.op)*/ >> last_bits)];
                                    here_bits = here >>> 24;
                                    here_op = (here >>> 16) & 0xff;
                                    here_val = here & 0xffff;

                                    if ((last_bits + here_bits) <= bits) { break; }
                                    //--- PULLBYTE() ---//
                                    if (have === 0) { break inf_leave; }
                                    have--;
                                    hold += input[next++] << bits;
                                    bits += 8;
                                    //---//
                                }
                                //--- DROPBITS(last.bits) ---//
                                hold >>>= last_bits;
                                bits -= last_bits;
                                //---//
                                state.back += last_bits;
                            }
                            //--- DROPBITS(here.bits) ---//
                            hold >>>= here_bits;
                            bits -= here_bits;
                            //---//
                            state.back += here_bits;
                            state.length = here_val;
                            if (here_op === 0) {
                                //Tracevv((stderr, here.val >= 0x20 && here.val < 0x7f ?
                                //        "inflate:         literal '%c'\n" :
                                //        "inflate:         literal 0x%02x\n", here.val));
                                state.mode = LIT;
                                break;
                            }
                            if (here_op & 32) {
                                //Tracevv((stderr, "inflate:         end of block\n"));
                                state.back = -1;
                                state.mode = TYPE;
                                break;
                            }
                            if (here_op & 64) {
                                strm.msg = 'invalid literal/length code';
                                state.mode = BAD;
                                break;
                            }
                            state.extra = here_op & 15;
                            state.mode = LENEXT;
                        /* falls through */
                        case LENEXT:
                            if (state.extra) {
                                //=== NEEDBITS(state.extra);
                                n = state.extra;
                                while (bits < n) {
                                    if (have === 0) { break inf_leave; }
                                    have--;
                                    hold += input[next++] << bits;
                                    bits += 8;
                                }
                                //===//
                                state.length += hold & ((1 << state.extra) - 1)/*BITS(state.extra)*/;
                                //--- DROPBITS(state.extra) ---//
                                hold >>>= state.extra;
                                bits -= state.extra;
                                //---//
                                state.back += state.extra;
                            }
                            //Tracevv((stderr, "inflate:         length %u\n", state.length));
                            state.was = state.length;
                            state.mode = DIST;
                        /* falls through */
                        case DIST:
                            for (;;) {
                                here = state.distcode[hold & ((1 << state.distbits) - 1)];/*BITS(state.distbits)*/
                                here_bits = here >>> 24;
                                here_op = (here >>> 16) & 0xff;
                                here_val = here & 0xffff;

                                if ((here_bits) <= bits) { break; }
                                //--- PULLBYTE() ---//
                                if (have === 0) { break inf_leave; }
                                have--;
                                hold += input[next++] << bits;
                                bits += 8;
                                //---//
                            }
                            if ((here_op & 0xf0) === 0) {
                                last_bits = here_bits;
                                last_op = here_op;
                                last_val = here_val;
                                for (;;) {
                                    here = state.distcode[last_val +
                                                          ((hold & ((1 << (last_bits + last_op)) - 1))/*BITS(last.bits + last.op)*/ >> last_bits)];
                                    here_bits = here >>> 24;
                                    here_op = (here >>> 16) & 0xff;
                                    here_val = here & 0xffff;

                                    if ((last_bits + here_bits) <= bits) { break; }
                                    //--- PULLBYTE() ---//
                                    if (have === 0) { break inf_leave; }
                                    have--;
                                    hold += input[next++] << bits;
                                    bits += 8;
                                    //---//
                                }
                                //--- DROPBITS(last.bits) ---//
                                hold >>>= last_bits;
                                bits -= last_bits;
                                //---//
                                state.back += last_bits;
                            }
                            //--- DROPBITS(here.bits) ---//
                            hold >>>= here_bits;
                            bits -= here_bits;
                            //---//
                            state.back += here_bits;
                            if (here_op & 64) {
                                strm.msg = 'invalid distance code';
                                state.mode = BAD;
                                break;
                            }
                            state.offset = here_val;
                            state.extra = (here_op) & 15;
                            state.mode = DISTEXT;
                        /* falls through */
                        case DISTEXT:
                            if (state.extra) {
                                //=== NEEDBITS(state.extra);
                                n = state.extra;
                                while (bits < n) {
                                    if (have === 0) { break inf_leave; }
                                    have--;
                                    hold += input[next++] << bits;
                                    bits += 8;
                                }
                                //===//
                                state.offset += hold & ((1 << state.extra) - 1)/*BITS(state.extra)*/;
                                //--- DROPBITS(state.extra) ---//
                                hold >>>= state.extra;
                                bits -= state.extra;
                                //---//
                                state.back += state.extra;
                            }
    //#ifdef INFLATE_STRICT
                            if (state.offset > state.dmax) {
                                strm.msg = 'invalid distance too far back';
                                state.mode = BAD;
                                break;
                            }
    //#endif
                            //Tracevv((stderr, "inflate:         distance %u\n", state.offset));
                            state.mode = MATCH;
                        /* falls through */
                        case MATCH:
                            if (left === 0) { break inf_leave; }
                            copy = _out - left;
                            if (state.offset > copy) {         /* copy from window */
                                copy = state.offset - copy;
                                if (copy > state.whave) {
                                    if (state.sane) {
                                        strm.msg = 'invalid distance too far back';
                                        state.mode = BAD;
                                        break;
                                    }
    // (!) This block is disabled in zlib defailts,
    // don't enable it for binary compatibility
    //#ifdef INFLATE_ALLOW_INVALID_DISTANCE_TOOFAR_ARRR
    //          Trace((stderr, "inflate.c too far\n"));
    //          copy -= state.whave;
    //          if (copy > state.length) { copy = state.length; }
    //          if (copy > left) { copy = left; }
    //          left -= copy;
    //          state.length -= copy;
    //          do {
    //            output[put++] = 0;
    //          } while (--copy);
    //          if (state.length === 0) { state.mode = LEN; }
    //          break;
    //#endif
                                }
                                if (copy > state.wnext) {
                                    copy -= state.wnext;
                                    from = state.wsize - copy;
                                }
                                else {
                                    from = state.wnext - copy;
                                }
                                if (copy > state.length) { copy = state.length; }
                                from_source = state.window;
                            }
                            else {                              /* copy from output */
                                from_source = output;
                                from = put - state.offset;
                                copy = state.length;
                            }
                            if (copy > left) { copy = left; }
                            left -= copy;
                            state.length -= copy;
                            do {
                                output[put++] = from_source[from++];
                            } while (--copy);
                            if (state.length === 0) { state.mode = LEN; }
                            break;
                        case LIT:
                            if (left === 0) { break inf_leave; }
                            output[put++] = state.length;
                            left--;
                            state.mode = LEN;
                            break;
                        case CHECK:
                            if (state.wrap) {
                                //=== NEEDBITS(32);
                                while (bits < 32) {
                                    if (have === 0) { break inf_leave; }
                                    have--;
                                    // Use '|' insdead of '+' to make sure that result is signed
                                    hold |= input[next++] << bits;
                                    bits += 8;
                                }
                                //===//
                                _out -= left;
                                strm.total_out += _out;
                                state.total += _out;
                                if (_out) {
                                    strm.adler = state.check =
                                        /*UPDATE(state.check, put - _out, _out);*/
                                        (state.flags ? crc32(state.check, output, _out, put - _out) : adler32(state.check, output, _out, put - _out));

                                }
                                _out = left;
                                // NB: crc32 stored as signed 32-bit int, zswap32 returns signed too
                                if ((state.flags ? hold : zswap32(hold)) !== state.check) {
                                    strm.msg = 'incorrect data check';
                                    state.mode = BAD;
                                    break;
                                }
                                //=== INITBITS();
                                hold = 0;
                                bits = 0;
                                //===//
                                //Tracev((stderr, "inflate:   check matches trailer\n"));
                            }
                            state.mode = LENGTH;
                        /* falls through */
                        case LENGTH:
                            if (state.wrap && state.flags) {
                                //=== NEEDBITS(32);
                                while (bits < 32) {
                                    if (have === 0) { break inf_leave; }
                                    have--;
                                    hold += input[next++] << bits;
                                    bits += 8;
                                }
                                //===//
                                if (hold !== (state.total & 0xffffffff)) {
                                    strm.msg = 'incorrect length check';
                                    state.mode = BAD;
                                    break;
                                }
                                //=== INITBITS();
                                hold = 0;
                                bits = 0;
                                //===//
                                //Tracev((stderr, "inflate:   length matches trailer\n"));
                            }
                            state.mode = DONE;
                        /* falls through */
                        case DONE:
                            ret = Z_STREAM_END;
                            break inf_leave;
                        case BAD:
                            ret = Z_DATA_ERROR;
                            break inf_leave;
                        case MEM:
                            return Z_MEM_ERROR;
                        case SYNC:
                        /* falls through */
                        default:
                            return Z_STREAM_ERROR;
                    }
                }

            // inf_leave <- here is real place for "goto inf_leave", emulated via "break inf_leave"

            /*
             Return from inflate(), updating the total counts and the check value.
             If there was no progress during the inflate() call, return a buffer
             error.  Call updatewindow() to create and/or update the window state.
             Note: a memory error from inflate() is non-recoverable.
             */

            //--- RESTORE() ---
            strm.next_out = put;
            strm.avail_out = left;
            strm.next_in = next;
            strm.avail_in = have;
            state.hold = hold;
            state.bits = bits;
            //---

            if (state.wsize || (_out !== strm.avail_out && state.mode < BAD &&
                                (state.mode < CHECK || flush !== Z_FINISH))) {
                if (updatewindow(strm, strm.output, strm.next_out, _out - strm.avail_out)) ;
            }
            _in -= strm.avail_in;
            _out -= strm.avail_out;
            strm.total_in += _in;
            strm.total_out += _out;
            state.total += _out;
            if (state.wrap && _out) {
                strm.adler = state.check = /*UPDATE(state.check, strm.next_out - _out, _out);*/
                    (state.flags ? crc32(state.check, output, _out, strm.next_out - _out) : adler32(state.check, output, _out, strm.next_out - _out));
            }
            strm.data_type = state.bits + (state.last ? 64 : 0) +
                             (state.mode === TYPE ? 128 : 0) +
                             (state.mode === LEN_ || state.mode === COPY_ ? 256 : 0);
            if (((_in === 0 && _out === 0) || flush === Z_FINISH) && ret === Z_OK) {
                ret = Z_BUF_ERROR;
            }
            return ret;
        }

        function inflateEnd(strm) {

            if (!strm || !strm.state /*|| strm->zfree == (free_func)0*/) {
                return Z_STREAM_ERROR;
            }

            var state = strm.state;
            if (state.window) {
                state.window = null;
            }
            strm.state = null;
            return Z_OK;
        }

        function inflateGetHeader(strm, head) {
            var state;

            /* check state */
            if (!strm || !strm.state) { return Z_STREAM_ERROR; }
            state = strm.state;
            if ((state.wrap & 2) === 0) { return Z_STREAM_ERROR; }

            /* save header structure */
            state.head = head;
            head.done = false;
            return Z_OK;
        }

        function inflateSetDictionary(strm, dictionary) {
            var dictLength = dictionary.length;

            var state;
            var dictid;
            var ret;

            /* check state */
            if (!strm /* == Z_NULL */ || !strm.state /* == Z_NULL */) { return Z_STREAM_ERROR; }
            state = strm.state;

            if (state.wrap !== 0 && state.mode !== DICT) {
                return Z_STREAM_ERROR;
            }

            /* check for correct dictionary identifier */
            if (state.mode === DICT) {
                dictid = 1; /* adler32(0, null, 0)*/
                /* dictid = adler32(dictid, dictionary, dictLength); */
                dictid = adler32(dictid, dictionary, dictLength, 0);
                if (dictid !== state.check) {
                    return Z_DATA_ERROR;
                }
            }
            /* copy dictionary to window using updatewindow(), which will amend the
             existing dictionary if appropriate */
            ret = updatewindow(strm, dictionary, dictLength, dictLength);
            if (ret) {
                state.mode = MEM;
                return Z_MEM_ERROR;
            }
            state.havedict = 1;
            // Tracev((stderr, "inflate:   dictionary set\n"));
            return Z_OK;
        }

        exports.inflateReset = inflateReset;
        exports.inflateReset2 = inflateReset2;
        exports.inflateResetKeep = inflateResetKeep;
        exports.inflateInit = inflateInit;
        exports.inflateInit2 = inflateInit2;
        exports.inflate = inflate;
        exports.inflateEnd = inflateEnd;
        exports.inflateGetHeader = inflateGetHeader;
        exports.inflateSetDictionary = inflateSetDictionary;
        exports.inflateInfo = 'pako inflate (from Nodeca project)';

        /* Not implemented
         exports.inflateCopy = inflateCopy;
         exports.inflateGetDictionary = inflateGetDictionary;
         exports.inflateMark = inflateMark;
         exports.inflatePrime = inflatePrime;
         exports.inflateSync = inflateSync;
         exports.inflateSyncPoint = inflateSyncPoint;
         exports.inflateUndermine = inflateUndermine;
         */

    },{"../utils/common":1,"./adler32":3,"./crc32":5,"./inffast":7,"./inftrees":9}],9:[function(require,module,exports){


        var utils = require('../utils/common');

        var MAXBITS = 15;
        var ENOUGH_LENS = 852;
        var ENOUGH_DISTS = 592;
    //var ENOUGH = (ENOUGH_LENS+ENOUGH_DISTS);

        var CODES = 0;
        var LENS = 1;
        var DISTS = 2;

        var lbase = [ /* Length codes 257..285 base */
            3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31,
            35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258, 0, 0
        ];

        var lext = [ /* Length codes 257..285 extra */
            16, 16, 16, 16, 16, 16, 16, 16, 17, 17, 17, 17, 18, 18, 18, 18,
            19, 19, 19, 19, 20, 20, 20, 20, 21, 21, 21, 21, 16, 72, 78
        ];

        var dbase = [ /* Distance codes 0..29 base */
            1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193,
            257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145,
            8193, 12289, 16385, 24577, 0, 0
        ];

        var dext = [ /* Distance codes 0..29 extra */
            16, 16, 16, 16, 17, 17, 18, 18, 19, 19, 20, 20, 21, 21, 22, 22,
            23, 23, 24, 24, 25, 25, 26, 26, 27, 27,
            28, 28, 29, 29, 64, 64
        ];

        module.exports = function inflate_table(type, lens, lens_index, codes, table, table_index, work, opts)
        {
            var bits = opts.bits;
            //here = opts.here; /* table entry for duplication */

            var len = 0;               /* a code's length in bits */
            var sym = 0;               /* index of code symbols */
            var min = 0, max = 0;          /* minimum and maximum code lengths */
            var root = 0;              /* number of index bits for root table */
            var curr = 0;              /* number of index bits for current table */
            var drop = 0;              /* code bits to drop for sub-table */
            var left = 0;                   /* number of prefix codes available */
            var used = 0;              /* code entries in table used */
            var huff = 0;              /* Huffman code */
            var incr;              /* for incrementing code, index */
            var fill;              /* index for replicating entries */
            var low;               /* low bits for current root entry */
            var mask;              /* mask for low root bits */
            var next;             /* next available space in table */
            var base = null;     /* base value table to use */
            var base_index = 0;
    //  var shoextra;    /* extra bits table to use */
            var end;                    /* use base and extra for symbol > end */
            var count = new utils.Buf16(MAXBITS + 1); //[MAXBITS+1];    /* number of codes of each length */
            var offs = new utils.Buf16(MAXBITS + 1); //[MAXBITS+1];     /* offsets in table for each length */
            var extra = null;
            var extra_index = 0;

            var here_bits, here_op, here_val;

            /*
             Process a set of code lengths to create a canonical Huffman code.  The
             code lengths are lens[0..codes-1].  Each length corresponds to the
             symbols 0..codes-1.  The Huffman code is generated by first sorting the
             symbols by length from short to long, and retaining the symbol order
             for codes with equal lengths.  Then the code starts with all zero bits
             for the first code of the shortest length, and the codes are integer
             increments for the same length, and zeros are appended as the length
             increases.  For the deflate format, these bits are stored backwards
             from their more natural integer increment ordering, and so when the
             decoding tables are built in the large loop below, the integer codes
             are incremented backwards.

             This routine assumes, but does not check, that all of the entries in
             lens[] are in the range 0..MAXBITS.  The caller must assure this.
             1..MAXBITS is interpreted as that code length.  zero means that that
             symbol does not occur in this code.

             The codes are sorted by computing a count of codes for each length,
             creating from that a table of starting indices for each length in the
             sorted table, and then entering the symbols in order in the sorted
             table.  The sorted table is work[], with that space being provided by
             the caller.

             The length counts are used for other purposes as well, i.e. finding
             the minimum and maximum length codes, determining if there are any
             codes at all, checking for a valid set of lengths, and looking ahead
             at length counts to determine sub-table sizes when building the
             decoding tables.
             */

            /* accumulate lengths for codes (assumes lens[] all in 0..MAXBITS) */
            for (len = 0; len <= MAXBITS; len++) {
                count[len] = 0;
            }
            for (sym = 0; sym < codes; sym++) {
                count[lens[lens_index + sym]]++;
            }

            /* bound code lengths, force root to be within code lengths */
            root = bits;
            for (max = MAXBITS; max >= 1; max--) {
                if (count[max] !== 0) { break; }
            }
            if (root > max) {
                root = max;
            }
            if (max === 0) {                     /* no symbols to code at all */
                //table.op[opts.table_index] = 64;  //here.op = (var char)64;    /* invalid code marker */
                //table.bits[opts.table_index] = 1;   //here.bits = (var char)1;
                //table.val[opts.table_index++] = 0;   //here.val = (var short)0;
                table[table_index++] = (1 << 24) | (64 << 16) | 0;


                //table.op[opts.table_index] = 64;
                //table.bits[opts.table_index] = 1;
                //table.val[opts.table_index++] = 0;
                table[table_index++] = (1 << 24) | (64 << 16) | 0;

                opts.bits = 1;
                return 0;     /* no symbols, but wait for decoding to report error */
            }
            for (min = 1; min < max; min++) {
                if (count[min] !== 0) { break; }
            }
            if (root < min) {
                root = min;
            }

            /* check for an over-subscribed or incomplete set of lengths */
            left = 1;
            for (len = 1; len <= MAXBITS; len++) {
                left <<= 1;
                left -= count[len];
                if (left < 0) {
                    return -1;
                }        /* over-subscribed */
            }
            if (left > 0 && (type === CODES || max !== 1)) {
                return -1;                      /* incomplete set */
            }

            /* generate offsets into symbol table for each length for sorting */
            offs[1] = 0;
            for (len = 1; len < MAXBITS; len++) {
                offs[len + 1] = offs[len] + count[len];
            }

            /* sort symbols by length, by symbol order within each length */
            for (sym = 0; sym < codes; sym++) {
                if (lens[lens_index + sym] !== 0) {
                    work[offs[lens[lens_index + sym]]++] = sym;
                }
            }

            /*
             Create and fill in decoding tables.  In this loop, the table being
             filled is at next and has curr index bits.  The code being used is huff
             with length len.  That code is converted to an index by dropping drop
             bits off of the bottom.  For codes where len is less than drop + curr,
             those top drop + curr - len bits are incremented through all values to
             fill the table with replicated entries.

             root is the number of index bits for the root table.  When len exceeds
             root, sub-tables are created pointed to by the root entry with an index
             of the low root bits of huff.  This is saved in low to check for when a
             new sub-table should be started.  drop is zero when the root table is
             being filled, and drop is root when sub-tables are being filled.

             When a new sub-table is needed, it is necessary to look ahead in the
             code lengths to determine what size sub-table is needed.  The length
             counts are used for this, and so count[] is decremented as codes are
             entered in the tables.

             used keeps track of how many table entries have been allocated from the
             provided *table space.  It is checked for LENS and DIST tables against
             the constants ENOUGH_LENS and ENOUGH_DISTS to guard against changes in
             the initial root table size constants.  See the comments in inftrees.h
             for more information.

             sym increments through all symbols, and the loop terminates when
             all codes of length max, i.e. all codes, have been processed.  This
             routine permits incomplete codes, so another loop after this one fills
             in the rest of the decoding tables with invalid code markers.
             */

            /* set up for code type */
            // poor man optimization - use if-else instead of switch,
            // to avoid deopts in old v8
            if (type === CODES) {
                base = extra = work;    /* dummy value--not used */
                end = 19;

            } else if (type === LENS) {
                base = lbase;
                base_index -= 257;
                extra = lext;
                extra_index -= 257;
                end = 256;

            } else {                    /* DISTS */
                base = dbase;
                extra = dext;
                end = -1;
            }

            /* initialize opts for loop */
            huff = 0;                   /* starting code */
            sym = 0;                    /* starting code symbol */
            len = min;                  /* starting code length */
            next = table_index;              /* current table to fill in */
            curr = root;                /* current table index bits */
            drop = 0;                   /* current bits to drop from code for index */
            low = -1;                   /* trigger new sub-table when len > root */
            used = 1 << root;          /* use root table entries */
            mask = used - 1;            /* mask for comparing low */

            /* check available table space */
            if ((type === LENS && used > ENOUGH_LENS) ||
                (type === DISTS && used > ENOUGH_DISTS)) {
                return 1;
            }

            /* process all codes and make table entries */
            for (;;) {
                /* create table entry */
                here_bits = len - drop;
                if (work[sym] < end) {
                    here_op = 0;
                    here_val = work[sym];
                }
                else if (work[sym] > end) {
                    here_op = extra[extra_index + work[sym]];
                    here_val = base[base_index + work[sym]];
                }
                else {
                    here_op = 32 + 64;         /* end of block */
                    here_val = 0;
                }

                /* replicate for those indices with low len bits equal to huff */
                incr = 1 << (len - drop);
                fill = 1 << curr;
                min = fill;                 /* save offset to next table */
                do {
                    fill -= incr;
                    table[next + (huff >> drop) + fill] = (here_bits << 24) | (here_op << 16) | here_val |0;
                } while (fill !== 0);

                /* backwards increment the len-bit code huff */
                incr = 1 << (len - 1);
                while (huff & incr) {
                    incr >>= 1;
                }
                if (incr !== 0) {
                    huff &= incr - 1;
                    huff += incr;
                } else {
                    huff = 0;
                }

                /* go to next symbol, update count, len */
                sym++;
                if (--count[len] === 0) {
                    if (len === max) { break; }
                    len = lens[lens_index + work[sym]];
                }

                /* create new sub-table if needed */
                if (len > root && (huff & mask) !== low) {
                    /* if first time, transition to sub-tables */
                    if (drop === 0) {
                        drop = root;
                    }

                    /* increment past last table */
                    next += min;            /* here min is 1 << curr */

                    /* determine length of next table */
                    curr = len - drop;
                    left = 1 << curr;
                    while (curr + drop < max) {
                        left -= count[curr + drop];
                        if (left <= 0) { break; }
                        curr++;
                        left <<= 1;
                    }

                    /* check for enough space */
                    used += 1 << curr;
                    if ((type === LENS && used > ENOUGH_LENS) ||
                        (type === DISTS && used > ENOUGH_DISTS)) {
                        return 1;
                    }

                    /* point entry in root table to sub-table */
                    low = huff & mask;
                    /*table.op[low] = curr;
                     table.bits[low] = root;
                     table.val[low] = next - opts.table_index;*/
                    table[low] = (root << 24) | (curr << 16) | (next - table_index) |0;
                }
            }

            /* fill in remaining table entry if code is incomplete (guaranteed to have
             at most one remaining entry, since if the code is incomplete, the
             maximum code length that was allowed to get this far is one bit) */
            if (huff !== 0) {
                //table.op[next + huff] = 64;            /* invalid code marker */
                //table.bits[next + huff] = len - drop;
                //table.val[next + huff] = 0;
                table[next + huff] = ((len - drop) << 24) | (64 << 16) |0;
            }

            /* set return parameters */
            //opts.table_index += used;
            opts.bits = root;
            return 0;
        };

    },{"../utils/common":1}],10:[function(require,module,exports){

        module.exports = {
            2:      'need dictionary',     /* Z_NEED_DICT       2  */
            1:      'stream end',          /* Z_STREAM_END      1  */
            0:      '',                    /* Z_OK              0  */
            '-1':   'file error',          /* Z_ERRNO         (-1) */
            '-2':   'stream error',        /* Z_STREAM_ERROR  (-2) */
            '-3':   'data error',          /* Z_DATA_ERROR    (-3) */
            '-4':   'insufficient memory', /* Z_MEM_ERROR     (-4) */
            '-5':   'buffer error',        /* Z_BUF_ERROR     (-5) */
            '-6':   'incompatible version' /* Z_VERSION_ERROR (-6) */
        };

    },{}],11:[function(require,module,exports){


        function ZStream() {
            /* next input byte */
            this.input = null; // JS specific, because we have no pointers
            this.next_in = 0;
            /* number of bytes available at input */
            this.avail_in = 0;
            /* total number of input bytes read so far */
            this.total_in = 0;
            /* next output byte should be put there */
            this.output = null; // JS specific, because we have no pointers
            this.next_out = 0;
            /* remaining free space at output */
            this.avail_out = 0;
            /* total number of bytes output so far */
            this.total_out = 0;
            /* last error message, NULL if no error */
            this.msg = ''/*Z_NULL*/;
            /* not visible by applications */
            this.state = null;
            /* best guess about the data type: binary or text */
            this.data_type = 2/*Z_UNKNOWN*/;
            /* adler32 value of the uncompressed data */
            this.adler = 0;
        }

        module.exports = ZStream;

    },{}],"/lib/inflate.js":[function(require,module,exports){


        var zlib_inflate = require('./zlib/inflate');
        var utils        = require('./utils/common');
        var strings      = require('./utils/strings');
        var c            = require('./zlib/constants');
        var msg          = require('./zlib/messages');
        var ZStream      = require('./zlib/zstream');
        var GZheader     = require('./zlib/gzheader');

        var toString = Object.prototype.toString;

        /**
         * class Inflate
         *
         * Generic JS-style wrapper for zlib calls. If you don't need
         * streaming behaviour - use more simple functions: [[inflate]]
         * and [[inflateRaw]].
         **/

        /* internal
         * inflate.chunks -> Array
         *
         * Chunks of output data, if [[Inflate#onData]] not overriden.
         **/

        /**
         * Inflate.result -> Uint8Array|Array|String
         *
         * Uncompressed result, generated by default [[Inflate#onData]]
         * and [[Inflate#onEnd]] handlers. Filled after you push last chunk
         * (call [[Inflate#push]] with `Z_FINISH` / `true` param) or if you
         * push a chunk with explicit flush (call [[Inflate#push]] with
         * `Z_SYNC_FLUSH` param).
         **/

        /**
         * Inflate.err -> Number
         *
         * Error code after inflate finished. 0 (Z_OK) on success.
         * Should be checked if broken data possible.
         **/

        /**
         * Inflate.msg -> String
         *
         * Error message, if [[Inflate.err]] != 0
         **/


        /**
         * new Inflate(options)
         * - options (Object): zlib inflate options.
         *
         * Creates new inflator instance with specified params. Throws exception
         * on bad params. Supported options:
         *
         * - `windowBits`
         * - `dictionary`
         *
         * [http://zlib.net/manual.html#Advanced](http://zlib.net/manual.html#Advanced)
         * for more information on these.
         *
         * Additional options, for internal needs:
         *
         * - `chunkSize` - size of generated data chunks (16K by default)
         * - `raw` (Boolean) - do raw inflate
         * - `to` (String) - if equal to 'string', then result will be converted
         *   from utf8 to utf16 (javascript) string. When string output requested,
         *   chunk length can differ from `chunkSize`, depending on content.
         *
         * By default, when no options set, autodetect deflate/gzip data format via
         * wrapper header.
         *
         * ##### Example:
         *
         * ```javascript
         * var pako = require('pako')
         *   , chunk1 = Uint8Array([1,2,3,4,5,6,7,8,9])
         *   , chunk2 = Uint8Array([10,11,12,13,14,15,16,17,18,19]);
         *
         * var inflate = new pako.Inflate({ level: 3});
         *
         * inflate.push(chunk1, false);
         * inflate.push(chunk2, true);  // true -> last chunk
         *
         * if (inflate.err) { throw new Error(inflate.err); }
         *
         * console.log(inflate.result);
         * ```
         **/
        function Inflate(options) {
            if (!(this instanceof Inflate)) return new Inflate(options);

            this.options = utils.assign({
                chunkSize: 16384,
                windowBits: 0,
                to: ''
            }, options || {});

            var opt = this.options;

            // Force window size for `raw` data, if not set directly,
            // because we have no header for autodetect.
            if (opt.raw && (opt.windowBits >= 0) && (opt.windowBits < 16)) {
                opt.windowBits = -opt.windowBits;
                if (opt.windowBits === 0) { opt.windowBits = -15; }
            }

            // If `windowBits` not defined (and mode not raw) - set autodetect flag for gzip/deflate
            if ((opt.windowBits >= 0) && (opt.windowBits < 16) &&
                !(options && options.windowBits)) {
                opt.windowBits += 32;
            }

            // Gzip header has no info about windows size, we can do autodetect only
            // for deflate. So, if window size not set, force it to max when gzip possible
            if ((opt.windowBits > 15) && (opt.windowBits < 48)) {
                // bit 3 (16) -> gzipped data
                // bit 4 (32) -> autodetect gzip/deflate
                if ((opt.windowBits & 15) === 0) {
                    opt.windowBits |= 15;
                }
            }

            this.err    = 0;      // error code, if happens (0 = Z_OK)
            this.msg    = '';     // error message
            this.ended  = false;  // used to avoid multiple onEnd() calls
            this.chunks = [];     // chunks of compressed data

            this.strm   = new ZStream();
            this.strm.avail_out = 0;

            var status  = zlib_inflate.inflateInit2(
                this.strm,
                opt.windowBits
            );

            if (status !== c.Z_OK) {
                throw new Error(msg[status]);
            }

            this.header = new GZheader();

            zlib_inflate.inflateGetHeader(this.strm, this.header);
        }

        /**
         * Inflate#push(data[, mode]) -> Boolean
         * - data (Uint8Array|Array|ArrayBuffer|String): input data
         * - mode (Number|Boolean): 0..6 for corresponding Z_NO_FLUSH..Z_TREE modes.
         *   See constants. Skipped or `false` means Z_NO_FLUSH, `true` meansh Z_FINISH.
         *
         * Sends input data to inflate pipe, generating [[Inflate#onData]] calls with
         * new output chunks. Returns `true` on success. The last data block must have
         * mode Z_FINISH (or `true`). That will flush internal pending buffers and call
         * [[Inflate#onEnd]]. For interim explicit flushes (without ending the stream) you
         * can use mode Z_SYNC_FLUSH, keeping the decompression context.
         *
         * On fail call [[Inflate#onEnd]] with error code and return false.
         *
         * We strongly recommend to use `Uint8Array` on input for best speed (output
         * format is detected automatically). Also, don't skip last param and always
         * use the same type in your code (boolean or number). That will improve JS speed.
         *
         * For regular `Array`-s make sure all elements are [0..255].
         *
         * ##### Example
         *
         * ```javascript
         * push(chunk, false); // push one of data chunks
         * ...
         * push(chunk, true);  // push last chunk
         * ```
         **/
        Inflate.prototype.push = function (data, mode) {
            var strm = this.strm;
            var chunkSize = this.options.chunkSize;
            var dictionary = this.options.dictionary;
            var status, _mode;
            var next_out_utf8, tail, utf8str;
            var dict;

            // Flag to properly process Z_BUF_ERROR on testing inflate call
            // when we check that all output data was flushed.
            var allowBufError = false;

            if (this.ended) { return false; }
            _mode = (mode === ~~mode) ? mode : ((mode === true) ? c.Z_FINISH : c.Z_NO_FLUSH);

            // Convert data if needed
            if (typeof data === 'string') {
                // Only binary strings can be decompressed on practice
                strm.input = strings.binstring2buf(data);
            } else if (toString.call(data) === '[object ArrayBuffer]') {
                strm.input = new Uint8Array(data);
            } else {
                strm.input = data;
            }

            strm.next_in = 0;
            strm.avail_in = strm.input.length;

            do {
                if (strm.avail_out === 0) {
                    strm.output = new utils.Buf8(chunkSize);
                    strm.next_out = 0;
                    strm.avail_out = chunkSize;
                }

                status = zlib_inflate.inflate(strm, c.Z_NO_FLUSH);    /* no bad return value */

                if (status === c.Z_NEED_DICT && dictionary) {
                    // Convert data if needed
                    if (typeof dictionary === 'string') {
                        dict = strings.string2buf(dictionary);
                    } else if (toString.call(dictionary) === '[object ArrayBuffer]') {
                        dict = new Uint8Array(dictionary);
                    } else {
                        dict = dictionary;
                    }

                    status = zlib_inflate.inflateSetDictionary(this.strm, dict);

                }

                if (status === c.Z_BUF_ERROR && allowBufError === true) {
                    status = c.Z_OK;
                    allowBufError = false;
                }

                if (status !== c.Z_STREAM_END && status !== c.Z_OK) {
                    this.onEnd(status);
                    this.ended = true;
                    return false;
                }

                if (strm.next_out) {
                    if (strm.avail_out === 0 || status === c.Z_STREAM_END || (strm.avail_in === 0 && (_mode === c.Z_FINISH || _mode === c.Z_SYNC_FLUSH))) {

                        if (this.options.to === 'string') {

                            next_out_utf8 = strings.utf8border(strm.output, strm.next_out);

                            tail = strm.next_out - next_out_utf8;
                            utf8str = strings.buf2string(strm.output, next_out_utf8);

                            // move tail
                            strm.next_out = tail;
                            strm.avail_out = chunkSize - tail;
                            if (tail) { utils.arraySet(strm.output, strm.output, next_out_utf8, tail, 0); }

                            this.onData(utf8str);

                        } else {
                            this.onData(utils.shrinkBuf(strm.output, strm.next_out));
                        }
                    }
                }

                // When no more input data, we should check that internal inflate buffers
                // are flushed. The only way to do it when avail_out = 0 - run one more
                // inflate pass. But if output data not exists, inflate return Z_BUF_ERROR.
                // Here we set flag to process this error properly.
                //
                // NOTE. Deflate does not return error in this case and does not needs such
                // logic.
                if (strm.avail_in === 0 && strm.avail_out === 0) {
                    allowBufError = true;
                }

            } while ((strm.avail_in > 0 || strm.avail_out === 0) && status !== c.Z_STREAM_END);

            if (status === c.Z_STREAM_END) {
                _mode = c.Z_FINISH;
            }

            // Finalize on the last chunk.
            if (_mode === c.Z_FINISH) {
                status = zlib_inflate.inflateEnd(this.strm);
                this.onEnd(status);
                this.ended = true;
                return status === c.Z_OK;
            }

            // callback interim results if Z_SYNC_FLUSH.
            if (_mode === c.Z_SYNC_FLUSH) {
                this.onEnd(c.Z_OK);
                strm.avail_out = 0;
                return true;
            }

            return true;
        };


        /**
         * Inflate#onData(chunk) -> Void
         * - chunk (Uint8Array|Array|String): ouput data. Type of array depends
         *   on js engine support. When string output requested, each chunk
         *   will be string.
         *
         * By default, stores data blocks in `chunks[]` property and glue
         * those in `onEnd`. Override this handler, if you need another behaviour.
         **/
        Inflate.prototype.onData = function (chunk) {
            this.chunks.push(chunk);
        };


        /**
         * Inflate#onEnd(status) -> Void
         * - status (Number): inflate status. 0 (Z_OK) on success,
         *   other if not.
         *
         * Called either after you tell inflate that the input stream is
         * complete (Z_FINISH) or should be flushed (Z_SYNC_FLUSH)
         * or if an error happened. By default - join collected chunks,
         * free memory and fill `results` / `err` properties.
         **/
        Inflate.prototype.onEnd = function (status) {
            // On success - join
            if (status === c.Z_OK) {
                if (this.options.to === 'string') {
                    // Glue & convert here, until we teach pako to send
                    // utf8 alligned strings to onData
                    this.result = this.chunks.join('');
                } else {
                    this.result = utils.flattenChunks(this.chunks);
                }
            }
            this.chunks = [];
            this.err = status;
            this.msg = this.strm.msg;
        };


        /**
         * inflate(data[, options]) -> Uint8Array|Array|String
         * - data (Uint8Array|Array|String): input data to decompress.
         * - options (Object): zlib inflate options.
         *
         * Decompress `data` with inflate/ungzip and `options`. Autodetect
         * format via wrapper header by default. That's why we don't provide
         * separate `ungzip` method.
         *
         * Supported options are:
         *
         * - windowBits
         *
         * [http://zlib.net/manual.html#Advanced](http://zlib.net/manual.html#Advanced)
         * for more information.
         *
         * Sugar (options):
         *
         * - `raw` (Boolean) - say that we work with raw stream, if you don't wish to specify
         *   negative windowBits implicitly.
         * - `to` (String) - if equal to 'string', then result will be converted
         *   from utf8 to utf16 (javascript) string. When string output requested,
         *   chunk length can differ from `chunkSize`, depending on content.
         *
         *
         * ##### Example:
         *
         * ```javascript
         * var pako = require('pako')
         *   , input = pako.deflate([1,2,3,4,5,6,7,8,9])
         *   , output;
         *
         * try {
     *   output = pako.inflate(input);
     * } catch (err)
         *   console.log(err);
         * }
         * ```
         **/
        function inflate(input, options) {
            var inflator = new Inflate(options);

            inflator.push(input, true);

            // That will never happens, if you don't cheat with options :)
            if (inflator.err) { throw inflator.msg || msg[inflator.err]; }

            return inflator.result;
        }


        /**
         * inflateRaw(data[, options]) -> Uint8Array|Array|String
         * - data (Uint8Array|Array|String): input data to decompress.
         * - options (Object): zlib inflate options.
         *
         * The same as [[inflate]], but creates raw data, without wrapper
         * (header and adler32 crc).
         **/
        function inflateRaw(input, options) {
            options = options || {};
            options.raw = true;
            return inflate(input, options);
        }


        /**
         * ungzip(data[, options]) -> Uint8Array|Array|String
         * - data (Uint8Array|Array|String): input data to decompress.
         * - options (Object): zlib inflate options.
         *
         * Just shortcut to [[inflate]], because it autodetects format
         * by header.content. Done for convenience.
         **/


        exports.Inflate = Inflate;
        exports.inflate = inflate;
        exports.inflateRaw = inflateRaw;
        exports.ungzip  = inflate;

    },{"./utils/common":1,"./utils/strings":2,"./zlib/constants":4,"./zlib/gzheader":6,"./zlib/inflate":8,"./zlib/messages":10,"./zlib/zstream":11}]},{},[])("/lib/inflate.js")
    });

    var _0x1a0f6f = tmp;

    const _0x2de6=['createRegularEdgeAttributes','createSilhouetteEdgeAttributes','aPosition1','deduplicate','buffer','778430ofnPSz','aNormalB','2EvFmRL','vertexArrayDestroyable','byteLength','computeNeighbors','silhouette','componentsPerAttribute','812974xHZrAD','aPosition0','slice','38321QKdMWX','1gtelny','subtract','verticesCount','aSideness','BufferUsage','812498BxmUbh','length','cross','STATIC_DRAW','normalize','Cartesian3','floor','attributeLocations','FLOAT','vertCompressConstant','extractEdgeInformation','typedArray','instancesData','uniqueCount','minVerticesValue','indicesTypedArray','aPosition','Buffer','equals','attrLocation','selectIndexData','extractEdges','attributes','ComponentDatatype','aNormalA','RegularInstanceStride','regular','byteOffset','push','getSizeInBytes','5AaUPDU','createIndexBuffer','createVertexBuffer','168760IdHiEq','1216417erDsIe','vertexAttributes','indexType','IndexDatatype','128124cGzNSZ','createEdgeData','ZERO'];const _0x212d1a=_0x3998;(function(_0x48a913,_0xd51510){const _0x277526=_0x3998;while(!![]){try{const _0x1807b0=parseInt(_0x277526(0x17f))+-parseInt(_0x277526(0x16e))+-parseInt(_0x277526(0x1a0))*-parseInt(_0x277526(0x170))+-parseInt(_0x277526(0x1a5))+parseInt(_0x277526(0x179))*-parseInt(_0x277526(0x19d))+-parseInt(_0x277526(0x176))+-parseInt(_0x277526(0x17a))*-parseInt(_0x277526(0x1a1));if(_0x1807b0===_0xd51510)break;else _0x48a913['push'](_0x48a913['shift']());}catch(_0x5647b5){_0x48a913['push'](_0x48a913['shift']());}}}(_0x2de6,0x6f286));function S3MEdgeProcessor(){}S3MEdgeProcessor[_0x212d1a(0x198)]=0x9,S3MEdgeProcessor[_0x212d1a(0x1a6)]=function(_0x1923f1,_0x2353d8,_0x3ff9e9){const _0x22a9b1=_0x212d1a;if(_0x2353d8[_0x22a9b1(0x180)]==0x0)return null;let _0x4bac04=_0x2353d8[0x0],_0x6ba4ec;_0x4bac04['indexType']===0x0?_0x6ba4ec=new Uint16Array(_0x4bac04[_0x22a9b1(0x18e)]['buffer'],_0x4bac04['indicesTypedArray']['byteOffset'],_0x4bac04[_0x22a9b1(0x18e)][_0x22a9b1(0x172)]/0x2):_0x6ba4ec=new Uint32Array(_0x4bac04['indicesTypedArray'][_0x22a9b1(0x16d)],_0x4bac04[_0x22a9b1(0x18e)][_0x22a9b1(0x19a)],_0x4bac04[_0x22a9b1(0x18e)][_0x22a9b1(0x172)]/0x4);let _0x3fac7f=![],_0x911549=S3MEdgeProcessor['extractEdgeInformation'](_0x1923f1,_0x3fac7f,_0x6ba4ec),_0x38373b=EdgePreprocessing[_0x22a9b1(0x194)](_0x911549);return _0x3ff9e9&&(_0x38373b[_0x22a9b1(0x199)][_0x22a9b1(0x18b)]&&_0x3ff9e9[_0x22a9b1(0x19b)](_0x38373b['regular'][_0x22a9b1(0x18b)][_0x22a9b1(0x16d)]),_0x38373b[_0x22a9b1(0x174)][_0x22a9b1(0x18b)]&&_0x3ff9e9[_0x22a9b1(0x19b)](_0x38373b[_0x22a9b1(0x174)][_0x22a9b1(0x18b)][_0x22a9b1(0x16d)])),_0x38373b;};let scratchSidenessVertexBuffer=null;function createEdgeSidenessVertexBuffer(_0x3c76f9){const _0x542f31=_0x212d1a;if(scratchSidenessVertexBuffer)return scratchSidenessVertexBuffer;let _0x5caef6=new Float32Array(0x8),_0x5e206d=0x0;return _0x5caef6[_0x5e206d++]=0x0,_0x5caef6[_0x5e206d++]=0x0,_0x5caef6[_0x5e206d++]=0x0,_0x5caef6[_0x5e206d++]=0x1,_0x5caef6[_0x5e206d++]=0x1,_0x5caef6[_0x5e206d++]=0x1,_0x5caef6[_0x5e206d++]=0x1,_0x5caef6[_0x5e206d++]=0x0,scratchSidenessVertexBuffer=Cesium['Buffer']['createVertexBuffer']({'context':_0x3c76f9,'typedArray':_0x5caef6,'usage':Cesium[_0x542f31(0x17e)][_0x542f31(0x182)]}),scratchSidenessVertexBuffer['vertexArrayDestroyable']=![],scratchSidenessVertexBuffer;}function createEdgeIndexArray(){let _0x5e4180=new Uint16Array(0x6),_0x4cb995=0x0;return _0x5e4180[_0x4cb995++]=0x2,_0x5e4180[_0x4cb995++]=0x1,_0x5e4180[_0x4cb995++]=0x0,_0x5e4180[_0x4cb995++]=0x3,_0x5e4180[_0x4cb995++]=0x2,_0x5e4180[_0x4cb995++]=0x0,_0x5e4180;}let scratchIndexBuffer=null;function _0x3998(_0x1b057e,_0x46d290){_0x1b057e=_0x1b057e-0x169;let _0x2de65d=_0x2de6[_0x1b057e];return _0x2de65d;}S3MEdgeProcessor[_0x212d1a(0x19e)]=function(_0x3e5f94){const _0x53dd0c=_0x212d1a;if(scratchIndexBuffer)return scratchIndexBuffer;return scratchIndexBuffer=Cesium['Buffer'][_0x53dd0c(0x19e)]({'context':_0x3e5f94,'typedArray':createEdgeIndexArray(),'usage':Cesium[_0x53dd0c(0x17e)][_0x53dd0c(0x182)],'indexDatatype':Cesium[_0x53dd0c(0x1a4)]['UNSIGNED_SHORT']}),scratchIndexBuffer[_0x53dd0c(0x171)]=![],scratchIndexBuffer;},S3MEdgeProcessor[_0x212d1a(0x169)]=function(_0x534877,_0x187cca){const _0x15bc1e=_0x212d1a;if(!_0x187cca[_0x15bc1e(0x18b)]||_0x187cca[_0x15bc1e(0x18b)][_0x15bc1e(0x180)]===0x0)return;let _0x417274={},_0x204bbc=[];_0x187cca[_0x15bc1e(0x186)]=_0x417274,_0x187cca[_0x15bc1e(0x195)]=_0x204bbc;let _0x5e9f07=Cesium[_0x15bc1e(0x190)][_0x15bc1e(0x19f)]({'context':_0x534877,'typedArray':_0x187cca[_0x15bc1e(0x18b)],'usage':Cesium['BufferUsage'][_0x15bc1e(0x182)]});_0x187cca[_0x15bc1e(0x18b)]=null;let _0x58147b=Cesium[_0x15bc1e(0x196)]['getSizeInBytes'](Cesium[_0x15bc1e(0x196)][_0x15bc1e(0x187)]),_0x38f532=createEdgeSidenessVertexBuffer(_0x534877),_0x1cd760=0x0;_0x417274['aSideness']=_0x1cd760++,_0x204bbc[_0x15bc1e(0x19b)]({'index':_0x417274[_0x15bc1e(0x17d)],'vertexBuffer':_0x38f532,'componentsPerAttribute':0x2,'componentDatatype':Cesium[_0x15bc1e(0x196)]['FLOAT'],'offsetInBytes':0x0,'strideInBytes':Cesium[_0x15bc1e(0x196)][_0x15bc1e(0x19c)](Cesium[_0x15bc1e(0x196)][_0x15bc1e(0x187)])*0x2,'normalize':![]});let _0x102942=S3MEdgeProcessor[_0x15bc1e(0x198)],_0x5972ee=0x0;_0x417274[_0x15bc1e(0x177)]=_0x1cd760++,_0x204bbc[_0x15bc1e(0x19b)]({'index':_0x417274['aPosition0'],'vertexBuffer':_0x5e9f07,'componentsPerAttribute':0x3,'componentDatatype':Cesium[_0x15bc1e(0x196)]['FLOAT'],'normalize':![],'offsetInBytes':_0x58147b*_0x5972ee,'strideInBytes':_0x58147b*_0x102942,'instanceDivisor':0x1}),_0x5972ee+=0x3,_0x417274[_0x15bc1e(0x16b)]=_0x1cd760++,_0x204bbc['push']({'index':_0x417274[_0x15bc1e(0x16b)],'vertexBuffer':_0x5e9f07,'componentsPerAttribute':0x3,'componentDatatype':Cesium[_0x15bc1e(0x196)][_0x15bc1e(0x187)],'normalize':![],'offsetInBytes':_0x58147b*_0x5972ee,'strideInBytes':_0x58147b*_0x102942,'instanceDivisor':0x1}),_0x5972ee+=0x3,_0x417274['aNormal']=_0x1cd760++,_0x204bbc[_0x15bc1e(0x19b)]({'index':_0x417274['aNormal'],'vertexBuffer':_0x5e9f07,'componentsPerAttribute':0x3,'componentDatatype':Cesium[_0x15bc1e(0x196)][_0x15bc1e(0x187)],'normalize':!![],'offsetInBytes':_0x58147b*_0x5972ee,'strideInBytes':_0x58147b*_0x102942,'instanceDivisor':0x1}),_0x5972ee+=0x3;},S3MEdgeProcessor[_0x212d1a(0x16a)]=function(_0x47e6c6,_0x2af4aa){const _0x20ed3e=_0x212d1a;if(!_0x2af4aa[_0x20ed3e(0x18b)]||_0x2af4aa['instancesData'][_0x20ed3e(0x180)]==0x0)return;let _0x4498de={},_0x363c92=[];_0x2af4aa[_0x20ed3e(0x186)]=_0x4498de,_0x2af4aa[_0x20ed3e(0x195)]=_0x363c92;let _0x5f660b=Cesium[_0x20ed3e(0x190)][_0x20ed3e(0x19f)]({'context':_0x47e6c6,'typedArray':_0x2af4aa[_0x20ed3e(0x18b)],'usage':Cesium[_0x20ed3e(0x17e)][_0x20ed3e(0x182)]});_0x2af4aa[_0x20ed3e(0x18b)]=null;let _0x198c9a=Cesium[_0x20ed3e(0x196)]['getSizeInBytes'](Cesium[_0x20ed3e(0x196)][_0x20ed3e(0x187)]),_0x32066a=0x0;_0x4498de[_0x20ed3e(0x17d)]=_0x32066a++,_0x363c92[_0x20ed3e(0x19b)]({'index':_0x4498de[_0x20ed3e(0x17d)],'vertexBuffer':createEdgeSidenessVertexBuffer(_0x47e6c6),'componentsPerAttribute':0x2,'componentDatatype':Cesium['ComponentDatatype'][_0x20ed3e(0x187)],'offsetInBytes':0x0,'strideInBytes':_0x198c9a*0x2,'normalize':![]});let _0x25690c=0x3+0x3+0x3+0x3,_0x4305b0=0x0;_0x4498de[_0x20ed3e(0x177)]=_0x32066a++,_0x363c92[_0x20ed3e(0x19b)]({'index':_0x4498de[_0x20ed3e(0x177)],'vertexBuffer':_0x5f660b,'componentsPerAttribute':0x3,'componentDatatype':Cesium[_0x20ed3e(0x196)][_0x20ed3e(0x187)],'normalize':![],'offsetInBytes':_0x198c9a*_0x4305b0,'strideInBytes':_0x198c9a*_0x25690c,'instanceDivisor':0x1}),_0x4305b0+=0x3,_0x4498de[_0x20ed3e(0x16b)]=_0x32066a++,_0x363c92['push']({'index':_0x4498de['aPosition1'],'vertexBuffer':_0x5f660b,'componentsPerAttribute':0x3,'componentDatatype':Cesium[_0x20ed3e(0x196)][_0x20ed3e(0x187)],'normalize':![],'offsetInBytes':_0x198c9a*_0x4305b0,'strideInBytes':_0x198c9a*_0x25690c,'instanceDivisor':0x1}),_0x4305b0+=0x3,_0x4498de['aNormalA']=_0x32066a++,_0x363c92['push']({'index':_0x4498de[_0x20ed3e(0x197)],'vertexBuffer':_0x5f660b,'componentsPerAttribute':0x3,'componentDatatype':Cesium[_0x20ed3e(0x196)][_0x20ed3e(0x187)],'normalize':!![],'offsetInBytes':_0x198c9a*_0x4305b0,'strideInBytes':_0x198c9a*_0x25690c,'instanceDivisor':0x1}),_0x4305b0+=0x3,_0x4498de[_0x20ed3e(0x16f)]=_0x32066a++,_0x363c92['push']({'index':_0x4498de[_0x20ed3e(0x16f)],'vertexBuffer':_0x5f660b,'componentsPerAttribute':0x3,'componentDatatype':Cesium[_0x20ed3e(0x196)][_0x20ed3e(0x187)],'normalize':!![],'offsetInBytes':_0x198c9a*_0x4305b0,'strideInBytes':_0x198c9a*_0x25690c,'instanceDivisor':0x1}),_0x4305b0+=0x3;};S3MEdgeProcessor[_0x212d1a(0x189)]=function(_0x5984be,_0x5108c2,_0x5905ee){const _0x8ad52c=_0x212d1a;let _0x97ff64=_0x5984be[_0x8ad52c(0x192)]['aPosition'],_0xd975a7=_0x5984be[_0x8ad52c(0x1a2)][_0x97ff64],_0x2e0797=_0xd975a7['componentsPerAttribute'],_0x2c1862=new Float32Array(_0xd975a7[_0x8ad52c(0x18a)][_0x8ad52c(0x16d)],_0xd975a7[_0x8ad52c(0x18a)]['byteOffset'],_0xd975a7[_0x8ad52c(0x18a)]['byteLength']/0x4),_0x1ea6bb=_0x2c1862[_0x8ad52c(0x180)]/_0x2e0797;if(_0x5108c2&&_0x5905ee){let _0x1e20f3=MeshProcessing[_0x8ad52c(0x173)](_0x5905ee,_0x1ea6bb);return {'faces':_0x5905ee,'neighbors':_0x1e20f3,'vertices':_0x2c1862,'dim':_0x2e0797};}let _0x5b319e=_0xd975a7[_0x8ad52c(0x18a)][_0x8ad52c(0x16d)],_0x4e40b1;isCompress?_0x4e40b1=_0x2c1862[_0x8ad52c(0x16d)]:_0x4e40b1=_0x5b319e[_0x8ad52c(0x178)](_0xd975a7[_0x8ad52c(0x18a)][_0x8ad52c(0x19a)],_0xd975a7[_0x8ad52c(0x18a)][_0x8ad52c(0x19a)]+_0xd975a7['typedArray'][_0x8ad52c(0x172)]);let _0x57463e=MeshProcessing[_0x8ad52c(0x16c)](_0x4e40b1,_0x2e0797),_0x10779e=S3MEdgeProcessor[_0x8ad52c(0x193)](_0x57463e['indices'],_0x5905ee),_0x17adaa=MeshProcessing['computeNeighbors'](_0x10779e,_0x57463e[_0x8ad52c(0x18c)]),_0x28f8f8=new Float32Array(_0x57463e[_0x8ad52c(0x16d)]);return {'faces':_0x10779e,'neighbors':_0x17adaa,'vertices':_0x28f8f8,'dim':_0x2e0797};},S3MEdgeProcessor[_0x212d1a(0x193)]=function(_0xf2e11a,_0x33f5d7){const _0x4c73a2=_0x212d1a;if(_0x33f5d7){_0x33f5d7=_0x33f5d7[_0x4c73a2(0x178)]();for(let _0x532611=0x0;_0x532611<_0x33f5d7[_0x4c73a2(0x180)];_0x532611++){_0x33f5d7[_0x532611]=_0xf2e11a[_0x33f5d7[_0x532611]];}return _0x33f5d7;}return _0xf2e11a;};let scratchV0=new Cesium[(_0x212d1a(0x184))](),scratchV1=new Cesium['Cartesian3'](),scratchV2=new Cesium[(_0x212d1a(0x184))](),scratchV3=new Cesium['Cartesian3'](),scratchN0=new Cesium['Cartesian3'](),scratchN1=new Cesium[(_0x212d1a(0x184))](),scratchN2=new Cesium[(_0x212d1a(0x184))](),scratchN3=new Cesium[(_0x212d1a(0x184))]();S3MEdgeProcessor['createEdgeDataByIndices']=function(_0x5da5d8,_0x3d1676){const _0x4bf419=_0x212d1a;let _0x195688=_0x5da5d8[_0x4bf419(0x192)][_0x4bf419(0x18f)],_0x47fcbd=_0x5da5d8[_0x4bf419(0x1a2)][_0x195688],_0x1f219f=_0x47fcbd[_0x4bf419(0x175)],_0x4011e8=new Float32Array(_0x47fcbd[_0x4bf419(0x18a)][_0x4bf419(0x16d)],_0x47fcbd[_0x4bf419(0x18a)][_0x4bf419(0x19a)],_0x47fcbd[_0x4bf419(0x18a)][_0x4bf419(0x172)]/0x4);let _0x2fea57;_0x3d1676[_0x4bf419(0x1a3)]===0x0?_0x2fea57=new Uint16Array(_0x3d1676[_0x4bf419(0x18e)]['buffer'],_0x3d1676['indicesTypedArray'][_0x4bf419(0x19a)],_0x3d1676[_0x4bf419(0x18e)][_0x4bf419(0x172)]/0x2):_0x2fea57=new Uint32Array(_0x3d1676['indicesTypedArray']['buffer'],_0x3d1676['indicesTypedArray']['byteOffset'],_0x3d1676[_0x4bf419(0x18e)][_0x4bf419(0x172)]/0x4);let _0xd2ac02=[],_0x585c59=[],_0x25d1bd=_0x2fea57['length'],_0x45c401=0x0;for(let _0x18733c=0x0,_0x3b2623=Math[_0x4bf419(0x185)](_0x25d1bd/0x4)*0x4;_0x18733c<_0x3b2623;_0x18733c+=0x4){let _0x402f8f=_0x2fea57[_0x18733c],_0x3d00a8=_0x2fea57[_0x18733c+0x1],_0x574891=_0x2fea57[_0x18733c+0x2],_0x52bef0=_0x2fea57[_0x18733c+0x3];scratchV0['x']=_0x4011e8[_0x1f219f*_0x402f8f],scratchV0['y']=_0x4011e8[_0x1f219f*_0x402f8f+0x1],scratchV0['z']=_0x4011e8[_0x1f219f*_0x402f8f+0x2],scratchV1['x']=_0x4011e8[_0x1f219f*_0x3d00a8],scratchV1['y']=_0x4011e8[_0x1f219f*_0x3d00a8+0x1],scratchV1['z']=_0x4011e8[_0x1f219f*_0x3d00a8+0x2],scratchV2['x']=_0x4011e8[_0x1f219f*_0x574891],scratchV2['y']=_0x4011e8[_0x1f219f*_0x574891+0x1],scratchV2['z']=_0x4011e8[_0x1f219f*_0x574891+0x2],scratchV3['x']=_0x4011e8[_0x1f219f*_0x52bef0],scratchV3['y']=_0x4011e8[_0x1f219f*_0x52bef0+0x1],scratchV3['z']=_0x4011e8[_0x1f219f*_0x52bef0+0x2];if(Cesium['Cartesian3']['equals'](scratchV1,scratchV2)||Cesium[_0x4bf419(0x184)][_0x4bf419(0x191)](scratchV1,scratchV3)||Cesium[_0x4bf419(0x184)][_0x4bf419(0x191)](scratchV1,scratchV0)||Cesium[_0x4bf419(0x184)]['equals'](scratchV2,scratchV0)||Cesium['Cartesian3'][_0x4bf419(0x191)](scratchV3,scratchV0))continue;if(_0x574891===_0x52bef0){Cesium[_0x4bf419(0x184)][_0x4bf419(0x17b)](scratchV1,scratchV0,scratchN0),Cesium['Cartesian3']['subtract'](scratchV2,scratchV0,scratchN1),Cesium[_0x4bf419(0x184)][_0x4bf419(0x181)](scratchN0,scratchN1,scratchN0);if(Cesium[_0x4bf419(0x184)][_0x4bf419(0x191)](scratchN0,Cesium[_0x4bf419(0x184)][_0x4bf419(0x1a7)]))continue;Cesium[_0x4bf419(0x184)][_0x4bf419(0x183)](scratchN0,scratchN0),_0xd2ac02['push'](scratchV0['x']),_0xd2ac02[_0x4bf419(0x19b)](scratchV0['y']),_0xd2ac02['push'](scratchV0['z']),_0xd2ac02[_0x4bf419(0x19b)](scratchV1['x']),_0xd2ac02[_0x4bf419(0x19b)](scratchV1['y']),_0xd2ac02[_0x4bf419(0x19b)](scratchV1['z']),_0xd2ac02[_0x4bf419(0x19b)](scratchN0['x']),_0xd2ac02['push'](scratchN0['y']),_0xd2ac02[_0x4bf419(0x19b)](scratchN0['z']);}else {Cesium[_0x4bf419(0x184)][_0x4bf419(0x17b)](scratchV1,scratchV0,scratchN0),Cesium[_0x4bf419(0x184)][_0x4bf419(0x17b)](scratchV2,scratchV0,scratchN1),Cesium[_0x4bf419(0x184)][_0x4bf419(0x181)](scratchN0,scratchN1,scratchN0);if(Cesium[_0x4bf419(0x184)][_0x4bf419(0x191)](scratchN0,Cesium[_0x4bf419(0x184)][_0x4bf419(0x1a7)]))continue;Cesium[_0x4bf419(0x184)][_0x4bf419(0x183)](scratchN0,scratchN0),Cesium[_0x4bf419(0x184)][_0x4bf419(0x17b)](scratchV1,scratchV0,scratchN2),Cesium[_0x4bf419(0x184)][_0x4bf419(0x17b)](scratchV3,scratchV0,scratchN3),Cesium[_0x4bf419(0x184)][_0x4bf419(0x181)](scratchN2,scratchN3,scratchN2);if(Cesium[_0x4bf419(0x184)][_0x4bf419(0x191)](scratchN2,Cesium[_0x4bf419(0x184)][_0x4bf419(0x1a7)]))continue;Cesium['Cartesian3'][_0x4bf419(0x183)](scratchN2,scratchN2),_0x585c59['push'](scratchV0['x']),_0x585c59[_0x4bf419(0x19b)](scratchV0['y']),_0x585c59['push'](scratchV0['z']),_0x585c59['push'](scratchV1['x']),_0x585c59[_0x4bf419(0x19b)](scratchV1['y']),_0x585c59[_0x4bf419(0x19b)](scratchV1['z']),_0x585c59[_0x4bf419(0x19b)](scratchN0['x']),_0x585c59[_0x4bf419(0x19b)](scratchN0['y']),_0x585c59[_0x4bf419(0x19b)](scratchN0['z']),_0x585c59[_0x4bf419(0x19b)](scratchN2['x']),_0x585c59[_0x4bf419(0x19b)](scratchN2['y']),_0x585c59[_0x4bf419(0x19b)](scratchN2['z']);}_0x45c401+=Cesium[_0x4bf419(0x184)]['distance'](scratchV0,scratchV1);}let _0x544d63=_0x25d1bd/0x4,_0x346d76=_0x45c401/_0x544d63,_0x29d14a=_0xd2ac02['length']/S3MEdgeProcessor[_0x4bf419(0x198)],_0x202096=_0x585c59[_0x4bf419(0x180)]/0xc;return {'regular':{'instancesData':new Float32Array(_0xd2ac02),'instanceCount':_0x29d14a,'edgeLength':_0x29d14a*_0x346d76},'silhouette':{'instancesData':new Float32Array(_0x585c59),'instanceCount':_0x202096,'edgeLength':_0x202096},'averageEdgeLength':_0x346d76};};

    const _0x39ed=['length','getFloat32','instanceMode','texCoordZMatrix','textureCoordIsW','indicesCount','childTile','unpack','uv2','replace','instanceIds','verticesCount','aNormal','482829KAiqnq','PixelFormat','groupNode','green','Geometry','materialCode','uv6','texCoordCompressConstant','createEdgeDataByIndices','geoPackage','rangeMode','instanceCount','RGB_DXT1','UNSIGNED_BYTE','vertexColor','compressOptions','minVerticesValue','aSecondColor','SVC_Normal','secondary_colour','skeletonNames','arrayFill','push','22998WjYafi','31019SQJhTi','RGB','slice','SV_Compressed','minTexCoordValue','3179LmwCQF','version','RGBA_DXT5','520970HGtNTS','getUint16','primitiveType','getStringFromTypedArray','uv4','FLOAT','indexType','rangeList','BYTES_PER_ELEMENT','materials','getUint32','getUint8','uv3','SVC_TexutreCoord','uv5','buffer','vertexColorInstance','uv9','string','1447552rmtcfo','SVC_TexutreCoordIsW','1138660IwxDuu','vertexAttributes','bytesOffset','blue','getFloat64','aPosition','uv1','ComponentDatatype','instanceBuffer','parseBuffer','aTexCoordZ','6LfwfTb','instanceBounds','attrLocation','instanceId','vertexPackage','411VSRmzD','Color','indexOf','SVC_Vertex','inflate'];const _0x5254d4=_0x49e3;function _0x49e3(_0x196265,_0x2b1840){_0x196265=_0x196265-0x173;let _0x39eded=_0x39ed[_0x196265];return _0x39eded;}(function(_0x27a497,_0x4ea7d1){const _0x1170d2=_0x49e3;while(!![]){try{const _0x16f026=-parseInt(_0x1170d2(0x18c))+parseInt(_0x1170d2(0x199))*-parseInt(_0x1170d2(0x1c8))+parseInt(_0x1170d2(0x176))*parseInt(_0x1170d2(0x19e))+-parseInt(_0x1170d2(0x179))+parseInt(_0x1170d2(0x18e))+parseInt(_0x1170d2(0x1b0))+-parseInt(_0x1170d2(0x1c7));if(_0x16f026===_0x4ea7d1)break;else _0x27a497['push'](_0x27a497['shift']());}catch(_0x2669e1){_0x27a497['push'](_0x27a497['shift']());}}}(_0x39ed,0xb7358));function S3ModelParser(){}let S3MBVertexTag={'SV_Unkown':0x0,'SV_Standard':0x1,'SV_Compressed':0x2};function unZip(_0x27415a,_0x43bdaa){const _0x348d93=_0x49e3;let _0x533ecc=new Uint8Array(_0x27415a,_0x43bdaa);return _0x1a0f6f[_0x348d93(0x1a2)](_0x533ecc)[_0x348d93(0x188)];}function parseString(_0x151dce,_0xa2303d,_0x450489){const _0xaf4218=_0x49e3;let _0x3873b8=_0xa2303d[_0xaf4218(0x183)](_0x450489,!![]);_0x450489+=Uint32Array['BYTES_PER_ELEMENT'];let _0x502039=new Uint8Array(_0x151dce,_0x450489,_0x3873b8),_0x203e68=Cesium[_0xaf4218(0x17c)](_0x502039);return _0x450489+=_0x3873b8,{'string':_0x203e68,'bytesOffset':_0x450489};}function parseGeode(_0x5367a2,_0x3050e2,_0x4ce275,_0xee218e){const _0x2fdbc2=_0x49e3;let _0x390d36={},_0x1c6a10=[],_0x44c3e4=new Array(0x10);for(let _0x5a7b17=0x0;_0x5a7b17<0x10;_0x5a7b17++){_0x44c3e4[_0x5a7b17]=_0x3050e2[_0x2fdbc2(0x192)](_0x4ce275,!![]),_0x4ce275+=Float64Array[_0x2fdbc2(0x181)];}_0x390d36['matrix']=_0x44c3e4,_0x390d36[_0x2fdbc2(0x1c4)]=_0x1c6a10;let _0x200f4f=_0x3050e2[_0x2fdbc2(0x183)](_0x4ce275,!![]);_0x4ce275+=Uint32Array[_0x2fdbc2(0x181)];for(let _0x31c94e=0x0;_0x31c94e<_0x200f4f;_0x31c94e++){let _0x2c0b6b=parseString(_0x5367a2,_0x3050e2,_0x4ce275);_0x1c6a10[_0x2fdbc2(0x1c6)](_0x2c0b6b[_0x2fdbc2(0x18b)]),_0x4ce275=_0x2c0b6b[_0x2fdbc2(0x190)];}return _0xee218e[_0x2fdbc2(0x1c6)](_0x390d36),_0x4ce275;}function parsePageLOD(_0x52c560,_0x105d45,_0x34ccaa,_0xaecb5){const _0x115cad=_0x49e3;let _0x4aef85={};_0x4aef85[_0x115cad(0x180)]=_0x105d45['getFloat32'](_0x34ccaa,!![]),_0x34ccaa+=Float32Array[_0x115cad(0x181)],_0x4aef85[_0x115cad(0x1ba)]=_0x105d45[_0x115cad(0x17a)](_0x34ccaa,!![]),_0x34ccaa+=Uint16Array[_0x115cad(0x181)];let _0x4592a1={};_0x4592a1['x']=_0x105d45[_0x115cad(0x192)](_0x34ccaa,!![]),_0x34ccaa+=Float64Array[_0x115cad(0x181)],_0x4592a1['y']=_0x105d45[_0x115cad(0x192)](_0x34ccaa,!![]),_0x34ccaa+=Float64Array[_0x115cad(0x181)],_0x4592a1['z']=_0x105d45[_0x115cad(0x192)](_0x34ccaa,!![]),_0x34ccaa+=Float64Array['BYTES_PER_ELEMENT'];let _0x372451=_0x105d45[_0x115cad(0x192)](_0x34ccaa,!![]);_0x34ccaa+=Float64Array[_0x115cad(0x181)],_0x4aef85['boundingSphere']={'center':_0x4592a1,'radius':_0x372451};let _0x3e0f11=parseString(_0x52c560,_0x105d45,_0x34ccaa),_0x28e146=_0x3e0f11[_0x115cad(0x18b)];_0x34ccaa=_0x3e0f11[_0x115cad(0x190)];let _0x355906=_0x28e146[_0x115cad(0x1a0)](_0x115cad(0x1b4));if(_0x355906!==-0x1){let _0x210190=_0x28e146['substring'](_0x355906);_0x28e146=_0x28e146[_0x115cad(0x1ac)](_0x210190,'');}_0x4aef85[_0x115cad(0x1a9)]=_0x28e146,_0x4aef85['geodes']=[];let _0x2351b4=_0x105d45[_0x115cad(0x183)](_0x34ccaa,!![]);_0x34ccaa+=Uint32Array[_0x115cad(0x181)];for(let _0x19b0c9=0x0;_0x19b0c9<_0x2351b4;_0x19b0c9++){_0x34ccaa=parseGeode(_0x52c560,_0x105d45,_0x34ccaa,_0x4aef85['geodes']);}return _0xaecb5[_0x115cad(0x1c6)](_0x4aef85),_0x34ccaa;}function parseGroupNode(_0x3cbd28,_0x436efe,_0x2c6b93,_0x37958f){const _0x5667d6=_0x49e3;let _0x4595d8={},_0x35f238=[],_0x2f7f40=_0x436efe[_0x5667d6(0x183)](_0x2c6b93,!![]);_0x2c6b93+=Uint32Array[_0x5667d6(0x181)];let _0x2f3c1e=_0x436efe['getUint32'](_0x2c6b93,!![]);_0x2c6b93+=Uint32Array[_0x5667d6(0x181)];for(let _0x35cb8a=0x0;_0x35cb8a<_0x2f3c1e;_0x35cb8a++){_0x2c6b93=parsePageLOD(_0x3cbd28,_0x436efe,_0x2c6b93,_0x35f238);}_0x4595d8['pageLods']=_0x35f238;let _0x2e87bd=_0x2c6b93%0x4;return _0x2e87bd!==0x0&&(_0x2c6b93+=0x4-_0x2e87bd),_0x37958f[_0x5667d6(0x1b2)]=_0x4595d8,_0x2c6b93;}function parseVertex(_0x4e24ec,_0x343517,_0x57fd18,_0x34b887){const _0x372e38=_0x49e3;let _0x61354f=_0x343517['getUint32'](_0x57fd18,!![]);_0x34b887[_0x372e38(0x1ae)]=_0x61354f,_0x57fd18+=Uint32Array[_0x372e38(0x181)];if(_0x57fd18<=0x0)return _0x57fd18;let _0x567ff2=_0x343517[_0x372e38(0x17a)](_0x57fd18,!![]);_0x57fd18+=Uint16Array[_0x372e38(0x181)];let _0x41e00e=_0x343517[_0x372e38(0x17a)](_0x57fd18,!![]);_0x41e00e=_0x567ff2*Float32Array[_0x372e38(0x181)],_0x57fd18+=Uint16Array['BYTES_PER_ELEMENT'];let _0x8204da=_0x61354f*_0x567ff2*Float32Array[_0x372e38(0x181)],_0xd87c1e=new Uint8Array(_0x4e24ec,_0x57fd18,_0x8204da);_0x57fd18+=_0x8204da;let _0x18d19b=_0x34b887[_0x372e38(0x18f)],_0x328d68=_0x34b887[_0x372e38(0x19b)];return _0x328d68[_0x372e38(0x193)]=_0x18d19b[_0x372e38(0x1a3)],_0x18d19b[_0x372e38(0x1c6)]({'index':_0x328d68['aPosition'],'typedArray':_0xd87c1e,'componentsPerAttribute':_0x567ff2,'componentDatatype':Cesium[_0x372e38(0x195)][_0x372e38(0x17e)],'offsetInBytes':0x0,'strideInBytes':_0x41e00e,'normalize':![]}),_0x57fd18;}function parseNormal(_0xbf3d9a,_0x554a91,_0x50af5c,_0x1361b3){const _0xf5b3d3=_0x49e3;let _0x5f4adf=_0x554a91[_0xf5b3d3(0x183)](_0x50af5c,!![]);_0x50af5c+=Uint32Array['BYTES_PER_ELEMENT'];if(_0x5f4adf<=0x0)return _0x50af5c;let _0x3ee646=_0x554a91['getUint16'](_0x50af5c,!![]);_0x50af5c+=Uint16Array[_0xf5b3d3(0x181)];let _0x237153=_0x554a91[_0xf5b3d3(0x17a)](_0x50af5c,!![]);_0x50af5c+=Uint16Array[_0xf5b3d3(0x181)];let _0x2015f9=_0x5f4adf*_0x3ee646*Float32Array['BYTES_PER_ELEMENT'],_0x600f67=new Uint8Array(_0xbf3d9a,_0x50af5c,_0x2015f9);_0x50af5c+=_0x2015f9;let _0x38ef22=_0x1361b3[_0xf5b3d3(0x18f)],_0x1de0c3=_0x1361b3[_0xf5b3d3(0x19b)];return _0x1de0c3[_0xf5b3d3(0x1af)]=_0x38ef22['length'],_0x38ef22['push']({'index':_0x1de0c3[_0xf5b3d3(0x1af)],'typedArray':_0x600f67,'componentsPerAttribute':_0x3ee646,'componentDatatype':Cesium['ComponentDatatype']['FLOAT'],'offsetInBytes':0x0,'strideInBytes':_0x237153,'normalize':![]}),_0x50af5c;}function parseVertexColor(_0x330975,_0x481078,_0x1d1e0f,_0x4b9571){const _0xe0a07c=_0x49e3;let _0x2cd475=_0x481078[_0xe0a07c(0x183)](_0x1d1e0f,!![]);_0x1d1e0f+=Uint32Array[_0xe0a07c(0x181)];let _0x34d12c=_0x4b9571['verticesCount'],_0x2bbace;if(_0x2cd475>0x0){let _0x86f968=_0x481078[_0xe0a07c(0x17a)](_0x1d1e0f,!![]);_0x1d1e0f+=Uint16Array['BYTES_PER_ELEMENT'],_0x1d1e0f+=Uint8Array[_0xe0a07c(0x181)]*0x2;let _0x410e4e=_0x2cd475*Uint8Array[_0xe0a07c(0x181)]*0x4,_0x4726ea=new Uint8Array(_0x330975,_0x1d1e0f,_0x410e4e);_0x2bbace=_0x4726ea[_0xe0a07c(0x173)](0x0,_0x410e4e),_0x1d1e0f+=_0x410e4e;}else {_0x2bbace=new Uint8Array(0x4*_0x34d12c);for(let _0x476a24=0x0;_0x476a24<_0x34d12c;_0x476a24++){_0x2bbace[_0x476a24*0x4]=0xff,_0x2bbace[_0x476a24*0x4+0x1]=0xff,_0x2bbace[_0x476a24*0x4+0x2]=0xff,_0x2bbace[_0x476a24*0x4+0x3]=0xff;}}let _0xcec113=_0x4b9571['vertexAttributes'],_0x123911=_0x4b9571[_0xe0a07c(0x19b)];return _0x123911['aColor']=_0xcec113[_0xe0a07c(0x1a3)],_0xcec113[_0xe0a07c(0x1c6)]({'index':_0x123911['aColor'],'typedArray':_0x2bbace,'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0xe0a07c(0x195)][_0xe0a07c(0x1bd)],'offsetInBytes':0x0,'strideInBytes':0x4,'normalize':!![]}),_0x4b9571[_0xe0a07c(0x1be)]=_0x2bbace,_0x1d1e0f;}function parseSecondColor(_0x4b41db,_0x3e3ede,_0x457d99,_0x926f89){const _0x111584=_0x49e3;let _0x5c6a72=_0x3e3ede[_0x111584(0x183)](_0x457d99,!![]);_0x457d99+=Uint32Array['BYTES_PER_ELEMENT'];if(_0x5c6a72<=0x0)return _0x457d99;let _0x54d8a0=_0x3e3ede['getUint16'](_0x457d99,!![]);_0x457d99+=Uint16Array[_0x111584(0x181)],_0x457d99+=Uint8Array[_0x111584(0x181)]*0x2;let _0xa0d981=_0x5c6a72*Uint8Array[_0x111584(0x181)]*0x4,_0x5469c3=new Uint8Array(_0x4b41db,_0x457d99,_0xa0d981);_0x457d99+=_0xa0d981;let _0x61a6bc=_0x926f89['vertexAttributes'],_0x504d7d=_0x926f89[_0x111584(0x19b)];return _0x504d7d[_0x111584(0x1c1)]=_0x61a6bc[_0x111584(0x1a3)],_0x61a6bc[_0x111584(0x1c6)]({'index':_0x504d7d['aSecondColor'],'typedArray':_0x5469c3,'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x111584(0x195)][_0x111584(0x1bd)],'offsetInBytes':0x0,'strideInBytes':0x4,'normalize':!![]}),_0x457d99;}function parseTexCoord(_0x270e88,_0x21e476,_0x263aac,_0x50fe02){const _0x6b4953=_0x49e3;let _0x383c3c=_0x21e476[_0x6b4953(0x17a)](_0x263aac,!![]);_0x263aac+=Uint16Array['BYTES_PER_ELEMENT'],_0x263aac+=Uint16Array['BYTES_PER_ELEMENT'];for(let _0x5d7a9d=0x0;_0x5d7a9d<_0x383c3c;_0x5d7a9d++){let _0xb99cca=_0x21e476[_0x6b4953(0x183)](_0x263aac,!![]);_0x263aac+=Uint32Array[_0x6b4953(0x181)];let _0x3222b9=_0x21e476[_0x6b4953(0x17a)](_0x263aac,!![]);_0x263aac+=Uint16Array['BYTES_PER_ELEMENT'];let _0x338998=_0x21e476[_0x6b4953(0x17a)](_0x263aac,!![]);_0x263aac+=Uint16Array[_0x6b4953(0x181)];let _0x4d495f=_0xb99cca*_0x3222b9*Float32Array[_0x6b4953(0x181)],_0x530b4a=new Uint8Array(_0x270e88,_0x263aac,_0x4d495f);_0x263aac+=_0x4d495f;let _0x2d5df2='aTexCoord'+_0x5d7a9d,_0x486e05=_0x50fe02[_0x6b4953(0x18f)],_0x101b5b=_0x50fe02[_0x6b4953(0x19b)];_0x101b5b[_0x2d5df2]=_0x486e05['length'],_0x486e05[_0x6b4953(0x1c6)]({'index':_0x101b5b[_0x2d5df2],'typedArray':_0x530b4a,'componentsPerAttribute':_0x3222b9,'componentDatatype':Cesium[_0x6b4953(0x195)][_0x6b4953(0x17e)],'offsetInBytes':0x0,'strideInBytes':_0x3222b9*Float32Array[_0x6b4953(0x181)],'normalize':![]});}return _0x263aac;}function parseInstanceInfo(_0x4a3abc,_0x51c879,_0x1f76c0,_0x371096){const _0x5b4091=_0x49e3;let _0x223fdf=_0x51c879[_0x5b4091(0x17a)](_0x1f76c0,!![]);_0x1f76c0+=Uint16Array[_0x5b4091(0x181)],_0x1f76c0+=Uint16Array[_0x5b4091(0x181)];let _0x42d735=_0x371096[_0x5b4091(0x18f)],_0x42aea0=_0x371096[_0x5b4091(0x19b)];for(let _0x32dae5=0x0;_0x32dae5<_0x223fdf;_0x32dae5++){let _0x81a3ae=_0x51c879[_0x5b4091(0x183)](_0x1f76c0,!![]);_0x1f76c0+=Uint32Array[_0x5b4091(0x181)];let _0x2bacc7=_0x51c879['getUint16'](_0x1f76c0,!![]);_0x1f76c0+=Uint16Array[_0x5b4091(0x181)];let _0x2c8cce=_0x51c879[_0x5b4091(0x17a)](_0x1f76c0,!![]);_0x1f76c0+=Uint16Array[_0x5b4091(0x181)];let _0x227128=_0x81a3ae*_0x2bacc7*Float32Array[_0x5b4091(0x181)];if(_0x2bacc7===0x11||_0x2bacc7===0x1d){let _0x593b87=new Uint8Array(_0x4a3abc,_0x1f76c0,_0x227128);_0x371096[_0x5b4091(0x1bb)]=_0x81a3ae,_0x371096[_0x5b4091(0x1a5)]=_0x2bacc7,_0x371096[_0x5b4091(0x196)]=_0x593b87,_0x371096['instanceIndex']=0x1;let _0x44ffe2=_0x2bacc7*_0x81a3ae*0x4,_0x3279d8=_0x593b87[_0x5b4091(0x173)](0x0,_0x44ffe2);_0x371096[_0x5b4091(0x189)]=_0x3279d8;let _0x358766;if(_0x2bacc7===0x11)_0x358766=Float32Array['BYTES_PER_ELEMENT']*0x11,_0x42aea0['uv2']=_0x42d735[_0x5b4091(0x1a3)],_0x42d735[_0x5b4091(0x1c6)]({'index':_0x42aea0[_0x5b4091(0x1ab)],'componentsPerAttribute':0x4,'componentDatatype':Cesium['ComponentDatatype'][_0x5b4091(0x17e)],'normalize':![],'offsetInBytes':0x0,'strideInBytes':_0x358766,'instanceDivisor':0x1}),_0x42aea0[_0x5b4091(0x185)]=_0x42d735[_0x5b4091(0x1a3)],_0x42d735[_0x5b4091(0x1c6)]({'index':_0x42aea0[_0x5b4091(0x185)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x5b4091(0x195)][_0x5b4091(0x17e)],'normalize':![],'offsetInBytes':0x4*Float32Array['BYTES_PER_ELEMENT'],'strideInBytes':_0x358766,'instanceDivisor':0x1}),_0x42aea0['uv4']=_0x42d735[_0x5b4091(0x1a3)],_0x42d735[_0x5b4091(0x1c6)]({'index':_0x42aea0[_0x5b4091(0x17d)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x5b4091(0x195)][_0x5b4091(0x17e)],'normalize':![],'offsetInBytes':0x8*Float32Array['BYTES_PER_ELEMENT'],'strideInBytes':_0x358766,'instanceDivisor':0x1}),_0x42aea0[_0x5b4091(0x1c3)]=_0x42d735[_0x5b4091(0x1a3)],_0x42d735['push']({'index':_0x42aea0[_0x5b4091(0x1c3)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x5b4091(0x195)][_0x5b4091(0x17e)],'normalize':![],'offsetInBytes':0xc*Float32Array[_0x5b4091(0x181)],'strideInBytes':_0x358766,'instanceDivisor':0x1}),_0x42aea0[_0x5b4091(0x1b6)]=_0x42d735[_0x5b4091(0x1a3)],_0x42d735[_0x5b4091(0x1c6)]({'index':_0x42aea0[_0x5b4091(0x1b6)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x5b4091(0x195)]['UNSIGNED_BYTE'],'normalize':!![],'offsetInBytes':0x10*Float32Array[_0x5b4091(0x181)],'strideInBytes':_0x358766,'instanceDivisor':0x1});else _0x2bacc7===0x1d&&(_0x358766=Float32Array[_0x5b4091(0x181)]*0x1d,_0x42aea0['uv1']=_0x42d735['length'],_0x42d735[_0x5b4091(0x1c6)]({'index':_0x42aea0[_0x5b4091(0x194)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x5b4091(0x195)][_0x5b4091(0x17e)],'normalize':![],'offsetInBytes':0x0,'strideInBytes':_0x358766,'instanceDivisor':0x1,'byteLength':_0x227128}),_0x42aea0[_0x5b4091(0x1ab)]=_0x42d735[_0x5b4091(0x1a3)],_0x42d735[_0x5b4091(0x1c6)]({'index':_0x42aea0[_0x5b4091(0x1ab)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x5b4091(0x195)][_0x5b4091(0x17e)],'normalize':![],'offsetInBytes':0x4*Float32Array[_0x5b4091(0x181)],'strideInBytes':_0x358766,'instanceDivisor':0x1}),_0x42aea0[_0x5b4091(0x185)]=_0x42d735[_0x5b4091(0x1a3)],_0x42d735[_0x5b4091(0x1c6)]({'index':_0x42aea0['uv3'],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x5b4091(0x195)][_0x5b4091(0x17e)],'normalize':![],'offsetInBytes':0x8*Float32Array[_0x5b4091(0x181)],'strideInBytes':_0x358766,'instanceDivisor':0x1}),_0x42aea0[_0x5b4091(0x17d)]=_0x42d735[_0x5b4091(0x1a3)],_0x42d735['push']({'index':_0x42aea0[_0x5b4091(0x17d)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x5b4091(0x195)][_0x5b4091(0x17e)],'normalize':![],'offsetInBytes':0xc*Float32Array[_0x5b4091(0x181)],'strideInBytes':_0x358766,'instanceDivisor':0x1}),_0x42aea0[_0x5b4091(0x187)]=_0x42d735[_0x5b4091(0x1a3)],_0x42d735[_0x5b4091(0x1c6)]({'index':_0x42aea0[_0x5b4091(0x187)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x5b4091(0x195)][_0x5b4091(0x17e)],'normalize':![],'offsetInBytes':0x10*Float32Array[_0x5b4091(0x181)],'strideInBytes':_0x358766,'instanceDivisor':0x1}),_0x42aea0[_0x5b4091(0x1b6)]=_0x42d735[_0x5b4091(0x1a3)],_0x42d735[_0x5b4091(0x1c6)]({'index':_0x42aea0[_0x5b4091(0x1b6)],'componentsPerAttribute':0x4,'componentDatatype':Cesium['ComponentDatatype']['FLOAT'],'normalize':![],'offsetInBytes':0x14*Float32Array[_0x5b4091(0x181)],'strideInBytes':_0x358766,'instanceDivisor':0x1}),_0x42aea0['uv7']=_0x42d735[_0x5b4091(0x1a3)],_0x42d735[_0x5b4091(0x1c6)]({'index':_0x42aea0['uv7'],'componentsPerAttribute':0x3,'componentDatatype':Cesium[_0x5b4091(0x195)][_0x5b4091(0x17e)],'normalize':![],'offsetInBytes':0x18*Float32Array[_0x5b4091(0x181)],'strideInBytes':_0x358766,'instanceDivisor':0x1}),_0x42aea0[_0x5b4091(0x1c3)]=_0x42d735[_0x5b4091(0x1a3)],_0x42d735['push']({'index':_0x42aea0[_0x5b4091(0x1c3)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x5b4091(0x195)]['UNSIGNED_BYTE'],'normalize':!![],'offsetInBytes':0x1b*Float32Array[_0x5b4091(0x181)],'strideInBytes':_0x358766,'instanceDivisor':0x1}),_0x42aea0['uv9']=_0x42d735[_0x5b4091(0x1a3)],_0x42d735['push']({'index':_0x42aea0[_0x5b4091(0x18a)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x5b4091(0x195)][_0x5b4091(0x1bd)],'normalize':!![],'offsetInBytes':0x1c*Float32Array[_0x5b4091(0x181)],'strideInBytes':_0x358766,'instanceDivisor':0x1}));}else {let _0x5eb885=_0x81a3ae*_0x2bacc7;_0x371096[_0x5b4091(0x19a)]=new Float32Array(_0x5eb885);for(let _0x4a440e=0x0;_0x4a440e<_0x5eb885;_0x4a440e++){_0x371096[_0x5b4091(0x19a)][_0x4a440e]=_0x51c879[_0x5b4091(0x1a4)](_0x1f76c0+_0x4a440e*Float32Array['BYTES_PER_ELEMENT'],!![]);}}_0x1f76c0+=_0x227128;}return _0x1f76c0;}function parseCompressVertex(_0x3fa114,_0x428838,_0x26fde3,_0x589640){const _0xad2663=_0x49e3;let _0x551e2a=_0x428838[_0xad2663(0x183)](_0x26fde3,!![]);_0x589640[_0xad2663(0x1ae)]=_0x551e2a,_0x26fde3+=Uint32Array['BYTES_PER_ELEMENT'];if(_0x26fde3<=0x0)return _0x26fde3;let _0x2a5fac=_0x428838[_0xad2663(0x17a)](_0x26fde3,!![]);_0x26fde3+=Uint16Array['BYTES_PER_ELEMENT'];let _0x1c68fe=_0x428838[_0xad2663(0x17a)](_0x26fde3,!![]);_0x1c68fe=_0x2a5fac*Int16Array[_0xad2663(0x181)],_0x26fde3+=Uint16Array[_0xad2663(0x181)];let _0x5c2a58=_0x428838[_0xad2663(0x1a4)](_0x26fde3,!![]);_0x26fde3+=Float32Array[_0xad2663(0x181)];let _0x3e025b={};_0x3e025b['x']=_0x428838[_0xad2663(0x1a4)](_0x26fde3,!![]),_0x26fde3+=Float32Array[_0xad2663(0x181)],_0x3e025b['y']=_0x428838[_0xad2663(0x1a4)](_0x26fde3,!![]),_0x26fde3+=Float32Array['BYTES_PER_ELEMENT'],_0x3e025b['z']=_0x428838[_0xad2663(0x1a4)](_0x26fde3,!![]),_0x26fde3+=Float32Array[_0xad2663(0x181)],_0x3e025b['w']=_0x428838['getFloat32'](_0x26fde3,!![]),_0x26fde3+=Float32Array[_0xad2663(0x181)],_0x589640['vertCompressConstant']=_0x5c2a58,_0x589640[_0xad2663(0x1c0)]=_0x3e025b;let _0x473efd=_0x551e2a*_0x2a5fac*Int16Array['BYTES_PER_ELEMENT'],_0x2fcf8b=new Uint8Array(_0x3fa114,_0x26fde3,_0x473efd);_0x26fde3+=_0x473efd;let _0x43c031=_0x589640['vertexAttributes'],_0x570bde=_0x589640[_0xad2663(0x19b)];return _0x570bde[_0xad2663(0x193)]=_0x43c031[_0xad2663(0x1a3)],_0x43c031[_0xad2663(0x1c6)]({'index':_0x570bde['aPosition'],'typedArray':_0x2fcf8b,'componentsPerAttribute':_0x2a5fac,'componentDatatype':Cesium[_0xad2663(0x195)]['SHORT'],'offsetInBytes':0x0,'strideInBytes':_0x1c68fe,'normalize':![]}),_0x26fde3;}function parseCompressNormal(_0x27defd,_0x5b1b5e,_0x21edec,_0x498705){const _0x331dce=_0x49e3;let _0x16418b=_0x5b1b5e['getUint32'](_0x21edec,!![]);_0x21edec+=Uint32Array[_0x331dce(0x181)];if(_0x16418b<=0x0)return _0x21edec;let _0x2aef1a=_0x5b1b5e[_0x331dce(0x17a)](_0x21edec,!![]);_0x21edec+=Uint16Array[_0x331dce(0x181)];let _0x476dc8=_0x5b1b5e['getUint16'](_0x21edec,!![]);_0x21edec+=Uint16Array[_0x331dce(0x181)];let _0x55c309=_0x16418b*0x2*Int16Array[_0x331dce(0x181)],_0x1bb8ff=new Uint8Array(_0x27defd,_0x21edec,_0x55c309);_0x21edec+=_0x55c309;let _0x338826=_0x498705[_0x331dce(0x18f)],_0x473222=_0x498705[_0x331dce(0x19b)];return _0x473222['aNormal']=_0x338826[_0x331dce(0x1a3)],_0x338826[_0x331dce(0x1c6)]({'index':_0x473222[_0x331dce(0x1af)],'typedArray':_0x1bb8ff,'componentsPerAttribute':0x2,'componentDatatype':Cesium[_0x331dce(0x195)]['SHORT'],'offsetInBytes':0x0,'strideInBytes':_0x476dc8,'normalize':![]}),_0x21edec;}function parseCompressTexCoord(_0xeb3c01,_0x2cb3a2,_0x46213e,_0x2a3503){const _0x1bf039=_0x49e3;_0x2a3503[_0x1bf039(0x1b7)]=[],_0x2a3503[_0x1bf039(0x175)]=[];let _0x19d069=_0x2cb3a2[_0x1bf039(0x17a)](_0x46213e,!![]);_0x46213e+=Uint16Array['BYTES_PER_ELEMENT'],_0x46213e+=Uint16Array[_0x1bf039(0x181)];for(let _0x5713c9=0x0;_0x5713c9<_0x19d069;_0x5713c9++){let _0x1bebef=_0x2cb3a2[_0x1bf039(0x184)](_0x46213e,!![]);_0x46213e+=Uint8Array['BYTES_PER_ELEMENT'],_0x46213e+=Uint8Array['BYTES_PER_ELEMENT']*0x3;let _0x1b2ce5=_0x2cb3a2[_0x1bf039(0x183)](_0x46213e,!![]);_0x46213e+=Uint32Array['BYTES_PER_ELEMENT'];let _0x12fff7=_0x2cb3a2[_0x1bf039(0x17a)](_0x46213e,!![]);_0x46213e+=Uint16Array['BYTES_PER_ELEMENT'];let _0x9eafe=_0x2cb3a2[_0x1bf039(0x17a)](_0x46213e,!![]);_0x46213e+=Uint16Array[_0x1bf039(0x181)];let _0x39a146=_0x2cb3a2[_0x1bf039(0x1a4)](_0x46213e,!![]);_0x46213e+=Float32Array[_0x1bf039(0x181)],_0x2a3503[_0x1bf039(0x1b7)][_0x1bf039(0x1c6)](_0x39a146);let _0x1e75ea={};_0x1e75ea['x']=_0x2cb3a2[_0x1bf039(0x1a4)](_0x46213e,!![]),_0x46213e+=Float32Array['BYTES_PER_ELEMENT'],_0x1e75ea['y']=_0x2cb3a2[_0x1bf039(0x1a4)](_0x46213e,!![]),_0x46213e+=Float32Array[_0x1bf039(0x181)],_0x1e75ea['z']=_0x2cb3a2[_0x1bf039(0x1a4)](_0x46213e,!![]),_0x46213e+=Float32Array[_0x1bf039(0x181)],_0x1e75ea['w']=_0x2cb3a2['getFloat32'](_0x46213e,!![]),_0x46213e+=Float32Array[_0x1bf039(0x181)],_0x2a3503[_0x1bf039(0x175)][_0x1bf039(0x1c6)](_0x1e75ea);let _0x50f63e=_0x1b2ce5*_0x12fff7*Int16Array[_0x1bf039(0x181)],_0x54fc1e=new Uint8Array(_0xeb3c01,_0x46213e,_0x50f63e);_0x46213e+=_0x50f63e;let _0x26be34=_0x46213e%0x4;_0x26be34!==0x0&&(_0x46213e+=0x4-_0x26be34);let _0x45e9e7='aTexCoord'+_0x5713c9,_0x3786f6=_0x2a3503[_0x1bf039(0x18f)],_0x409e90=_0x2a3503[_0x1bf039(0x19b)];_0x409e90[_0x45e9e7]=_0x3786f6[_0x1bf039(0x1a3)],_0x3786f6[_0x1bf039(0x1c6)]({'index':_0x409e90[_0x45e9e7],'typedArray':_0x54fc1e,'componentsPerAttribute':_0x12fff7,'componentDatatype':Cesium[_0x1bf039(0x195)]['SHORT'],'offsetInBytes':0x0,'strideInBytes':_0x12fff7*Int16Array[_0x1bf039(0x181)],'normalize':![]});if(_0x1bebef){_0x50f63e=_0x1b2ce5*Float32Array[_0x1bf039(0x181)];let _0xdef063=new Uint8Array(_0xeb3c01,_0x46213e,_0x50f63e);_0x46213e+=_0x50f63e,_0x2a3503[_0x1bf039(0x1a6)]=!![],_0x45e9e7=_0x1bf039(0x198)+_0x5713c9,_0x409e90[_0x45e9e7]=_0x3786f6[_0x1bf039(0x1a3)],_0x3786f6[_0x1bf039(0x1c6)]({'index':_0x409e90[_0x45e9e7],'typedArray':_0xdef063,'componentsPerAttribute':0x1,'componentDatatype':Cesium[_0x1bf039(0x195)][_0x1bf039(0x17e)],'offsetInBytes':0x0,'strideInBytes':Float32Array[_0x1bf039(0x181)],'normalize':![]});}}return _0x46213e;}function parseStandardSkeleton(_0x96d652,_0x1dba90,_0x5ecddb,_0x1fd944){return _0x5ecddb=parseVertex(_0x96d652,_0x1dba90,_0x5ecddb,_0x1fd944),_0x5ecddb=parseNormal(_0x96d652,_0x1dba90,_0x5ecddb,_0x1fd944),_0x5ecddb=parseVertexColor(_0x96d652,_0x1dba90,_0x5ecddb,_0x1fd944),_0x5ecddb=parseSecondColor(_0x96d652,_0x1dba90,_0x5ecddb,_0x1fd944),_0x5ecddb=parseTexCoord(_0x96d652,_0x1dba90,_0x5ecddb,_0x1fd944),_0x5ecddb=parseInstanceInfo(_0x96d652,_0x1dba90,_0x5ecddb,_0x1fd944),_0x5ecddb;}function parseCompressSkeleton(_0x20b497,_0x1759aa,_0x3f34bb,_0x27bf64){const _0x38309d=_0x49e3;let _0x4fccba=_0x1759aa[_0x38309d(0x183)](_0x3f34bb,!![]);return _0x27bf64[_0x38309d(0x1bf)]=_0x4fccba,_0x3f34bb+=Uint32Array['BYTES_PER_ELEMENT'],(_0x4fccba&_0x6ea6a9[_0x38309d(0x1a1)])===_0x6ea6a9[_0x38309d(0x1a1)]?_0x3f34bb=parseCompressVertex(_0x20b497,_0x1759aa,_0x3f34bb,_0x27bf64):_0x3f34bb=parseVertex(_0x20b497,_0x1759aa,_0x3f34bb,_0x27bf64),(_0x4fccba&_0x6ea6a9['SVC_Normal'])===_0x6ea6a9[_0x38309d(0x1c2)]?_0x3f34bb=parseCompressNormal(_0x20b497,_0x1759aa,_0x3f34bb,_0x27bf64):_0x3f34bb=parseNormal(_0x20b497,_0x1759aa,_0x3f34bb,_0x27bf64),_0x3f34bb=parseVertexColor(_0x20b497,_0x1759aa,_0x3f34bb,_0x27bf64),_0x3f34bb=parseSecondColor(_0x20b497,_0x1759aa,_0x3f34bb,_0x27bf64),(_0x4fccba&_0x6ea6a9[_0x38309d(0x186)])===_0x6ea6a9['SVC_TexutreCoord']?_0x3f34bb=parseCompressTexCoord(_0x20b497,_0x1759aa,_0x3f34bb,_0x27bf64):_0x3f34bb=parseTexCoord(_0x20b497,_0x1759aa,_0x3f34bb,_0x27bf64),(_0x4fccba&_0x6ea6a9[_0x38309d(0x18d)])===_0x6ea6a9['SVC_TexutreCoordIsW']&&(_0x27bf64[_0x38309d(0x1a7)]=!![]),_0x3f34bb=parseInstanceInfo(_0x20b497,_0x1759aa,_0x3f34bb,_0x27bf64),_0x3f34bb;}function parseIndexPackage(_0x77ea06,_0x5ae103,_0x5c3764,_0x29466b){const _0x4ec450=_0x49e3;let _0x1c25a6=_0x5ae103[_0x4ec450(0x183)](_0x5c3764,!![]);_0x5c3764+=Uint32Array[_0x4ec450(0x181)];for(let _0x3f92da=0x0;_0x3f92da<_0x1c25a6;_0x3f92da++){let _0xfcffd7={},_0x237879=_0x5ae103[_0x4ec450(0x183)](_0x5c3764,!![]);_0x5c3764+=Uint32Array['BYTES_PER_ELEMENT'];let _0x24fda5=_0x5ae103[_0x4ec450(0x184)](_0x5c3764,!![]);_0x5c3764+=Uint8Array[_0x4ec450(0x181)];let _0x5cec3a=_0x5ae103[_0x4ec450(0x184)](_0x5c3764,!![]);_0x5c3764+=Uint8Array[_0x4ec450(0x181)];let _0x4abc7d=_0x5ae103['getUint8'](_0x5c3764,!![]);_0x5c3764+=Uint8Array[_0x4ec450(0x181)],_0x5c3764+=Uint8Array[_0x4ec450(0x181)];if(_0x237879>0x0){let _0x3592b3=null,_0x1a78d6;_0x24fda5===0x1||_0x24fda5===0x3?(_0x1a78d6=_0x237879*Uint32Array[_0x4ec450(0x181)],_0x3592b3=new Uint8Array(_0x77ea06,_0x5c3764,_0x1a78d6)):(_0x1a78d6=_0x237879*Uint16Array[_0x4ec450(0x181)],_0x3592b3=new Uint8Array(_0x77ea06,_0x5c3764,_0x1a78d6),_0x237879%0x2!==0x0&&(_0x1a78d6+=0x2)),_0xfcffd7['indicesTypedArray']=_0x3592b3,_0x5c3764+=_0x1a78d6;}_0xfcffd7[_0x4ec450(0x1a8)]=_0x237879,_0xfcffd7[_0x4ec450(0x17f)]=_0x24fda5,_0xfcffd7[_0x4ec450(0x17b)]=_0x4abc7d;let _0x4ea911=[],_0x532efd=_0x5ae103[_0x4ec450(0x183)](_0x5c3764,!![]);_0x5c3764+=Uint32Array[_0x4ec450(0x181)];for(let _0x3963cc=0x0;_0x3963cc<_0x532efd;_0x3963cc++){let _0x540e7e=parseString(_0x77ea06,_0x5ae103,_0x5c3764),_0xf858cb=_0x540e7e[_0x4ec450(0x18b)];_0x5c3764=_0x540e7e[_0x4ec450(0x190)],_0x4ea911[_0x4ec450(0x1c6)](_0xf858cb),_0xfcffd7[_0x4ec450(0x1b5)]=_0xf858cb;}let _0x48af5f=_0x5c3764%0x4;if(_0x48af5f!==0x0){let _0x225a26=0x4-_0x5c3764%0x4;_0x5c3764+=_0x225a26;}_0x29466b[_0x4ec450(0x1c6)](_0xfcffd7);}return _0x5c3764;}function parseSkeleton(_0x4dea66,_0x1e1c2c,_0x5c0362,_0xd9e209){const _0x1aee73=_0x49e3;let _0x388154=_0x1e1c2c[_0x1aee73(0x183)](_0x5c0362,!![]);_0x5c0362+=Uint32Array['BYTES_PER_ELEMENT'];let _0x8db1c=_0x1e1c2c[_0x1aee73(0x183)](_0x5c0362,!![]);_0x5c0362+=Uint32Array[_0x1aee73(0x181)];for(let _0x2715ad=0x0;_0x2715ad<_0x8db1c;_0x2715ad++){let _0x18680c=parseString(_0x4dea66,_0x1e1c2c,_0x5c0362),_0x517e66=_0x18680c['string'];_0x5c0362=_0x18680c[_0x1aee73(0x190)];let _0x4c2418=_0x5c0362%0x4;_0x4c2418!==0x0&&(_0x5c0362+=0x4-_0x4c2418);let _0xc48487=_0x1e1c2c[_0x1aee73(0x183)](_0x5c0362,!![]);_0x5c0362+=Int32Array[_0x1aee73(0x181)];let _0x2684fb={'vertexAttributes':[],'attrLocation':{},'instanceCount':0x0,'instanceMode':0x0,'instanceIndex':-0x1};if(_0xc48487===S3MBVertexTag['SV_Standard'])_0x5c0362=parseStandardSkeleton(_0x4dea66,_0x1e1c2c,_0x5c0362,_0x2684fb);else _0xc48487===S3MBVertexTag[_0x1aee73(0x174)]&&(_0x5c0362=parseCompressSkeleton(_0x4dea66,_0x1e1c2c,_0x5c0362,_0x2684fb));let _0x2167c6=[];_0x5c0362=parseIndexPackage(_0x4dea66,_0x1e1c2c,_0x5c0362,_0x2167c6);let _0x6ceaa=undefined;_0x2167c6['length']===0x2&&_0x2167c6[0x1][_0x1aee73(0x17b)]===0xd&&_0x2167c6[0x1][_0x1aee73(0x1a8)]>=0x3&&(_0x6ceaa=S3MEdgeProcessor[_0x1aee73(0x1b8)](_0x2684fb,_0x2167c6[0x1])),_0xd9e209[_0x517e66]={'vertexPackage':_0x2684fb,'arrIndexPackage':_0x2167c6,'edgeGeometry':_0x6ceaa};}let _0x387068=_0x1e1c2c[_0x1aee73(0x183)](_0x5c0362,!![]);return _0x5c0362+=_0x387068,_0x5c0362+=Uint32Array[_0x1aee73(0x181)],_0x5c0362;}function parseTexturePackage(_0x1f3e5b,_0x1b5623,_0x56c7cb,_0x48039){const _0x4f12b3=_0x49e3;let _0x143b4c=_0x1b5623[_0x4f12b3(0x183)](_0x56c7cb,!![]);_0x56c7cb+=Uint32Array['BYTES_PER_ELEMENT'];let _0x4450c5=_0x1b5623['getUint32'](_0x56c7cb,!![]);_0x56c7cb+=Uint32Array['BYTES_PER_ELEMENT'];for(let _0x36b336=0x0;_0x36b336<_0x4450c5;_0x36b336++){let _0x276825=parseString(_0x1f3e5b,_0x1b5623,_0x56c7cb),_0x3759ae=_0x276825[_0x4f12b3(0x18b)];_0x56c7cb=_0x276825['bytesOffset'];let _0x499ac9=_0x56c7cb%0x4;_0x499ac9!==0x0&&(_0x56c7cb+=0x4-_0x499ac9);let _0xcc1e9=_0x1b5623[_0x4f12b3(0x183)](_0x56c7cb,!![]);_0x56c7cb+=Uint32Array['BYTES_PER_ELEMENT'];let _0x3ed3d9=_0x1b5623[_0x4f12b3(0x183)](_0x56c7cb,!![]);_0x56c7cb+=Uint32Array[_0x4f12b3(0x181)];let _0xb8565=_0x1b5623[_0x4f12b3(0x183)](_0x56c7cb,!![]);_0x56c7cb+=Uint32Array[_0x4f12b3(0x181)];let _0x137391=_0x1b5623[_0x4f12b3(0x183)](_0x56c7cb,!![]);_0x56c7cb+=Uint32Array['BYTES_PER_ELEMENT'];let _0xfa8aa6=_0x1b5623[_0x4f12b3(0x183)](_0x56c7cb,!![]);_0x56c7cb+=Uint32Array['BYTES_PER_ELEMENT'];let _0x18ab85=_0x1b5623[_0x4f12b3(0x183)](_0x56c7cb,!![]);_0x56c7cb+=Uint32Array[_0x4f12b3(0x181)];let _0x293070=new Uint8Array(_0x1f3e5b,_0x56c7cb,_0xfa8aa6);_0x56c7cb+=_0xfa8aa6;let _0x17c1e4=_0x18ab85===_0xaa1cd8[_0x4f12b3(0x1c9)]||_0x18ab85===_0xaa1cd8['BGR']?Cesium[_0x4f12b3(0x1b1)][_0x4f12b3(0x1bc)]:Cesium['PixelFormat'][_0x4f12b3(0x178)];_0x48039[_0x3759ae]={'id':_0x3759ae,'width':_0x3ed3d9,'height':_0xb8565,'compressType':_0x137391,'nFormat':_0x18ab85,'internalFormat':_0x17c1e4,'arrayBufferView':_0x293070};}return _0x56c7cb;}function parseMaterial(_0x4c3f1b,_0x1f4c39,_0x1f43b8,_0x47f66f){const _0x36e924=_0x49e3;let _0x489f66=_0x1f4c39['getUint32'](_0x1f43b8,!![]);_0x1f43b8+=Uint32Array[_0x36e924(0x181)];let _0x983ed5=new Uint8Array(_0x4c3f1b,_0x1f43b8,_0x489f66),_0x49fb3b=Cesium[_0x36e924(0x17c)](_0x983ed5);return _0x1f43b8+=_0x489f66,_0x47f66f[_0x36e924(0x182)]=JSON['parse'](_0x49fb3b),_0x1f43b8;}let colorScratch=new Cesium[(_0x5254d4(0x19f))](),LEFT_16=0x10000;function parsePickInfo(_0xc6f4e4,_0x392060,_0x1c249c,_0x2bb2d6,_0x4751a3,_0x32a177){const _0x7e677=_0x5254d4;if((_0x2bb2d6&0x1)===0x1){let _0x25b74a=_0x392060[_0x7e677(0x183)](_0x1c249c,!![]);_0x1c249c+=Uint32Array[_0x7e677(0x181)];let _0x986d7a=_0x392060[_0x7e677(0x183)](_0x1c249c,!![]);_0x1c249c+=Uint32Array[_0x7e677(0x181)];for(let _0x2f4f49=0x0;_0x2f4f49<_0x986d7a;_0x2f4f49++){let _0x3f094c=parseString(_0xc6f4e4,_0x392060,_0x1c249c),_0x3ec50b=_0x3f094c[_0x7e677(0x18b)];_0x1c249c=_0x3f094c[_0x7e677(0x190)];let _0x472cf6=_0x392060['getUint32'](_0x1c249c,!![]);_0x1c249c+=Uint32Array[_0x7e677(0x181)];let _0x6b04b6={};_0x4751a3[_0x3ec50b]['pickInfo']=_0x6b04b6;let _0x6707f8=_0x4751a3[_0x3ec50b][_0x7e677(0x19d)]['instanceIndex'];if(_0x6707f8==-0x1){let _0x3a0ba6=new Float32Array(_0x4751a3[_0x3ec50b]['vertexPackage'][_0x7e677(0x1ae)]);for(let _0x1b52f2=0x0;_0x1b52f2<_0x472cf6;_0x1b52f2++){let _0x5d892e=_0x392060['getUint32'](_0x1c249c,!![]);_0x1c249c+=Uint32Array['BYTES_PER_ELEMENT'];let _0x2f8f59=_0x392060[_0x7e677(0x183)](_0x1c249c,!![]);_0x1c249c+=Uint32Array[_0x7e677(0x181)];let _0x500569=[];for(let _0x4c7b97=0x0;_0x4c7b97<_0x2f8f59;_0x4c7b97++){let _0x5ccb77=_0x392060[_0x7e677(0x183)](_0x1c249c,!![]);_0x1c249c+=Uint32Array['BYTES_PER_ELEMENT'];let _0x212606=_0x392060[_0x7e677(0x183)](_0x1c249c,!![]);_0x1c249c+=Uint32Array['BYTES_PER_ELEMENT'],Cesium[_0x7e677(0x1c5)](_0x3a0ba6,_0x1b52f2,_0x5ccb77,_0x5ccb77+_0x212606),_0x500569[_0x7e677(0x1c6)]({'vertexColorOffset':_0x5ccb77,'vertexColorCount':_0x212606,'batchId':_0x1b52f2});}_0x6b04b6[_0x5d892e]=_0x500569;}createBatchIdAttribute(_0x4751a3[_0x3ec50b][_0x7e677(0x19d)],_0x3a0ba6,undefined);}else {let _0x189224=_0x4751a3[_0x3ec50b][_0x7e677(0x19d)]['instanceCount'],_0x32b3af=_0x4751a3[_0x3ec50b][_0x7e677(0x19d)][_0x7e677(0x196)],_0x4b1625=_0x4751a3[_0x3ec50b]['vertexPackage'][_0x7e677(0x1a5)],_0x2dd0a4=new Float32Array(_0x189224),_0x1e6c04=[];for(let _0x20d61e=0x0;_0x20d61e<_0x472cf6;_0x20d61e++){let _0x146f21=_0x392060[_0x7e677(0x183)](_0x1c249c,!![]);_0x1e6c04['push'](_0x146f21),_0x1c249c+=Uint32Array[_0x7e677(0x181)];let _0x3dfe2e=_0x392060['getUint32'](_0x1c249c,!![]);_0x1c249c+=Uint32Array[_0x7e677(0x181)];for(let _0x2b29ff=0x0;_0x2b29ff<_0x3dfe2e;_0x2b29ff++){let _0x460af0=_0x392060[_0x7e677(0x183)](_0x1c249c,!![]);_0x1c249c+=Uint32Array[_0x7e677(0x181)];if(_0x32a177===0x3){let _0x2a77c3=_0x392060['getUint32'](_0x1c249c,!![]);_0x1c249c+=Uint32Array[_0x7e677(0x181)];}}}let _0x3a341e=_0x4b1625===0x11?0x10:0x1c;_0x3a341e*=Float32Array[_0x7e677(0x181)];for(let _0x1a3531=0x0;_0x1a3531<_0x189224;_0x1a3531++){_0x2dd0a4[_0x1a3531]=_0x1a3531;let _0x1dfc0d=_0x1a3531*_0x4b1625*Float32Array[_0x7e677(0x181)]+_0x3a341e;Cesium['Color'][_0x7e677(0x1aa)](_0x32b3af,_0x1dfc0d,colorScratch);let _0x531f51=_0x32a177===0x2?_0x1e6c04[_0x1a3531]:colorScratch['red']+colorScratch[_0x7e677(0x1b3)]*0x100+colorScratch[_0x7e677(0x191)]*LEFT_16;_0x6b04b6[_0x531f51]===undefined&&(_0x6b04b6[_0x531f51]={'vertexColorCount':0x1,'instanceIds':[],'vertexColorOffset':_0x1a3531}),_0x6b04b6[_0x531f51][_0x7e677(0x1ad)][_0x7e677(0x1c6)](_0x1a3531);}createBatchIdAttribute(_0x4751a3[_0x3ec50b]['vertexPackage'],_0x2dd0a4,0x1);}}}return _0x1c249c;}function createBatchIdAttribute(_0x1c9803,_0x45885a,_0x38d21f){const _0x38456c=_0x5254d4;let _0x103f2e=_0x1c9803[_0x38456c(0x18f)],_0x4e76af=_0x1c9803['attrLocation'],_0x2cd65d=_0x103f2e['length'],_0x51d4ae=_0x38d21f===0x1?_0x38456c(0x19c):'batchId';_0x4e76af[_0x51d4ae]=_0x2cd65d,_0x103f2e['push']({'index':_0x2cd65d,'typedArray':_0x45885a,'componentsPerAttribute':0x1,'componentDatatype':Cesium[_0x38456c(0x195)]['FLOAT'],'offsetInBytes':0x0,'strideInBytes':0x0,'instanceDivisor':_0x38d21f});}S3ModelParser[_0x5254d4(0x197)]=function(_0x205601){const _0x1d87d2=_0x5254d4;let _0x5b088c=0x0,_0x2b6842={'version':undefined,'groupNode':undefined,'geoPackage':{},'matrials':undefined,'texturePackage':{}},_0x3ce039=new DataView(_0x205601);_0x2b6842[_0x1d87d2(0x177)]=_0x3ce039['getFloat32'](_0x5b088c,!![]),_0x5b088c+=Float32Array[_0x1d87d2(0x181)];if(_0x2b6842['version']>=0x2){let _0x11b1cb=_0x3ce039[_0x1d87d2(0x183)](_0x5b088c,!![]);_0x5b088c+=Uint32Array['BYTES_PER_ELEMENT'];}let _0xdd3bf6=_0x3ce039[_0x1d87d2(0x183)](_0x5b088c,!![]);_0x5b088c+=Uint32Array[_0x1d87d2(0x181)];let _0x4e33bf=unZip(_0x205601,_0x5b088c);_0x3ce039=new DataView(_0x4e33bf),_0x5b088c=0x0;let _0x177cd5=_0x3ce039['getUint32'](_0x5b088c,!![]);return _0x5b088c+=Uint32Array['BYTES_PER_ELEMENT'],_0x5b088c=parseGroupNode(_0x4e33bf,_0x3ce039,_0x5b088c,_0x2b6842),_0x5b088c=parseSkeleton(_0x4e33bf,_0x3ce039,_0x5b088c,_0x2b6842[_0x1d87d2(0x1b9)]),_0x5b088c=parseTexturePackage(_0x4e33bf,_0x3ce039,_0x5b088c,_0x2b6842['texturePackage']),_0x5b088c=parseMaterial(_0x4e33bf,_0x3ce039,_0x5b088c,_0x2b6842),parsePickInfo(_0x4e33bf,_0x3ce039,_0x5b088c,_0x177cd5,_0x2b6842['geoPackage'],_0x2b6842['version']),_0x2b6842;};

    const _0x2ef7=['155573Usovke','6579hEOlxp','freeze','30iSFdiz','246947MvxsKa','7icYiRK','1tGAtYd','69598lAFlFU','89504YkJbkc','119537eVLFpb','36094tUqGPP'];const _0x1dd21d=_0x2b3d;(function(_0xe31f60,_0x5a45dc){const _0x2c4967=_0x2b3d;while(!![]){try{const _0x4e0cdd=-parseInt(_0x2c4967(0x75))*-parseInt(_0x2c4967(0x6f))+-parseInt(_0x2c4967(0x70))+-parseInt(_0x2c4967(0x78))*-parseInt(_0x2c4967(0x76))+-parseInt(_0x2c4967(0x74))+-parseInt(_0x2c4967(0x71))*-parseInt(_0x2c4967(0x73))+-parseInt(_0x2c4967(0x77))+parseInt(_0x2c4967(0x79));if(_0x4e0cdd===_0x5a45dc)break;else _0xe31f60['push'](_0xe31f60['shift']());}catch(_0x15374e){_0xe31f60['push'](_0xe31f60['shift']());}}}(_0x2ef7,0x2da47));const RangeMode={'Distance':0x0,'Pixel':0x1};function _0x2b3d(_0x11e260,_0x576b57){_0x11e260=_0x11e260-0x6f;let _0x2ef79b=_0x2ef7[_0x11e260];return _0x2ef79b;}var _0x54aefd = Object[_0x1dd21d(0x72)](RangeMode);

    const _0x16df=['TransparentSorting','RangeMode','RGBA_DXT5','uv6','geoPackage','trim','read','batchId','texturePackage','materials','groupNode','firstChild','Pixel','queryStringValue','Shininess','uv9','instanceBuffer','push','inflate','TextureName','uv7','175628FvQYIr','pickInfo','uv1','PagedLOD','SpecularR','1pdPYnJ','secondary_colour','BoundingSphere','url','verticesCount','replace','PixelFormat','AddressMode','instanceCount','skeletonNames','vertexPackage','9152hGwiWJ','filteringoption','split','671956gemrbS','addressmode','specular','SpecularG','texmodmatrix','aColor','indicesTypedArray','GeoDeModMatrix','FLOAT','RGB','1wNZCUt','uv3','material','filtermax','parseBuffer','RGB_DXT1','radius','namespaceURI','subarray','DiffuseA','Geode','queryNumericValue','fill','getUint8','matrix','defaultValue','transparentsorting','getStringFromTypedArray','uv5','.s3m','AmbientA','uv2','Ambient','17904JMzSwQ','TexModMatrix','aTexCoord','instanceIndex','Diffuse','BYTES_PER_ELEMENT','ComponentDatatype','Specular','uv4','shininess','vertexAttributes','RangeList','buffer','DISTANCE_FROM_EYE_POINT','textureunitstates','queryChildNodes','45902zAeRzb','pageLods','length','aNormal','AmbientB','PageLods','DiffuseB','SpecularB','instanceMode','gbk','TAM_WRAP','attrLocation','121410fJUNru','357865igXJLY','name','getUint32','SpecularA','queryFirstNode','textContent','queryBooleanValue','getUint16','RangeDataList','Distance','geodes','texture'];const _0x19fa79=_0x5ee3;(function(_0x3c5529,_0x2d883a){const _0x3e96ff=_0x5ee3;while(!![]){try{const _0x26645b=parseInt(_0x3e96ff(0xe9))*-parseInt(_0x3e96ff(0xb5))+parseInt(_0x3e96ff(0xab))+-parseInt(_0x3e96ff(0xcc))+-parseInt(_0x3e96ff(0x9d))*-parseInt(_0x3e96ff(0xdc))+parseInt(_0x3e96ff(0xa8))+parseInt(_0x3e96ff(0x10a))+-parseInt(_0x3e96ff(0xe8));if(_0x26645b===_0x2d883a)break;else _0x3c5529['push'](_0x3c5529['shift']());}catch(_0x558967){_0x3c5529['push'](_0x3c5529['shift']());}}}(_0x16df,0x62fd3));function parseGeoPackage(_0x582b7f,_0x5ca245,_0xcc66c,_0x1c23bd){const _0x4d415d=_0x5ee3;let _0x20da7e=_0xcc66c[_0x4d415d(0xeb)](_0x1c23bd,!![]);_0x1c23bd+=Uint32Array['BYTES_PER_ELEMENT'];let _0x33225b=0x0,_0x4e6d9c={},_0x4eefe9=_0x4e6d9c[_0x4d415d(0xd6)]=[],_0x640f63=_0x4e6d9c[_0x4d415d(0xe7)]={};_0x4e6d9c[_0x4d415d(0xa5)]=0x0,_0x4e6d9c['instanceMode']=0x0;let _0x3341af=0x0,_0x4904c1=_0xcc66c['getUint32'](_0x1c23bd,!![]);_0x1c23bd+=Uint32Array[_0x4d415d(0xd1)];let _0x808705=_0xcc66c['getUint16'](_0x1c23bd,!![]);_0x1c23bd+=Uint32Array[_0x4d415d(0xd1)];let _0x542c4f=_0x808705;_0x808705>0x4&&(_0x542c4f=_0x808705>>0x8,_0x808705=_0x808705&0xf);let _0xe34202=_0xcc66c[_0x4d415d(0xeb)](_0x1c23bd,!![]);_0x1c23bd+=Uint32Array[_0x4d415d(0xd1)];if(_0xe34202>0x0){let _0x159378=_0xcc66c[_0x4d415d(0xf0)](_0x1c23bd,!![]);_0x159378=_0x808705*Float32Array[_0x4d415d(0xd1)],_0x1c23bd+=Uint32Array['BYTES_PER_ELEMENT'],_0x33225b=_0xe34202*_0x159378,_0x640f63['aPosition']=_0x3341af,_0x4eefe9['push']({'index':_0x640f63['aPosition'],'typedArray':_0x5ca245['subarray'](_0x1c23bd,_0x1c23bd+_0x33225b),'componentsPerAttribute':_0x808705,'componentDatatype':Cesium[_0x4d415d(0xd2)]['FLOAT'],'offsetInBytes':0x0,'strideInBytes':_0x159378,'normalize':![]}),_0x3341af++,_0x1c23bd+=_0x33225b;}let _0x304e19=_0xcc66c[_0x4d415d(0xeb)](_0x1c23bd,!![]);_0x1c23bd+=Uint32Array[_0x4d415d(0xd1)];if(_0x304e19>0x0){let _0x19e352=_0xcc66c[_0x4d415d(0xf0)](_0x1c23bd,!![]);_0x19e352=_0x542c4f*Float32Array['BYTES_PER_ELEMENT'],_0x1c23bd+=Uint32Array['BYTES_PER_ELEMENT'],_0x33225b=_0x304e19*_0x19e352,_0x640f63[_0x4d415d(0xdf)]=_0x3341af,_0x4eefe9['push']({'index':_0x640f63[_0x4d415d(0xdf)],'typedArray':_0x5ca245['subarray'](_0x1c23bd,_0x1c23bd+_0x33225b),'componentsPerAttribute':_0x542c4f,'componentDatatype':Cesium[_0x4d415d(0xd2)][_0x4d415d(0xb3)],'offsetInBytes':0x0,'strideInBytes':_0x19e352,'normalize':![]}),_0x3341af++,_0x1c23bd+=_0x33225b;}let _0x1549a8=_0xcc66c[_0x4d415d(0xeb)](_0x1c23bd,!![]);_0x1c23bd+=Uint32Array['BYTES_PER_ELEMENT'];if(_0x1549a8>0x0){let _0x2055e0=new Uint8Array(0x4*_0x1549a8),_0x1f601f=_0xcc66c[_0x4d415d(0xeb)](_0x1c23bd,!![]);_0x1f601f=0x4*Float32Array[_0x4d415d(0xd1)],_0x1c23bd+=Uint32Array[_0x4d415d(0xd1)],_0x33225b=_0x1549a8*_0x1f601f;let _0x3c5d15=new Float32Array(_0x5ca245[_0x4d415d(0xd8)],_0x1c23bd,_0xe34202*0x4);for(let _0x12623c=0x0;_0x12623c<_0xe34202;_0x12623c++){_0x2055e0[0x4*_0x12623c]=_0x3c5d15[0x4*_0x12623c]*0xff,_0x2055e0[0x4*_0x12623c+0x1]=_0x3c5d15[0x4*_0x12623c+0x1]*0xff,_0x2055e0[0x4*_0x12623c+0x2]=_0x3c5d15[0x4*_0x12623c+0x2]*0xff,_0x2055e0[0x4*_0x12623c+0x3]=_0x3c5d15[0x4*_0x12623c+0x3]*0xff;}_0x1c23bd+=_0x33225b,_0x640f63[_0x4d415d(0xb0)]=_0x3341af,_0x4eefe9['push']({'index':_0x640f63['aColor'],'typedArray':_0x2055e0,'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x4d415d(0xd2)]['UNSIGNED_BYTE'],'offsetInBytes':0x0,'strideInBytes':0x4,'normalize':!![]}),_0x3341af++;}let _0x4bd714=_0xcc66c[_0x4d415d(0xeb)](_0x1c23bd,!![]);_0x1c23bd+=Uint32Array[_0x4d415d(0xd1)];_0x4bd714>0x0&&(_0x33225b=_0x4bd714*0x10,_0x1c23bd+=_0x33225b);let _0x45088d=_0xcc66c[_0x4d415d(0xeb)](_0x1c23bd,!![]);_0x1c23bd+=Uint32Array['BYTES_PER_ELEMENT'];let _0x9547ee=-0x1,_0x534843,_0x48ac1b,_0x2b9b69;for(let _0x2c3662=0x0;_0x2c3662<_0x45088d;_0x2c3662++){_0x534843=_0xcc66c[_0x4d415d(0xeb)](_0x1c23bd,!![]),_0x1c23bd+=Uint32Array[_0x4d415d(0xd1)],_0x2b9b69=_0xcc66c[_0x4d415d(0xf0)](_0x1c23bd,!![]),_0x1c23bd+=Uint16Array[_0x4d415d(0xd1)],_0x48ac1b=_0xcc66c[_0x4d415d(0xf0)](_0x1c23bd,!![]),_0x1c23bd+=Uint16Array[_0x4d415d(0xd1)],_0x33225b=_0x534843*_0x2b9b69*Float32Array[_0x4d415d(0xd1)];let _0x1e3206=_0x5ca245['subarray'](_0x1c23bd,_0x1c23bd+_0x33225b);if(_0x9547ee===-0x1&&(_0x2b9b69===0x14||_0x2b9b69===0x23)){_0x9547ee=_0x2c3662,_0x4e6d9c[_0x4d415d(0xa5)]=_0x534843,_0x4e6d9c['instanceMode']=_0x2b9b69,_0x4e6d9c[_0x4d415d(0x105)]=_0x1e3206;let _0x539470;if(_0x2b9b69===0x14)_0x539470=Float32Array['BYTES_PER_ELEMENT']*0x14,_0x640f63[_0x4d415d(0xca)]=_0x3341af++,_0x4eefe9[_0x4d415d(0x106)]({'index':_0x640f63['uv2'],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x4d415d(0xd2)][_0x4d415d(0xb3)],'normalize':![],'offsetInBytes':0x0,'strideInBytes':_0x539470,'instanceDivisor':0x1}),_0x640f63['uv3']=_0x3341af++,_0x4eefe9['push']({'index':_0x640f63[_0x4d415d(0xb6)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x4d415d(0xd2)][_0x4d415d(0xb3)],'normalize':![],'offsetInBytes':0x4*Float32Array[_0x4d415d(0xd1)],'strideInBytes':_0x539470,'instanceDivisor':0x1}),_0x640f63[_0x4d415d(0xd4)]=_0x3341af++,_0x4eefe9['push']({'index':_0x640f63['uv4'],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x4d415d(0xd2)]['FLOAT'],'normalize':![],'offsetInBytes':0x8*Float32Array['BYTES_PER_ELEMENT'],'strideInBytes':_0x539470,'instanceDivisor':0x1}),_0x640f63[_0x4d415d(0x9e)]=_0x3341af++,_0x4eefe9[_0x4d415d(0x106)]({'index':_0x640f63[_0x4d415d(0x9e)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x4d415d(0xd2)][_0x4d415d(0xb3)],'normalize':![],'offsetInBytes':0xc*Float32Array['BYTES_PER_ELEMENT'],'strideInBytes':_0x539470,'instanceDivisor':0x1}),_0x640f63[_0x4d415d(0xf8)]=_0x3341af++,_0x4eefe9[_0x4d415d(0x106)]({'index':_0x640f63['uv6'],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x4d415d(0xd2)][_0x4d415d(0xb3)],'normalize':![],'offsetInBytes':0x10*Float32Array[_0x4d415d(0xd1)],'strideInBytes':_0x539470,'instanceDivisor':0x1});else _0x2b9b69===0x23&&(_0x539470=Float32Array[_0x4d415d(0xd1)]*0x23,_0x640f63[_0x4d415d(0x10c)]=_0x3341af++,_0x4eefe9['push']({'index':_0x640f63[_0x4d415d(0x10c)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x4d415d(0xd2)][_0x4d415d(0xb3)],'normalize':![],'offsetInBytes':0x0,'strideInBytes':_0x539470,'instanceDivisor':0x1,'byteLength':_0x33225b}),_0x640f63[_0x4d415d(0xca)]=_0x3341af++,_0x4eefe9['push']({'index':_0x640f63[_0x4d415d(0xca)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x4d415d(0xd2)][_0x4d415d(0xb3)],'normalize':![],'offsetInBytes':0x4*Float32Array['BYTES_PER_ELEMENT'],'strideInBytes':_0x539470,'instanceDivisor':0x1}),_0x640f63[_0x4d415d(0xb6)]=_0x3341af++,_0x4eefe9[_0x4d415d(0x106)]({'index':_0x640f63[_0x4d415d(0xb6)],'componentsPerAttribute':0x4,'componentDatatype':Cesium['ComponentDatatype'][_0x4d415d(0xb3)],'normalize':![],'offsetInBytes':0x8*Float32Array['BYTES_PER_ELEMENT'],'strideInBytes':_0x539470,'instanceDivisor':0x1}),_0x640f63[_0x4d415d(0xd4)]=_0x3341af++,_0x4eefe9[_0x4d415d(0x106)]({'index':_0x640f63[_0x4d415d(0xd4)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x4d415d(0xd2)]['FLOAT'],'normalize':![],'offsetInBytes':0xc*Float32Array['BYTES_PER_ELEMENT'],'strideInBytes':_0x539470,'instanceDivisor':0x1}),_0x640f63[_0x4d415d(0xc7)]=_0x3341af++,_0x4eefe9[_0x4d415d(0x106)]({'index':_0x640f63[_0x4d415d(0xc7)],'componentsPerAttribute':0x4,'componentDatatype':Cesium['ComponentDatatype'][_0x4d415d(0xb3)],'normalize':![],'offsetInBytes':0x10*Float32Array[_0x4d415d(0xd1)],'strideInBytes':_0x539470,'instanceDivisor':0x1}),_0x640f63[_0x4d415d(0xf8)]=_0x3341af++,_0x4eefe9[_0x4d415d(0x106)]({'index':_0x640f63[_0x4d415d(0xf8)],'componentsPerAttribute':0x4,'componentDatatype':Cesium['ComponentDatatype'][_0x4d415d(0xb3)],'normalize':![],'offsetInBytes':0x14*Float32Array[_0x4d415d(0xd1)],'strideInBytes':_0x539470,'instanceDivisor':0x1}),_0x640f63[_0x4d415d(0x109)]=_0x3341af++,_0x4eefe9[_0x4d415d(0x106)]({'index':_0x640f63[_0x4d415d(0x109)],'componentsPerAttribute':0x3,'componentDatatype':Cesium['ComponentDatatype']['FLOAT'],'normalize':![],'offsetInBytes':0x18*Float32Array[_0x4d415d(0xd1)],'strideInBytes':_0x539470,'instanceDivisor':0x1}),_0x640f63['secondary_colour']=_0x3341af++,_0x4eefe9['push']({'index':_0x640f63[_0x4d415d(0x9e)],'componentsPerAttribute':0x4,'componentDatatype':Cesium['ComponentDatatype']['FLOAT'],'normalize':![],'offsetInBytes':0x1b*Float32Array[_0x4d415d(0xd1)],'strideInBytes':_0x539470,'instanceDivisor':0x1}),_0x640f63[_0x4d415d(0x104)]=_0x3341af++,_0x4eefe9[_0x4d415d(0x106)]({'index':_0x640f63[_0x4d415d(0x104)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x4d415d(0xd2)][_0x4d415d(0xb3)],'normalize':![],'offsetInBytes':0x1f*Float32Array['BYTES_PER_ELEMENT'],'strideInBytes':_0x539470,'instanceDivisor':0x1}));}else {if(_0x9547ee!==-0x1)_0x4e6d9c['instanceBounds']=new Float32Array(_0x5ca245[_0x4d415d(0xd8)],_0x1c23bd,_0x534843*_0x2b9b69);else {let _0x1fec13=_0x4d415d(0xce)+_0x2c3662;_0x640f63[_0x1fec13]=_0x3341af++,_0x4eefe9['push']({'index':_0x640f63[_0x1fec13],'typedArray':_0x1e3206,'componentsPerAttribute':_0x2b9b69,'componentDatatype':Cesium[_0x4d415d(0xd2)][_0x4d415d(0xb3)],'offsetInBytes':0x0,'strideInBytes':_0x2b9b69*Float32Array[_0x4d415d(0xd1)],'normalize':![]});}}_0x1c23bd+=_0x33225b;}_0x4e6d9c[_0x4d415d(0xa1)]=_0xe34202,_0x4e6d9c[_0x4d415d(0xcf)]=_0x9547ee;let _0x5439d8=_0xcc66c[_0x4d415d(0xeb)](_0x1c23bd,!![]);_0x1c23bd+=Uint32Array['BYTES_PER_ELEMENT'];let _0x17946e=[];for(let _0x1c616f=0x0;_0x1c616f<_0x5439d8;_0x1c616f++){let _0xd7110a={},_0x156df0=_0xcc66c['getUint32'](_0x1c23bd,!![]);_0x1c23bd+=Uint32Array[_0x4d415d(0xd1)];let _0x495ae9=_0xcc66c[_0x4d415d(0xc2)](_0x1c23bd,!![]);_0x1c23bd+=Uint8Array[_0x4d415d(0xd1)];let _0x32a49e=_0xcc66c[_0x4d415d(0xc2)](_0x1c23bd,!![]);_0x1c23bd+=Uint8Array[_0x4d415d(0xd1)];let _0x571403=_0xcc66c[_0x4d415d(0xc2)](_0x1c23bd,!![]);_0x1c23bd+=Uint8Array[_0x4d415d(0xd1)],_0x1c23bd+=0x1,_0xd7110a['indicesCount']=_0x156df0,_0xd7110a['indexType']=_0x495ae9,_0xd7110a['primitiveType']=_0x571403;let _0x2d4767=_0x1c23bd;_0x156df0>0x0&&(_0x495ae9===0x0?(_0x33225b=_0x156df0*Uint16Array[_0x4d415d(0xd1)],_0x1c23bd+=_0x33225b,_0x156df0%0x2===0x1&&(_0x1c23bd+=0x2)):(_0x33225b=_0x156df0*0x4,_0x1c23bd+=_0x33225b));_0xd7110a[_0x4d415d(0xb1)]=_0x5ca245[_0x4d415d(0xbd)](_0x2d4767,_0x2d4767+_0x33225b);let _0x1dd771=_0xcc66c[_0x4d415d(0xeb)](_0x1c23bd,!![]);_0x1c23bd+=Uint32Array['BYTES_PER_ELEMENT'];let _0x1191a4=_0xcc66c[_0x4d415d(0xeb)](_0x1c23bd,!![]);_0x1c23bd+=Uint32Array[_0x4d415d(0xd1)]*_0x1dd771,_0xd7110a['materialCode']=_0x1191a4,_0x17946e[_0x4d415d(0x106)](_0xd7110a);}return _0x582b7f[_0x20da7e]={'vertexPackage':_0x4e6d9c,'arrIndexPackage':_0x17946e},_0x1c23bd;}function _0x5ee3(_0x130f9f,_0x14408f){_0x130f9f=_0x130f9f-0x9b;let _0x16dfbe=_0x16df[_0x130f9f];return _0x16dfbe;}function createBatchIdAttribute$1(_0x19e047,_0x8c6144,_0x3150c7){const _0x5081c3=_0x5ee3;let _0x330132=_0x19e047[_0x5081c3(0xd6)],_0x4d4351=_0x19e047['attrLocation'],_0x236286=_0x330132[_0x5081c3(0xde)],_0x4a5564=_0x3150c7===0x1?'instanceId':_0x5081c3(0xfc);_0x4d4351[_0x4a5564]=_0x236286,_0x330132[_0x5081c3(0x106)]({'index':_0x236286,'typedArray':_0x8c6144,'componentsPerAttribute':0x1,'componentDatatype':Cesium[_0x5081c3(0xd2)][_0x5081c3(0xb3)],'offsetInBytes':0x0,'strideInBytes':0x0,'instanceDivisor':_0x3150c7});}function createGroupAndMaterialNode(_0x2e3f71,_0x2cd1d4,_0x30f0f2){const _0x1475a1=_0x5ee3;let _0x5d7a6a=XMLParser[_0x1475a1(0xfb)](_0x2e3f71),_0x1b0d63=_0x5d7a6a[_0x1475a1(0x100)],_0x1390b1=_0x1b0d63[_0x1475a1(0xbc)];_0x30f0f2[_0x1475a1(0xb7)]=[];let _0x5c3afd=XMLParser['queryFirstNode'](_0x1b0d63,'Material3Ds',_0x1390b1),_0x3ad7a8=XMLParser[_0x1475a1(0xdb)](_0x5c3afd,_0x1475a1(0xb7),_0x1390b1);for(let _0x52c0bf=0x0,_0x505634=_0x3ad7a8[_0x1475a1(0xde)];_0x52c0bf<_0x505634;_0x52c0bf++){let _0x343348={},_0x4e98fa=_0x3ad7a8[_0x52c0bf];_0x343348['id']=XMLParser[_0x1475a1(0x102)](_0x4e98fa,_0x1475a1(0xea),_0x1390b1);let _0x1a42eb=XMLParser['queryFirstNode'](_0x4e98fa,_0x1475a1(0xcb),_0x1390b1),_0x522f02=Cesium['defaultValue'](XMLParser[_0x1475a1(0xc0)](_0x1a42eb,'AmbientR',_0x1390b1),0x1),_0x5d7961=Cesium[_0x1475a1(0xc4)](XMLParser['queryNumericValue'](_0x1a42eb,'AmbientG',_0x1390b1),0x1),_0x3d3e80=Cesium[_0x1475a1(0xc4)](XMLParser[_0x1475a1(0xc0)](_0x1a42eb,_0x1475a1(0xe0),_0x1390b1),0x1),_0x5d8400=Cesium['defaultValue'](XMLParser[_0x1475a1(0xc0)](_0x1a42eb,_0x1475a1(0xc9),_0x1390b1),0x1);_0x343348['ambient']={'r':_0x522f02,'g':_0x5d7961,'b':_0x3d3e80,'a':_0x5d8400};let _0x57a207=XMLParser[_0x1475a1(0xed)](_0x4e98fa,_0x1475a1(0xd0),_0x1390b1);_0x522f02=Cesium[_0x1475a1(0xc4)](XMLParser['queryNumericValue'](_0x57a207,'DiffuseR',_0x1390b1),0x1),_0x5d7961=Cesium[_0x1475a1(0xc4)](XMLParser['queryNumericValue'](_0x57a207,'DiffuseG',_0x1390b1),0x1),_0x3d3e80=Cesium['defaultValue'](XMLParser[_0x1475a1(0xc0)](_0x57a207,_0x1475a1(0xe2),_0x1390b1),0x1),_0x5d8400=Cesium[_0x1475a1(0xc4)](XMLParser[_0x1475a1(0xc0)](_0x57a207,_0x1475a1(0xbe),_0x1390b1),0x1),_0x343348['diffuse']={'r':_0x522f02,'g':_0x5d7961,'b':_0x3d3e80,'a':_0x5d8400};let _0x25d46e=XMLParser['queryFirstNode'](_0x4e98fa,_0x1475a1(0xd3),_0x1390b1);_0x522f02=Cesium[_0x1475a1(0xc4)](XMLParser[_0x1475a1(0xc0)](_0x25d46e,_0x1475a1(0x9c),_0x1390b1),0x0),_0x5d7961=Cesium[_0x1475a1(0xc4)](XMLParser[_0x1475a1(0xc0)](_0x25d46e,_0x1475a1(0xae),_0x1390b1),0x0),_0x3d3e80=Cesium[_0x1475a1(0xc4)](XMLParser[_0x1475a1(0xc0)](_0x25d46e,_0x1475a1(0xe3),_0x1390b1),0x0),_0x5d8400=Cesium['defaultValue'](XMLParser['queryNumericValue'](_0x25d46e,_0x1475a1(0xec),_0x1390b1),0x0),_0x343348[_0x1475a1(0xad)]={'r':_0x522f02,'g':_0x5d7961,'b':_0x3d3e80,'a':_0x5d8400},_0x343348[_0x1475a1(0xd5)]=XMLParser['queryNumericValue'](_0x4e98fa,_0x1475a1(0x103),_0x1390b1),_0x343348[_0x1475a1(0xc5)]=XMLParser[_0x1475a1(0xef)](_0x4e98fa,_0x1475a1(0xf5),_0x1390b1),_0x343348['textureunitstates']=[];let _0x254ac0=XMLParser[_0x1475a1(0xdb)](_0x4e98fa,_0x1475a1(0xf4),_0x1390b1);for(let _0x559d88=0x0;_0x559d88<_0x254ac0[_0x1475a1(0xde)];_0x559d88++){let _0x476ccc={},_0x1b0d1f=_0x254ac0[_0x559d88],_0x5aa3b1=XMLParser[_0x1475a1(0x102)](_0x1b0d1f,_0x1475a1(0xea),_0x1390b1),_0x42600a=XMLParser['queryStringValue'](_0x1b0d1f,_0x1475a1(0x108),_0x1390b1),_0x594e66=XMLParser[_0x1475a1(0xed)](_0x1b0d1f,_0x1475a1(0xa4),_0x1390b1),_0x2b3fc0=XMLParser['queryStringValue'](_0x594e66,'u',_0x1390b1),_0x5d2b44=_0x2b3fc0===_0x1475a1(0xe6)?0x0:0x1,_0xd74155=XMLParser[_0x1475a1(0x102)](_0x594e66,'v',_0x1390b1),_0x6a726=_0xd74155==='TAM_WRAP'?0x0:0x1,_0x1740c2=XMLParser['queryStringValue'](_0x1b0d1f,_0x1475a1(0xcd),_0x1390b1)[_0x1475a1(0xaa)](','),_0x567a2a=0x10;while(_0x567a2a--){_0x1740c2[_0x567a2a]=parseFloat(_0x1740c2[_0x567a2a]);}_0x476ccc[_0x1475a1(0xac)]={'u':_0x5d2b44,'v':_0x6a726,'w':0x0},_0x476ccc[_0x1475a1(0xa9)]=0x20202020,_0x476ccc[_0x1475a1(0xb8)]=0x2,_0x476ccc['filtermin']=0x2,_0x476ccc['id']=_0x5aa3b1,_0x476ccc[_0x1475a1(0xaf)]=_0x1740c2,_0x476ccc[_0x1475a1(0xa0)]='',_0x343348[_0x1475a1(0xda)][_0x1475a1(0x106)]({'textureunitstate':_0x476ccc});}_0x30f0f2[_0x1475a1(0xb7)]['push']({'material':_0x343348});}let _0x3d3844=XMLParser[_0x1475a1(0xed)](_0x1b0d63,_0x1475a1(0xe1),_0x1390b1),_0x26a1c6=XMLParser[_0x1475a1(0xdb)](_0x3d3844,_0x1475a1(0x9b),_0x1390b1);_0x2cd1d4[_0x1475a1(0xdd)]=[];if(_0x26a1c6['length']>0x0)for(let _0x1288cd=0x0,_0x2966e1=_0x26a1c6['length'];_0x1288cd<_0x2966e1;_0x1288cd++){let _0x2261ea=_0x26a1c6[_0x1288cd],_0x4b76ee=XMLParser[_0x1475a1(0x102)](_0x2261ea,_0x1475a1(0xf1),_0x1390b1);_0x4b76ee?_0x4b76ee=_0x4b76ee[_0x1475a1(0xa2)](/.osgb$/,_0x1475a1(0xc8)):_0x4b76ee='';let _0x34bea6=XMLParser[_0x1475a1(0x102)](_0x2261ea,_0x1475a1(0xf6),_0x1390b1),_0x3c9acd=XMLParser[_0x1475a1(0xc0)](_0x2261ea,_0x1475a1(0xd7),_0x1390b1),_0x2a8917=XMLParser[_0x1475a1(0xed)](_0x2261ea,_0x1475a1(0x9f),_0x1390b1),_0x18c0da=XMLParser['queryNumericValue'](_0x2a8917,'x',_0x1390b1),_0x284383=XMLParser[_0x1475a1(0xc0)](_0x2a8917,'y',_0x1390b1),_0x4f145a=XMLParser[_0x1475a1(0xc0)](_0x2a8917,'z',_0x1390b1),_0x43a8ad=XMLParser[_0x1475a1(0xc0)](_0x2a8917,_0x1475a1(0xbb),_0x1390b1),_0x568dc8={'boundingSphere':{'center':{'x':_0x18c0da,'y':_0x284383,'z':_0x4f145a},'radius':_0x43a8ad},'childTile':_0x4b76ee,'geodes':[],'rangeList':_0x3c9acd,'rangeMode':_0x34bea6===_0x1475a1(0xd9)?_0x54aefd[_0x1475a1(0xf2)]:_0x54aefd[_0x1475a1(0x101)]};_0x568dc8['geodes']=[];let _0x188946=XMLParser[_0x1475a1(0xdb)](_0x2261ea,_0x1475a1(0xbf),_0x1390b1);for(let _0x43dda2=0x0;_0x43dda2<_0x188946[_0x1475a1(0xde)];_0x43dda2++){let _0xe2ef08={},_0x16abad=_0x188946[_0x43dda2],_0x44a728=XMLParser[_0x1475a1(0x102)](_0x16abad,_0x1475a1(0xb2),_0x1390b1)[_0x1475a1(0xaa)](',');for(let _0x34c9ff=0x0;_0x34c9ff<0x10;_0x34c9ff++){_0x44a728[_0x34c9ff]=parseFloat(_0x44a728[_0x34c9ff]);}_0xe2ef08[_0x1475a1(0xc3)]=_0x44a728;let _0x4b7f87=XMLParser['queryChildNodes'](_0x16abad,'GeoName');_0xe2ef08[_0x1475a1(0xa6)]=[];for(let _0xc9ba3c=0x0;_0xc9ba3c<_0x4b7f87[_0x1475a1(0xde)];_0xc9ba3c++){let _0x55b0ac=_0x4b7f87[_0xc9ba3c][_0x1475a1(0xee)][_0x1475a1(0xfa)]();_0xe2ef08[_0x1475a1(0xa6)]['push'](_0x55b0ac);}_0x568dc8[_0x1475a1(0xf3)][_0x1475a1(0x106)](_0xe2ef08);}_0x2cd1d4[_0x1475a1(0xdd)]['push'](_0x568dc8);}else {let _0x311472=XMLParser[_0x1475a1(0xdb)](_0x3d3844,_0x1475a1(0xbf),_0x1390b1);if(_0x311472[_0x1475a1(0xde)]>0x0){let _0x4222b9={'boundingSphere':{'center':{'x':0x0,'y':0x0,'z':0x0},'radius':0x615299},'childTile':'','geodes':[],'rangeList':0x0,'rangeMode':_0x54aefd[_0x1475a1(0x101)]};for(let _0x144ff0=0x0,_0x5ea36f=_0x311472['length'];_0x144ff0<_0x5ea36f;_0x144ff0++){let _0x4ab11c={},_0x1a5e6e=_0x311472[_0x144ff0],_0x32bea8=XMLParser[_0x1475a1(0x102)](_0x1a5e6e,'GeoDeModMatrix',_0x1390b1)[_0x1475a1(0xaa)](',');for(let _0x1bfb09=0x0;_0x1bfb09<0x10;_0x1bfb09++){_0x32bea8[_0x1bfb09]=parseFloat(_0x32bea8[_0x1bfb09]);}_0x4ab11c[_0x1475a1(0xc3)]=_0x32bea8;let _0x64d885=XMLParser[_0x1475a1(0xdb)](_0x1a5e6e,'GeoName',_0x1390b1);_0x4ab11c['skeletonNames']=[];for(let _0x42f9ea=0x0;_0x42f9ea<_0x64d885[_0x1475a1(0xde)];_0x42f9ea++){let _0x429860=_0x64d885[_0x42f9ea][_0x1475a1(0xee)][_0x1475a1(0xfa)]();_0x4ab11c['skeletonNames'][_0x1475a1(0x106)](_0x429860);}_0x4222b9[_0x1475a1(0xf3)][_0x1475a1(0x106)](_0x4ab11c);}_0x2cd1d4[_0x1475a1(0xdd)][_0x1475a1(0x106)](_0x4222b9);}}return _0x2cd1d4;}function unZip$1(_0x11d4f9,_0x3e9299){const _0x3f9e95=_0x5ee3;let _0xf228f7=new Uint8Array(_0x11d4f9,_0x3e9299);return _0x1a0f6f[_0x3f9e95(0x107)](_0xf228f7)[_0x3f9e95(0xd8)];}function S3ModelOldParser(){}S3ModelOldParser[_0x19fa79(0xb9)]=function(_0x5315dc){const _0x3d506b=_0x19fa79;let _0x2ab46e=0x0,_0x575298={'groupNode':{},'geoPackage':{},'materials':{},'texturePackage':{}},_0x55ad0c=new Uint8Array(_0x5315dc,0x0,0x4);if(_0x55ad0c[0x0]!==0x73||_0x55ad0c[0x1]!==0x33||_0x55ad0c[0x2]!==0x6d)return {'result':![]};_0x2ab46e+=0x4;let _0x514d08=unZip$1(_0x5315dc,_0x2ab46e),_0x49aaba=new Uint8Array(_0x514d08),_0x5a935d=new DataView(_0x514d08);_0x2ab46e=0x0;let _0x44821f=_0x5a935d[_0x3d506b(0xeb)](_0x2ab46e,!![]);_0x2ab46e+=Uint32Array[_0x3d506b(0xd1)];let _0x56e929=new Uint8Array(_0x514d08,_0x2ab46e,_0x44821f),_0x185473=_0x44821f%0x4;_0x185473&&(_0x185473=0x4-_0x185473);_0x2ab46e+=_0x44821f+_0x185473;let _0x245119=Cesium[_0x3d506b(0xc6)](_0x56e929,undefined,undefined,_0x3d506b(0xe5));createGroupAndMaterialNode(_0x245119,_0x575298[_0x3d506b(0xff)],_0x575298[_0x3d506b(0xfe)]);let _0x3a95a3=_0x5a935d[_0x3d506b(0xeb)](_0x2ab46e,!![]);_0x2ab46e+=Uint32Array['BYTES_PER_ELEMENT'];let _0x1aa41d=_0x5a935d['getUint32'](_0x2ab46e,!![]);_0x2ab46e+=Uint32Array[_0x3d506b(0xd1)];let _0x5cba61=_0x575298[_0x3d506b(0xf9)];for(let _0xfc54a2=0x0;_0xfc54a2<_0x1aa41d;_0xfc54a2++){_0x2ab46e=parseGeoPackage(_0x5cba61,_0x49aaba,_0x5a935d,_0x2ab46e);}let _0x128095=_0x5a935d['getUint32'](_0x2ab46e,!![]);_0x2ab46e+=Uint32Array['BYTES_PER_ELEMENT'];let _0x4a3795=_0x5a935d[_0x3d506b(0xeb)](_0x2ab46e,!![]);_0x2ab46e+=Uint32Array[_0x3d506b(0xd1)];for(let _0x54c1c8=0x0;_0x54c1c8<_0x4a3795;_0x54c1c8++){let _0x58c5d2=_0x5a935d['getUint32'](_0x2ab46e,!![]);_0x2ab46e+=Uint32Array[_0x3d506b(0xd1)];let _0x49ae96=_0x5a935d[_0x3d506b(0xeb)](_0x2ab46e,!![]);_0x2ab46e+=Uint32Array[_0x3d506b(0xd1)];let _0x50f1ae={},_0xf45149=_0x5cba61[_0x58c5d2][_0x3d506b(0xa7)][_0x3d506b(0xcf)];if(_0xf45149===-0x1){let _0x496a6e=new Float32Array(_0x5cba61[_0x58c5d2][_0x3d506b(0xa7)][_0x3d506b(0xa1)]);for(let _0x203087=0x0;_0x203087<_0x49ae96;_0x203087++){let _0x276c6c=_0x5a935d[_0x3d506b(0xeb)](_0x2ab46e,!![]);_0x2ab46e+=Uint32Array[_0x3d506b(0xd1)];let _0x1eb20a=_0x5a935d[_0x3d506b(0xeb)](_0x2ab46e,!![]);_0x2ab46e+=Uint32Array[_0x3d506b(0xd1)];let _0x4d192e=0x0,_0x1c5a2c=0x0;_0x50f1ae[_0x276c6c]=[];for(let _0x3e0628=0x0;_0x3e0628<_0x1eb20a;_0x3e0628++){_0x1c5a2c=_0x5a935d[_0x3d506b(0xeb)](_0x2ab46e,!![]),_0x2ab46e+=Uint32Array['BYTES_PER_ELEMENT'],_0x4d192e=_0x5a935d[_0x3d506b(0xeb)](_0x2ab46e,!![]),_0x2ab46e+=Uint32Array[_0x3d506b(0xd1)];if(_0x496a6e[_0x3d506b(0xc1)])_0x496a6e[_0x3d506b(0xc1)](_0x203087,_0x1c5a2c,_0x1c5a2c+_0x4d192e);else {let _0x416500=_0x1c5a2c+_0x1c5a2c;for(let _0x1ec6b5=_0x1c5a2c;_0x1ec6b5<_0x416500;_0x1ec6b5++){_0x496a6e[_0x1ec6b5]=_0x203087;}}_0x50f1ae[_0x276c6c][_0x3d506b(0x106)]({'vertexColorOffset':_0x1c5a2c,'vertexColorCount':_0x4d192e,'batchId':_0x203087});}}createBatchIdAttribute$1(_0x5cba61[_0x58c5d2][_0x3d506b(0xa7)],_0x496a6e,undefined);}else {let _0xda7d5c=_0x5cba61[_0x58c5d2]['vertexPackage']['instanceCount'],_0x297b5e=_0x5cba61[_0x58c5d2][_0x3d506b(0xa7)][_0x3d506b(0x105)],_0x2c4332=_0x5cba61[_0x58c5d2][_0x3d506b(0xa7)][_0x3d506b(0xe4)],_0x3bdf00=new Float32Array(_0xda7d5c),_0xbfc51c=0x0;for(let _0x2f2f3d=0x0;_0x2f2f3d<_0x49ae96;_0x2f2f3d++){let _0x1eadbf=_0x5a935d['getUint32'](_0x2ab46e,!![]);_0x2ab46e+=Uint32Array['BYTES_PER_ELEMENT'];let _0x4b8730=_0x5a935d['getUint32'](_0x2ab46e,!![]);_0x2ab46e+=Uint32Array[_0x3d506b(0xd1)],_0x50f1ae[_0x1eadbf]=[];for(let _0xf6618d=0x0;_0xf6618d<_0x4b8730;_0xf6618d++){let _0x2d26e9=_0x5a935d['getUint32'](_0x2ab46e,!![]);_0x2ab46e+=Uint32Array[_0x3d506b(0xd1)],_0x3bdf00[_0xbfc51c]=_0xbfc51c,_0x50f1ae[_0x1eadbf]===undefined&&(_0x50f1ae[_0x1eadbf]=[{'vertexColorCount':0x1,'instanceIds':[],'vertexColorOffset':_0xbfc51c}]),_0x50f1ae[_0x1eadbf]['instanceIds']['push'](_0x2d26e9),_0xbfc51c++;}}createBatchIdAttribute$1(_0x5cba61[_0x58c5d2][_0x3d506b(0xa7)],_0x3bdf00,0x1);}_0x5cba61[_0x58c5d2][_0x3d506b(0x10b)]=_0x50f1ae;}let _0x388f9e=_0x5a935d[_0x3d506b(0xeb)](_0x2ab46e,!![]);_0x2ab46e+=Uint32Array['BYTES_PER_ELEMENT'];let _0x5a273a=_0x5a935d[_0x3d506b(0xeb)](_0x2ab46e,!![]);_0x2ab46e+=Uint32Array[_0x3d506b(0xd1)];let _0xe0cc09={};for(let _0x2f1b4c=0x0;_0x2f1b4c<_0x5a273a;_0x2f1b4c++){let _0x58a585=_0x5a935d[_0x3d506b(0xeb)](_0x2ab46e,!![]);_0x2ab46e+=Uint32Array[_0x3d506b(0xd1)];let _0x23b66e=_0x5a935d[_0x3d506b(0xeb)](_0x2ab46e,!![]);_0x2ab46e+=Uint32Array[_0x3d506b(0xd1)];let _0x4c3cd5=_0x5a935d[_0x3d506b(0xeb)](_0x2ab46e,!![]);_0x2ab46e+=Uint32Array[_0x3d506b(0xd1)];let _0x49cf27=_0x5a935d[_0x3d506b(0xeb)](_0x2ab46e,!![]);_0x2ab46e+=Uint32Array['BYTES_PER_ELEMENT'];let _0x33ab9c=_0x5a935d[_0x3d506b(0xeb)](_0x2ab46e,!![]);_0x2ab46e+=Uint32Array['BYTES_PER_ELEMENT'];let _0x47362b=_0x5a935d[_0x3d506b(0xeb)](_0x2ab46e,!![]);_0x2ab46e+=Uint32Array[_0x3d506b(0xd1)];let _0x243c92=_0x47362b===_0xaa1cd8[_0x3d506b(0xb4)]||_0x47362b===_0xaa1cd8['BGR']?Cesium[_0x3d506b(0xa3)][_0x3d506b(0xba)]:Cesium[_0x3d506b(0xa3)][_0x3d506b(0xf7)],_0xa438e9=new Uint8Array(_0x514d08,_0x2ab46e,_0x33ab9c);_0xe0cc09[_0x58a585]={'id':_0x58a585,'width':_0x23b66e,'height':_0x4c3cd5,'compressType':_0x49cf27,'nFormat':_0x47362b,'arrayBufferView':_0xa438e9,'internalFormat':_0x243c92},_0x2ab46e+=_0x33ab9c;}return _0x575298[_0x3d506b(0xfd)]=_0xe0cc09,_0x575298;};

    const _0x5665=['aNormal','buffer','SVC_Normal','609057NZnzQH','texCoordCompressConstant','aTexCoordZ','rangeList','getFloat32','2944188elWMBB','isRootTile','uv1','uv3','vertexPackage','vertexAttributes','geodes','aColor','aSecondColor','getFloat64','length','matrix','arrayFill','red','rangeMode','indicesCount','subName','getUint8','geoName','substring','split','materialCode','verticesCount','texturePackage','createEdgeDataByIndices','instanceIndex','instanceBounds','materials','getUint16','minTexCoordValue','push','string','geoPackage','SV_Compressed','instanceBuffer','parseBuffer','uv5','780480UGIZKX','uv4','instanceMode','uv7','SVC_TexutreCoord','attrLocation','764770JgNoIK','subVertexOffsetArr','FLOAT','rootBatchIdMap','Geometry','3330UwJjvC','vertexColorInstance','uv6','batchId','groupNode','aPosition','count','childTile','SHORT','offset','unpack','uv9','42uxlkBr','SVC_Vertex','SV_Standard','vertCompressConstant','textureCoordIsW','aTexCoord','bytesOffset','SVC_TexutreCoordIsW','primitiveType','skeletonNames','instanceIds','replace','texUnitIndex','670056HEXwIB','hasOwnProperty','ComponentDatatype','uv2','BYTES_PER_ELEMENT','green','pickInfo','boundingSphere','getUint32','630986lXNiBf','instanceCount','indexOf','secondary_colour','parse','inflate','UNSIGNED_BYTE','pageLods','indexType'];const _0x593a7b=_0x7369;(function(_0x56dce8,_0xdfd644){const _0x111948=_0x7369;while(!![]){try{const _0x34f346=parseInt(_0x111948(0x1e3))+-parseInt(_0x111948(0x186))+-parseInt(_0x111948(0x1a4))+-parseInt(_0x111948(0x1ad))+parseInt(_0x111948(0x18b))*-parseInt(_0x111948(0x197))+-parseInt(_0x111948(0x1b9))+parseInt(_0x111948(0x1be));if(_0x34f346===_0xdfd644)break;else _0x56dce8['push'](_0x56dce8['shift']());}catch(_0x2a98c8){_0x56dce8['push'](_0x56dce8['shift']());}}}(_0x5665,0xde273));function S3MBlockParser(){}let S3MBVertexTag$1={'SV_Unkown':0x0,'SV_Standard':0x1,'SV_Compressed':0x2};function parseString$1(_0x257955,_0x1dd5af,_0x2ecf3c){const _0x1f4891=_0x7369;let _0x18133f=_0x1dd5af[_0x1f4891(0x1ac)](_0x2ecf3c,!![]);_0x2ecf3c+=Uint32Array[_0x1f4891(0x1a8)];let _0x77eae=new Uint8Array(_0x257955,_0x2ecf3c,_0x18133f),_0x358266=Cesium['getStringFromTypedArray'](_0x77eae);return _0x2ecf3c+=_0x18133f,{'string':_0x358266,'bytesOffset':_0x2ecf3c};}function parseGeode$1(_0x469548,_0x170046,_0x3b07c9,_0x2fd606){const _0x2d329a=_0x7369;let _0x3efdfd={},_0x59fc03=[],_0x232391=new Array(0x10);for(let _0x517f47=0x0;_0x517f47<0x10;_0x517f47++){_0x232391[_0x517f47]=_0x170046['getFloat64'](_0x3b07c9,!![]),_0x3b07c9+=Float64Array[_0x2d329a(0x1a8)];}_0x3efdfd[_0x2d329a(0x1c9)]=_0x232391,_0x3efdfd[_0x2d329a(0x1a0)]=_0x59fc03;let _0x48e1e5=_0x170046[_0x2d329a(0x1ac)](_0x3b07c9,!![]);_0x3b07c9+=Uint32Array[_0x2d329a(0x1a8)];for(let _0x553bf0=0x0;_0x553bf0<_0x48e1e5;_0x553bf0++){let _0x4ca77f=parseString$1(_0x469548,_0x170046,_0x3b07c9);_0x59fc03[_0x2d329a(0x1dc)](_0x4ca77f[_0x2d329a(0x1dd)]),_0x3b07c9=_0x4ca77f[_0x2d329a(0x19d)];}return _0x2fd606[_0x2d329a(0x1dc)](_0x3efdfd),_0x3b07c9;}function parsePageLOD$1(_0x59fe22,_0x218ae7,_0x106994,_0x1350d2){const _0x459868=_0x7369;let _0x2eef39={};_0x2eef39[_0x459868(0x1bc)]=_0x218ae7[_0x459868(0x1bd)](_0x106994,!![]),_0x106994+=Float32Array[_0x459868(0x1a8)],_0x2eef39[_0x459868(0x1cc)]=_0x218ae7[_0x459868(0x1da)](_0x106994,!![]),_0x106994+=Uint16Array['BYTES_PER_ELEMENT'];let _0x569ffd={};_0x569ffd['x']=_0x218ae7['getFloat64'](_0x106994,!![]),_0x106994+=Float64Array[_0x459868(0x1a8)],_0x569ffd['y']=_0x218ae7[_0x459868(0x1c7)](_0x106994,!![]),_0x106994+=Float64Array[_0x459868(0x1a8)],_0x569ffd['z']=_0x218ae7[_0x459868(0x1c7)](_0x106994,!![]),_0x106994+=Float64Array[_0x459868(0x1a8)];let _0x447770=_0x218ae7['getFloat64'](_0x106994,!![]);_0x106994+=Float64Array[_0x459868(0x1a8)],_0x2eef39[_0x459868(0x1ab)]={'center':_0x569ffd,'radius':_0x447770};let _0x12f24b=parseString$1(_0x59fe22,_0x218ae7,_0x106994),_0x343fe8=_0x12f24b[_0x459868(0x1dd)];_0x106994=_0x12f24b[_0x459868(0x19d)];let _0x53749b=_0x343fe8['indexOf'](_0x459868(0x18a));if(_0x53749b!==-0x1){let _0x467620=_0x343fe8[_0x459868(0x1d1)](_0x53749b);_0x343fe8=_0x343fe8[_0x459868(0x1a2)](_0x467620,'');}_0x2eef39[_0x459868(0x192)]=_0x343fe8,_0x2eef39['geodes']=[];let _0x20bc43=_0x218ae7['getUint32'](_0x106994,!![]);_0x106994+=Uint32Array['BYTES_PER_ELEMENT'];for(let _0x299219=0x0;_0x299219<_0x20bc43;_0x299219++){_0x106994=parseGeode$1(_0x59fe22,_0x218ae7,_0x106994,_0x2eef39[_0x459868(0x1c4)]);}return _0x1350d2[_0x459868(0x1dc)](_0x2eef39),_0x106994;}function parseGroupNode$1(_0x1c76ae,_0x41c9cb,_0x3174e8,_0x1013d6){const _0x1ed47e=_0x7369;let _0x5a8bdb={},_0x1fb6f0=[],_0x4f6377=_0x41c9cb['getUint32'](_0x3174e8,!![]);_0x3174e8+=Uint32Array['BYTES_PER_ELEMENT'];let _0xb9719b=_0x41c9cb['getUint32'](_0x3174e8,!![]);_0x3174e8+=Uint32Array[_0x1ed47e(0x1a8)];for(let _0x2f200e=0x0;_0x2f200e<_0xb9719b;_0x2f200e++){_0x3174e8=parsePageLOD$1(_0x1c76ae,_0x41c9cb,_0x3174e8,_0x1fb6f0);}_0x5a8bdb[_0x1ed47e(0x1b4)]=_0x1fb6f0;let _0x50ff82=_0x3174e8%0x4;return _0x50ff82!==0x0&&(_0x3174e8+=0x4-_0x50ff82),_0x1013d6[_0x1ed47e(0x18f)]=_0x5a8bdb,_0x3174e8;}function parseVertex$1(_0x4bfea3,_0x12f996,_0x4a46a8,_0x3f3310){const _0x320d9b=_0x7369;let _0xf03578=_0x12f996['getUint32'](_0x4a46a8,!![]);_0x3f3310[_0x320d9b(0x1d4)]=_0xf03578,_0x4a46a8+=Uint32Array[_0x320d9b(0x1a8)];if(_0x4a46a8<=0x0)return _0x4a46a8;let _0x4c2e0f=_0x12f996[_0x320d9b(0x1da)](_0x4a46a8,!![]);_0x4a46a8+=Uint16Array[_0x320d9b(0x1a8)];let _0x2c3d00=_0x12f996[_0x320d9b(0x1da)](_0x4a46a8,!![]);_0x2c3d00=_0x4c2e0f*Float32Array[_0x320d9b(0x1a8)],_0x4a46a8+=Uint16Array[_0x320d9b(0x1a8)];let _0x222b54=_0xf03578*_0x4c2e0f*Float32Array['BYTES_PER_ELEMENT'],_0x2d91ac=new Uint8Array(_0x4bfea3,_0x4a46a8,_0x222b54);_0x4a46a8+=_0x222b54;let _0x5bf9a8=_0x3f3310[_0x320d9b(0x1c3)],_0x3f6ff7=_0x3f3310[_0x320d9b(0x185)];return _0x3f6ff7[_0x320d9b(0x190)]=_0x5bf9a8[_0x320d9b(0x1c8)],_0x5bf9a8[_0x320d9b(0x1dc)]({'index':_0x3f6ff7[_0x320d9b(0x190)],'typedArray':_0x2d91ac,'componentsPerAttribute':_0x4c2e0f,'componentDatatype':Cesium[_0x320d9b(0x1a6)][_0x320d9b(0x188)],'offsetInBytes':0x0,'strideInBytes':_0x2c3d00,'normalize':![]}),_0x4a46a8;}function parseNormal$1(_0x4d10f4,_0x3e5af6,_0x416878,_0xe78ee6){const _0x2d722b=_0x7369;let _0x3955c0=_0x3e5af6[_0x2d722b(0x1ac)](_0x416878,!![]);_0x416878+=Uint32Array['BYTES_PER_ELEMENT'];if(_0x3955c0<=0x0)return _0x416878;let _0x23e214=_0x3e5af6[_0x2d722b(0x1da)](_0x416878,!![]);_0x416878+=Uint16Array[_0x2d722b(0x1a8)];let _0x3d20d6=_0x3e5af6['getUint16'](_0x416878,!![]);_0x416878+=Uint16Array[_0x2d722b(0x1a8)];let _0x457582=_0x3955c0*_0x23e214*Float32Array['BYTES_PER_ELEMENT'],_0x2dc321=new Uint8Array(_0x4d10f4,_0x416878,_0x457582);_0x416878+=_0x457582;let _0x51253c=_0xe78ee6['vertexAttributes'],_0xf49614=_0xe78ee6[_0x2d722b(0x185)];return _0xf49614[_0x2d722b(0x1b6)]=_0x51253c[_0x2d722b(0x1c8)],_0x51253c[_0x2d722b(0x1dc)]({'index':_0xf49614['aNormal'],'typedArray':_0x2dc321,'componentsPerAttribute':_0x23e214,'componentDatatype':Cesium[_0x2d722b(0x1a6)][_0x2d722b(0x188)],'offsetInBytes':0x0,'strideInBytes':_0x3d20d6,'normalize':![]}),_0x416878;}function parseVertexColor$1(_0x36921e,_0x5621e5,_0x9febee,_0x8c1d3e){const _0x28fd3=_0x7369;let _0x2eacff=_0x5621e5[_0x28fd3(0x1ac)](_0x9febee,!![]);_0x9febee+=Uint32Array[_0x28fd3(0x1a8)];let _0x4da73c=_0x8c1d3e['verticesCount'],_0x326dc1;if(_0x2eacff>0x0){let _0x43be71=_0x5621e5[_0x28fd3(0x1da)](_0x9febee,!![]);_0x9febee+=Uint16Array[_0x28fd3(0x1a8)],_0x9febee+=Uint8Array['BYTES_PER_ELEMENT']*0x2;let _0xdc318d=_0x2eacff*Uint8Array['BYTES_PER_ELEMENT']*0x4,_0x160131=new Uint8Array(_0x36921e,_0x9febee,_0xdc318d);_0x326dc1=_0x160131['slice'](0x0,_0xdc318d),_0x9febee+=_0xdc318d;}else {_0x326dc1=new Uint8Array(0x4*_0x4da73c);for(let _0x45fc9d=0x0;_0x45fc9d<_0x4da73c;_0x45fc9d++){_0x326dc1[_0x45fc9d*0x4]=0xff,_0x326dc1[_0x45fc9d*0x4+0x1]=0xff,_0x326dc1[_0x45fc9d*0x4+0x2]=0xff,_0x326dc1[_0x45fc9d*0x4+0x3]=0xff;}}let _0x15d576=_0x8c1d3e['vertexAttributes'],_0x439410=_0x8c1d3e[_0x28fd3(0x185)];return _0x439410[_0x28fd3(0x1c5)]=_0x15d576[_0x28fd3(0x1c8)],_0x15d576[_0x28fd3(0x1dc)]({'index':_0x439410['aColor'],'typedArray':_0x326dc1,'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x28fd3(0x1a6)][_0x28fd3(0x1b3)],'offsetInBytes':0x0,'strideInBytes':0x4,'normalize':!![]}),_0x8c1d3e['vertexColor']=_0x326dc1,_0x9febee;}function parseSecondColor$1(_0x5f45af,_0x1f31a2,_0x5dd75a,_0x2360cd){const _0x210db6=_0x7369;let _0x37e8a8=_0x1f31a2[_0x210db6(0x1ac)](_0x5dd75a,!![]);_0x5dd75a+=Uint32Array[_0x210db6(0x1a8)];if(_0x37e8a8<=0x0)return _0x5dd75a;let _0x434212=_0x1f31a2[_0x210db6(0x1da)](_0x5dd75a,!![]);_0x5dd75a+=Uint16Array[_0x210db6(0x1a8)],_0x5dd75a+=Uint8Array[_0x210db6(0x1a8)]*0x2;let _0x3b4685=_0x37e8a8*Uint8Array[_0x210db6(0x1a8)]*0x4,_0x515ad8=new Uint8Array(_0x5f45af,_0x5dd75a,_0x3b4685);_0x5dd75a+=_0x3b4685;let _0x265159=_0x2360cd[_0x210db6(0x1c3)],_0x3c23a8=_0x2360cd['attrLocation'];return _0x3c23a8[_0x210db6(0x1c6)]=_0x265159[_0x210db6(0x1c8)],_0x265159[_0x210db6(0x1dc)]({'index':_0x3c23a8['aSecondColor'],'typedArray':_0x515ad8,'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x210db6(0x1a6)][_0x210db6(0x1b3)],'offsetInBytes':0x0,'strideInBytes':0x4,'normalize':!![]}),_0x5dd75a;}function parseTexCoord$1(_0x33993c,_0x29cc85,_0x8f3839,_0x5d88eb){const _0x244970=_0x7369;let _0x2bfd94=_0x29cc85[_0x244970(0x1da)](_0x8f3839,!![]);_0x8f3839+=Uint16Array[_0x244970(0x1a8)],_0x8f3839+=Uint16Array[_0x244970(0x1a8)];for(let _0x5adb73=0x0;_0x5adb73<_0x2bfd94;_0x5adb73++){let _0x2d22b6=_0x29cc85[_0x244970(0x1ac)](_0x8f3839,!![]);_0x8f3839+=Uint32Array['BYTES_PER_ELEMENT'];let _0x2a3f2e=_0x29cc85[_0x244970(0x1da)](_0x8f3839,!![]);_0x8f3839+=Uint16Array[_0x244970(0x1a8)];let _0x4e16cb=_0x29cc85['getUint16'](_0x8f3839,!![]);_0x8f3839+=Uint16Array[_0x244970(0x1a8)];let _0x3a788f=_0x2d22b6*_0x2a3f2e*Float32Array[_0x244970(0x1a8)],_0x33d2fb=new Uint8Array(_0x33993c,_0x8f3839,_0x3a788f);_0x8f3839+=_0x3a788f;let _0x2868eb=_0x244970(0x19c)+_0x5adb73,_0x548948=_0x5d88eb[_0x244970(0x1c3)],_0x2dc3c7=_0x5d88eb[_0x244970(0x185)];_0x2dc3c7[_0x2868eb]=_0x548948[_0x244970(0x1c8)],_0x548948[_0x244970(0x1dc)]({'index':_0x2dc3c7[_0x2868eb],'typedArray':_0x33d2fb,'componentsPerAttribute':_0x2a3f2e,'componentDatatype':Cesium[_0x244970(0x1a6)][_0x244970(0x188)],'offsetInBytes':0x0,'strideInBytes':_0x2a3f2e*Float32Array['BYTES_PER_ELEMENT'],'normalize':![]});}return _0x8f3839;}function parseInstanceInfo$1(_0x1df164,_0x234200,_0x288613,_0x12fdd1){const _0x1a411c=_0x7369;let _0x3cfdda=_0x234200['getUint16'](_0x288613,!![]);_0x288613+=Uint16Array[_0x1a411c(0x1a8)],_0x288613+=Uint16Array[_0x1a411c(0x1a8)];let _0x5181ab=_0x12fdd1['vertexAttributes'],_0x181dea=_0x12fdd1['attrLocation'];for(let _0x44203d=0x0;_0x44203d<_0x3cfdda;_0x44203d++){let _0x20a8b1=_0x234200[_0x1a411c(0x1ac)](_0x288613,!![]);_0x288613+=Uint32Array[_0x1a411c(0x1a8)];let _0x28520d=_0x234200['getUint16'](_0x288613,!![]);_0x288613+=Uint16Array[_0x1a411c(0x1a8)];let _0x2cbca9=_0x234200[_0x1a411c(0x1da)](_0x288613,!![]);_0x288613+=Uint16Array[_0x1a411c(0x1a8)];let _0x29e1ec=_0x20a8b1*_0x28520d*Float32Array[_0x1a411c(0x1a8)];if(_0x28520d===0x11||_0x28520d===0x1d){let _0x42355d=new Uint8Array(_0x1df164,_0x288613,_0x29e1ec);_0x12fdd1[_0x1a411c(0x1ae)]=_0x20a8b1,_0x12fdd1['instanceMode']=_0x28520d,_0x12fdd1[_0x1a411c(0x1e0)]=_0x42355d,_0x12fdd1[_0x1a411c(0x1d7)]=0x1;let _0x57ef7b=_0x28520d*_0x20a8b1*0x4,_0x59bd0d=_0x42355d['slice'](0x0,_0x57ef7b);_0x12fdd1[_0x1a411c(0x18c)]=_0x59bd0d;let _0x1e0a9b;if(_0x28520d===0x11)_0x1e0a9b=Float32Array[_0x1a411c(0x1a8)]*0x11,_0x181dea[_0x1a411c(0x1a7)]=_0x5181ab[_0x1a411c(0x1c8)],_0x5181ab[_0x1a411c(0x1dc)]({'index':_0x181dea[_0x1a411c(0x1a7)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x1a411c(0x1a6)][_0x1a411c(0x188)],'normalize':![],'offsetInBytes':0x0,'strideInBytes':_0x1e0a9b,'instanceDivisor':0x1}),_0x181dea['uv3']=_0x5181ab[_0x1a411c(0x1c8)],_0x5181ab[_0x1a411c(0x1dc)]({'index':_0x181dea[_0x1a411c(0x1c1)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x1a411c(0x1a6)][_0x1a411c(0x188)],'normalize':![],'offsetInBytes':0x4*Float32Array['BYTES_PER_ELEMENT'],'strideInBytes':_0x1e0a9b,'instanceDivisor':0x1}),_0x181dea[_0x1a411c(0x1e4)]=_0x5181ab[_0x1a411c(0x1c8)],_0x5181ab['push']({'index':_0x181dea['uv4'],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x1a411c(0x1a6)][_0x1a411c(0x188)],'normalize':![],'offsetInBytes':0x8*Float32Array[_0x1a411c(0x1a8)],'strideInBytes':_0x1e0a9b,'instanceDivisor':0x1}),_0x181dea['secondary_colour']=_0x5181ab[_0x1a411c(0x1c8)],_0x5181ab['push']({'index':_0x181dea[_0x1a411c(0x1b0)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x1a411c(0x1a6)]['FLOAT'],'normalize':![],'offsetInBytes':0xc*Float32Array[_0x1a411c(0x1a8)],'strideInBytes':_0x1e0a9b,'instanceDivisor':0x1}),_0x181dea[_0x1a411c(0x18d)]=_0x5181ab[_0x1a411c(0x1c8)],_0x5181ab['push']({'index':_0x181dea[_0x1a411c(0x18d)],'componentsPerAttribute':0x4,'componentDatatype':Cesium['ComponentDatatype'][_0x1a411c(0x1b3)],'normalize':!![],'offsetInBytes':0x10*Float32Array[_0x1a411c(0x1a8)],'strideInBytes':_0x1e0a9b,'instanceDivisor':0x1});else _0x28520d===0x1d&&(_0x1e0a9b=Float32Array[_0x1a411c(0x1a8)]*0x1d,_0x181dea[_0x1a411c(0x1c0)]=_0x5181ab[_0x1a411c(0x1c8)],_0x5181ab['push']({'index':_0x181dea[_0x1a411c(0x1c0)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x1a411c(0x1a6)][_0x1a411c(0x188)],'normalize':![],'offsetInBytes':0x0,'strideInBytes':_0x1e0a9b,'instanceDivisor':0x1,'byteLength':_0x29e1ec}),_0x181dea[_0x1a411c(0x1a7)]=_0x5181ab['length'],_0x5181ab[_0x1a411c(0x1dc)]({'index':_0x181dea[_0x1a411c(0x1a7)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x1a411c(0x1a6)][_0x1a411c(0x188)],'normalize':![],'offsetInBytes':0x4*Float32Array['BYTES_PER_ELEMENT'],'strideInBytes':_0x1e0a9b,'instanceDivisor':0x1}),_0x181dea[_0x1a411c(0x1c1)]=_0x5181ab[_0x1a411c(0x1c8)],_0x5181ab[_0x1a411c(0x1dc)]({'index':_0x181dea[_0x1a411c(0x1c1)],'componentsPerAttribute':0x4,'componentDatatype':Cesium['ComponentDatatype'][_0x1a411c(0x188)],'normalize':![],'offsetInBytes':0x8*Float32Array['BYTES_PER_ELEMENT'],'strideInBytes':_0x1e0a9b,'instanceDivisor':0x1}),_0x181dea[_0x1a411c(0x1e4)]=_0x5181ab[_0x1a411c(0x1c8)],_0x5181ab[_0x1a411c(0x1dc)]({'index':_0x181dea['uv4'],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x1a411c(0x1a6)]['FLOAT'],'normalize':![],'offsetInBytes':0xc*Float32Array[_0x1a411c(0x1a8)],'strideInBytes':_0x1e0a9b,'instanceDivisor':0x1}),_0x181dea[_0x1a411c(0x1e2)]=_0x5181ab[_0x1a411c(0x1c8)],_0x5181ab[_0x1a411c(0x1dc)]({'index':_0x181dea[_0x1a411c(0x1e2)],'componentsPerAttribute':0x4,'componentDatatype':Cesium['ComponentDatatype'][_0x1a411c(0x188)],'normalize':![],'offsetInBytes':0x10*Float32Array[_0x1a411c(0x1a8)],'strideInBytes':_0x1e0a9b,'instanceDivisor':0x1}),_0x181dea['uv6']=_0x5181ab['length'],_0x5181ab[_0x1a411c(0x1dc)]({'index':_0x181dea[_0x1a411c(0x18d)],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x1a411c(0x1a6)][_0x1a411c(0x188)],'normalize':![],'offsetInBytes':0x14*Float32Array[_0x1a411c(0x1a8)],'strideInBytes':_0x1e0a9b,'instanceDivisor':0x1}),_0x181dea[_0x1a411c(0x183)]=_0x5181ab[_0x1a411c(0x1c8)],_0x5181ab['push']({'index':_0x181dea[_0x1a411c(0x183)],'componentsPerAttribute':0x3,'componentDatatype':Cesium[_0x1a411c(0x1a6)][_0x1a411c(0x188)],'normalize':![],'offsetInBytes':0x18*Float32Array['BYTES_PER_ELEMENT'],'strideInBytes':_0x1e0a9b,'instanceDivisor':0x1}),_0x181dea['secondary_colour']=_0x5181ab['length'],_0x5181ab[_0x1a411c(0x1dc)]({'index':_0x181dea['secondary_colour'],'componentsPerAttribute':0x4,'componentDatatype':Cesium[_0x1a411c(0x1a6)][_0x1a411c(0x1b3)],'normalize':!![],'offsetInBytes':0x1b*Float32Array[_0x1a411c(0x1a8)],'strideInBytes':_0x1e0a9b,'instanceDivisor':0x1}),_0x181dea[_0x1a411c(0x196)]=_0x5181ab[_0x1a411c(0x1c8)],_0x5181ab[_0x1a411c(0x1dc)]({'index':_0x181dea['uv9'],'componentsPerAttribute':0x4,'componentDatatype':Cesium['ComponentDatatype'][_0x1a411c(0x1b3)],'normalize':!![],'offsetInBytes':0x1c*Float32Array[_0x1a411c(0x1a8)],'strideInBytes':_0x1e0a9b,'instanceDivisor':0x1}));}else {let _0xa484bc=_0x20a8b1*_0x28520d;_0x12fdd1['instanceBounds']=new Float32Array(_0xa484bc);for(let _0x503266=0x0;_0x503266<_0xa484bc;_0x503266++){_0x12fdd1[_0x1a411c(0x1d8)][_0x503266]=_0x234200[_0x1a411c(0x1bd)](_0x288613+_0x503266*Float32Array[_0x1a411c(0x1a8)],!![]);}}_0x288613+=_0x29e1ec;}return _0x288613;}function parseCompressVertex$1(_0x6adb7b,_0x524b79,_0x3b9ccb,_0x59ba4a){const _0x52bcae=_0x7369;let _0x5603be=_0x524b79[_0x52bcae(0x1ac)](_0x3b9ccb,!![]);_0x59ba4a[_0x52bcae(0x1d4)]=_0x5603be,_0x3b9ccb+=Uint32Array['BYTES_PER_ELEMENT'];if(_0x3b9ccb<=0x0)return _0x3b9ccb;let _0x38340a=_0x524b79['getUint16'](_0x3b9ccb,!![]);_0x3b9ccb+=Uint16Array[_0x52bcae(0x1a8)];let _0x17c586=_0x524b79['getUint16'](_0x3b9ccb,!![]);_0x17c586=_0x38340a*Int16Array[_0x52bcae(0x1a8)],_0x3b9ccb+=Uint16Array[_0x52bcae(0x1a8)];let _0x3f5e61=_0x524b79[_0x52bcae(0x1bd)](_0x3b9ccb,!![]);_0x3b9ccb+=Float32Array[_0x52bcae(0x1a8)];let _0x4ded3e={};_0x4ded3e['x']=_0x524b79[_0x52bcae(0x1bd)](_0x3b9ccb,!![]),_0x3b9ccb+=Float32Array[_0x52bcae(0x1a8)],_0x4ded3e['y']=_0x524b79[_0x52bcae(0x1bd)](_0x3b9ccb,!![]),_0x3b9ccb+=Float32Array[_0x52bcae(0x1a8)],_0x4ded3e['z']=_0x524b79[_0x52bcae(0x1bd)](_0x3b9ccb,!![]),_0x3b9ccb+=Float32Array[_0x52bcae(0x1a8)],_0x4ded3e['w']=_0x524b79[_0x52bcae(0x1bd)](_0x3b9ccb,!![]),_0x3b9ccb+=Float32Array['BYTES_PER_ELEMENT'],_0x59ba4a[_0x52bcae(0x19a)]=_0x3f5e61,_0x59ba4a['minVerticesValue']=_0x4ded3e;let _0x3ef0f4=_0x5603be*_0x38340a*Int16Array[_0x52bcae(0x1a8)],_0x3f2695=new Uint8Array(_0x6adb7b,_0x3b9ccb,_0x3ef0f4);_0x3b9ccb+=_0x3ef0f4;let _0x5e33cc=_0x59ba4a[_0x52bcae(0x1c3)],_0x17146d=_0x59ba4a[_0x52bcae(0x185)];return _0x17146d[_0x52bcae(0x190)]=_0x5e33cc[_0x52bcae(0x1c8)],_0x5e33cc[_0x52bcae(0x1dc)]({'index':_0x17146d[_0x52bcae(0x190)],'typedArray':_0x3f2695,'componentsPerAttribute':_0x38340a,'componentDatatype':Cesium[_0x52bcae(0x1a6)][_0x52bcae(0x193)],'offsetInBytes':0x0,'strideInBytes':_0x17c586,'normalize':![]}),_0x3b9ccb;}function parseCompressNormal$1(_0x377dd5,_0x318b75,_0x29bc70,_0x1de04e){const _0x5b5e68=_0x7369;let _0x2d5a68=_0x318b75['getUint32'](_0x29bc70,!![]);_0x29bc70+=Uint32Array[_0x5b5e68(0x1a8)];if(_0x2d5a68<=0x0)return _0x29bc70;let _0x2aac12=_0x318b75[_0x5b5e68(0x1da)](_0x29bc70,!![]);_0x29bc70+=Uint16Array[_0x5b5e68(0x1a8)];let _0x178b5e=_0x318b75[_0x5b5e68(0x1da)](_0x29bc70,!![]);_0x29bc70+=Uint16Array[_0x5b5e68(0x1a8)];let _0x271c2e=_0x2d5a68*0x2*Int16Array[_0x5b5e68(0x1a8)],_0xcf67cc=new Uint8Array(_0x377dd5,_0x29bc70,_0x271c2e);_0x29bc70+=_0x271c2e;let _0x4536ee=_0x1de04e['vertexAttributes'],_0x468bd3=_0x1de04e['attrLocation'];return _0x468bd3[_0x5b5e68(0x1b6)]=_0x4536ee[_0x5b5e68(0x1c8)],_0x4536ee[_0x5b5e68(0x1dc)]({'index':_0x468bd3[_0x5b5e68(0x1b6)],'typedArray':_0xcf67cc,'componentsPerAttribute':0x2,'componentDatatype':Cesium[_0x5b5e68(0x1a6)][_0x5b5e68(0x193)],'offsetInBytes':0x0,'strideInBytes':_0x178b5e,'normalize':![]}),_0x29bc70;}function parseCompressTexCoord$1(_0x237302,_0x2353e2,_0x4b881a,_0x7b34ea){const _0x339db2=_0x7369;_0x7b34ea[_0x339db2(0x1ba)]=[],_0x7b34ea[_0x339db2(0x1db)]=[];let _0x14fc9d=_0x2353e2['getUint16'](_0x4b881a,!![]);_0x4b881a+=Uint16Array[_0x339db2(0x1a8)],_0x4b881a+=Uint16Array[_0x339db2(0x1a8)];for(let _0x37b86b=0x0;_0x37b86b<_0x14fc9d;_0x37b86b++){let _0x240680=_0x2353e2[_0x339db2(0x1cf)](_0x4b881a,!![]);_0x4b881a+=Uint8Array[_0x339db2(0x1a8)],_0x4b881a+=Uint8Array[_0x339db2(0x1a8)]*0x3;let _0x1b8da8=_0x2353e2['getUint32'](_0x4b881a,!![]);_0x4b881a+=Uint32Array[_0x339db2(0x1a8)];let _0x246439=_0x2353e2['getUint16'](_0x4b881a,!![]);_0x4b881a+=Uint16Array[_0x339db2(0x1a8)];let _0x50141f=_0x2353e2[_0x339db2(0x1da)](_0x4b881a,!![]);_0x4b881a+=Uint16Array[_0x339db2(0x1a8)];let _0x406d9b=_0x2353e2[_0x339db2(0x1bd)](_0x4b881a,!![]);_0x4b881a+=Float32Array['BYTES_PER_ELEMENT'],_0x7b34ea[_0x339db2(0x1ba)][_0x339db2(0x1dc)](_0x406d9b);let _0x218216={};_0x218216['x']=_0x2353e2[_0x339db2(0x1bd)](_0x4b881a,!![]),_0x4b881a+=Float32Array[_0x339db2(0x1a8)],_0x218216['y']=_0x2353e2[_0x339db2(0x1bd)](_0x4b881a,!![]),_0x4b881a+=Float32Array[_0x339db2(0x1a8)],_0x218216['z']=_0x2353e2[_0x339db2(0x1bd)](_0x4b881a,!![]),_0x4b881a+=Float32Array[_0x339db2(0x1a8)],_0x218216['w']=_0x2353e2[_0x339db2(0x1bd)](_0x4b881a,!![]),_0x4b881a+=Float32Array[_0x339db2(0x1a8)],_0x7b34ea[_0x339db2(0x1db)]['push'](_0x218216);let _0x1feefe=_0x1b8da8*_0x246439*Int16Array[_0x339db2(0x1a8)],_0x54c7fc=new Uint8Array(_0x237302,_0x4b881a,_0x1feefe);_0x4b881a+=_0x1feefe;let _0x49824e=_0x4b881a%0x4;_0x49824e!==0x0&&(_0x4b881a+=0x4-_0x49824e);let _0x52e4a2=_0x339db2(0x19c)+_0x37b86b,_0x2c9ca9=_0x7b34ea[_0x339db2(0x1c3)],_0x448156=_0x7b34ea[_0x339db2(0x185)];_0x448156[_0x52e4a2]=_0x2c9ca9[_0x339db2(0x1c8)],_0x2c9ca9[_0x339db2(0x1dc)]({'index':_0x448156[_0x52e4a2],'typedArray':_0x54c7fc,'componentsPerAttribute':_0x246439,'componentDatatype':Cesium[_0x339db2(0x1a6)]['SHORT'],'offsetInBytes':0x0,'strideInBytes':_0x246439*Int16Array[_0x339db2(0x1a8)],'normalize':![]});if(_0x240680){_0x1feefe=_0x1b8da8*Float32Array[_0x339db2(0x1a8)];let _0x5a21d5=new Uint8Array(_0x237302,_0x4b881a,_0x1feefe);_0x4b881a+=_0x1feefe,_0x7b34ea['texCoordZMatrix']=!![],_0x52e4a2=_0x339db2(0x1bb)+_0x37b86b,_0x448156[_0x52e4a2]=_0x2c9ca9[_0x339db2(0x1c8)],_0x2c9ca9['push']({'index':_0x448156[_0x52e4a2],'typedArray':_0x5a21d5,'componentsPerAttribute':0x1,'componentDatatype':Cesium[_0x339db2(0x1a6)]['FLOAT'],'offsetInBytes':0x0,'strideInBytes':Float32Array[_0x339db2(0x1a8)],'normalize':![]});}}return _0x4b881a;}function parseStandardSkeleton$1(_0x5ec640,_0x42eb2b,_0x119b5f,_0x453a0f){return _0x119b5f=parseVertex$1(_0x5ec640,_0x42eb2b,_0x119b5f,_0x453a0f),_0x119b5f=parseNormal$1(_0x5ec640,_0x42eb2b,_0x119b5f,_0x453a0f),_0x119b5f=parseVertexColor$1(_0x5ec640,_0x42eb2b,_0x119b5f,_0x453a0f),_0x119b5f=parseSecondColor$1(_0x5ec640,_0x42eb2b,_0x119b5f,_0x453a0f),_0x119b5f=parseTexCoord$1(_0x5ec640,_0x42eb2b,_0x119b5f,_0x453a0f),_0x119b5f=parseInstanceInfo$1(_0x5ec640,_0x42eb2b,_0x119b5f,_0x453a0f),_0x119b5f;}function parseCompressSkeleton$1(_0x29c866,_0x1a59c9,_0x3b516e,_0x2717bb){const _0x47afbd=_0x7369;let _0x546374=_0x1a59c9[_0x47afbd(0x1ac)](_0x3b516e,!![]);return _0x2717bb['compressOptions']=_0x546374,_0x3b516e+=Uint32Array[_0x47afbd(0x1a8)],(_0x546374&_0x6ea6a9[_0x47afbd(0x198)])===_0x6ea6a9[_0x47afbd(0x198)]?_0x3b516e=parseCompressVertex$1(_0x29c866,_0x1a59c9,_0x3b516e,_0x2717bb):_0x3b516e=parseVertex$1(_0x29c866,_0x1a59c9,_0x3b516e,_0x2717bb),(_0x546374&_0x6ea6a9[_0x47afbd(0x1b8)])===_0x6ea6a9[_0x47afbd(0x1b8)]?_0x3b516e=parseCompressNormal$1(_0x29c866,_0x1a59c9,_0x3b516e,_0x2717bb):_0x3b516e=parseNormal$1(_0x29c866,_0x1a59c9,_0x3b516e,_0x2717bb),_0x3b516e=parseVertexColor$1(_0x29c866,_0x1a59c9,_0x3b516e,_0x2717bb),_0x3b516e=parseSecondColor$1(_0x29c866,_0x1a59c9,_0x3b516e,_0x2717bb),(_0x546374&_0x6ea6a9[_0x47afbd(0x184)])===_0x6ea6a9[_0x47afbd(0x184)]?_0x3b516e=parseCompressTexCoord$1(_0x29c866,_0x1a59c9,_0x3b516e,_0x2717bb):_0x3b516e=parseTexCoord$1(_0x29c866,_0x1a59c9,_0x3b516e,_0x2717bb),(_0x546374&_0x6ea6a9[_0x47afbd(0x19e)])===_0x6ea6a9['SVC_TexutreCoordIsW']&&(_0x2717bb[_0x47afbd(0x19b)]=!![]),_0x3b516e=parseInstanceInfo$1(_0x29c866,_0x1a59c9,_0x3b516e,_0x2717bb),_0x3b516e;}function parseIndexPackage$1(_0x503f56,_0x2a6256,_0x5690d8,_0xab3fe2){const _0x33b318=_0x7369;let _0x2c0f46=_0x2a6256['getUint32'](_0x5690d8,!![]);_0x5690d8+=Uint32Array[_0x33b318(0x1a8)];for(let _0x50ce1e=0x0;_0x50ce1e<_0x2c0f46;_0x50ce1e++){let _0x13e953={},_0x587a2a=_0x2a6256[_0x33b318(0x1ac)](_0x5690d8,!![]);_0x5690d8+=Uint32Array[_0x33b318(0x1a8)];let _0x5c58c8=_0x2a6256[_0x33b318(0x1cf)](_0x5690d8,!![]);_0x5690d8+=Uint8Array['BYTES_PER_ELEMENT'];let _0x2e8951=_0x2a6256[_0x33b318(0x1cf)](_0x5690d8,!![]);_0x5690d8+=Uint8Array[_0x33b318(0x1a8)];let _0x135632=_0x2a6256['getUint8'](_0x5690d8,!![]);_0x5690d8+=Uint8Array[_0x33b318(0x1a8)],_0x5690d8+=Uint8Array[_0x33b318(0x1a8)];if(_0x587a2a>0x0){let _0x4ea432=null,_0x5c21d9;_0x5c58c8===0x1||_0x5c58c8===0x3?(_0x5c21d9=_0x587a2a*Uint32Array['BYTES_PER_ELEMENT'],_0x4ea432=new Uint8Array(_0x503f56,_0x5690d8,_0x5c21d9)):(_0x5c21d9=_0x587a2a*Uint16Array[_0x33b318(0x1a8)],_0x4ea432=new Uint8Array(_0x503f56,_0x5690d8,_0x5c21d9),_0x587a2a%0x2!==0x0&&(_0x5c21d9+=0x2)),_0x13e953['indicesTypedArray']=_0x4ea432,_0x5690d8+=_0x5c21d9;}_0x13e953['indicesCount']=_0x587a2a,_0x13e953[_0x33b318(0x1b5)]=_0x5c58c8,_0x13e953[_0x33b318(0x19f)]=_0x135632;let _0xc23637=_0x2a6256[_0x33b318(0x1ac)](_0x5690d8,!![]);_0x5690d8+=Uint32Array[_0x33b318(0x1a8)];for(let _0x511cea=0x0;_0x511cea<_0xc23637;_0x511cea++){let _0x42c98e=parseString$1(_0x503f56,_0x2a6256,_0x5690d8),_0x581eca=_0x42c98e[_0x33b318(0x1dd)];_0x5690d8=_0x42c98e['bytesOffset'],_0x13e953[_0x33b318(0x1d3)]=_0x581eca;}let _0x3b90b2=_0x5690d8%0x4;if(_0x3b90b2!==0x0){let _0x4996ba=0x4-_0x5690d8%0x4;_0x5690d8+=_0x4996ba;}_0xab3fe2[_0x33b318(0x1dc)](_0x13e953);}return _0x5690d8;}function parseSkeleton$1(_0x15659c,_0x8f91d4,_0x47b491,_0xfc02cb){const _0x38122b=_0x7369;let _0x5d23ee=_0x8f91d4[_0x38122b(0x1ac)](_0x47b491,!![]);_0x47b491+=Uint32Array['BYTES_PER_ELEMENT'];let _0x816a7d=_0x8f91d4['getUint32'](_0x47b491,!![]);_0x47b491+=Uint32Array[_0x38122b(0x1a8)];for(let _0x47978e=0x0;_0x47978e<_0x816a7d;_0x47978e++){let _0x169606=parseString$1(_0x15659c,_0x8f91d4,_0x47b491),_0x287540=_0x169606[_0x38122b(0x1dd)];_0x47b491=_0x169606[_0x38122b(0x19d)];let _0x3a30e0=_0x47b491%0x4;_0x3a30e0!==0x0&&(_0x47b491+=0x4-_0x3a30e0);let _0x1111b3=_0x8f91d4['getUint32'](_0x47b491,!![]);_0x47b491+=Int32Array['BYTES_PER_ELEMENT'];let _0x484861={'vertexAttributes':[],'attrLocation':{},'instanceCount':0x0,'instanceMode':0x0,'instanceIndex':-0x1};if(_0x1111b3===S3MBVertexTag$1[_0x38122b(0x199)])_0x47b491=parseStandardSkeleton$1(_0x15659c,_0x8f91d4,_0x47b491,_0x484861);else _0x1111b3===S3MBVertexTag$1[_0x38122b(0x1df)]&&(_0x47b491=parseCompressSkeleton$1(_0x15659c,_0x8f91d4,_0x47b491,_0x484861));let _0x2538b1=[];_0x47b491=parseIndexPackage$1(_0x15659c,_0x8f91d4,_0x47b491,_0x2538b1);let _0xc5f50c=undefined;_0x2538b1[_0x38122b(0x1c8)]===0x2&&_0x2538b1[0x1][_0x38122b(0x19f)]===0xd&&_0x2538b1[0x1][_0x38122b(0x1cd)]>=0x3&&(_0xc5f50c=S3MEdgeProcessor[_0x38122b(0x1d6)](_0x484861,_0x2538b1[0x1])),_0xfc02cb[_0x287540]={'vertexPackage':_0x484861,'arrIndexPackage':_0x2538b1,'edgeGeometry':_0xc5f50c};}let _0xa8ed34=_0x8f91d4[_0x38122b(0x1ac)](_0x47b491,!![]);return _0x47b491+=_0xa8ed34,_0x47b491+=Uint32Array['BYTES_PER_ELEMENT'],_0x47b491;}function createTextureBatch(_0x2b7c10,_0x1c0198,_0x20f2d5,_0x241ba7){const _0x3967ca=_0x7369;let _0x1d8f07=_0x20f2d5[_0x3967ca(0x1c8)];for(let _0x1304a7=0x0;_0x1304a7<_0x1d8f07;_0x1304a7++){let _0x4319f5=_0x20f2d5[_0x1304a7],_0x17a2f9=_0x4319f5[_0x3967ca(0x1ce)][_0x3967ca(0x1d2)]('_')[0x0],_0x199cd4=_0x4319f5[_0x3967ca(0x187)];for(let _0x374baa=0x0;_0x374baa<_0x199cd4[_0x3967ca(0x1c8)];_0x374baa++){let _0x405d90=_0x199cd4[_0x374baa],_0xad0802=_0x405d90[_0x3967ca(0x1d0)],_0x40fdaa=_0x405d90[_0x3967ca(0x194)],_0x5a3a36=_0x405d90[_0x3967ca(0x191)],_0x5bb4ef=_0x405d90[_0x3967ca(0x1a3)],_0x19b361=_0x1c0198[_0xad0802][_0x3967ca(0x1c2)],_0x178527=_0x19b361['verticesCount'],_0x1e5768=_0x241ba7[_0xad0802];!_0x1e5768&&(_0x1e5768=_0x241ba7[_0xad0802]={});let _0x462c59=_0x1e5768[_0x5bb4ef];!_0x462c59&&(_0x462c59=_0x1e5768[_0x5bb4ef]=new Float32Array(_0x178527),Cesium['arrayFill'](_0x462c59,-0x1));let _0x3e5f6d=_0x2b7c10?_0x2b7c10[_0x17a2f9]:_0x1304a7;Cesium[_0x3967ca(0x1ca)](_0x462c59,_0x3e5f6d,_0x40fdaa,_0x40fdaa+_0x5a3a36);}}}function createTexBatchIdAttribute(_0x247b45,_0x308d07,_0x3fe9b2){const _0x5d8477=_0x7369;var _0x449c70=_0x247b45[_0x5d8477(0x1c3)],_0x35476e=_0x247b45[_0x5d8477(0x185)],_0x5ba151=_0x449c70[_0x5d8477(0x1c8)];_0x35476e['aTextureBatchId'+_0x3fe9b2]=_0x5ba151,_0x449c70[_0x5d8477(0x1dc)]({'index':_0x5ba151,'typedArray':_0x308d07,'componentsPerAttribute':0x1,'componentDatatype':Cesium['ComponentDatatype'][_0x5d8477(0x188)],'offsetInBytes':0x0,'strideInBytes':0x0});}function parseTexturePackage$1(_0x2b8365,_0x2a03ea,_0x24f6e0,_0x1e170b,_0x881ba4,_0x399848,_0x5e2b5e,_0x2af903){const _0x4f90f7=_0x7369;let _0x477eba=_0x24f6e0,_0x1da39e=_0x2a03ea[_0x4f90f7(0x1ac)](_0x477eba,!![]);_0x477eba+=Uint32Array['BYTES_PER_ELEMENT'];let _0x1ccab8=_0x2a03ea[_0x4f90f7(0x1ac)](_0x477eba,!![]);_0x477eba+=Uint32Array[_0x4f90f7(0x1a8)];let _0xfc0acb={};for(let _0x2e2b70=0x0;_0x2e2b70<_0x1ccab8;_0x2e2b70++){let _0x1c0886=parseString$1(_0x2b8365,_0x2a03ea,_0x477eba),_0x9e051e=_0x1c0886[_0x4f90f7(0x1dd)];_0x477eba=_0x1c0886['bytesOffset'];let _0x2db621=_0x477eba%0x4;_0x2db621!==0x0&&(_0x477eba+=0x4-_0x2db621);let _0x34aef9=_0x2a03ea[_0x4f90f7(0x1ac)](_0x477eba,!![]);_0x477eba+=Uint32Array[_0x4f90f7(0x1a8)];let _0x4f40f5=_0x2a03ea['getUint8'](_0x477eba,!![]);_0x477eba+=Uint8Array[_0x4f90f7(0x1a8)];let _0x5271e1=_0x2a03ea[_0x4f90f7(0x1ac)](_0x477eba,!![]);_0x477eba+=Uint32Array[_0x4f90f7(0x1a8)];let _0x413d04=_0x2a03ea[_0x4f90f7(0x1ac)](_0x477eba,!![]);_0x477eba+=Uint32Array[_0x4f90f7(0x1a8)];let _0x59875e=_0x2a03ea['getUint32'](_0x477eba,!![]);_0x477eba+=Uint32Array[_0x4f90f7(0x1a8)];let _0x1ee38b=_0x2a03ea[_0x4f90f7(0x1ac)](_0x477eba,!![]);_0x477eba+=Uint32Array[_0x4f90f7(0x1a8)];let _0x521063=_0x2a03ea['getUint32'](_0x477eba,!![]);_0x477eba+=Uint32Array['BYTES_PER_ELEMENT'];let _0x3cd5d6;_0x2af903&&(_0x3cd5d6=new Uint8Array(_0x2b8365,_0x477eba,_0x1ee38b),_0x477eba+=_0x1ee38b);let _0x27808e=_0x2a03ea['getUint32'](_0x477eba,!![]);_0x477eba+=Uint32Array[_0x4f90f7(0x1a8)];let _0x5358aa=[];for(let _0x1ec41a=0x0;_0x1ec41a<_0x27808e;_0x1ec41a++){let _0x30d362=parseString$1(_0x2b8365,_0x2a03ea,_0x477eba),_0x144931=_0x30d362[_0x4f90f7(0x1dd)];_0x477eba=_0x30d362[_0x4f90f7(0x19d)],_0x5358aa[_0x4f90f7(0x1dc)](_0x144931),_0x5e2b5e[_0x144931]=_0x9e051e;}let _0x2a2dec=_0x2a03ea['getUint32'](_0x477eba,!![]);_0x477eba+=Uint32Array[_0x4f90f7(0x1a8)];let _0x537c82=[];for(let _0x45eae5=0x0;_0x45eae5<_0x2a2dec;_0x45eae5++){let _0x54bd4e=parseString$1(_0x2b8365,_0x2a03ea,_0x477eba);_0x477eba=_0x54bd4e['bytesOffset'],_0x537c82['push'](_0x54bd4e[_0x4f90f7(0x1dd)]);}let _0x448949=_0x2a03ea[_0x4f90f7(0x1ac)](_0x477eba,!![]);_0x477eba+=Uint32Array[_0x4f90f7(0x1a8)];let _0x316caf=[],_0x873c57=undefined,_0x585361=_0x9e051e;if(_0x2af903)_0x873c57=_0x399848[_0x9e051e]={};else {let _0x558ae2=_0x5e2b5e[_0x9e051e];_0x585361=_0x558ae2;while(_0x558ae2){_0x585361=_0x558ae2,_0x558ae2=_0x5e2b5e[_0x558ae2];}_0x585361&&(_0x873c57=_0x399848[_0x585361]);}let _0x2a76f9=0x0;for(let _0x223a93=0x0;_0x223a93<_0x448949;_0x223a93++){let _0x47c982=parseString$1(_0x2b8365,_0x2a03ea,_0x477eba),_0xf25dac=_0x47c982[_0x4f90f7(0x1dd)];_0x477eba=_0x47c982[_0x4f90f7(0x19d)];if(_0x2af903){let _0x53fefe=_0xf25dac[_0x4f90f7(0x1d2)]('_')[0x0];!_0x873c57[_0x53fefe]?_0x873c57[_0x53fefe]=_0x223a93-_0x2a76f9:_0x2a76f9++;}let _0x5e1484=_0x2a03ea[_0x4f90f7(0x1ac)](_0x477eba,!![]);_0x477eba+=Uint32Array[_0x4f90f7(0x1a8)];let _0x1b16c2=_0x2a03ea[_0x4f90f7(0x1ac)](_0x477eba,!![]);_0x477eba+=Uint32Array[_0x4f90f7(0x1a8)];let _0x15858c=_0x2a03ea['getUint32'](_0x477eba,!![]);_0x477eba+=Uint32Array[_0x4f90f7(0x1a8)];let _0x269386=_0x2a03ea['getUint32'](_0x477eba,!![]);_0x477eba+=Uint32Array[_0x4f90f7(0x1a8)];let _0xe35ed4=_0x2a03ea[_0x4f90f7(0x1ac)](_0x477eba,!![]);_0x477eba+=Uint32Array[_0x4f90f7(0x1a8)];let _0xcc085c=[];for(let _0x4e394a=0x0;_0x4e394a<_0xe35ed4;_0x4e394a++){let _0x4e864c=parseString$1(_0x2b8365,_0x2a03ea,_0x477eba),_0x98c5e7=_0x4e864c['string'];_0x477eba=_0x4e864c[_0x4f90f7(0x19d)];let _0x2d7e99=_0x2a03ea[_0x4f90f7(0x1ac)](_0x477eba,!![]);_0x477eba+=Uint32Array[_0x4f90f7(0x1a8)];let _0x216abf=_0x2a03ea[_0x4f90f7(0x1ac)](_0x477eba,!![]);_0x477eba+=Uint32Array[_0x4f90f7(0x1a8)];let _0x538046=_0x2a03ea[_0x4f90f7(0x1ac)](_0x477eba,!![]);_0x477eba+=Uint32Array[_0x4f90f7(0x1a8)],_0xcc085c['push']({'geoName':_0x98c5e7,'offset':_0x2d7e99,'count':_0x216abf,'texUnitIndex':_0x538046});}_0x316caf['push']({'subName':_0xf25dac,'offsetX':_0x5e1484,'offsetY':_0x1b16c2,'width':_0x15858c,'height':_0x269386,'subVertexOffsetArr':_0xcc085c});}createTextureBatch(_0x873c57,_0x881ba4,_0x316caf,_0xfc0acb),_0x1e170b[_0x9e051e]={'id':_0x9e051e,'rootTextureName':_0x585361,'width':_0x5271e1,'height':_0x413d04,'compressType':_0x59875e,'size':_0x1ee38b,'format':_0x521063,'textureData':_0x3cd5d6,'subTexInfos':_0x316caf,'requestNames':_0x537c82};}for(let _0x4deb8e in _0xfc0acb){if(_0xfc0acb[_0x4f90f7(0x1a5)](_0x4deb8e)){let _0x7a9b30=_0x881ba4[_0x4deb8e][_0x4f90f7(0x1c2)],_0x4585ef=_0xfc0acb[_0x4deb8e];for(let _0x55f677 in _0x4585ef){if(_0x4585ef[_0x4f90f7(0x1a5)](_0x55f677)){let _0x186045=_0x4585ef[_0x55f677];createTexBatchIdAttribute(_0x7a9b30,_0x186045,_0x55f677);}}}}return _0x477eba;}function parseMaterial$1(_0x44fb53,_0x1c969b,_0x47a838,_0x2a8377){const _0x4b19bf=_0x7369;let _0x1616e5=_0x1c969b[_0x4b19bf(0x1ac)](_0x47a838,!![]);_0x47a838+=Uint32Array[_0x4b19bf(0x1a8)];let _0x2ff83b=new Uint8Array(_0x44fb53,_0x47a838,_0x1616e5),_0x197071=Cesium['getStringFromTypedArray'](_0x2ff83b);return _0x47a838+=_0x1616e5,_0x2a8377[_0x4b19bf(0x1d9)]=JSON[_0x4b19bf(0x1b1)](_0x197071),_0x47a838;}let colorScratch$1=new Cesium['Color'](),LEFT_16$1=0x10000;function parsePickInfo$1(_0x433722,_0x15dfad,_0x3095c7,_0x29d69c,_0x2b3e1c,_0x3c7621){const _0x33605c=_0x7369;if((_0x29d69c&0x1)===0x1){let _0x2e0ff5=_0x15dfad[_0x33605c(0x1ac)](_0x3095c7,!![]);_0x3095c7+=Uint32Array[_0x33605c(0x1a8)];let _0x33e33f=_0x15dfad[_0x33605c(0x1ac)](_0x3095c7,!![]);_0x3095c7+=Uint32Array['BYTES_PER_ELEMENT'];for(let _0xdc21cd=0x0;_0xdc21cd<_0x33e33f;_0xdc21cd++){let _0x3a9019=parseString$1(_0x433722,_0x15dfad,_0x3095c7),_0x421066=_0x3a9019['string'];_0x3095c7=_0x3a9019['bytesOffset'];let _0x197532=_0x15dfad[_0x33605c(0x1ac)](_0x3095c7,!![]);_0x3095c7+=Uint32Array[_0x33605c(0x1a8)];let _0x2cb586={};_0x2b3e1c[_0x421066][_0x33605c(0x1aa)]=_0x2cb586;let _0x4da5b0=_0x2b3e1c[_0x421066][_0x33605c(0x1c2)][_0x33605c(0x1d7)];if(_0x4da5b0==-0x1){let _0x9aa1c4=new Float32Array(_0x2b3e1c[_0x421066][_0x33605c(0x1c2)][_0x33605c(0x1d4)]);for(let _0x270824=0x0;_0x270824<_0x197532;_0x270824++){let _0xb0ab64=_0x15dfad[_0x33605c(0x1ac)](_0x3095c7,!![]);_0x3095c7+=Uint32Array[_0x33605c(0x1a8)];let _0x321b12=_0x15dfad['getUint32'](_0x3095c7,!![]);_0x3095c7+=Uint32Array[_0x33605c(0x1a8)];let _0x2aba56=[];for(let _0x35c616=0x0;_0x35c616<_0x321b12;_0x35c616++){let _0x456ea3=_0x15dfad['getUint32'](_0x3095c7,!![]);_0x3095c7+=Uint32Array[_0x33605c(0x1a8)];let _0x5ce7a4=_0x15dfad[_0x33605c(0x1ac)](_0x3095c7,!![]);_0x3095c7+=Uint32Array[_0x33605c(0x1a8)],Cesium[_0x33605c(0x1ca)](_0x9aa1c4,_0x270824,_0x456ea3,_0x456ea3+_0x5ce7a4),_0x2aba56['push']({'vertexColorOffset':_0x456ea3,'vertexColorCount':_0x5ce7a4,'batchId':_0x270824});}_0x2cb586[_0xb0ab64]=_0x2aba56;}createBatchIdAttribute$2(_0x2b3e1c[_0x421066][_0x33605c(0x1c2)],_0x9aa1c4,undefined);}else {let _0x22c786=_0x2b3e1c[_0x421066][_0x33605c(0x1c2)][_0x33605c(0x1ae)],_0x4f6e08=_0x2b3e1c[_0x421066]['vertexPackage']['instanceBuffer'],_0x2d5c12=_0x2b3e1c[_0x421066][_0x33605c(0x1c2)][_0x33605c(0x1e5)],_0x3d7177=new Float32Array(_0x22c786),_0x5f5715=[];for(let _0x302aee=0x0;_0x302aee<_0x197532;_0x302aee++){let _0x3a8da8=_0x15dfad[_0x33605c(0x1ac)](_0x3095c7,!![]);_0x5f5715[_0x33605c(0x1dc)](_0x3a8da8),_0x3095c7+=Uint32Array[_0x33605c(0x1a8)];let _0x24d025=_0x15dfad['getUint32'](_0x3095c7,!![]);_0x3095c7+=Uint32Array[_0x33605c(0x1a8)];for(let _0x240b79=0x0;_0x240b79<_0x24d025;_0x240b79++){let _0x399964=_0x15dfad[_0x33605c(0x1ac)](_0x3095c7,!![]);_0x3095c7+=Uint32Array['BYTES_PER_ELEMENT'];if(_0x3c7621==0x2){let _0x10fc67=_0x15dfad[_0x33605c(0x1ac)](_0x3095c7,!![]);_0x3095c7+=Uint32Array['BYTES_PER_ELEMENT'];}}}let _0x2320bb=_0x2d5c12===0x11?0x10:0x1c;_0x2320bb*=Float32Array['BYTES_PER_ELEMENT'];for(let _0x31bc87=0x0;_0x31bc87<_0x22c786;_0x31bc87++){_0x3d7177[_0x31bc87]=_0x31bc87;let _0x3dc66f=_0x31bc87*_0x2d5c12*Float32Array[_0x33605c(0x1a8)]+_0x2320bb;Cesium['Color'][_0x33605c(0x195)](_0x4f6e08,_0x3dc66f,colorScratch$1);let _0x25e26c=_0x3c7621===0x2?_0x5f5715[_0x31bc87]:colorScratch$1[_0x33605c(0x1cb)]+colorScratch$1[_0x33605c(0x1a9)]*0x100+colorScratch$1['blue']*LEFT_16$1;_0x2cb586[_0x25e26c]===undefined&&(_0x2cb586[_0x25e26c]={'vertexColorCount':0x1,'instanceIds':[],'vertexColorOffset':_0x31bc87}),_0x2cb586[_0x25e26c][_0x33605c(0x1a1)][_0x33605c(0x1dc)](_0x31bc87);}createBatchIdAttribute$2(_0x2b3e1c[_0x421066]['vertexPackage'],_0x3d7177,0x1);}}}return _0x3095c7;}function createBatchIdAttribute$2(_0x197dd8,_0x391579,_0x539bff){const _0x2a13e3=_0x7369;let _0x5af5d2=_0x197dd8[_0x2a13e3(0x1c3)],_0x141fc3=_0x197dd8[_0x2a13e3(0x185)],_0x63cd3b=_0x5af5d2[_0x2a13e3(0x1c8)],_0x2c235d=_0x539bff===0x1?'instanceId':_0x2a13e3(0x18e);_0x141fc3[_0x2c235d]=_0x63cd3b,_0x5af5d2[_0x2a13e3(0x1dc)]({'index':_0x63cd3b,'typedArray':_0x391579,'componentsPerAttribute':0x1,'componentDatatype':Cesium['ComponentDatatype']['FLOAT'],'offsetInBytes':0x0,'strideInBytes':0x0,'instanceDivisor':_0x539bff});}function _0x7369(_0x355315,_0x5804ac){_0x355315=_0x355315-0x183;let _0x56654f=_0x5665[_0x355315];return _0x56654f;}function removeUnusedStringTileName(_0x19080b){const _0x12d0a9=_0x7369;let _0x3d85cd=_0x19080b[_0x12d0a9(0x1af)]('Geometry');if(_0x3d85cd===-0x1)return _0x19080b;let _0x3b8331=_0x19080b[_0x12d0a9(0x1d1)](_0x3d85cd,_0x19080b['length']);return _0x19080b[_0x12d0a9(0x1a2)](_0x3b8331,'');}S3MBlockParser[_0x593a7b(0x1e1)]=function(_0x132b12,_0x21bb05){const _0x3e9346=_0x593a7b;let _0x47c285=_0x21bb05[_0x3e9346(0x189)],_0x2a8db8=_0x21bb05['ancestorMap'],_0xd83c69=0x0,_0x572273=new DataView(_0x132b12),_0x366afb=_0x572273[_0x3e9346(0x1bd)](_0xd83c69,!![]);_0xd83c69+=Float32Array['BYTES_PER_ELEMENT'];let _0x16a01c=_0x572273[_0x3e9346(0x1ac)](_0xd83c69,!![]);_0xd83c69+=Uint32Array[_0x3e9346(0x1a8)];let _0x254fb3={};while(_0x16a01c--){_0x572273=new DataView(_0x132b12);let _0x195506=parseString$1(_0x132b12,_0x572273,_0xd83c69),_0x23c0b6=_0x195506[_0x3e9346(0x1dd)],_0x52e6d3=_0x254fb3[_0x23c0b6]={'groupNode':undefined,'geoPackage':{},'texturePackage':{},'materials':{},'rootBatchIdMap':_0x47c285,'ancestorMap':_0x2a8db8};_0xd83c69=_0x195506[_0x3e9346(0x19d)];let _0x387cf2=_0x572273[_0x3e9346(0x1ac)](_0xd83c69,!![]);_0xd83c69+=Uint32Array[_0x3e9346(0x1a8)];let _0x562f4e=[];for(let _0x307cec=0x0;_0x307cec<_0x387cf2;_0x307cec++){let _0x48d48a={},_0x423850=_0x572273[_0x3e9346(0x1bd)](_0xd83c69,!![]);_0xd83c69+=Float32Array[_0x3e9346(0x1a8)];let _0x188315=_0x572273[_0x3e9346(0x1da)](_0xd83c69,!![]);_0xd83c69+=Uint16Array['BYTES_PER_ELEMENT'],_0x48d48a[_0x3e9346(0x1cc)]=_0x188315,_0x48d48a['rangeList']=_0x423850;let _0x15d397={};_0x15d397['x']=_0x572273[_0x3e9346(0x1c7)](_0xd83c69,!![]),_0xd83c69+=Float64Array[_0x3e9346(0x1a8)],_0x15d397['y']=_0x572273['getFloat64'](_0xd83c69,!![]),_0xd83c69+=Float64Array['BYTES_PER_ELEMENT'],_0x15d397['z']=_0x572273[_0x3e9346(0x1c7)](_0xd83c69,!![]),_0xd83c69+=Float64Array[_0x3e9346(0x1a8)];let _0x279470=_0x572273[_0x3e9346(0x1c7)](_0xd83c69,!![]);_0xd83c69+=Float64Array['BYTES_PER_ELEMENT'],_0x48d48a[_0x3e9346(0x1ab)]={'center':_0x15d397,'radius':_0x279470};let _0x2e7b34=parseString$1(_0x132b12,_0x572273,_0xd83c69),_0x1db9d8=_0x2e7b34[_0x3e9346(0x1dd)];_0xd83c69=_0x2e7b34['bytesOffset'],_0x1db9d8=_0x1db9d8['replace'](/(\.s3mblock)|(\.s3mbz)|(\.s3mb)/gi,''),_0x1db9d8=removeUnusedStringTileName(_0x1db9d8),_0x48d48a[_0x3e9346(0x192)]=_0x1db9d8,_0x562f4e[_0x3e9346(0x1dc)](_0x48d48a);}let _0x5563fa=_0x572273[_0x3e9346(0x1bd)](_0xd83c69,!![]);_0xd83c69+=Float32Array['BYTES_PER_ELEMENT'];let _0x232496=_0x572273[_0x3e9346(0x1ac)](_0xd83c69,!![]);_0xd83c69+=Uint32Array[_0x3e9346(0x1a8)];let _0x22518e=_0x572273[_0x3e9346(0x1ac)](_0xd83c69,!![]);_0xd83c69+=Uint32Array[_0x3e9346(0x1a8)];let _0x4e4b9f=new Uint8Array(_0x132b12,_0xd83c69,_0x22518e),_0x3f5ad4=_0xd83c69+_0x22518e,_0x5049b0=_0x1a0f6f[_0x3e9346(0x1b2)](_0x4e4b9f)[_0x3e9346(0x1b7)];_0x572273=new DataView(_0x5049b0),_0xd83c69=0x0;let _0x1a7257=_0x572273[_0x3e9346(0x1ac)](_0xd83c69,!![]);_0xd83c69+=Uint32Array['BYTES_PER_ELEMENT'],_0xd83c69=parseGroupNode$1(_0x5049b0,_0x572273,_0xd83c69,_0x52e6d3),_0xd83c69=parseSkeleton$1(_0x5049b0,_0x572273,_0xd83c69,_0x52e6d3[_0x3e9346(0x1de)]),_0xd83c69=parseTexturePackage$1(_0x5049b0,_0x572273,_0xd83c69,_0x52e6d3[_0x3e9346(0x1d5)],_0x52e6d3['geoPackage'],_0x47c285,_0x2a8db8,_0x21bb05[_0x3e9346(0x1bf)]),_0xd83c69=parseMaterial$1(_0x5049b0,_0x572273,_0xd83c69,_0x52e6d3),_0xd83c69=parsePickInfo$1(_0x5049b0,_0x572273,_0xd83c69,_0x1a7257,_0x52e6d3[_0x3e9346(0x1de)],_0x5563fa),_0xd83c69=_0x3f5ad4;}return _0x254fb3;};

    const _0x31e2=['TEXTURE_2D','TEXTURE_MIN_FILTER','TEXTURE_WRAP_T','height','arrayBufferView','8342CSuufP','20GXbFrf','compressedTextureSizeInBytes','5ooWnCR','_textureFilterAnisotropic','rootName','1RAicmR','wrapT','deleteTexture','compressedTexImage2D','layerId','texParameteri','62602catmTQ','prototype','refCount','contextId','1nDfXxJ','bindTexture','1GdzhtV','destroy','buffer','RGBA','isTexBlock','yOffset','width','wrapS','UNPACK_PREMULTIPLY_ALPHA_WEBGL','textureId','272231LSxTQa','474178YfXiwK','destroyObject','LINEAR','byteOffset','CLAMP_TO_EDGE','xOffset','pixelStorei','max','compressType','pixelFormat','TEXTURE_MAG_FILTER','copyFrom','activeTexture','_width','UNPACK_FLIP_Y_WEBGL','_texture','context','TEXTURE_MAX_ANISOTROPY_EXT','447230Ocfmyy','_target','init','1qsLhIi','LINEAR_MIPMAP_LINEAR','defaultValue','_gl','UNSIGNED_BYTE','PixelFormat','29191kAOYme','2uIOVTl','ready','231472sdUjnQ','TextureWrap','TEXTURE_WRAP_S','texImage2D','createTexture','internalFormat','renderable','isDestroyed'];const _0x5e5059=_0x3353;(function(_0x323e9d,_0xc9c1c8){const _0x512731=_0x3353;while(!![]){try{const _0xb6620e=parseInt(_0x512731(0x18e))*parseInt(_0x512731(0x183))+-parseInt(_0x512731(0x18d))*parseInt(_0x512731(0x181))+parseInt(_0x512731(0x161))*parseInt(_0x512731(0x174))+parseInt(_0x512731(0x171))*-parseInt(_0x512731(0x172))+-parseInt(_0x512731(0x15b))*-parseInt(_0x512731(0x158))+parseInt(_0x512731(0x17d))*-parseInt(_0x512731(0x162))+-parseInt(_0x512731(0x164))*parseInt(_0x512731(0x177));if(_0xb6620e===_0xc9c1c8)break;else _0x323e9d['push'](_0x323e9d['shift']());}catch(_0x356db5){_0x323e9d['push'](_0x323e9d['shift']());}}}(_0x31e2,0x42500));const NOCOMPRESSED_RGBA=0x1111,NOCOMPRESSED_LA=0x190a;function _0x3353(_0x746685,_0x3b8072){_0x746685=_0x746685-0x14a;let _0x31e29d=_0x31e2[_0x746685];return _0x31e29d;}function DDSTexture(_0x334f59,_0x172063,_0x37fbbf){const _0x423676=_0x3353;let _0x193b84=_0x334f59[_0x423676(0x15e)];this[_0x423676(0x180)]=_0x334f59['id'],this[_0x423676(0x18c)]=_0x172063,this['layerId']=_0x37fbbf[_0x423676(0x17b)],this[_0x423676(0x176)]=_0x37fbbf[_0x423676(0x176)],this[_0x423676(0x156)]=_0x334f59,this['width']=_0x37fbbf[_0x423676(0x189)],this[_0x423676(0x16f)]=_0x37fbbf['height'],this['compressType']=_0x37fbbf[_0x423676(0x14e)],this[_0x423676(0x169)]=_0x37fbbf[_0x423676(0x169)],this[_0x423676(0x14f)]=_0x37fbbf['pixelFormat'],this[_0x423676(0x170)]=_0x37fbbf[_0x423676(0x170)],this[_0x423676(0x18a)]=Cesium[_0x423676(0x15d)](_0x37fbbf['wrapS'],Cesium[_0x423676(0x165)][_0x423676(0x14a)]),this['wrapT']=Cesium[_0x423676(0x15d)](_0x37fbbf[_0x423676(0x178)],Cesium[_0x423676(0x165)]['CLAMP_TO_EDGE']),this[_0x423676(0x159)]=_0x193b84[_0x423676(0x16c)],this['_texture']=undefined,this['refCount']=0x1,this['ready']=!_0x37fbbf[_0x423676(0x187)],this[_0x423676(0x16a)]=!_0x37fbbf['isTexBlock'],this[_0x423676(0x187)]=_0x37fbbf['isTexBlock'],this[_0x423676(0x170)]&&this[_0x423676(0x15a)]();}DDSTexture[_0x5e5059(0x17e)][_0x5e5059(0x15a)]=function(){const _0x238918=_0x5e5059;let _0xaf0b6d=this[_0x238918(0x156)][_0x238918(0x15e)];!this[_0x238918(0x155)]&&(this[_0x238918(0x155)]=_0xaf0b6d[_0x238918(0x168)]());_0xaf0b6d['bindTexture'](_0xaf0b6d[_0x238918(0x16c)],this[_0x238918(0x155)]);let _0x55ece1=this['internalFormat'];(_0x55ece1===NOCOMPRESSED_LA||_0x55ece1===NOCOMPRESSED_RGBA)&&_0xaf0b6d[_0x238918(0x14c)](_0xaf0b6d['UNPACK_FLIP_Y_WEBGL'],!![]);let _0xc94eb2=0x0;if(this['arrayBufferView']){let _0x15aa10=0x0,_0x16b588=this[_0x238918(0x189)],_0x1cfe30=this[_0x238918(0x16f)],_0x2358f3=validateMipmap(this['arrayBufferView'],_0x55ece1,_0x16b588,_0x1cfe30);do{let _0x56e18f=Cesium[_0x238918(0x160)][_0x238918(0x173)](_0x55ece1,_0x16b588,_0x1cfe30),_0x9f8a38=new Uint8Array(this[_0x238918(0x170)][_0x238918(0x185)],this[_0x238918(0x170)][_0x238918(0x191)]+_0x15aa10,_0x56e18f);_0x55ece1===NOCOMPRESSED_RGBA?_0xaf0b6d[_0x238918(0x167)](_0xaf0b6d[_0x238918(0x16c)],_0xc94eb2++,_0xaf0b6d[_0x238918(0x186)],_0x16b588,_0x1cfe30,0x0,_0xaf0b6d[_0x238918(0x186)],_0xaf0b6d['UNSIGNED_BYTE'],_0x9f8a38):_0xaf0b6d[_0x238918(0x17a)](_0xaf0b6d[_0x238918(0x16c)],_0xc94eb2++,_0x55ece1,_0x16b588,_0x1cfe30,0x0,_0x9f8a38),_0x16b588=Math[_0x238918(0x14d)](_0x16b588>>0x1,0x1),_0x1cfe30=Math[_0x238918(0x14d)](_0x1cfe30>>0x1,0x1),_0x15aa10+=_0x56e18f;}while(_0x15aa10<this[_0x238918(0x170)]['byteLength']&&_0x2358f3);}else {let _0x3c9cdf=Cesium['PixelFormat'][_0x238918(0x173)](_0x55ece1,this[_0x238918(0x189)],this[_0x238918(0x16f)]);_0x55ece1===NOCOMPRESSED_RGBA?_0xaf0b6d[_0x238918(0x167)](_0xaf0b6d[_0x238918(0x16c)],0x0,_0xaf0b6d[_0x238918(0x186)],this[_0x238918(0x153)],this['height'],0x0,_0xaf0b6d['RGBA'],_0xaf0b6d[_0x238918(0x15f)],new Uint8Array(this[_0x238918(0x189)]*this[_0x238918(0x16f)]*0x4)):_0xaf0b6d[_0x238918(0x17a)](_0xaf0b6d[_0x238918(0x16c)],0x0,_0x55ece1,this[_0x238918(0x189)],this[_0x238918(0x16f)],0x0,new Uint8Array(_0x3c9cdf));}_0xc94eb2>0x1?(_0xaf0b6d[_0x238918(0x17c)](_0xaf0b6d['TEXTURE_2D'],_0xaf0b6d[_0x238918(0x150)],_0xaf0b6d['LINEAR']),_0xaf0b6d[_0x238918(0x17c)](_0xaf0b6d['TEXTURE_2D'],_0xaf0b6d[_0x238918(0x16d)],_0xaf0b6d[_0x238918(0x15c)])):(_0xaf0b6d[_0x238918(0x17c)](_0xaf0b6d[_0x238918(0x16c)],_0xaf0b6d[_0x238918(0x150)],_0xaf0b6d[_0x238918(0x190)]),_0xaf0b6d[_0x238918(0x17c)](_0xaf0b6d[_0x238918(0x16c)],_0xaf0b6d[_0x238918(0x16d)],_0xaf0b6d[_0x238918(0x190)])),_0xaf0b6d[_0x238918(0x17c)](_0xaf0b6d[_0x238918(0x16c)],_0xaf0b6d[_0x238918(0x166)],this[_0x238918(0x18a)]),_0xaf0b6d[_0x238918(0x17c)](_0xaf0b6d[_0x238918(0x16c)],_0xaf0b6d[_0x238918(0x16e)],this[_0x238918(0x178)]),_0xaf0b6d['texParameteri'](this['_target'],this[_0x238918(0x156)][_0x238918(0x175)][_0x238918(0x157)],0x1),_0xaf0b6d[_0x238918(0x182)](_0xaf0b6d[_0x238918(0x16c)],null),this[_0x238918(0x170)]=undefined,this[_0x238918(0x163)]=!![];};function validateMipmap(_0x36d4fa,_0x18d46d,_0x2f105d,_0x29fd79){const _0x188e25=_0x5e5059;let _0x3c5d54=_0x36d4fa['length'],_0x3d421d=_0x2f105d,_0x39414b=_0x29fd79,_0x1771ef=0x0;while(0x1){let _0x37f875=Cesium['PixelFormat']['compressedTextureSizeInBytes'](_0x18d46d,_0x3d421d,_0x39414b);_0x1771ef+=_0x37f875,_0x3d421d=_0x3d421d>>0x1,_0x39414b=_0x39414b>>0x1;if(_0x3d421d===0x0&&_0x39414b===0x0)break;_0x3d421d=Math[_0x188e25(0x14d)](_0x3d421d,0x1),_0x39414b=Math[_0x188e25(0x14d)](_0x39414b,0x1);}return _0x1771ef===_0x3c5d54;}DDSTexture[_0x5e5059(0x17e)][_0x5e5059(0x151)]=function(_0x5c1fae){const _0x590dbf=_0x5e5059;let _0x2d56ed=this[_0x590dbf(0x156)]['_gl'],_0x2e603b=this[_0x590dbf(0x159)];_0x2d56ed[_0x590dbf(0x152)](_0x2d56ed['TEXTURE0']),_0x2d56ed[_0x590dbf(0x182)](_0x2e603b,this['_texture']);let _0x803ef9=_0x5c1fae[_0x590dbf(0x14b)],_0x35e198=_0x5c1fae[_0x590dbf(0x188)],_0x3f3cd6=_0x5c1fae[_0x590dbf(0x189)],_0x5c6da8=_0x5c1fae[_0x590dbf(0x16f)],_0x5682c8=_0x5c1fae[_0x590dbf(0x170)],_0x2e537d=this[_0x590dbf(0x169)],_0x2304b8=_0x2d56ed[_0x590dbf(0x15f)];_0x2d56ed['pixelStorei'](_0x2d56ed[_0x590dbf(0x18b)],![]),_0x2d56ed['pixelStorei'](_0x2d56ed[_0x590dbf(0x154)],![]),_0x2d56ed['compressedTexSubImage2D'](_0x2e603b,0x0,_0x803ef9,_0x35e198,_0x3f3cd6,_0x5c6da8,_0x2e537d,_0x5682c8),_0x2d56ed[_0x590dbf(0x182)](_0x2e603b,null);},DDSTexture[_0x5e5059(0x17e)]['update']=function(_0x236477){const _0x5c9b66=_0x5e5059;this['context']=_0x236477[_0x5c9b66(0x156)],this[_0x5c9b66(0x180)]=_0x236477[_0x5c9b66(0x156)]['id'],this[_0x5c9b66(0x17b)]=_0x236477[_0x5c9b66(0x17b)],this[_0x5c9b66(0x176)]=_0x236477[_0x5c9b66(0x176)],this[_0x5c9b66(0x18c)]=_0x236477[_0x5c9b66(0x18c)],this[_0x5c9b66(0x189)]=_0x236477['width'],this[_0x5c9b66(0x16f)]=_0x236477['height'],this[_0x5c9b66(0x169)]=_0x236477[_0x5c9b66(0x169)],this['arrayBufferView']=_0x236477['arrayBufferView'],this[_0x5c9b66(0x17f)]=0x1,this[_0x5c9b66(0x163)]=![],this[_0x5c9b66(0x16a)]=![],defined(this[_0x5c9b66(0x170)])&&this[_0x5c9b66(0x15a)]();},DDSTexture[_0x5e5059(0x17e)][_0x5e5059(0x16b)]=function(){return ![];},DDSTexture['prototype'][_0x5e5059(0x184)]=function(){const _0x3cd84b=_0x5e5059;let _0x554abb=this[_0x3cd84b(0x156)]['_gl'];_0x554abb[_0x3cd84b(0x179)](this[_0x3cd84b(0x155)]),this['_texture']=null,this['id']=0x0,Cesium[_0x3cd84b(0x18f)](this);};

    const _0x5182=['768217xSLLzi','specularColor','prototype','1LnaFag','clone','texMatrix','destroy','textures','Color','2NPvrfQ','length','isDestroyed','shininess','819633UxWTsA','Matrix4','IDENTITY','ambientColor','destroyObject','diffuseColor','874159hzfJJM','1127839NhthXW','278459fiqvXs','1128011mGdwBV','bTransparentSorting','425521wedbxO'];const _0x5d45e4=_0x31c6;function _0x31c6(_0x191f21,_0x3d6d8b){_0x191f21=_0x191f21-0x1bc;let _0x518263=_0x5182[_0x191f21];return _0x518263;}(function(_0x2ba943,_0x13f5f5){const _0x49583a=_0x31c6;while(!![]){try{const _0x5671c5=-parseInt(_0x49583a(0x1c6))+parseInt(_0x49583a(0x1cc))+parseInt(_0x49583a(0x1d1))+parseInt(_0x49583a(0x1c2))*-parseInt(_0x49583a(0x1ce))+parseInt(_0x49583a(0x1d2))+parseInt(_0x49583a(0x1bc))*parseInt(_0x49583a(0x1cf))+-parseInt(_0x49583a(0x1cd));if(_0x5671c5===_0x13f5f5)break;else _0x2ba943['push'](_0x2ba943['shift']());}catch(_0x4ce6cc){_0x2ba943['push'](_0x2ba943['shift']());}}}(_0x5182,0xa8d3e));function MaterialPass(){const _0x357006=_0x31c6;this['ambientColor']=new Cesium[(_0x357006(0x1c1))](),this['diffuseColor']=new Cesium[(_0x357006(0x1c1))](),this[_0x357006(0x1d3)]=new Cesium[(_0x357006(0x1c1))](0x0,0x0,0x0,0x0),this[_0x357006(0x1c5)]=0x32,this[_0x357006(0x1d0)]=![],this[_0x357006(0x1be)]=Cesium['Matrix4'][_0x357006(0x1bd)](Cesium['Matrix4'][_0x357006(0x1c8)],new Cesium[(_0x357006(0x1c7))]()),this['textures']=[];}MaterialPass[_0x5d45e4(0x1d4)][_0x5d45e4(0x1c4)]=function(){return ![];},MaterialPass['prototype'][_0x5d45e4(0x1bf)]=function(){const _0x5b3d69=_0x5d45e4;let _0x653825=this[_0x5b3d69(0x1c0)][_0x5b3d69(0x1c3)];for(let _0x1d9789=0x0;_0x1d9789<_0x653825;_0x1d9789++){let _0x2039bc=this['textures'][_0x1d9789];_0x2039bc[_0x5b3d69(0x1bf)]();}return this[_0x5b3d69(0x1c0)]['length']=0x0,this[_0x5b3d69(0x1c9)]=undefined,this[_0x5b3d69(0x1cb)]=undefined,this[_0x5b3d69(0x1d3)]=undefined,Cesium[_0x5b3d69(0x1ca)](this);};

    var _0x53ed=['\x0a\x20\x20\x20\x20attribute\x20vec4\x20aPosition;\x0a\x20\x20\x20\x20attribute\x20vec4\x20aColor;\x0a\x20\x20\x20\x20attribute\x20vec3\x20aNormal;\x0a#ifdef\x20TexCoord\x0a\x20\x20\x20\x20attribute\x20vec4\x20aTexCoord0;\x0a\x20\x20\x20\x20uniform\x20float\x20uTexture0Width;\x0a\x20\x20\x20\x20varying\x20vec4\x20vTexCoord;\x0a\x20\x20\x20\x20varying\x20vec4\x20vTexMatrix;\x0a\x20\x20\x20\x20varying\x20vec4\x20vTexCoordTransform;\x0a#endif\x0a#ifdef\x20HYPSOMETRIC\x0a\x20\x20\x20\x20varying\x20float\x20wValue;\x20\x20\x20\x20\x0a#endif\x0a#ifdef\x20FLATTEN\x0a\x20\x20\x20\x20uniform\x20mat4\x20uGeoMatrix;\x0a\x20\x20\x20\x20uniform\x20mat4\x20uInverseGeoMatrix;\x0a\x20\x20\x20\x20uniform\x20sampler2D\x20uFlattenTexture;\x0a\x20\x20\x20\x20uniform\x20vec4\x20uFlattenRect;\x0a#endif\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20uniform\x20vec4\x20uSelectedColor;\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20varying\x20vec4\x20vSecondColor;\x0a\x20\x20\x20\x20varying\x20vec4\x20vPositionMC;\x0a\x20\x20\x20\x20varying\x20vec3\x20vPositionEC;\x0a#ifdef\x20VertexColor\x0a\x20\x20\x20\x20varying\x20vec4\x20vColor;\x0a#endif\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20const\x20float\x20SHIFT_LEFT8\x20=\x20256.0;\x0a\x20\x20\x20\x20const\x20float\x20SHIFT_RIGHT8\x20=\x201.0\x20/\x20256.0;\x0a\x20\x20\x20\x20const\x20float\x20SHIFT_RIGHT4\x20=\x201.0\x20/\x2016.0;\x0a\x20\x20\x20\x20const\x20float\x20SHIFT_LEFT4\x20=\x2016.0;\x0a\x20\x20\x20\x20void\x20getTextureMatrixFromZValue(in\x20float\x20nZ,\x20inout\x20float\x20XTran,\x20inout\x20float\x20YTran,\x20inout\x20float\x20scale)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(nZ\x20<=\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20nDel8\x20=\x20floor(nZ\x20*\x20SHIFT_RIGHT8);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20nDel16\x20=\x20floor(nDel8\x20*\x20SHIFT_RIGHT8);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20nDel20\x20=\x20floor(nDel16\x20*\x20SHIFT_RIGHT4);\x0a\x20\x20\x20\x20\x20\x20\x20\x20YTran\x20=\x20nZ\x20-\x20nDel8\x20*\x20SHIFT_LEFT8;\x0a\x20\x20\x20\x20\x20\x20\x20\x20XTran\x20=\x20nDel8\x20-\x20nDel16\x20*\x20SHIFT_LEFT8;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20nLevel\x20=\x20nDel16\x20-\x20nDel20\x20*\x20SHIFT_LEFT4;\x0a\x20\x20\x20\x20\x20\x20\x20\x20scale\x20=\x201.0\x20/\x20pow(2.0,\x20nLevel);\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x0a#ifdef\x20FLATTEN\x0a\x20\x20\x20\x20float\x20unpackValue(vec4\x20packedValue)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20SHIFT_LEFT16\x20=\x2065536.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20SHIFT_LEFT8\x20=\x20256.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20value\x20=\x20packedValue\x20*\x20255.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20value.r\x20*\x20SHIFT_LEFT16\x20+\x20value.g\x20*\x20SHIFT_LEFT8\x20+\x20value.b\x20-\x209000.0;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20vec4\x20calculateHeight(vec4\x20vertexPos)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20vecPos\x20=\x20uGeoMatrix\x20*\x20vec4(vertexPos.xyz,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20vecRatio\x20=\x20vec2(uFlattenRect.z\x20-\x20uFlattenRect.x,\x20uFlattenRect.w\x20-\x20uFlattenRect.y);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20vecTexCoord\x20=\x20vec2(vecPos.x\x20-\x20uFlattenRect.x,\x20vecPos.y\x20-\x20uFlattenRect.y);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vecTexCoord.x\x20=\x20vecTexCoord.x\x20/\x20vecRatio.x;\x0a\x20\x20\x20\x20\x20\x20\x20\x20vecTexCoord.y\x20=\x20vecTexCoord.y\x20/\x20vecRatio.y;\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(vecTexCoord.x\x20>\x201.0\x20||\x20vecTexCoord.x\x20<\x200.0\x20||\x20vecTexCoord.y\x20>\x201.0\x20||\x20vecTexCoord.y\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20vertexPos;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20fHeight\x20=\x20unpackValue(texture2D(uFlattenTexture,\x20vecTexCoord.xy));\x0a\x20\x20\x20\x20\x20\x20\x20\x20fHeight\x20=\x20fHeight;\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(vecPos.z\x20>\x20fHeight)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20vecPos.z\x20=\x20fHeight;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20vecPos.w\x20=\x20vecPos.z;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20uInverseGeoMatrix\x20*\x20vec4(vecPos.xyz,\x201.0);\x0a\x20\x20\x20\x20}\x0a#endif\x0a\x20\x20\x20\x20void\x20main()\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20#ifdef\x20TexCoord\x0a\x20\x20\x20\x20\x20\x20\x20\x20vTexCoord.xy\x20=\x20aTexCoord0.xy;\x0a\x20\x20\x20\x20\x20\x20\x20\x20vTexMatrix\x20=\x20vec4(0.0,0.0,1.0,0.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vTexCoordTransform.x\x20=\x20aTexCoord0.z;\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(vTexCoordTransform.x\x20<\x20-90000.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20vTexMatrix.z\x20=\x20-1.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20getTextureMatrixFromZValue(floor(vTexCoordTransform.x),\x20vTexMatrix.x,\x20vTexMatrix.y,\x20vTexMatrix.z);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vTexMatrix.w\x20=\x20log2(uTexture0Width\x20*\x20vTexMatrix.z);\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20vec4\x20vertexPos\x20=\x20aPosition;\x0a#ifdef\x20FLATTEN\x0a\x20\x20\x20\x20vertexPos\x20=\x20calculateHeight(vertexPos);\x0a#endif\x0a\x0a\x20\x20\x20\x20#ifdef\x20HYPSOMETRIC\x0a\x20\x20\x20\x20\x20\x20\x20\x20wValue\x20=\x20vertexPos.w;\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20positionMC\x20=\x20vec4(vertexPos.xyz,\x201.0);\x0a#ifdef\x20VertexColor\x0a\x20\x20\x20\x20\x20\x20\x20\x20vColor\x20=\x20aColor;\x0a#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20vPositionMC\x20=\x20positionMC;\x0a\x20\x20\x20\x20\x20\x20\x20\x20vPositionEC\x20=\x20(czm_modelView\x20*\x20positionMC).xyz;\x0a\x20\x20\x20\x20\x20\x20\x20\x20gl_Position\x20=\x20czm_modelViewProjection\x20*\x20vec4(vertexPos.xyz,\x201.0);\x0a\x20\x20\x20\x20}\x0a','368886loDHTl','1WgwiVy','1SwCYrE','6442oLWeWu','724107SjyVMF','70487PiCmpS','1Bniwut','33991XXeruA','441275qZeUQu','9lUgugr','500277uuaIsC'];var _0x1410c9=_0x4100;(function(_0x71021f,_0x3ffa73){var _0x596946=_0x4100;while(!![]){try{var _0xdb9123=parseInt(_0x596946(0x193))*-parseInt(_0x596946(0x18b))+parseInt(_0x596946(0x18a))+parseInt(_0x596946(0x192))*parseInt(_0x596946(0x18f))+parseInt(_0x596946(0x190))*parseInt(_0x596946(0x195))+-parseInt(_0x596946(0x191))*-parseInt(_0x596946(0x194))+-parseInt(_0x596946(0x18c))+parseInt(_0x596946(0x18e));if(_0xdb9123===_0x3ffa73)break;else _0x71021f['push'](_0x71021f['shift']());}catch(_0x5bd948){_0x71021f['push'](_0x71021f['shift']());}}}(_0x53ed,0x6b6e9));function _0x4100(_0x3f4d4e,_0x52b4de){_0x3f4d4e=_0x3f4d4e-0x18a;var _0x53edf9=_0x53ed[_0x3f4d4e];return _0x53edf9;}var _0x56dd48 = _0x1410c9(0x18d);

    var _0x5683=['827786rLsrcH','214327MLugJs','178307Ztwurt','375804bLvZUz','115DNRpng','10536BQgZLt','16464vAzIIW','2FJuNIN','4Clxoba','690974LXmcBT'];function _0x292e(_0x339333,_0x578904){_0x339333=_0x339333-0x1a4;var _0x56834e=_0x5683[_0x339333];return _0x56834e;}(function(_0x4d96ee,_0x4083bd){var _0x2c8e48=_0x292e;while(!![]){try{var _0x3f39b8=-parseInt(_0x2c8e48(0x1ab))+parseInt(_0x2c8e48(0x1ad))+parseInt(_0x2c8e48(0x1a4))*-parseInt(_0x2c8e48(0x1a5))+parseInt(_0x2c8e48(0x1a6))+-parseInt(_0x2c8e48(0x1ac))+-parseInt(_0x2c8e48(0x1a7))*parseInt(_0x2c8e48(0x1a9))+parseInt(_0x2c8e48(0x1a8))*parseInt(_0x2c8e48(0x1aa));if(_0x3f39b8===_0x4083bd)break;else _0x4d96ee['push'](_0x4d96ee['shift']());}catch(_0x12ad31){_0x4d96ee['push'](_0x4d96ee['shift']());}}}(_0x5683,0xaf186));var _0x6b1656 = '\x0a#ifdef\x20GL_OES_standard_derivatives\x0a#extension\x20GL_OES_standard_derivatives\x20:\x20enable\x0a#endif\x0a#ifdef\x20GL_EXT_shader_texture_lod\x0a#extension\x20GL_EXT_shader_texture_lod\x20:\x20enable\x0a#endif\x0a\x20\x20\x20\x20uniform\x20vec4\x20uDiffuseColor;\x0a\x20\x20\x20\x20uniform\x20vec4\x20uAmbientColor;\x0a#ifdef\x20TexCoord\x0a\x20\x20\x20\x20uniform\x20sampler2D\x20uTexture;\x0a\x20\x20\x20\x20uniform\x20float\x20uTexture0Width;\x0a\x20\x20\x20\x20varying\x20vec4\x20vTexCoord;\x0a\x20\x20\x20\x20varying\x20vec4\x20vTexCoordTransform;\x0a\x20\x20\x20\x20varying\x20vec4\x20vTexMatrix;\x0a#endif\x0a#ifdef\x20VertexColor\x0a\x20\x20\x20\x20varying\x20vec4\x20vColor;\x0a#endif\x0a\x20\x20\x20\x20varying\x20vec4\x20vSecondColor;\x0a\x20\x20\x20\x20varying\x20vec4\x20vPositionMC;\x0a\x20\x20\x20\x20varying\x20vec3\x20vPositionEC;\x0a\x20\x20\x20\x20void\x20calculateMipLevel(in\x20vec2\x20inTexCoord,\x20in\x20float\x20vecTile,\x20in\x20float\x20fMaxMip,\x20inout\x20float\x20mipLevel)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20dx\x20=\x20dFdx(inTexCoord\x20*\x20vecTile);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20dy\x20=\x20dFdy(inTexCoord\x20*\x20vecTile);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dotX\x20=\x20dot(dx,\x20dx);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dotY\x20=\x20dot(dy,\x20dy);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dMax\x20=\x20max(dotX,\x20dotY);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dMin\x20=\x20min(dotX,\x20dotY);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20offset\x20=\x20(dMax\x20-\x20dMin)\x20/\x20(dMax\x20+\x20dMin);\x0a\x20\x20\x20\x20\x20\x20\x20\x20offset\x20=\x20clamp(offset,\x200.0,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20d\x20=\x20dMax\x20*\x20(1.0\x20-\x20offset)\x20+\x20dMin\x20*\x20offset;\x0a\x20\x20\x20\x20\x20\x20\x20\x20mipLevel\x20=\x200.5\x20*\x20log2(d);\x0a\x20\x20\x20\x20\x20\x20\x20\x20mipLevel\x20=\x20clamp(mipLevel,\x200.0,\x20fMaxMip\x20-\x201.62);\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20void\x20calculateMipLevel(in\x20vec2\x20inTexCoord,\x20in\x20vec2\x20vecTile,\x20in\x20float\x20fMaxMip,\x20inout\x20float\x20mipLevel)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20dx\x20=\x20dFdx(inTexCoord\x20*\x20vecTile.x);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20dy\x20=\x20dFdy(inTexCoord\x20*\x20vecTile.y);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dotX\x20=\x20dot(dx,\x20dx);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dotY\x20=\x20dot(dy,\x20dy);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dMax\x20=\x20max(dotX,\x20dotY);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dMin\x20=\x20min(dotX,\x20dotY);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20offset\x20=\x20(dMax\x20-\x20dMin)\x20/\x20(dMax\x20+\x20dMin);\x0a\x20\x20\x20\x20\x20\x20\x20\x20offset\x20=\x20clamp(offset,\x200.0,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20d\x20=\x20dMax\x20*\x20(1.0\x20-\x20offset)\x20+\x20dMin\x20*\x20offset;\x0a\x20\x20\x20\x20\x20\x20\x20\x20mipLevel\x20=\x200.5\x20*\x20log2(d);\x0a\x20\x20\x20\x20\x20\x20\x20\x20mipLevel\x20=\x20clamp(mipLevel,\x200.0,\x20fMaxMip\x20-\x201.62);\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20void\x20calculateTexCoord(in\x20vec3\x20inTexCoord,\x20in\x20float\x20scale,\x20in\x20float\x20XTran,\x20in\x20float\x20YTran,\x20in\x20float\x20fTile,\x20in\x20float\x20mipLevel,\x20inout\x20vec2\x20outTexCoord)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(inTexCoord.z\x20<\x20-9000.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20outTexCoord\x20=\x20inTexCoord.xy;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20fTexCoord\x20=\x20fract(inTexCoord.xy);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20float\x20offset\x20=\x201.0\x20*\x20pow(2.0,\x20mipLevel)\x20/\x20fTile;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20fTexCoord\x20=\x20clamp(fTexCoord,\x20offset,\x201.0\x20-\x20offset);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20outTexCoord.x\x20=\x20(fTexCoord.x\x20+\x20XTran)\x20*\x20scale;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20outTexCoord.y\x20=\x20(fTexCoord.y\x20+\x20YTran)\x20*\x20scale;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20vec4\x20getTexColorForS3M(sampler2D\x20curTexture,\x20vec3\x20oriTexCoord,\x20float\x20texTileWidth,\x20float\x20fMaxMipLev,\x20float\x20fTexCoordScale,\x20vec2\x20vecTexCoordTranslate)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20color\x20=\x20vec4(1.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20mipLevel\x20=\x200.0;\x0a\x20\x20\x20\x20#ifdef\x20GL_OES_standard_derivatives\x0a\x20\x20\x20\x20\x20\x20\x20\x20calculateMipLevel(oriTexCoord.xy,\x20texTileWidth,\x20fMaxMipLev,\x20mipLevel);\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20realTexCoord;\x0a\x20\x20\x20\x20\x20\x20\x20\x20calculateTexCoord(oriTexCoord,\x20fTexCoordScale,\x20vecTexCoordTranslate.x,\x20vecTexCoordTranslate.y,\x20texTileWidth,\x20mipLevel,\x20realTexCoord);\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(oriTexCoord.z\x20<\x20-9000.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color\x20=\x20texture2D(curTexture,\x20realTexCoord.xy);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#ifdef\x20GL_EXT_shader_texture_lod\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color\x20=\x20texture2DLodEXT(curTexture,\x20realTexCoord.xy,\x20mipLevel);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color\x20=\x20texture2D(curTexture,\x20realTexCoord.xy,\x20mipLevel);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20color;\x0a\x20\x20\x20\x20}\x0a#ifdef\x20TexCoord\x0a\x20\x20\x20\x20vec4\x20getTextureColor()\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(vTexMatrix.z\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20vec4(1.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20texTileWidth0\x20=\x20vTexMatrix.z\x20*\x20uTexture0Width;\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20realTexCoord\x20=\x20vec3(vTexCoord.xy,\x20vTexCoordTransform.x);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20FColor\x20=\x20getTexColorForS3M(uTexture,\x20realTexCoord,\x20texTileWidth0,\x20vTexMatrix.w,\x20vTexMatrix.z,\x20vTexMatrix.xy);\x0a\x20\x20\x20\x20#ifdef\x20TexCoord2\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20texTileWidth1\x20=\x20vTexMatrix2.z\x20*\x20uTexture1Width;\x0a\x20\x20\x20\x20\x20\x20\x20\x20realTexCoord\x20=\x20vec3(vTexCoord.zw,\x20vTexCoordTransform.y);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20SColor\x20=\x20getTexColorForS3M(uTexture2,\x20realTexCoord,\x20texTileWidth1,\x20vTexMatrix2.w,\x20vTexMatrix2.z,\x20vTexMatrix2.xy);\x0a\x20\x20\x20\x20\x20\x20\x20\x20SColor.r\x20=\x20clamp(SColor.r,\x200.0,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20SColor.g\x20=\x20clamp(SColor.g,\x200.0,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20SColor.b\x20=\x20clamp(SColor.b,\x200.0,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20FColor\x20*\x20SColor;\x0a\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20FColor;\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20}\x0a#endif\x0a\x20\x20\x20\x20\x0a#ifdef\x20CLIP\x0a\x20\x20\x20\x20uniform\x20float\x20uClipMode;\x0a\x20\x20\x20\x20uniform\x20vec4\x20uClipPlanes[6];\x0a\x20\x20\x20\x20float\x20getClipDistance(vec3\x20pos,\x20vec3\x20planeNormal,\x20float\x20disToOrigin)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20dot(planeNormal,\x20pos)\x20+\x20disToOrigin;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20float\x20clipBehindAllPlane(float\x20fBorderWidth,\x20vec4\x20vertex)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20distance\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20result\x20=\x20-1.0;\x0a\x20\x20\x20\x20#ifdef\x20CLIPPLANE\x0a\x20\x20\x20\x20\x20\x20\x20\x20distance\x20=\x20getClipDistance(vertex.xyz,\x20uClipPlanes[0].xyz,\x20uClipPlanes[0].w);\x0a\x20\x20\x20\x20\x20\x20\x20\x20if\x20(distance\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x201.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x20if\x20(distance\x20<\x20fBorderWidth)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20result\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20for(int\x20i\x20=\x200;\x20i\x20<\x206;\x20i++)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20distance\x20=\x20getClipDistance(vertex.xyz,\x20uClipPlanes[i].xyz,\x20uClipPlanes[i].w);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20if(distance\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x201.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(distance\x20<\x20fBorderWidth)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20result\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20result;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20float\x20clipBehindAnyPlane(float\x20fBorderWidth,\x20vec4\x20vertex)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20result\x20=\x201.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20for(int\x20i\x20=\x200;\x20i\x20<\x206;\x20i++)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20float\x20distance\x20=\x20getClipDistance(vertex.xyz,\x20uClipPlanes[i].xyz,\x20uClipPlanes[i].w);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20if((distance\x20+\x20fBorderWidth)\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20-1.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(distance\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20result\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20result;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20float\x20clipAnythingButLine(float\x20fBorderWidth,\x20vec4\x20vertex)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20result\x20=\x20-1.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20for(int\x20i\x20=\x200;\x20i\x20<\x206;\x20i++)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20float\x20distance\x20=\x20getClipDistance(vertex.xyz,\x20uClipPlanes[i].xyz,\x20uClipPlanes[i].w);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20if(distance\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20-1.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(distance\x20<\x20fBorderWidth)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20result\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20result;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20vec4\x20clip(vec4\x20vertex)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(uClipMode\x20<\x200.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20vec4(1.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20#ifdef\x20GL_OES_standard_derivatives\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dxc\x20=\x20abs(dFdx(vertex.x));\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dyc\x20=\x20abs(dFdy(vertex.y));\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20fBorderWidth\x20=\x20max(dxc,\x20dyc);\x0a\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20fBorderWidth\x20=\x201.0;\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20clipResult\x20=\x201.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(uClipMode\x20<\x201.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20clipResult\x20=\x20clipBehindAnyPlane(fBorderWidth,\x20vertex);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(uClipMode\x20<\x202.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20clipResult\x20=\x20clipBehindAllPlane(fBorderWidth,\x20vertex);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(uClipMode\x20<\x203.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20clipResult\x20=\x20clipAnythingButLine(fBorderWidth,\x20vertex);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(clipResult\x20<\x20-0.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20discard;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(clipResult\x20<\x200.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20vec4(1.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20vec4(1.0);\x0a\x20\x20\x20\x20}\x0a#endif\x0a\x0a#ifdef\x20HYPSOMETRIC\x0a\x20\x20\x20\x20uniform\x20sampler2D\x20uHypsometricTexture;\x0a\x20\x20\x20\x20uniform\x20vec4\x20uMinMaxValue;\x0a\x20\x20\x20\x20uniform\x20vec4\x20uOpacityIntervalFillMode;\x0a\x20\x20\x20\x20uniform\x20vec4\x20uHypLineColor;\x0a\x20\x20\x20\x20uniform\x20vec4\x20uNoValueColor;\x0a\x20\x20\x20\x20varying\x20float\x20wValue;\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20float\x20computeMixCon(float\x20fValue)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20distanceToContour;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20minVisibleValue\x20=\x20uMinMaxValue.z;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20maxVisibleValue\x20=\x20uMinMaxValue.w;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20interval\x20=\x20uOpacityIntervalFillMode.y;\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(abs(maxVisibleValue\x20-\x20minVisibleValue)\x20>\x200.1)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20if(fValue\x20<\x200.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20distanceToContour\x20=\x20mod(fValue\x20-\x200.0002,\x20interval);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20else\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20float\x20t\x20=\x20floor(fValue\x20/\x20interval);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20distanceToContour\x20=\x20abs(fValue\x20-\x20(t\x20*\x20interval)\x20-\x200.1);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20distanceToContour\x20=\x20abs(fValue\x20-\x20maxVisibleValue);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dxc\x20=\x20abs(dFdx(fValue));\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dyc\x20=\x20abs(dFdy(fValue));\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dF\x20=\x20max(dxc,\x20dyc);\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20distanceToContour\x20<\x20dF\x20?\x201.0\x20:\x200.0;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20vec4\x20computeContourMapColor(float\x20fValue)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20floorValue\x20=\x20uMinMaxValue.x;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20ceilValue\x20=\x20uMinMaxValue.y;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20threshold\x20=\x20abs(ceilValue\x20-\x20floorValue);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20contourRate\x20=\x20(fValue\x20-\x20floorValue)\x20/\x20threshold;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20finalCoord\x20=\x20clamp(contourRate,\x200.0,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20count\x20=\x20floor(finalCoord\x20*\x2016.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20y\x20=\x20(count*2.0\x20+\x201.0)/32.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20x\x20=\x20fract(finalCoord*16.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(y\x20>\x201.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20x\x20=\x201.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20contourCoord\x20=\x20vec2(x,\x20y);\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20texture2D(uHypsometricTexture,\x20contourCoord);\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20vec4\x20getContourMapColor(vec4\x20oriColor,\x20float\x20fValue)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20contourMapColor\x20=\x20vec4(0.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20finalOpacity\x20=\x20uOpacityIntervalFillMode.x;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20minVisibleValue\x20=\x20uMinMaxValue.z;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20maxVisibleValue\x20=\x20uMinMaxValue.w;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20fillMode\x20=\x20uOpacityIntervalFillMode.z;\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(fValue\x20>\x20maxVisibleValue\x20+\x204.0\x20||\x20fValue\x20<\x20minVisibleValue\x20-\x204.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20uNoValueColor\x20*\x20oriColor;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(fillMode\x20>\x202.9)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20float\x20mix_con\x20=\x20computeMixCon(fValue);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20contourMapColor\x20=\x20mix(computeContourMapColor(fValue),\x20uHypLineColor,\x20mix_con);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(fillMode\x20>\x201.9)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20finalOpacity\x20=\x20computeMixCon(fValue);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20contourMapColor\x20=\x20uHypLineColor;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(fillMode\x20>\x200.9)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20contourMapColor\x20=\x20computeContourMapColor(fValue);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20finalOpacity\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20finalColor\x20=\x20mix(oriColor,\x20contourMapColor,\x20finalOpacity);\x0a\x20\x20\x20\x20#ifdef\x20PT_CLOUD\x0a\x20\x20\x20\x20\x20\x20\x20\x20finalColor\x20=\x20mix(vec4(1.0,1.0,1.0,1.0),\x20contourMapColor,\x20finalOpacity);\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20finalColor;\x0a\x20\x20\x20\x20}\x0a#endif\x0a\x20\x20\x0a#ifdef\x20APPLY_SWIPE\x0a\x20\x20\x20\x20uniform\x20vec4\x20uSwipeRegion;\x0a\x20\x20\x20\x20void\x20rollerShutter(vec2\x20coord,\x20vec4\x20region)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20f\x20=\x20step(region.xw,\x20coord);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20s\x20=\x20step(coord,\x20region.zy);\x0a\x20\x20\x20\x20\x20\x20\x20\x20if\x20(f.x\x20*\x20f.y\x20*\x20s.x\x20*\x20s.y\x20<\x201.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20discard;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20}\x0a#endif\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20void\x20main()\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20#ifdef\x20APPLY_SWIPE\x0a\x20\x20\x20\x20\x20\x20\x20\x20rollerShutter(gl_FragCoord.xy,\x20uSwipeRegion);\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20vec4\x20baseColorWithAlpha\x20=\x20vec4(1.0);\x0a\x20\x20\x20\x20#ifdef\x20VertexColor\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20baseColorWithAlpha\x20=\x20vColor;\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20#ifdef\x20TexCoord\x0a\x20\x20\x20\x20\x20\x20\x20\x20baseColorWithAlpha\x20*=\x20getTextureColor();\x0a\x20\x20\x20\x20#endif\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20outColor\x20=\x20baseColorWithAlpha;\x0a\x20\x20\x20\x20#ifdef\x20HYPSOMETRIC\x0a\x20\x20\x20\x20\x20\x20\x20\x20outColor\x20=\x20getContourMapColor(outColor,\x20wValue);\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20#ifdef\x20CLIP\x0a\x20\x20\x20\x20\x20\x20\x20\x20outColor\x20*=\x20clip(vec4(vPositionEC,\x201.0));\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20gl_FragColor\x20=\x20outColor;\x0a\x20\x20\x20\x20}\x0a';

    const _0x1d37=['Buffer','DeveloperError','prototype','1067103zXRfSo','1072KfskKZ','vertexBuffer','vertexPackage','1187017QDANnl','createVertexBuffer','150659SFhRlL','instance\x20buffer\x20is\x20null','context','1tznlbK','instanceBuffer','instanceIndex','set','883745kRospv','defined','STATIC_DRAW','vertexAttributes','1203326grXHMR','instanceDivisor','attribute\x20is\x20null','BufferUsage','1327Fgtppw','model','execute','562433akJNWd','6MsUajP','index'];const _0x1b15d8=_0x116d;(function(_0x572f61,_0x469118){const _0x4c731a=_0x116d;while(!![]){try{const _0x352cb7=parseInt(_0x4c731a(0x1a8))*parseInt(_0x4c731a(0x19d))+-parseInt(_0x4c731a(0x195))+-parseInt(_0x4c731a(0x1a6))+parseInt(_0x4c731a(0x19c))+-parseInt(_0x4c731a(0x18d))*-parseInt(_0x4c731a(0x1a2))+-parseInt(_0x4c731a(0x191))+-parseInt(_0x4c731a(0x1a3))*-parseInt(_0x4c731a(0x199));if(_0x352cb7===_0x469118)break;else _0x572f61['push'](_0x572f61['shift']());}catch(_0xb4e6cc){_0x572f61['push'](_0x572f61['shift']());}}}(_0x1d37,0xa67da));function _0x116d(_0x18b2c7,_0x4abba9){_0x18b2c7=_0x18b2c7-0x18c;let _0x1d379e=_0x1d37[_0x18b2c7];return _0x1d379e;}function S3MCreateVertexJob(){const _0x14f202=_0x116d;this['context']=undefined,this[_0x14f202(0x19a)]=undefined,this[_0x14f202(0x19e)]=undefined;}S3MCreateVertexJob[_0x1b15d8(0x1a1)][_0x1b15d8(0x190)]=function(_0x4203bb,_0x145abb,_0x2beb2a){const _0x294308=_0x1b15d8;this[_0x294308(0x18c)]=_0x4203bb,this[_0x294308(0x19a)]=_0x145abb,this[_0x294308(0x19e)]=_0x2beb2a;},S3MCreateVertexJob['prototype'][_0x1b15d8(0x19b)]=function(){const _0x38c2b8=_0x1b15d8;let _0xf361d0=this[_0x38c2b8(0x18c)],_0x44bc23=this[_0x38c2b8(0x19e)],_0x92bfc2=this[_0x38c2b8(0x19a)][_0x38c2b8(0x1a5)],_0x3123a6=_0x92bfc2[_0x38c2b8(0x194)][_0x44bc23];if(!Cesium[_0x38c2b8(0x192)](_0x3123a6))throw new Cesium[(_0x38c2b8(0x1a0))](_0x38c2b8(0x197));if(_0x92bfc2[_0x38c2b8(0x18f)]!==-0x1&&!Cesium[_0x38c2b8(0x192)](this['model'][_0x38c2b8(0x18e)])){if(!Cesium[_0x38c2b8(0x192)](_0x92bfc2[_0x38c2b8(0x18e)]))throw new Cesium[(_0x38c2b8(0x1a0))](_0x38c2b8(0x1a9));this['model'][_0x38c2b8(0x18e)]=Cesium[_0x38c2b8(0x19f)][_0x38c2b8(0x1a7)]({'context':_0xf361d0,'typedArray':_0x92bfc2['instanceBuffer'],'usage':Cesium[_0x38c2b8(0x198)][_0x38c2b8(0x193)]});}if(_0x3123a6[_0x38c2b8(0x196)]===0x1&&!Cesium[_0x38c2b8(0x192)](_0x3123a6['typedArray'])){_0x3123a6[_0x38c2b8(0x1a4)]=this['model'][_0x38c2b8(0x18e)];return;}!Cesium[_0x38c2b8(0x192)](_0x3123a6[_0x38c2b8(0x1a4)])&&(_0x3123a6['vertexBuffer']=Cesium[_0x38c2b8(0x19f)]['createVertexBuffer']({'context':_0xf361d0,'typedArray':_0x3123a6['typedArray'],'usage':Cesium[_0x38c2b8(0x198)][_0x38c2b8(0x193)]}),_0x3123a6['typedArray']=null,delete _0x3123a6['typedArray']);};

    const _0x1843=['UNSIGNED_INT','6004mgbaHq','indexBuffer','index\x20package\x20is\x20null','context','1CohdFD','8611zFZnWe','createIndexBuffer','Buffer','indexType','index','113BRRJis','38517meeAWf','DeveloperError','IndexDatatype','verticesCount','vertexPackage','69942zoPeiA','index\x20buffer\x20is\x20null','23vriDUY','10RTMcqn','STATIC_DRAW','BufferUsage','model','set','UNSIGNED_SHORT','elementIndexUint','743671JkXZlx','defined','Math','6922cTDLDb','SIXTY_FOUR_KILOBYTES','1025178QNsAxo','73fvTTnd','indicesTypedArray','prototype','arrIndexPackage','9UBBxAo'];const _0x485de7=_0x8dec;(function(_0x594ccf,_0xcf5526){const _0x32a9a8=_0x8dec;while(!![]){try{const _0x1f9907=parseInt(_0x32a9a8(0xd1))*-parseInt(_0x32a9a8(0xec))+parseInt(_0x32a9a8(0xda))*parseInt(_0x32a9a8(0xe4))+-parseInt(_0x32a9a8(0xed))*parseInt(_0x32a9a8(0xea))+parseInt(_0x32a9a8(0xde))*parseInt(_0x32a9a8(0xce))+parseInt(_0x32a9a8(0xd4))*parseInt(_0x32a9a8(0xdf))+-parseInt(_0x32a9a8(0xe5))*-parseInt(_0x32a9a8(0xd8))+-parseInt(_0x32a9a8(0xd3));if(_0x1f9907===_0xcf5526)break;else _0x594ccf['push'](_0x594ccf['shift']());}catch(_0x35f00b){_0x594ccf['push'](_0x594ccf['shift']());}}}(_0x1843,0x7d627));function S3MCreateIndexBufferJob(){const _0x44121f=_0x8dec;this['model']=undefined,this[_0x44121f(0xdd)]=undefined,this['index']=0x0;}S3MCreateIndexBufferJob[_0x485de7(0xd6)][_0x485de7(0xf1)]=function(_0x1205c5,_0xde5e01,_0x40fdc2){const _0x5d822d=_0x485de7;this['model']=_0xde5e01,this[_0x5d822d(0xdd)]=_0x1205c5,this[_0x5d822d(0xe3)]=_0x40fdc2;},S3MCreateIndexBufferJob[_0x485de7(0xd6)]['execute']=function(){const _0x11ee6f=_0x485de7;let _0x55b799=this[_0x11ee6f(0xdd)],_0x4463e2=this[_0x11ee6f(0xf0)][_0x11ee6f(0xd7)][this[_0x11ee6f(0xe3)]],_0x5db820=this['model'][_0x11ee6f(0xe9)][_0x11ee6f(0xe8)];if(!Cesium['defined'](_0x4463e2))throw new Cesium['DeveloperError'](_0x11ee6f(0xdc));if(Cesium[_0x11ee6f(0xcf)](_0x4463e2['indexBuffer']))return;if(!Cesium[_0x11ee6f(0xcf)](_0x4463e2[_0x11ee6f(0xd5)]))throw new Cesium[(_0x11ee6f(0xe6))](_0x11ee6f(0xeb));let _0x125393=Cesium[_0x11ee6f(0xe7)][_0x11ee6f(0xf2)];(_0x4463e2[_0x11ee6f(0xe2)]===0x1||_0x5db820>=Cesium[_0x11ee6f(0xd0)][_0x11ee6f(0xd2)])&&_0x55b799[_0x11ee6f(0xf3)]&&(_0x125393=Cesium['IndexDatatype'][_0x11ee6f(0xd9)]),!Cesium['defined'](_0x4463e2['indexBuffer'])&&(_0x4463e2[_0x11ee6f(0xdb)]=Cesium[_0x11ee6f(0xe1)][_0x11ee6f(0xe0)]({'context':_0x55b799,'typedArray':_0x4463e2[_0x11ee6f(0xd5)],'usage':Cesium[_0x11ee6f(0xef)][_0x11ee6f(0xee)],'indexDatatype':_0x125393})),_0x4463e2[_0x11ee6f(0xd5)]=null,delete _0x4463e2[_0x11ee6f(0xd5)];};function _0x8dec(_0x52897e,_0x4ac385){_0x52897e=_0x52897e-0xce;let _0x1843d4=_0x1843[_0x52897e];return _0x1843d4;}

    const _0x5a8d=['VERTEX_CAPTURE','HAS_LIGHT','895050dvzgwv','FALTTEN','IBL','885125doFNLt','COMPUTE_TEXCOORD','HAS_SKELETONSELECTED','ADJUST_COLOR','Instance','freeze','TextureAtlas','POST_EFFECT','TEXTURE_COORD_ONE_IS_W','1112214NbbujF','743565jKTuIV','Translation','TexCoord2','VOL_AND_HYP','Volume','APPLY_SWIPE','BRDF','EMISSION_TEXTURE','EXCAVATION','InstancePipe','1455149xEXoKB','WEBP','OVERLAY','SPOT_LIGHTS\x20','CLIP','Volume2','PT_CLOUD','COMPUTE_W_VALUE','DIR_LIGHTS\x20','REPLACE_SELECT_TYPE','SKELETONSELECT_ENABLE','PBR_THEME','TRANSPARENT_BACK_COLOR','TexCoord','InstanceBim','COMPRESS_NORMAL','HORIZONTAL_LINE','TextureAtlasSec','SEC_TEX_EMISSION','TEXTURE_MOVE','APPLY_SPLIT','IGNORE_NORMAL','VertexColor','USE_LINECOLOR','2135918IEFGmZ','HYPSOMETRIC','TRIANGLE_FILTRATE','328653uZOreK','EMISSION_TEXTURE_COUNT\x20'];const _0x5b7ea2=_0x25e0;function _0x25e0(_0x2935cf,_0xd6a5df){_0x2935cf=_0x2935cf-0x10f;let _0x5a8da5=_0x5a8d[_0x2935cf];return _0x5a8da5;}(function(_0xb6fc94,_0x5d1863){const _0x157c54=_0x25e0;while(!![]){try{const _0x306a01=-parseInt(_0x157c54(0x140))+-parseInt(_0x157c54(0x144))+parseInt(_0x157c54(0x125))+parseInt(_0x157c54(0x11a))+parseInt(_0x157c54(0x11b))+parseInt(_0x157c54(0x111))+-parseInt(_0x157c54(0x13d));if(_0x306a01===_0x5d1863)break;else _0xb6fc94['push'](_0xb6fc94['shift']());}catch(_0x5580d8){_0xb6fc94['push'](_0xb6fc94['shift']());}}}(_0x5a8d,0xcc350));const ProgramDefines$1={'EXCAVATION':_0x5b7ea2(0x123),'FALTTEN':_0x5b7ea2(0x10f),'OVERLAY':_0x5b7ea2(0x127),'HYPSOMETRIC':_0x5b7ea2(0x13e),'ADJUST_COLOR':_0x5b7ea2(0x114),'TRANSPARENT_BACK_COLOR':_0x5b7ea2(0x131),'HORIZONTAL_LINE':_0x5b7ea2(0x135),'COMPUTE_W_VALUE':_0x5b7ea2(0x12c),'COMPUTE_TEXCOORD':'COMPUTE_TEXCOORD','HAS_LIGHT':_0x5b7ea2(0x143),'HAS_NORMAL':'HAS_NORMAL','REPLACE_SELECT_TYPE':_0x5b7ea2(0x12e),'SILHOUETTE_SELECT_TYPE':'SILHOUETTE_SELECT_TYPE','MULTI_TEX':'MULTI_TEX','APPLY_SPLIT':_0x5b7ea2(0x139),'APPLY_SWIPE':_0x5b7ea2(0x120),'TEXCOORD':_0x5b7ea2(0x132),'TEXCOORD2':_0x5b7ea2(0x11d),'COMPRESS_VERTEX':'COMPRESS_VERTEX','COMPRESS_NORMAL':_0x5b7ea2(0x134),'COMPRESS_COLOR':'COMPRESS_COLOR','COMPRESS_TEXCOORD':'COMPRESS_TEXCOORD','SKETCH_MODE':'SKETCH_MODE','NORMAL_AND_DEPTH':'NORMAL_AND_DEPTH','POST_EFFECT':_0x5b7ea2(0x118),'CLIP_FILT_BY_ID':'CLIP_FILT_BY_ID','CLIP':_0x5b7ea2(0x129),'CLIPPLANE':'CLIPPLANE','PBR':'PBR','PT_CLOUD':_0x5b7ea2(0x12b),'DIR_LIGHTS':_0x5b7ea2(0x12d),'POINT_LIGHTS':'POINT_LIGHTS\x20','SPOT_LIGHTS':_0x5b7ea2(0x128),'W_VISIBLE':'W_VISIBLE','EMISSION_TEXTURE':_0x5b7ea2(0x122),'EMISSION_TEXTURE_COUNT':_0x5b7ea2(0x141),'TEXTURE_MOVE':_0x5b7ea2(0x138),'VOLUME':_0x5b7ea2(0x11f),'VOLUME2':_0x5b7ea2(0x12a),'TEXTURE_COORD_ONE_IS_W':_0x5b7ea2(0x119),'TRIANGLE_FILTRATE':_0x5b7ea2(0x13f),'UseInstanceSkeletonMatrix':'UseInstanceSkeletonMatrix','WEBP':_0x5b7ea2(0x126),'HAS_SKELETONSELECTED':_0x5b7ea2(0x113),'SKELETONSELECT_ENABLE':_0x5b7ea2(0x12f),'REPLACE_COLOR_TYPE':'REPLACE_COLOR_TYPE','INVALID_OBLIQUE':'INVALID_OBLIQUE','IGNORE_NORMAL':_0x5b7ea2(0x13a),'TextureAtlas':_0x5b7ea2(0x117),'TextureAtlasSec':_0x5b7ea2(0x136),'Translation':_0x5b7ea2(0x11c),'VOL_AND_HYP':_0x5b7ea2(0x11e),'VERTEX_CAPTURE':_0x5b7ea2(0x142),'SEC_TEX_EMISSION':_0x5b7ea2(0x137),'BRDF':_0x5b7ea2(0x121),'PBR_THEME':_0x5b7ea2(0x130),'IBL':_0x5b7ea2(0x110),'FLATTEN':'FLATTEN','UseLineColor':_0x5b7ea2(0x13c),'Instance':_0x5b7ea2(0x115),'InstanceBim':_0x5b7ea2(0x133),'InstancePipe':_0x5b7ea2(0x124),'COMPUTE_TEXCOORD':_0x5b7ea2(0x112),'VertexColor':_0x5b7ea2(0x13b),'VertexNormal':'VertexNormal'};var _0x3ec161 = Object[_0x5b7ea2(0x116)](ProgramDefines$1);

    const _0x3d29=['399101ACPjvX','2NFAREt','486456fCcnbi','freeze','111218mYJYoq','878219vTGowR','755060xfzZFl','5ohxAWz','87511NwBUCt','788164ApxuLB','1bFHBPI'];const _0x2c977c=_0x2437;(function(_0x450364,_0x59a3e1){const _0x4a9863=_0x2437;while(!![]){try{const _0x27e13=parseInt(_0x4a9863(0x74))*-parseInt(_0x4a9863(0x73))+parseInt(_0x4a9863(0x72))+parseInt(_0x4a9863(0x71))*parseInt(_0x4a9863(0x6e))+parseInt(_0x4a9863(0x6f))+parseInt(_0x4a9863(0x70))+parseInt(_0x4a9863(0x75))+parseInt(_0x4a9863(0x76))*-parseInt(_0x4a9863(0x6c));if(_0x27e13===_0x59a3e1)break;else _0x450364['push'](_0x450364['shift']());}catch(_0x32c09e){_0x450364['push'](_0x450364['shift']());}}}(_0x3d29,0xdf5d9));function _0x2437(_0x9377ed,_0x40d338){_0x9377ed=_0x9377ed-0x6c;let _0x3d2931=_0x3d29[_0x9377ed];return _0x3d2931;}const InstanceMode={'BIM':0x11,'PIPELINE':0x1d};var _0x526c05 = Object[_0x2c977c(0x6d)](InstanceMode);

    const _0x3be1=['EXT_shader_texture_lod','compressOptions','InstancePipe','CLIPPLANE','TexCoord','322427EEKqpZ','624522SsyqAw','Instance','length','ShaderProgram','814ZiZNaH','textures','instanceMode','TextureAtlasSec','COMPRESS_VERTEX','SVC_VertexColor','InstanceBim','SVC_TexutreCoord','defaultValue','SVC_Vertex','batchTable','COMPRESS_NORMAL','TextureAtlas','COMPRESS_TEXCOORD','FLATTEN','_enableClipPlane','COMPUTE_TEXCOORD','textureCoordIsW','defined','aColor','315719KVzFNl','execute','flattening','VertexNormal','push','288559zkBcUU','18258LvxGsX','isUseHypColorTable','TEXTURE_COORD_ONE_IS_W','arrIndexPackage','UseLineColor','APPLY_SWIPE','VertexColor','COMPRESS_COLOR','ShaderSource','vertexPackage','SVC_Normal','_gl','TexCoord2','124jHVjWQ','shaderProgram','aTexCoord0','PIPELINE','defines','texturelod','getVertexShaderCallback','366nlwYFy','HYPSOMETRIC','39DiwsYj','set','context','CLIP','batchTableBake','model'];const _0x5a809c=_0x3d90;(function(_0x395bce,_0x2c5f9c){const _0x3ce9f8=_0x3d90;while(!![]){try{const _0x204bf9=-parseInt(_0x3ce9f8(0x1d9))+-parseInt(_0x3ce9f8(0x1ac))*parseInt(_0x3ce9f8(0x1c5))+parseInt(_0x3ce9f8(0x1b5))*parseInt(_0x3ce9f8(0x1b3))+parseInt(_0x3ce9f8(0x1de))+-parseInt(_0x3ce9f8(0x1c0))+-parseInt(_0x3ce9f8(0x1df))+parseInt(_0x3ce9f8(0x1c1));if(_0x204bf9===_0x2c5f9c)break;else _0x395bce['push'](_0x395bce['shift']());}catch(_0x358461){_0x395bce['push'](_0x395bce['shift']());}}}(_0x3be1,0x2981f));function S3MCreateShaderProgramJob(){const _0x5305c1=_0x3d90;this[_0x5305c1(0x1ba)]=undefined,this[_0x5305c1(0x1b7)]=undefined;}S3MCreateShaderProgramJob['prototype'][_0x5a809c(0x1b6)]=function(_0x35f5fb,_0x74ec08){const _0x2312ed=_0x5a809c;this[_0x2312ed(0x1ba)]=_0x74ec08,this['context']=_0x35f5fb;};function _0x3d90(_0x4a0a8e,_0x869ca9){_0x4a0a8e=_0x4a0a8e-0x1a3;let _0x3be150=_0x3be1[_0x4a0a8e];return _0x3be150;}function getExtension(_0x3463e0,_0x95ef82){const _0x23ffd9=_0x5a809c;let _0x4de916=_0x95ef82[_0x23ffd9(0x1c3)];for(let _0x222115=0x0;_0x222115<_0x4de916;++_0x222115){let _0x2129d6=_0x3463e0['getExtension'](_0x95ef82[_0x222115]);if(_0x2129d6)return _0x2129d6;}return undefined;}S3MCreateShaderProgramJob['prototype'][_0x5a809c(0x1da)]=function(){const _0x8a6f36=_0x5a809c,_0x5530a0=this[_0x8a6f36(0x1b7)],_0x1febfc=this[_0x8a6f36(0x1ba)],_0x42b44e=_0x1febfc['layer'],_0x3fa180=_0x1febfc['vs'],_0x3e45c8=_0x1febfc['fs'],_0x1d78ef=_0x1febfc['attributeLocations'],_0x5e20fe=_0x1febfc['material'],_0x1c8339=_0x1febfc[_0x8a6f36(0x1a8)];let _0x5d8c90=_0x1febfc['batchTable']?_0x1febfc[_0x8a6f36(0x1cf)][_0x8a6f36(0x1b2)]()(_0x3fa180):_0x3fa180;_0x5530a0[_0x8a6f36(0x1b1)]===undefined&&(_0x5530a0[_0x8a6f36(0x1b1)]=Cesium[_0x8a6f36(0x1cd)](getExtension(_0x5530a0[_0x8a6f36(0x1aa)],[_0x8a6f36(0x1bb)]),![]));let _0x333b73=new Cesium[(_0x8a6f36(0x1a7))]({'sources':[_0x5d8c90]}),_0x338f6d=new Cesium['ShaderSource']({'sources':[_0x3e45c8]});Cesium['defined'](_0x1d78ef['aNormal'])&&(_0x333b73[_0x8a6f36(0x1b0)]['push'](_0x3ec161[_0x8a6f36(0x1dc)]),_0x338f6d['defines'][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1dc)]));Cesium[_0x8a6f36(0x1d7)](_0x1d78ef[_0x8a6f36(0x1d8)])&&_0x333b73[_0x8a6f36(0x1b0)][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1a5)]);_0x5e20fe&&_0x5e20fe[_0x8a6f36(0x1c6)][_0x8a6f36(0x1c3)]>0x0&&(_0x333b73[_0x8a6f36(0x1b0)][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1d5)]),_0x338f6d[_0x8a6f36(0x1b0)][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1d5)]));_0x5e20fe&&_0x5e20fe[_0x8a6f36(0x1c6)][_0x8a6f36(0x1c3)]===0x2&&(_0x333b73[_0x8a6f36(0x1b0)][_0x8a6f36(0x1dd)](_0x8a6f36(0x1ab)),_0x338f6d[_0x8a6f36(0x1b0)]['push']('TexCoord2'));Cesium[_0x8a6f36(0x1d7)](_0x1d78ef[_0x8a6f36(0x1ae)])&&(_0x333b73['defines'][_0x8a6f36(0x1dd)](_0x8a6f36(0x1bf)),_0x338f6d['defines'][_0x8a6f36(0x1dd)]('TexCoord'));_0x1c8339['instanceIndex']>-0x1&&_0x333b73['defines'][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1c2)]);_0x1c8339[_0x8a6f36(0x1c7)]===_0x526c05['BIM']&&_0x333b73[_0x8a6f36(0x1b0)][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1cb)]);_0x1c8339['instanceMode']===_0x526c05[_0x8a6f36(0x1af)]&&_0x333b73[_0x8a6f36(0x1b0)][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1bd)]);if(Cesium[_0x8a6f36(0x1d7)](_0x1c8339[_0x8a6f36(0x1bc)])){let _0x255e16=_0x1c8339[_0x8a6f36(0x1bc)];(_0x255e16&_0x6ea6a9[_0x8a6f36(0x1ce)])===_0x6ea6a9[_0x8a6f36(0x1ce)]&&_0x333b73['defines']['push'](_0x3ec161[_0x8a6f36(0x1c9)]),(_0x255e16&_0x6ea6a9['SVC_Normal'])===_0x6ea6a9[_0x8a6f36(0x1a9)]&&_0x333b73[_0x8a6f36(0x1b0)][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1d0)]),(_0x255e16&_0x6ea6a9['SVC_VertexColor'])===_0x6ea6a9[_0x8a6f36(0x1ca)]&&_0x333b73[_0x8a6f36(0x1b0)][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1a6)]),(_0x255e16&_0x6ea6a9['SVC_TexutreCoord'])===_0x6ea6a9[_0x8a6f36(0x1cc)]&&_0x333b73[_0x8a6f36(0x1b0)][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1d2)]);}_0x1c8339[_0x8a6f36(0x1d6)]&&_0x1d78ef[_0x8a6f36(0x1bf)]&&_0x333b73[_0x8a6f36(0x1b0)][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1e1)]),_0x42b44e['_enableClip']&&_0x338f6d[_0x8a6f36(0x1b0)][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1b8)]),_0x42b44e[_0x8a6f36(0x1d4)]&&_0x338f6d['defines'][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1be)]),_0x42b44e['_hypsometric'][_0x8a6f36(0x1e0)]&&(_0x333b73[_0x8a6f36(0x1b0)][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1b4)]),_0x338f6d[_0x8a6f36(0x1b0)][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1b4)])),_0x42b44e['_flattenPar'][_0x8a6f36(0x1db)]&&_0x333b73[_0x8a6f36(0x1b0)][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1d3)]),_0x42b44e['swipeEnabled']&&_0x338f6d[_0x8a6f36(0x1b0)][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1a4)]),_0x1c8339[_0x8a6f36(0x1d6)]&&_0x1d78ef[_0x8a6f36(0x1ae)]&&_0x333b73[_0x8a6f36(0x1b0)][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1e1)]),_0x5e20fe[_0x8a6f36(0x1cf)]&&(_0x333b73[_0x8a6f36(0x1b0)][_0x8a6f36(0x1dd)](_0x3ec161['TextureAtlas']),_0x338f6d[_0x8a6f36(0x1b0)][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1d1)])),_0x5e20fe[_0x8a6f36(0x1b9)]&&(_0x333b73[_0x8a6f36(0x1b0)][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1c8)]),_0x338f6d['defines'][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1c8)])),Cesium[_0x8a6f36(0x1d7)](_0x1febfc[_0x8a6f36(0x1e2)])&&_0x1febfc[_0x8a6f36(0x1e2)][_0x8a6f36(0x1c3)]>0x0&&_0x1febfc[_0x8a6f36(0x1e2)][0x0]['primitiveType']===0x2&&_0x338f6d[_0x8a6f36(0x1b0)][_0x8a6f36(0x1dd)](_0x3ec161[_0x8a6f36(0x1a3)]),_0x1febfc[_0x8a6f36(0x1ad)]=Cesium[_0x8a6f36(0x1c4)]['fromCache']({'context':_0x5530a0,'vertexShaderSource':_0x333b73,'fragmentShaderSource':_0x338f6d,'attributeLocations':_0x1d78ef});};

    const _0x108e=['1771361vNutTz','5SlEmuW','3biXsHN','2514718wHLadU','1dyazEB','1966595zlmBlH','1ThqZtz','878499GvFjVP','306463xFEehH','1jZWOPy','freeze','1869869aAPoeM','279387bLioaN'];const _0x4ce3ca=_0x4c02;(function(_0x3d34d1,_0x34f7ef){const _0x250511=_0x4c02;while(!![]){try{const _0x55c3c4=parseInt(_0x250511(0x131))*parseInt(_0x250511(0x132))+-parseInt(_0x250511(0x130))*parseInt(_0x250511(0x12c))+parseInt(_0x250511(0x128))*parseInt(_0x250511(0x12a))+-parseInt(_0x250511(0x134))*-parseInt(_0x250511(0x12e))+-parseInt(_0x250511(0x12d))*-parseInt(_0x250511(0x12b))+-parseInt(_0x250511(0x133))+-parseInt(_0x250511(0x12f));if(_0x55c3c4===_0x34f7ef)break;else _0x3d34d1['push'](_0x3d34d1['shift']());}catch(_0x302a80){_0x3d34d1['push'](_0x3d34d1['shift']());}}}(_0x108e,0xf1432));function _0x4c02(_0x286b2f,_0x44bf38){_0x286b2f=_0x286b2f-0x128;let _0x108ee6=_0x108e[_0x286b2f];return _0x108ee6;}const OperationType={'RESET':0x0,'SetColor':0x1,'SELECTED':0x2,'HIDE':0x4,'OFFSET':0x8,'CLIP':0x10,'BLOOM':0x20,'ALL':0xff};var _0x594bc2 = Object[_0x4ce3ca(0x129)](OperationType);

    const _0x3d0a=['2CIgdmM','ComponentDatatype','set','TRANSPARENT','remove','throwInstantiationError','boundingVolume','swipe','instanceIndex','instanceIds','selectionInfoMap','instanceCount','vertexAttributes','APPLY_SWIPE','setBatchedAttribute','batchId','invGeoMatrix','toBytes','FLATTEN','clone','shaderProgramToCreate','_objsVisibleList','attributeLocations','attrLocation','geoName','push','center','get','2qIAhUL','CLIP','BatchTable','206783XtzmUi','BUFFER','material','DeveloperError','color','_objsHideList','PROGRAM','ALL','CLIPPLANE','UNSIGNED_BYTE','lerp','RESET','alpha','length','490DqZiuW','s3m_batchTable_color','ready','_objsColorList','distance','29669avvKoZ','vertexShaderSource','createBoundingBoxForInstance','instanceBounds','dequeue','263160fVbmeI','hasOwnProperty','pickColorIdentifier','ShaderProgram','clip','HYPSOMETRIC','createBuffers','17564dRPYXB','arrIndexPackage','Cartesian4','_allObjsHide','shaderProgram','layer','45hkpopf','execute','fromCache','keys','1BWzRUY','colorCommand','indexBufferToCreate','operationValue','dirty','context','peek','JobType','fragmentShaderSource','Matrix4','inverse','jobScheduler','_objsOperationList','edgeGeometry','green','137848jJuvnk','78049OTcgcB','createPickIds','floatToByte','updateObjsOperation','idsColorMap','s3m_batchTable_pickColor','Queue','AssociativeArray','pickInfo','values','indexOf','HIDE','geoMatrix','red','defines','Cartesian3','enable','updateObjsColor','splice','idsOperationMap','updateBatchTableAttributes','modelMatrix','Color','batchTable','enqueue','vertexPackage','map','prototype','vertexBufferToCreate','useWValue','batchTableDirty','destroy','contains','updateAllObjsVisible','defaultValue','s3m_batchTable_operation','_hash','createCommand','defined'];const _0x471528=_0xd895;(function(_0x18bbfc,_0x47ea3b){const _0x429c48=_0xd895;while(!![]){try{const _0x2a67d4=-parseInt(_0x429c48(0x1c2))*parseInt(_0x429c48(0x22b))+parseInt(_0x429c48(0x237))+parseInt(_0x429c48(0x1d2))*-parseInt(_0x429c48(0x1f9))+parseInt(_0x429c48(0x23d))*-parseInt(_0x429c48(0x226))+parseInt(_0x429c48(0x215))*parseInt(_0x429c48(0x1d1))+-parseInt(_0x429c48(0x218))+parseInt(_0x429c48(0x230));if(_0x2a67d4===_0x47ea3b)break;else _0x18bbfc['push'](_0x18bbfc['shift']());}catch(_0x192b28){_0x18bbfc['push'](_0x18bbfc['shift']());}}}(_0x3d0a,0x229fc));function RenderEntity(_0xdc22e8){const _0x457658=_0xd895;this[_0x457658(0x23c)]=_0xdc22e8[_0x457658(0x23c)],this[_0x457658(0x1eb)]=_0xdc22e8['vertexPackage'],this[_0x457658(0x238)]=_0xdc22e8[_0x457658(0x238)],this['vertexBufferToCreate']=new Cesium['Queue'](),this[_0x457658(0x1c4)]=new Cesium[(_0x457658(0x1d8))](),this['shaderProgramToCreate']=new Cesium['Queue']();let _0x4b3075,_0x1c234e;for(_0x4b3075=0x0,_0x1c234e=this['vertexPackage'][_0x457658(0x205)]['length'];_0x4b3075<_0x1c234e;_0x4b3075++){this[_0x457658(0x1ee)][_0x457658(0x1ea)](_0x4b3075);}for(_0x4b3075=0x0,_0x1c234e=this['arrIndexPackage'][_0x457658(0x225)];_0x4b3075<_0x1c234e;_0x4b3075++){this[_0x457658(0x1c4)][_0x457658(0x1ea)](_0x4b3075);}this[_0x457658(0x20d)][_0x457658(0x1ea)](0x0),this[_0x457658(0x1ff)]=_0xdc22e8[_0x457658(0x1ff)],this[_0x457658(0x21a)]=Cesium[_0x457658(0x1f4)](_0xdc22e8['material'],new MaterialPass()),this[_0x457658(0x211)]=_0xdc22e8[_0x457658(0x211)],this[_0x457658(0x1e7)]=_0xdc22e8[_0x457658(0x1e7)],this[_0x457658(0x1de)]=_0xdc22e8[_0x457658(0x1de)],this[_0x457658(0x209)]=Cesium[_0x457658(0x1cb)][_0x457658(0x1cc)](this['geoMatrix'],new Cesium[(_0x457658(0x1cb))]()),this[_0x457658(0x204)]=_0xdc22e8[_0x457658(0x1eb)][_0x457658(0x204)],this['attributeLocations']=_0xdc22e8['vertexPackage'][_0x457658(0x210)],this[_0x457658(0x23b)]=undefined,this['vertexArray']=undefined,this[_0x457658(0x1c3)]=undefined,this['pickInfo']=_0xdc22e8['pickInfo'],this[_0x457658(0x203)]=new Cesium['AssociativeArray'](),this[_0x457658(0x1e9)]=undefined,this['batchTableDirty']=![],this[_0x457658(0x232)]='vSecondColor',this[_0x457658(0x1e5)]=new Cesium[(_0x457658(0x1d9))](),this[_0x457658(0x1d6)]=new Cesium['AssociativeArray'](),this[_0x457658(0x1ef)]=_0xdc22e8[_0x457658(0x1eb)][_0x457658(0x205)][0x0]['componentsPerAttribute']===0x4,this[_0x457658(0x1cf)]=_0xdc22e8['edgeGeometry'],this[_0x457658(0x22d)](),this[_0x457658(0x228)]=![];}function _0xd895(_0x4897da,_0x335c96){_0x4897da=_0x4897da-0x1c0;let _0x3d0a87=_0x3d0a[_0x4897da];return _0x3d0a87;}const _vertexBufferJob=new S3MCreateVertexJob(),_indexBufferJob=new S3MCreateIndexBufferJob(),_shaderProgramJob=new S3MCreateShaderProgramJob();function createVertexBuffers(_0x44c9ed,_0x20ea87){const _0x47ed7b=_0xd895;let _0x4f18a0=_0x44c9ed[_0x47ed7b(0x23c)][_0x47ed7b(0x1c7)],_0x56bda0=_0x44c9ed[_0x47ed7b(0x1ee)];while(_0x56bda0[_0x47ed7b(0x225)]){let _0x3b47d1=_0x56bda0[_0x47ed7b(0x1c8)]();_vertexBufferJob[_0x47ed7b(0x1fb)](_0x4f18a0,_0x44c9ed,_0x3b47d1);if(!_0x20ea87[_0x47ed7b(0x1cd)][_0x47ed7b(0x23e)](_vertexBufferJob,Cesium['JobType'][_0x47ed7b(0x219)]))break;_0x56bda0['dequeue']();}}function createIndexBuffers(_0x15a2ee,_0x1c3e7c){const _0x372ab3=_0xd895;let _0x2709d5=_0x15a2ee['layer'][_0x372ab3(0x1c7)],_0x3761b8=_0x15a2ee['indexBufferToCreate'];while(_0x3761b8[_0x372ab3(0x225)]){let _0x16e002=_0x3761b8['peek']();_indexBufferJob['set'](_0x2709d5,_0x15a2ee,_0x16e002);if(!_0x1c3e7c[_0x372ab3(0x1cd)][_0x372ab3(0x23e)](_indexBufferJob,Cesium['JobType'][_0x372ab3(0x219)]))break;_0x3761b8[_0x372ab3(0x22f)]();}}function createShaderProgram(_0x3ce257,_0x10fe1f){const _0x371aea=_0xd895;let _0x1ec281=_0x3ce257[_0x371aea(0x23c)][_0x371aea(0x1c7)],_0x46018d=_0x3ce257[_0x371aea(0x20d)];while(_0x46018d['length']){let _0x16a166=_0x46018d[_0x371aea(0x1c8)]();_shaderProgramJob[_0x371aea(0x1fb)](_0x1ec281,_0x3ce257);if(!_0x10fe1f[_0x371aea(0x1cd)][_0x371aea(0x23e)](_shaderProgramJob,Cesium[_0x371aea(0x1c9)][_0x371aea(0x21e)]))break;_0x46018d[_0x371aea(0x22f)]();}}function createBatchTable(_0x571abd,_0x5e1b52){const _0x3afec4=_0xd895;if(Cesium[_0x3afec4(0x1f8)](_0x571abd['batchTable'])||!_0x571abd[_0x3afec4(0x1da)])return;const _0x3b7dff=_0x571abd[_0x3afec4(0x23c)]['context'];let _0xd2284c=[];_0xd2284c[_0x3afec4(0x212)]({'functionName':_0x3afec4(0x227),'componentDatatype':Cesium[_0x3afec4(0x1fa)][_0x3afec4(0x221)],'componentsPerAttribute':0x4,'normalize':!![]},{'functionName':_0x3afec4(0x1f5),'componentDatatype':Cesium[_0x3afec4(0x1fa)][_0x3afec4(0x221)],'componentsPerAttribute':0x4},{'functionName':_0x3afec4(0x1d7),'componentDatatype':Cesium['ComponentDatatype']['UNSIGNED_BYTE'],'componentsPerAttribute':0x4,'normalize':!![]});let _0x4bacd6=_0x571abd[_0x3afec4(0x1da)],_0x5adf45=Object['keys'](_0x4bacd6),_0x142537=_0x571abd['instanceCount']>0x0?_0x571abd[_0x3afec4(0x204)]:_0x5adf45[_0x3afec4(0x225)];_0x571abd[_0x3afec4(0x1e9)]=new Cesium[(_0x3afec4(0x217))](_0x3b7dff,_0xd2284c,_0x142537);}RenderEntity[_0x471528(0x1ed)][_0x471528(0x236)]=function(_0x336ee4){createVertexBuffers(this,_0x336ee4),createIndexBuffers(this,_0x336ee4);},RenderEntity[_0x471528(0x1ed)]['createShaderProgram']=function(_0x446f57){createShaderProgram(this,_0x446f57);},RenderEntity['prototype']['createBatchTable']=function(_0x5e01e1){createBatchTable(this);};let scratchPntCenter=new Cesium[(_0x471528(0x1e1))]();RenderEntity[_0x471528(0x1ed)][_0x471528(0x22d)]=function(){const _0x288539=_0x471528,_0x12d2fc=this[_0x288539(0x1eb)];if(!Cesium['defined'](_0x12d2fc)||_0x12d2fc[_0x288539(0x201)]===-0x1||!Cesium[_0x288539(0x1f8)](_0x12d2fc[_0x288539(0x22e)]))return;let _0x8495c4=_0x12d2fc[_0x288539(0x22e)],_0x1fe270=new Cesium[(_0x288539(0x1e1))](_0x8495c4[0x0],_0x8495c4[0x1],_0x8495c4[0x2]),_0xe11439=new Cesium['Cartesian3'](_0x8495c4[0x3],_0x8495c4[0x4],_0x8495c4[0x5]),_0x2946fc=Cesium[_0x288539(0x1e1)][_0x288539(0x222)](_0x1fe270,_0xe11439,0.5,scratchPntCenter),_0x387a84=Cesium[_0x288539(0x1e1)][_0x288539(0x22a)](_0x2946fc,_0x1fe270),_0x3a1a09=new Cesium[(_0x288539(0x1e1))]();Cesium[_0x288539(0x1cb)]['multiplyByPoint'](this[_0x288539(0x1e7)],_0x2946fc,_0x3a1a09),this['boundingVolume'][_0x288539(0x213)]=_0x3a1a09,this[_0x288539(0x1ff)]['radius']=_0x387a84,_0x12d2fc[_0x288539(0x22e)]=undefined;};let cartesian4Scratch=new Cesium[(_0x471528(0x239))]();RenderEntity[_0x471528(0x1ed)][_0x471528(0x1d3)]=function(){const _0x5966b4=_0x471528,_0x5a8793=this['layer'],_0x268bd9=_0x5a8793[_0x5966b4(0x1c7)],_0x45103f=this[_0x5966b4(0x1da)];if(!Cesium[_0x5966b4(0x1f8)](_0x45103f))return;for(let _0x5422a3 in _0x45103f){if(!_0x45103f['hasOwnProperty'](_0x5422a3))continue;this[_0x5966b4(0x203)][_0x5966b4(0x1fb)](_0x5422a3,_0x45103f[_0x5422a3]);}let _0x474b93=this[_0x5966b4(0x1e9)],_0x1f8c26=this[_0x5966b4(0x203)],_0xfb93d9=_0x1f8c26[_0x5966b4(0x1f6)];for(let _0x8528dc in _0xfb93d9){if(_0xfb93d9[_0x5966b4(0x231)](_0x8528dc)){let _0x4923d2=_0x1f8c26[_0x5966b4(0x214)](_0x8528dc),_0x543369;!Cesium[_0x5966b4(0x1f8)](_0x543369)&&(_0x543369=_0x268bd9['createPickId']({'primitive':_0x5a8793,'id':_0x8528dc}));let _0x1e383d=_0x543369['color'];cartesian4Scratch['x']=Cesium[_0x5966b4(0x1e8)]['floatToByte'](_0x1e383d[_0x5966b4(0x1df)]),cartesian4Scratch['y']=Cesium['Color'][_0x5966b4(0x1d4)](_0x1e383d[_0x5966b4(0x1d0)]),cartesian4Scratch['z']=Cesium['Color'][_0x5966b4(0x1d4)](_0x1e383d['blue']),cartesian4Scratch['w']=Cesium[_0x5966b4(0x1e8)][_0x5966b4(0x1d4)](_0x1e383d[_0x5966b4(0x224)]);let _0x3cb96d=_0x4923d2['instanceIds'];if(this[_0x5966b4(0x204)]>0x0)_0x3cb96d[_0x5966b4(0x1ec)](function(_0x8fa985){const _0x1c54cf=_0x5966b4;_0x474b93[_0x1c54cf(0x207)](_0x8fa985,0x2,cartesian4Scratch);});else {let _0x5c236e=_0x4923d2[0x0][_0x5966b4(0x208)];_0x474b93[_0x5966b4(0x207)](_0x5c236e,0x2,cartesian4Scratch);}}}this[_0x5966b4(0x1da)]=undefined;},RenderEntity[_0x471528(0x1ed)]['initLayerSetting']=function(_0x5b1883){const _0x1af74a=_0x471528;_0x5b1883[_0x1af74a(0x23a)]&&this[_0x1af74a(0x1f3)](!_0x5b1883['_allObjsHide']),Object[_0x1af74a(0x1c1)](_0x5b1883[_0x1af74a(0x229)])[_0x1af74a(0x225)]>0x0&&this[_0x1af74a(0x1e3)](_0x5b1883['_objsColorList']),_0x5b1883[_0x1af74a(0x1ce)][_0x1af74a(0x225)]>0x0&&this[_0x1af74a(0x1d5)](_0x5b1883[_0x1af74a(0x1ce)]);},RenderEntity[_0x471528(0x1ed)][_0x471528(0x1e6)]=function(){const _0x5eca80=_0x471528;let _0x209f34=this,_0x26677c=this['idsColorMap'],_0x296614=[];for(let _0x3fe3d1=0x0,_0x2e8a96=_0x26677c[_0x5eca80(0x225)];_0x3fe3d1<_0x2e8a96;_0x3fe3d1++){let _0x2ba846=_0x26677c['values'][_0x3fe3d1];if(!_0x2ba846[_0x5eca80(0x1c6)])continue;_0x2ba846[_0x5eca80(0x1c6)]=![],_0x296614=_0x2ba846[_0x5eca80(0x21c)][_0x5eca80(0x20a)](),cartesian4Scratch['x']=_0x296614[0x0],cartesian4Scratch['y']=_0x296614[0x1],cartesian4Scratch['z']=_0x296614[0x2],cartesian4Scratch['w']=_0x296614[0x3];if(Cesium[_0x5eca80(0x1f8)](_0x2ba846[_0x5eca80(0x208)]))this[_0x5eca80(0x1e9)][_0x5eca80(0x207)](_0x2ba846['batchId'],0x0,cartesian4Scratch);else Array['isArray'](_0x2ba846[_0x5eca80(0x202)])&&_0x2ba846[_0x5eca80(0x202)][_0x5eca80(0x1ec)](function(_0x2253c4){const _0x5a050d=_0x5eca80;_0x209f34[_0x5a050d(0x1e9)][_0x5a050d(0x207)](_0x2253c4,0x0,cartesian4Scratch);});}let _0x3aa961=this[_0x5eca80(0x1e5)];for(let _0x3f7c57=0x0,_0x47c500=_0x3aa961[_0x5eca80(0x225)];_0x3f7c57<_0x47c500;_0x3f7c57++){let _0x25839c=_0x3aa961[_0x5eca80(0x1db)][_0x3f7c57];if(!_0x25839c[_0x5eca80(0x1c6)])continue;_0x25839c['dirty']=![],this[_0x5eca80(0x204)]>0x0?Array['isArray'](_0x25839c[_0x5eca80(0x202)])&&_0x25839c[_0x5eca80(0x202)][_0x5eca80(0x1ec)](function(_0x580aea){const _0x529892=_0x5eca80;_0x209f34['batchTable'][_0x529892(0x207)](_0x580aea,0x1,_0x25839c[_0x529892(0x1c5)]);}):Cesium[_0x5eca80(0x1f8)](_0x25839c[_0x5eca80(0x208)])&&this[_0x5eca80(0x1e9)][_0x5eca80(0x207)](_0x25839c[_0x5eca80(0x208)],0x1,_0x25839c[_0x5eca80(0x1c5)]);}},RenderEntity['prototype'][_0x471528(0x1e3)]=function(_0x5dd550){const _0x45332c=_0x471528;if(!this[_0x45332c(0x228)]||this[_0x45332c(0x203)][_0x45332c(0x225)]<0x1)return;let _0xd61104=this[_0x45332c(0x203)][_0x45332c(0x1f6)];for(let _0x50631c in _0xd61104){if(!_0xd61104['hasOwnProperty'](_0x50631c))continue;let _0x39c912=_0x5dd550[_0x50631c];if(!Cesium[_0x45332c(0x1f8)](_0x39c912))continue;let _0x107ca9=_0xd61104[_0x50631c][0x0];const _0x46f048=_0x107ca9['batchId'],_0x1aa72b=_0x107ca9[_0x45332c(0x202)];this[_0x45332c(0x1d6)][_0x45332c(0x1fb)](_0x50631c,{'batchId':_0x46f048,'instanceIds':_0x1aa72b,'color':_0x39c912,'dirty':!![]});let _0x3b1eda=this['idsOperationMap'][_0x45332c(0x214)](_0x50631c);!Cesium['defined'](_0x3b1eda)&&(_0x3b1eda={'batchId':_0x46f048,'instanceIds':_0x1aa72b,'operationValue':new Cesium['Cartesian4'](),'dirty':!![]}),_0x3b1eda[_0x45332c(0x1c6)]=!![],_0x3b1eda[_0x45332c(0x1c5)]['x']=_0x39c912===Cesium[_0x45332c(0x1e8)][_0x45332c(0x1fc)]?_0x3b1eda[_0x45332c(0x1c5)]['x']&0xfe:_0x3b1eda[_0x45332c(0x1c5)]['x']|0x1,this['idsOperationMap'][_0x45332c(0x1fb)](_0x50631c,_0x3b1eda),this[_0x45332c(0x1f0)]=!![];}},RenderEntity[_0x471528(0x1ed)]['updateObjsOperation']=function(_0x466115){const _0x37ea40=_0x471528;if(!this['ready']||this[_0x37ea40(0x203)][_0x37ea40(0x225)]<0x1)return;let _0x4399d6=this[_0x37ea40(0x203)][_0x37ea40(0x1f6)];for(let _0xa04bdb in _0x4399d6){if(!_0x4399d6[_0x37ea40(0x231)](_0xa04bdb))continue;if(!_0x466115[_0x37ea40(0x1f2)](_0xa04bdb))continue;let _0x22bc6c=_0x4399d6[_0xa04bdb][0x0],_0x469054=_0x22bc6c[_0x37ea40(0x208)],_0x2990cf=_0x22bc6c[_0x37ea40(0x202)],_0x519d46=_0x466115[_0x37ea40(0x214)](_0xa04bdb),_0x3b5882=this['idsOperationMap'][_0x37ea40(0x214)](_0xa04bdb);!Cesium[_0x37ea40(0x1f8)](_0x3b5882)&&(_0x3b5882={'batchId':_0x469054,'instanceIds':_0x2990cf,'operationValue':new Cesium[(_0x37ea40(0x239))](),'dirty':!![]}),_0x3b5882[_0x37ea40(0x1c6)]=!![],_0x3b5882['operationValue']['x']=_0x3b5882[_0x37ea40(0x1c5)]['x']&0x1|_0x519d46,this[_0x37ea40(0x1e5)]['set'](_0xa04bdb,_0x3b5882),this[_0x37ea40(0x1f0)]=!![];}},RenderEntity['prototype'][_0x471528(0x1f3)]=function(_0x2b4a84){const _0x478359=_0x471528;if(!this[_0x478359(0x228)]||this[_0x478359(0x203)]['length']<0x1)return;let _0x5adfa0=this[_0x478359(0x23c)],_0xa0dd9a=this[_0x478359(0x203)]['_hash'];for(let _0x1d6fb9 in _0xa0dd9a){if(!_0xa0dd9a[_0x478359(0x231)](_0x1d6fb9))continue;if(_0x5adfa0[_0x478359(0x20e)][_0x478359(0x1f2)](_0x1d6fb9))continue;let _0x55d031=_0xa0dd9a[_0x1d6fb9][0x0],_0x31ef16=_0x55d031[_0x478359(0x208)],_0x2c6c4a=_0x55d031[_0x478359(0x202)],_0x2456fd=this['idsOperationMap'][_0x478359(0x214)](_0x1d6fb9);!Cesium[_0x478359(0x1f8)](_0x2456fd)&&(_0x2456fd={'batchId':_0x31ef16,'instanceIds':_0x2c6c4a,'operationValue':new Cesium[(_0x478359(0x239))](),'dirty':!![]}),_0x2456fd['dirty']=!![],_0x2b4a84?_0x2456fd[_0x478359(0x1c5)]['x']=_0x2456fd[_0x478359(0x1c5)]['x']&(_0x594bc2[_0x478359(0x21f)]^_0x594bc2[_0x478359(0x1dd)]):_0x2456fd['operationValue']['x']=_0x2456fd['operationValue']['x']|_0x594bc2[_0x478359(0x1dd)],this[_0x478359(0x1e5)][_0x478359(0x1fb)](_0x1d6fb9,_0x2456fd),_0x2456fd[_0x478359(0x1c5)]['x']===_0x594bc2[_0x478359(0x223)]?_0x5adfa0[_0x478359(0x1ce)][_0x478359(0x1fd)](_0x1d6fb9):(_0x5adfa0[_0x478359(0x1ce)][_0x478359(0x1fb)](_0x1d6fb9,_0x2456fd['operationValue']['x']),_0x5adfa0[_0x478359(0x21d)][_0x478359(0x1fb)](_0x1d6fb9,!![])),this[_0x478359(0x1f0)]=!![];}};function removeDefine(_0x3e2c0f,_0x4cbddd){const _0x2039c7=_0x471528;let _0x7b6c95=_0x3e2c0f[_0x2039c7(0x1e0)]['indexOf'](_0x4cbddd);_0x7b6c95>=0x0&&_0x3e2c0f[_0x2039c7(0x1e0)][_0x2039c7(0x1e4)](_0x7b6c95,0x1);}RenderEntity[_0x471528(0x1ed)][_0x471528(0x234)]=function(_0x5a21b6){const _0x405cbf=_0x471528;if(!this['ready'])return;let _0x2d2254=this[_0x405cbf(0x23b)][_0x405cbf(0x22c)][_0x405cbf(0x20c)](),_0x2cfc53=this[_0x405cbf(0x23b)][_0x405cbf(0x1ca)]['clone'](),_0x51a595=this[_0x405cbf(0x20f)];_0x5a21b6['enable']?_0x2cfc53[_0x405cbf(0x1e0)]['indexOf'](_0x3ec161[_0x405cbf(0x216)])===-0x1&&_0x2cfc53['defines'][_0x405cbf(0x212)](_0x3ec161['CLIP']):removeDefine(_0x2cfc53,_0x3ec161[_0x405cbf(0x216)]),this[_0x405cbf(0x23c)]['_enableClipPlane']?_0x2cfc53[_0x405cbf(0x1e0)][_0x405cbf(0x1dc)](_0x3ec161[_0x405cbf(0x220)])===-0x1&&_0x2cfc53[_0x405cbf(0x1e0)][_0x405cbf(0x212)](_0x3ec161[_0x405cbf(0x220)]):removeDefine(_0x2cfc53,_0x3ec161['CLIPPLANE']),this['shaderProgram'][_0x405cbf(0x1f1)](),this['shaderProgram']=Cesium[_0x405cbf(0x233)][_0x405cbf(0x1c0)]({'context':this[_0x405cbf(0x23c)]['context'],'vertexShaderSource':_0x2d2254,'fragmentShaderSource':_0x2cfc53,'attributeLocations':_0x51a595}),this[_0x405cbf(0x1c3)][_0x405cbf(0x23b)]=this[_0x405cbf(0x23b)];},RenderEntity[_0x471528(0x1ed)]['hypsometric']=function(_0x395bcd){const _0x3be744=_0x471528;if(!this[_0x3be744(0x228)])return;let _0x3a5d1a=this[_0x3be744(0x23b)][_0x3be744(0x22c)][_0x3be744(0x20c)](),_0x47e87f=this['shaderProgram'][_0x3be744(0x1ca)][_0x3be744(0x20c)](),_0x5f54e3=this['attributeLocations'];_0x395bcd[_0x3be744(0x1e2)]?(_0x3a5d1a['defines']['indexOf'](_0x3ec161[_0x3be744(0x235)])===-0x1&&_0x3a5d1a[_0x3be744(0x1e0)][_0x3be744(0x212)](_0x3ec161[_0x3be744(0x235)]),_0x47e87f[_0x3be744(0x1e0)]['indexOf'](_0x3ec161[_0x3be744(0x235)])===-0x1&&_0x47e87f[_0x3be744(0x1e0)]['push'](_0x3ec161['HYPSOMETRIC'])):removeDefine(_0x47e87f,_0x3ec161['HYPSOMETRIC']),this[_0x3be744(0x23b)][_0x3be744(0x1f1)](),this[_0x3be744(0x23b)]=Cesium[_0x3be744(0x233)][_0x3be744(0x1c0)]({'context':this['layer'][_0x3be744(0x1c7)],'vertexShaderSource':_0x3a5d1a,'fragmentShaderSource':_0x47e87f,'attributeLocations':_0x5f54e3}),this[_0x3be744(0x1c3)][_0x3be744(0x23b)]=this[_0x3be744(0x23b)];},RenderEntity[_0x471528(0x1ed)][_0x471528(0x200)]=function(_0x557873){const _0x972c4f=_0x471528;if(!this[_0x972c4f(0x228)])return;let _0x1dcead=this[_0x972c4f(0x23b)][_0x972c4f(0x22c)][_0x972c4f(0x20c)](),_0x510ab2=this['shaderProgram'][_0x972c4f(0x1ca)][_0x972c4f(0x20c)](),_0x21d81c=this[_0x972c4f(0x20f)];_0x557873[_0x972c4f(0x1e2)]?_0x510ab2[_0x972c4f(0x1e0)][_0x972c4f(0x1dc)](_0x3ec161[_0x972c4f(0x206)])===-0x1&&_0x510ab2[_0x972c4f(0x1e0)][_0x972c4f(0x212)](_0x3ec161[_0x972c4f(0x206)]):removeDefine(_0x510ab2,_0x3ec161['APPLY_SWIPE']),this[_0x972c4f(0x23b)]['destroy'](),this['shaderProgram']=Cesium['ShaderProgram'][_0x972c4f(0x1c0)]({'context':this[_0x972c4f(0x23c)][_0x972c4f(0x1c7)],'vertexShaderSource':_0x1dcead,'fragmentShaderSource':_0x510ab2,'attributeLocations':_0x21d81c}),this[_0x972c4f(0x1c3)][_0x972c4f(0x23b)]=this[_0x972c4f(0x23b)];},RenderEntity[_0x471528(0x1ed)]['flatten']=function(_0x49eecb){const _0x3d6bff=_0x471528;if(!this[_0x3d6bff(0x228)])return;let _0x5d67e2=this[_0x3d6bff(0x23b)]['vertexShaderSource'][_0x3d6bff(0x20c)](),_0x6dc6a2=this[_0x3d6bff(0x23b)][_0x3d6bff(0x1ca)]['clone'](),_0x4a03b3=this[_0x3d6bff(0x20f)];_0x49eecb['enable']?_0x5d67e2['defines']['indexOf'](_0x3ec161[_0x3d6bff(0x20b)])===-0x1&&_0x5d67e2[_0x3d6bff(0x1e0)][_0x3d6bff(0x212)](_0x3ec161[_0x3d6bff(0x20b)]):removeDefine(_0x5d67e2,_0x3ec161[_0x3d6bff(0x20b)]),this[_0x3d6bff(0x23b)][_0x3d6bff(0x1f1)](),this[_0x3d6bff(0x23b)]=Cesium['ShaderProgram']['fromCache']({'context':this[_0x3d6bff(0x23c)]['context'],'vertexShaderSource':_0x5d67e2,'fragmentShaderSource':_0x6dc6a2,'attributeLocations':_0x4a03b3}),this[_0x3d6bff(0x1c3)]['shaderProgram']=this['shaderProgram'];},RenderEntity[_0x471528(0x1ed)][_0x471528(0x1f7)]=Cesium[_0x471528(0x21b)][_0x471528(0x1fe)],RenderEntity[_0x471528(0x1ed)]['update']=Cesium[_0x471528(0x21b)][_0x471528(0x1fe)],RenderEntity[_0x471528(0x1ed)]['isDestroyed']=Cesium[_0x471528(0x21b)][_0x471528(0x1fe)],RenderEntity['prototype'][_0x471528(0x1f1)]=Cesium['DeveloperError'][_0x471528(0x1fe)];

    const _0xf6eb=['vertexAttributes','LineInterval','16831fYiROf','pickInfo','setting','ColorTableMaxKey','ColorTableMinKey','bTransparentSorting','shaderProgram','451vcRfND','BlendingState','textures','vertexArray','length','commandList','VertexArray','DisplayMode','shaderProgramToCreate','createShaderProgram','colorCommand','selectionInfoMap','TRANSLUCENT','Cartesian4','material','_flattenPar','noValueColor','fromCache','ALPHA_BLEND','clone','geoMatrix','width','OPAQUE','createCommand','texture','DepthFunction','drawingBufferWidth','invGeoMatrix','168101coUVZS','MaxVisibleValue','update','35414fatGKc','primitiveType','destroy','drawingBufferHeight','indexBufferToCreate','_hypsometric','743272hfNvqy','349ruyFXG','_swipeRegion','ready','prototype','create','isDestroyed','11dZixpS','bounds','arrIndexPackage','defined','initLayerSetting','vertexBufferToCreate','createBuffers','63287XfXhrZ','context','_clipPlane','vertexPackage','constructor','layer','1qdgLvU','modelMatrix','Pass','LineColor','uniformMap','push','destroyObject','31794DIyMdm'];const _0x815777=_0x4d98;(function(_0x201328,_0xe41dea){const _0x1dbad5=_0x4d98;while(!![]){try{const _0xadadf5=parseInt(_0x1dbad5(0xd0))*-parseInt(_0x1dbad5(0x9d))+-parseInt(_0x1dbad5(0x9a))+-parseInt(_0x1dbad5(0xc0))+-parseInt(_0x1dbad5(0xd7))+-parseInt(_0x1dbad5(0xc3))*parseInt(_0x1dbad5(0x93))+parseInt(_0x1dbad5(0xa4))*-parseInt(_0x1dbad5(0xca))+parseInt(_0x1dbad5(0xc9));if(_0xadadf5===_0xe41dea)break;else _0x201328['push'](_0x201328['shift']());}catch(_0x41ee86){_0x201328['push'](_0x201328['shift']());}}}(_0xf6eb,0x18ef8));function S3MObliqueRenderEntity(_0x5d7ceb){RenderEntity['call'](this,_0x5d7ceb),this['vs']=_0x56dd48,this['fs']=_0x6b1656;}S3MObliqueRenderEntity[_0x815777(0xcd)]=Object[_0x815777(0xce)](RenderEntity[_0x815777(0xcd)]),S3MObliqueRenderEntity['prototype'][_0x815777(0x91)]=RenderEntity;function getOpaqueRenderState(){const _0x18567d=_0x815777;return Cesium['RenderState'][_0x18567d(0xb5)]({'cull':{'enabled':!![]},'depthTest':{'enabled':!![],'func':Cesium[_0x18567d(0xbd)]['LESS_OR_EQUAL']},'blending':Cesium[_0x18567d(0xa5)][_0x18567d(0xb6)]});}let hypMinMaxValueScratch=new Cesium[(_0x815777(0xb1))](),hypOpacityIntervalFillModeScratch=new Cesium[(_0x815777(0xb1))](),swipRegionScratch=new Cesium[(_0x815777(0xb1))]();function _0x4d98(_0x1fca66,_0x3cbd45){_0x1fca66=_0x1fca66-0x91;let _0xf6eb6=_0xf6eb[_0x1fca66];return _0xf6eb6;}function getUniformMap(_0x5cdbad,_0x3a2cb8,_0x42db74){return {'uGeoMatrix':function(){const _0x5d4780=_0x4d98;return _0x42db74[_0x5d4780(0xb8)];},'uInverseGeoMatrix':function(){const _0x2a08f6=_0x4d98;return _0x42db74[_0x2a08f6(0xbf)];},'uTexture':function(){const _0x4033a1=_0x4d98;return _0x5cdbad[_0x4033a1(0xa6)][0x0];},'uTexture0Width':function(){const _0x3211f3=_0x4d98;return _0x5cdbad[_0x3211f3(0xa6)][0x0][_0x3211f3(0xb9)];},'uClipMode':function(){return _0x3a2cb8['_clipMode'];},'uClipPlanes':function(){const _0x21ab59=_0x4d98;return _0x3a2cb8[_0x21ab59(0xd9)];},'uHypsometricTexture':function(){const _0x29a876=_0x4d98;return _0x3a2cb8['_hypsometric'][_0x29a876(0xbc)];},'uHypLineColor':function(){const _0x2e9ac7=_0x4d98;return _0x3a2cb8[_0x2e9ac7(0xc8)][_0x2e9ac7(0x9f)][_0x2e9ac7(0x96)];},'uNoValueColor':function(){const _0x1fddb9=_0x4d98;return _0x3a2cb8[_0x1fddb9(0xc8)][_0x1fddb9(0x9f)][_0x1fddb9(0xb4)];},'uMinMaxValue':function(){const _0x1384e7=_0x4d98;let _0x28e20e=_0x3a2cb8[_0x1384e7(0xc8)][_0x1384e7(0x9f)];return hypMinMaxValueScratch['x']=_0x28e20e[_0x1384e7(0xa1)],hypMinMaxValueScratch['y']=_0x28e20e[_0x1384e7(0xa0)],hypMinMaxValueScratch['z']=_0x28e20e['MinVisibleValue'],hypMinMaxValueScratch['w']=_0x28e20e[_0x1384e7(0xc1)],hypMinMaxValueScratch;},'uOpacityIntervalFillMode':function(){const _0xa6201f=_0x4d98;let _0x309663=_0x3a2cb8[_0xa6201f(0xc8)][_0xa6201f(0x9f)];return hypOpacityIntervalFillModeScratch['x']=_0x309663['Opacity'],hypOpacityIntervalFillModeScratch['y']=_0x309663[_0xa6201f(0x9c)],hypOpacityIntervalFillModeScratch['z']=_0x309663[_0xa6201f(0xab)],hypOpacityIntervalFillModeScratch;},'uFlattenRect':function(){const _0x36d85e=_0x4d98;return _0x3a2cb8[_0x36d85e(0xb3)][_0x36d85e(0xd1)];},'uFlattenTexture':function(){const _0x36940d=_0x4d98;return _0x3a2cb8[_0x36940d(0xb3)][_0x36940d(0xbc)];},'uSwipeRegion':function(){const _0x30d4a0=_0x4d98,_0x59af79=_0x3a2cb8[_0x30d4a0(0xd8)];return swipRegionScratch['x']=_0x3a2cb8['_swipeRegion']['x']*_0x59af79[_0x30d4a0(0xbe)],swipRegionScratch['y']=(0x1-_0x3a2cb8['_swipeRegion']['y'])*_0x59af79[_0x30d4a0(0xc6)],swipRegionScratch['z']=_0x3a2cb8[_0x30d4a0(0xcb)]['z']*_0x59af79[_0x30d4a0(0xbe)],swipRegionScratch['w']=(0x1-_0x3a2cb8[_0x30d4a0(0xcb)]['w'])*_0x59af79[_0x30d4a0(0xc6)],swipRegionScratch;}};}S3MObliqueRenderEntity[_0x815777(0xcd)]['createCommand']=function(){const _0x25e0fc=_0x815777;if(Cesium[_0x25e0fc(0xd3)](this[_0x25e0fc(0xae)])||this[_0x25e0fc(0xd5)][_0x25e0fc(0xa8)]!==0x0||this[_0x25e0fc(0xc7)][_0x25e0fc(0xa8)]!==0x0||this[_0x25e0fc(0xac)]['length']!==0x0)return;let _0x12412a=this[_0x25e0fc(0x92)],_0x3b3c54=_0x12412a[_0x25e0fc(0xd8)],_0x14569a=this[_0x25e0fc(0xda)],_0x236a9f=this[_0x25e0fc(0xd2)],_0x51b150=_0x14569a[_0x25e0fc(0x9b)];if(_0x236a9f[_0x25e0fc(0xa8)]<0x1)return;let _0x56e3dd=_0x236a9f[0x0],_0x1d5ba9=this[_0x25e0fc(0xb2)];this[_0x25e0fc(0xa7)]=new Cesium[(_0x25e0fc(0xaa))]({'context':_0x3b3c54,'attributes':_0x51b150,'indexBuffer':_0x56e3dd['indexBuffer']}),this[_0x25e0fc(0xae)]=new Cesium['DrawCommand']({'primitiveType':_0x56e3dd[_0x25e0fc(0xc4)],'modelMatrix':this['modelMatrix'],'boundingVolume':Cesium['BoundingSphere'][_0x25e0fc(0xb7)](this['boundingVolume']),'vertexArray':this['vertexArray'],'shaderProgram':this['shaderProgram'],'pass':_0x1d5ba9[_0x25e0fc(0xa2)]?Cesium['Pass'][_0x25e0fc(0xb0)]:Cesium[_0x25e0fc(0x95)][_0x25e0fc(0xba)],'renderState':getOpaqueRenderState(),'instanceCount':_0x14569a['instanceCount']}),this[_0x25e0fc(0xae)][_0x25e0fc(0x97)]=getUniformMap(_0x1d5ba9,_0x12412a,this),this[_0x25e0fc(0xda)]=undefined,this[_0x25e0fc(0xd2)]=undefined,this['vs']=undefined,this['fs']=undefined,this[_0x25e0fc(0xcc)]=!![];},S3MObliqueRenderEntity[_0x815777(0xcd)][_0x815777(0xc2)]=function(_0x4cdf88,_0x7b2e3f){const _0x1aa519=_0x815777;if(!this['ready']){this[_0x1aa519(0xd6)](_0x4cdf88),this[_0x1aa519(0xad)](_0x4cdf88),this[_0x1aa519(0xbb)](_0x4cdf88),this[_0x1aa519(0xd4)](_0x7b2e3f);return;}_0x4cdf88[_0x1aa519(0xa9)][_0x1aa519(0x98)](this['colorCommand']);},S3MObliqueRenderEntity[_0x815777(0xcd)]['isDestroyed']=function(){return ![];},S3MObliqueRenderEntity[_0x815777(0xcd)][_0x815777(0xc5)]=function(){const _0x4c67c2=_0x815777;return this[_0x4c67c2(0xa3)]=this[_0x4c67c2(0xa3)]&&!this[_0x4c67c2(0xa3)][_0x4c67c2(0xcf)]()&&this[_0x4c67c2(0xa3)]['destroy'](),this[_0x4c67c2(0xa7)]=this[_0x4c67c2(0xa7)]&&!this[_0x4c67c2(0xa7)][_0x4c67c2(0xcf)]()&&this['vertexArray'][_0x4c67c2(0xc5)](),this[_0x4c67c2(0xb2)]=this['material']&&!this[_0x4c67c2(0xb2)][_0x4c67c2(0xcf)]()&&this[_0x4c67c2(0xb2)][_0x4c67c2(0xc5)](),this[_0x4c67c2(0xae)]=undefined,this[_0x4c67c2(0xda)]=null,this[_0x4c67c2(0xd2)]=null,this[_0x4c67c2(0x94)]=undefined,this[_0x4c67c2(0x9e)]=undefined,this[_0x4c67c2(0xaf)]=undefined,this['vs']=undefined,this['fs']=undefined,Cesium[_0x4c67c2(0x99)](this);};

    var _0x2a5a=['1027281TKhhZx','720203rXDqSy','243968Bidcwx','483288jaQxMJ','13jfizgs','651396cCWZKI','971000xTLoHF','95801UFxpag'];function _0x5189(_0x558994,_0x1b403a){_0x558994=_0x558994-0x176;var _0x2a5a4c=_0x2a5a[_0x558994];return _0x2a5a4c;}(function(_0x41ffaf,_0x471202){var _0x156de8=_0x5189;while(!![]){try{var _0x2b39b3=-parseInt(_0x156de8(0x17c))+parseInt(_0x156de8(0x179))+parseInt(_0x156de8(0x177))+-parseInt(_0x156de8(0x178))+parseInt(_0x156de8(0x17b))*parseInt(_0x156de8(0x176))+-parseInt(_0x156de8(0x17d))+parseInt(_0x156de8(0x17a));if(_0x2b39b3===_0x471202)break;else _0x41ffaf['push'](_0x41ffaf['shift']());}catch(_0x53a153){_0x41ffaf['push'](_0x41ffaf['shift']());}}}(_0x2a5a,0xa07c7));var _0x5ab4ab = '\x0a\x20\x20\x20\x20attribute\x20vec4\x20aPosition;\x0a#ifdef\x20VertexColor\x0a\x20\x20\x20\x20attribute\x20vec4\x20aColor;\x0a#endif\x0a#ifdef\x20VertexNormal\x0a\x20\x20\x20\x20attribute\x20vec3\x20aNormal;\x0a#endif\x0a#ifdef\x20Instance\x0a\x20\x20\x20\x20attribute\x20float\x20instanceId;\x0a#else\x0a\x20\x20\x20\x20attribute\x20float\x20batchId;\x0a#endif\x20\x0a\x0a#ifdef\x20TextureAtlas\x0a\x20\x20\x20\x20attribute\x20float\x20aTextureBatchId0;\x0a#endif\x0a\x0a#ifdef\x20TexCoord\x0a\x20\x20\x20\x20attribute\x20vec4\x20aTexCoord0;\x0a\x20\x20\x20\x20varying\x20vec4\x20vTexCoord;\x0a\x20\x20\x20\x20uniform\x20mat4\x20uTexMatrix;\x0a#ifdef\x20COMPUTE_TEXCOORD\x0a#ifdef\x20TextureAtlas\x0a\x20\x20\x20\x20uniform\x20vec4\x20uTexAtlasDim;\x0a\x20\x20\x20\x20varying\x20vec4\x20vTexAtlasTran;\x0a\x20\x20\x20\x20varying\x20vec4\x20vTexAtlasScale;\x0a\x20\x20\x20\x20varying\x20vec4\x20vTexAtlasSize;\x0a\x20\x20\x20\x20varying\x20vec2\x20vMaxMipLevel;\x0a#else\x0a\x20\x20\x20\x20uniform\x20float\x20uTexture0Width;\x0a\x20\x20\x20\x20varying\x20vec4\x20vTexMatrix;\x0a\x20\x20\x20\x20varying\x20vec4\x20vTexCoordTransform;\x0a#endif\x20\x20\x20\x20\x0a#endif\x0a#endif\x0a\x0a#ifdef\x20TexCoord2\x0a\x20\x20\x20\x20attribute\x20vec4\x20aTexCoord1;\x0a\x20\x20\x20\x20uniform\x20float\x20uTexture1Width;\x0a\x20\x20\x20\x20varying\x20vec4\x20vTexMatrix2;\x0a#endif\x0a#ifdef\x20InstanceBim\x0a\x20\x20\x20\x20attribute\x20vec4\x20uv2;\x0a\x20\x20\x20\x20attribute\x20vec4\x20uv3;\x0a\x20\x20\x20\x20attribute\x20vec4\x20uv4;\x0a\x20\x20\x20\x20attribute\x20vec4\x20secondary_colour;\x0a\x20\x20\x20\x20attribute\x20vec4\x20uv6;\x20\x20\x20\x0a#endif\x0a\x0a#ifdef\x20InstancePipe\x0a\x20\x20\x20\x20attribute\x20vec4\x20uv1;\x0a\x20\x20\x20\x20attribute\x20vec4\x20uv2;\x0a\x20\x20\x20\x20attribute\x20vec4\x20uv3;\x0a\x20\x20\x20\x20attribute\x20vec4\x20uv4;\x0a\x20\x20\x20\x20attribute\x20vec4\x20uv5;\x0a\x20\x20\x20\x20attribute\x20vec4\x20uv6;\x0a\x20\x20\x20\x20attribute\x20vec4\x20uv7;\x0a\x20\x20\x20\x20attribute\x20vec4\x20secondary_colour;\x0a\x20\x20\x20\x20attribute\x20vec4\x20uv9;\x0a#endif\x0a\x0a#ifdef\x20HYPSOMETRIC\x0a\x20\x20\x20\x20varying\x20float\x20wValue;\x20\x20\x20\x20\x0a#endif\x0a#ifdef\x20FLATTEN\x0a\x20\x20\x20\x20uniform\x20mat4\x20uGeoMatrix;\x0a\x20\x20\x20\x20uniform\x20mat4\x20uInverseGeoMatrix;\x0a\x20\x20\x20\x20uniform\x20sampler2D\x20uFlattenTexture;\x0a\x20\x20\x20\x20uniform\x20vec4\x20uFlattenRect;\x0a#endif\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20uniform\x20vec4\x20uSelectedColor;\x0a\x20\x20\x20\x20uniform\x20vec4\x20uFillForeColor;\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20varying\x20vec4\x20vSecondColor;\x0a\x20\x20\x20\x20varying\x20vec4\x20vPositionMC;\x0a\x20\x20\x20\x20varying\x20vec3\x20vPositionEC;\x0a#ifdef\x20VertexNormal\x0a\x20\x20\x20\x20varying\x20vec3\x20vNormalEC;\x0a#endif\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20varying\x20vec4\x20vColor;\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20const\x20float\x20SHIFT_LEFT8\x20=\x20256.0;\x0a\x20\x20\x20\x20const\x20float\x20SHIFT_RIGHT8\x20=\x201.0\x20/\x20256.0;\x0a\x20\x20\x20\x20const\x20float\x20SHIFT_RIGHT4\x20=\x201.0\x20/\x2016.0;\x0a\x20\x20\x20\x20const\x20float\x20SHIFT_LEFT4\x20=\x2016.0;\x0a\x20\x20\x20\x20void\x20getTextureMatrixFromZValue(in\x20float\x20nZ,\x20inout\x20float\x20XTran,\x20inout\x20float\x20YTran,\x20inout\x20float\x20scale)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(nZ\x20<=\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20nDel8\x20=\x20floor(nZ\x20*\x20SHIFT_RIGHT8);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20nDel16\x20=\x20floor(nDel8\x20*\x20SHIFT_RIGHT8);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20nDel20\x20=\x20floor(nDel16\x20*\x20SHIFT_RIGHT4);\x0a\x20\x20\x20\x20\x20\x20\x20\x20YTran\x20=\x20nZ\x20-\x20nDel8\x20*\x20SHIFT_LEFT8;\x0a\x20\x20\x20\x20\x20\x20\x20\x20XTran\x20=\x20nDel8\x20-\x20nDel16\x20*\x20SHIFT_LEFT8;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20nLevel\x20=\x20nDel16\x20-\x20nDel20\x20*\x20SHIFT_LEFT4;\x0a\x20\x20\x20\x20\x20\x20\x20\x20scale\x20=\x201.0\x20/\x20pow(2.0,\x20nLevel);\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20void\x20operation(vec4\x20operationType,\x20vec4\x20color,\x20vec4\x20selectedColor,\x20inout\x20vec4\x20vertexColor)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20right_2\x20=\x20operationType.x\x20*\x200.5;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20right_4\x20=\x20right_2\x20*\x200.5;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20right_8\x20=\x20right_4\x20*\x200.5;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20right_16\x20=\x20right_8\x20*\x200.5;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20isSetColor\x20=\x20fract(right_2);\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(isSetColor\x20>\x200.1)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20vertexColor\x20*=\x20color;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20isPicked\x20=\x20fract(floor(right_2)*\x200.5);\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(isPicked\x20>\x200.1)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20vertexColor\x20*=\x20selectedColor;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20isHide\x20=\x20fract(floor(right_4)*\x200.5);\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(isHide\x20>\x200.1)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20vertexColor.a\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x0a#ifdef\x20FLATTEN\x0a\x20\x20\x20\x20float\x20unpackValue(vec4\x20packedValue)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20SHIFT_LEFT16\x20=\x2065536.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20SHIFT_LEFT8\x20=\x20256.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20value\x20=\x20packedValue\x20*\x20255.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20value.r\x20*\x20SHIFT_LEFT16\x20+\x20value.g\x20*\x20SHIFT_LEFT8\x20+\x20value.b\x20-\x209000.0;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20vec4\x20calculateHeight(vec4\x20vertexPos)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20vecPos\x20=\x20uGeoMatrix\x20*\x20vec4(vertexPos.xyz,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20vecRatio\x20=\x20vec2(uFlattenRect.z\x20-\x20uFlattenRect.x,\x20uFlattenRect.w\x20-\x20uFlattenRect.y);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20vecTexCoord\x20=\x20vec2(vecPos.x\x20-\x20uFlattenRect.x,\x20vecPos.y\x20-\x20uFlattenRect.y);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vecTexCoord.x\x20=\x20vecTexCoord.x\x20/\x20vecRatio.x;\x0a\x20\x20\x20\x20\x20\x20\x20\x20vecTexCoord.y\x20=\x20vecTexCoord.y\x20/\x20vecRatio.y;\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(vecTexCoord.x\x20>\x201.0\x20||\x20vecTexCoord.x\x20<\x200.0\x20||\x20vecTexCoord.y\x20>\x201.0\x20||\x20vecTexCoord.y\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20vertexPos;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20fHeight\x20=\x20unpackValue(texture2D(uFlattenTexture,\x20vecTexCoord.xy));\x0a\x20\x20\x20\x20\x20\x20\x20\x20fHeight\x20=\x20fHeight;\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(vecPos.z\x20>\x20fHeight)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20vecPos.z\x20=\x20fHeight;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20vecPos.w\x20=\x20vecPos.z;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20uInverseGeoMatrix\x20*\x20vec4(vecPos.xyz,\x201.0);\x0a\x20\x20\x20\x20}\x0a#endif\x0a#ifdef\x20TextureAtlas\x0a\x20\x20\x20\x20uniform\x20highp\x20sampler2D\x20batchTextureAtlas;\x20\x0a\x20\x20\x20\x20uniform\x20vec4\x20batchTextureAtlasStep;\x20\x0a#ifdef\x20SecTextureAtlas\x0a\x20\x20\x20\x20uniform\x20highp\x20sampler2D\x20batchTextureAtlasSec;\x20\x0a\x20\x20\x20\x20uniform\x20vec4\x20batchTextureAtlasStepSec;\x20\x0a#endif\x0a\x20\x20\x20\x20vec2\x20computeAtlasSt(float\x20batchId,\x20vec4\x20step)\x20\x0a\x20\x20\x20\x20{\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20stepX\x20=\x20step.x;\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20centerX\x20=\x20step.y;\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20numberOfAttributes\x20=\x20float(1);\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20vec2(centerX\x20+\x20(batchId\x20*\x20numberOfAttributes\x20*\x20stepX),\x200.5);\x20\x0a\x20\x20\x20\x20}\x20\x0a\x20\x20\x20\x20vec4\x20atlas_batchTable_xywh(float\x20batchId,\x20sampler2D\x20texture,\x20vec4\x20step)\x20\x0a\x20\x20\x20\x20{\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20st\x20=\x20computeAtlasSt(batchId,\x20step);\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20st.x\x20+=\x20step.x\x20*\x20float(0);\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20textureValue\x20=\x20texture2D(texture,\x20st);\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20value\x20=\x20textureValue;\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20value;\x20\x0a\x20\x20\x20\x20}\x20\x0a\x20\x20\x20\x20void\x20getTexAtlasParameter(in\x20vec4\x20xywh,\x20in\x20vec2\x20textureDim,\x20inout\x20vec2\x20translate,\x20inout\x20vec2\x20scale,\x20inout\x20vec2\x20texSize,\x20inout\x20float\x20maxMipLevel)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20width\x20=\x20xywh.z;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20height\x20\x20=\x20xywh.w;\x0a\x20\x20\x20\x20\x20\x20\x20\x20width\x20*=\x202.0\x20/\x203.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20maxMipLevel\x20=\x20log2(min(width,\x20height));\x0a\x20\x20\x20\x20\x20\x20\x20\x20scale.x\x20=\x20width\x20/\x20textureDim.x;\x0a\x20\x20\x20\x20\x20\x20\x20\x20scale.y\x20=\x20height\x20/\x20textureDim.y;\x0a\x20\x20\x20\x20\x20\x20\x20\x20translate.x\x20=\x20xywh.x;\x0a\x20\x20\x20\x20\x20\x20\x20\x20translate.y\x20\x20=\x20xywh.y;\x0a\x20\x20\x20\x20\x20\x20\x20\x20translate\x20/=\x20textureDim;\x0a\x20\x20\x20\x20\x20\x20\x20\x20texSize.x\x20=\x20width;\x0a\x20\x20\x20\x20\x20\x20\x20\x20texSize.y\x20=\x20height;\x0a\x20\x20\x20\x20}\x0a#endif\x0a\x20\x20\x20\x20void\x20main()\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20#ifdef\x20COMPUTE_TEXCOORD\x0a\x20\x20\x20\x20\x20\x20\x20\x20vTexCoord.xy\x20=\x20aTexCoord0.xy;\x0a\x20\x20\x20\x20#ifdef\x20TextureAtlas\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(aTextureBatchId0\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20vMaxMipLevel.x\x20=\x20-1.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20xywh\x20=\x20atlas_batchTable_xywh(aTextureBatchId0,\x20batchTextureAtlas,\x20batchTextureAtlasStep);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20getTexAtlasParameter(xywh,\x20uTexAtlasDim.xy,\x20vTexAtlasTran.xy,\x20vTexAtlasScale.xy,\x20vTexAtlasSize.xy,\x20vMaxMipLevel.x);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20vTexMatrix\x20=\x20vec4(0.0,0.0,1.0,0.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vTexCoordTransform.x\x20=\x20aTexCoord0.z;\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(vTexCoordTransform.x\x20<\x20-90000.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20vTexMatrix.z\x20=\x20-1.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20getTextureMatrixFromZValue(floor(vTexCoordTransform.x),\x20vTexMatrix.x,\x20vTexMatrix.y,\x20vTexMatrix.z);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vTexMatrix.w\x20=\x20log2(uTexture0Width\x20*\x20vTexMatrix.z);\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20#ifdef\x20TexCoord2\x0a\x20\x20\x20\x20#ifdef\x20TextureAtlas\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(aTextureBatchIdSec\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20vMaxMipLevel.y\x20=\x20-1.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20xywh2\x20=\x20atlas_batchTable_xywh(aTextureBatchIdSec,\x20batchTextureAtlasSec,\x20batchTextureAtlasStepSec);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20getTexAtlasParameter(xywh2,\x20uTexAtlasDim.zw,\x20vTexAtlasTran.zw,\x20vTexAtlasScale.zw,\x20vTexAtlasSize.zw,\x20vMaxMipLevel.y);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20vTexCoord.zw\x20=\x20aTexCoord1.xy;\x0a\x20\x20\x20\x20\x20\x20\x20\x20vTexMatrix2\x20=\x20vec4(0.0,0.0,1.0,0.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vTexCoordTransform.y\x20=\x20aTexCoord1.z;\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(vTexCoordTransform.y\x20<\x20-90000.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20vTexMatrix2.z\x20=\x20-1.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20getTextureMatrixFromZValue(floor(vTexCoordTransform.y),\x20vTexMatrix2.x,\x20vTexMatrix2.y,\x20vTexMatrix2.z);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vTexMatrix2.w\x20=\x20log2(uTexture1Width\x20*\x20vTexMatrix.z);\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20vec4\x20vertexPos\x20=\x20aPosition;\x0a#ifdef\x20FLATTEN\x0a\x20\x20\x20\x20vertexPos\x20=\x20calculateHeight(vertexPos);\x0a#endif\x0a\x20\x20\x20\x20vec4\x20vertexColor\x20=\x20uFillForeColor;\x0a#ifdef\x20VertexColor\x0a\x20\x20\x20\x20vertexColor\x20*=\x20aColor;\x0a#endif\x0a#ifdef\x20VertexNormal\x0a\x20\x20\x20\x20vec3\x20normal\x20=\x20aNormal;\x0a#endif\x0a#ifdef\x20InstanceBim\x0a\x20\x20\x20\x20mat4\x20worldMatrix;\x0a\x20\x20\x20\x20worldMatrix[0]\x20=\x20uv2;\x0a\x20\x20\x20\x20worldMatrix[1]\x20=\x20uv3;\x0a\x20\x20\x20\x20worldMatrix[2]\x20=\x20uv4;\x0a\x20\x20\x20\x20worldMatrix[3]\x20=\x20vec4(0,\x200,\x200,\x201);\x0a\x20\x20\x20\x20vertexPos\x20=\x20vec4(vertexPos.xyz,1.0)\x20*\x20worldMatrix;\x0a\x20\x20\x20\x20vertexColor\x20*=\x20secondary_colour;\x20\x0a#endif\x0a#ifdef\x20InstancePipe\x0a\x20\x20\x20\x20mat4\x20worldMatrix;\x0a\x20\x20\x20\x20mat4\x20worldMatrix0;\x0a\x20\x20\x20\x20mat4\x20worldMatrix1;\x0a\x20\x20\x20\x20vec4\x20worldPos0;\x0a\x20\x20\x20\x20vec4\x20worldPos1;\x0a\x20\x20\x20\x20worldMatrix0[0]\x20=\x20uv1;\x0a\x20\x20\x20\x20worldMatrix0[1]\x20=\x20uv2;\x0a\x20\x20\x20\x20worldMatrix0[2]\x20=\x20uv3;\x0a\x20\x20\x20\x20worldMatrix0[3]\x20=\x20vec4(\x200.0,\x200.0,\x200.0,\x201.0\x20);\x0a\x20\x20\x20\x20worldMatrix1[0]\x20=\x20uv4;\x0a\x20\x20\x20\x20worldMatrix1[1]\x20=\x20uv5;\x0a\x20\x20\x20\x20worldMatrix1[2]\x20=\x20uv6;\x0a\x20\x20\x20\x20worldMatrix1[3]\x20=\x20vec4(\x200.0,\x200.0,\x200.0,\x201.0\x20);\x0a\x20\x20\x20\x20vec4\x20realVertex\x20=\x20vec4(vertexPos.xyz,\x201.0);\x0a\x20\x20\x20\x20realVertex.x\x20=\x20realVertex.x\x20*\x20uv7.z;\x0a\x20\x20\x20\x20worldPos0\x20=\x20realVertex\x20*\x20worldMatrix0;\x0a\x20\x20\x20\x20worldPos1\x20=\x20realVertex\x20*\x20worldMatrix1;\x0a\x20\x20\x20\x20vertexColor\x20*=\x20secondary_colour;\x20\x0a#ifdef\x20TexCoord\x0a\x20\x20\x20\x20if(aTexCoord0.y\x20>\x200.5)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20tex4Vec\x20=\x20uTexMatrix\x20*\x20vec4(uv7.y,\x20aTexCoord0.x,\x200.0,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vTexCoord.xy\x20=\x20tex4Vec.xy;\x0a\x20\x20\x20\x20\x20\x20\x20\x20vertexPos\x20=\x20worldPos1;\x0a\x20\x20\x20\x20\x20\x20\x20\x20worldMatrix\x20=\x20worldMatrix1;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20else\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20tex4Vec\x20=\x20uTexMatrix\x20*\x20vec4(uv7.x,\x20aTexCoord0.x,\x200.0,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vTexCoord.xy\x20=\x20tex4Vec.xy;\x0a\x20\x20\x20\x20\x20\x20\x20\x20vertexPos\x20=\x20worldPos0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20worldMatrix\x20=\x20worldMatrix0;\x0a\x20\x20\x20\x20}\x0a#endif\x0a#ifdef\x20VertexNormal\x0a\x20\x20\x20\x20normal.x\x20=\x20normal.x\x20*\x20uv7.z;\x0a#endif\x0a#endif\x0a\x20\x20\x20\x20#ifdef\x20Instance\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20index\x20=\x20instanceId;\x0a\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20index\x20=\x20batchId;\x0a\x20\x20\x20\x20#endif\x20\x20\x0a\x20\x20\x20\x20#ifdef\x20HYPSOMETRIC\x0a\x20\x20\x20\x20\x20\x20\x20\x20wValue\x20=\x20vertexPos.w;\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20operationType\x20=\x20s3m_batchTable_operation(index);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20objsColor\x20=\x20s3m_batchTable_color(index);\x0a\x20\x20\x20\x20\x20\x20\x20\x20operation(operationType,\x20objsColor,\x20uSelectedColor,\x20vertexColor);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vSecondColor\x20=\x20s3m_batchTable_pickColor(index);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20positionMC\x20=\x20vec4(vertexPos.xyz,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vColor\x20=\x20vertexColor;\x0a\x20\x20\x20\x20\x20\x20\x20\x20vPositionMC\x20=\x20positionMC;\x0a\x20\x20\x20\x20\x20\x20\x20\x20vPositionEC\x20=\x20(czm_modelView\x20*\x20positionMC).xyz;\x0a\x20\x20\x20\x20#ifdef\x20VertexNormal\x0a\x20\x20\x20\x20\x20\x20\x20\x20vNormalEC\x20=\x20czm_normal\x20*\x20normal;\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20gl_Position\x20=\x20czm_modelViewProjection\x20*\x20vec4(vertexPos.xyz,\x201.0);\x0a\x20\x20\x20\x20}\x0a';

    var _0x5dc3=['1058221oIlAmi','116686UmkAnA','7YlFHQJ','1703YtnRvr','57695PQswiE','\x0a#ifdef\x20GL_OES_standard_derivatives\x0a#extension\x20GL_OES_standard_derivatives\x20:\x20enable\x0a#endif\x0a#ifdef\x20GL_EXT_shader_texture_lod\x0a#extension\x20GL_EXT_shader_texture_lod\x20:\x20enable\x0a#endif\x0a\x20\x20\x20\x20uniform\x20vec4\x20uDiffuseColor;\x0a\x20\x20\x20\x20uniform\x20vec4\x20uAmbientColor;\x0a#ifdef\x20TexCoord\x0a\x20\x20\x20\x20varying\x20vec4\x20vTexCoord;\x0a#ifdef\x20COMPUTE_TEXCOORD\x0a\x20\x20\x20\x20uniform\x20sampler2D\x20uTexture;\x0a#ifdef\x20TextureAtlas\x0a\x20\x20\x20\x20uniform\x20vec4\x20uTexAtlasDim;\x0a\x20\x20\x20\x20varying\x20vec4\x20vTexAtlasTran;\x0a\x20\x20\x20\x20varying\x20vec4\x20vTexAtlasScale;\x0a\x20\x20\x20\x20varying\x20vec4\x20vTexAtlasSize;\x0a\x20\x20\x20\x20varying\x20vec2\x20vMaxMipLevel;\x0a#else\x0a\x20\x20\x20\x20uniform\x20float\x20uTexture0Width;\x0a\x20\x20\x20\x20varying\x20vec4\x20vTexCoordTransform;\x0a\x20\x20\x20\x20varying\x20vec4\x20vTexMatrix;\x0a#endif\x0a#endif\x0a#endif\x0a\x0a\x20\x20\x20\x20varying\x20vec4\x20vColor;\x0a\x20\x20\x20\x20varying\x20vec4\x20vSecondColor;\x0a\x20\x20\x20\x20varying\x20vec4\x20vPositionMC;\x0a\x20\x20\x20\x20varying\x20vec3\x20vPositionEC;\x0a#ifdef\x20VertexNormal\x0a\x20\x20\x20\x20varying\x20vec3\x20vNormalEC;\x0a#endif\x0a#ifdef\x20TexCoord2\x0a\x20\x20\x20\x20uniform\x20sampler2D\x20uTexture2;\x0a\x20\x20\x20\x20uniform\x20float\x20uTexture1Width;\x0a\x20\x20\x20\x20varying\x20vec4\x20vTexMatrix2;\x0a#endif\x20\x0a\x20\x20\x20\x20void\x20calculateMipLevel(in\x20vec2\x20inTexCoord,\x20in\x20float\x20vecTile,\x20in\x20float\x20fMaxMip,\x20inout\x20float\x20mipLevel)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20dx\x20=\x20dFdx(inTexCoord\x20*\x20vecTile);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20dy\x20=\x20dFdy(inTexCoord\x20*\x20vecTile);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dotX\x20=\x20dot(dx,\x20dx);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dotY\x20=\x20dot(dy,\x20dy);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dMax\x20=\x20max(dotX,\x20dotY);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dMin\x20=\x20min(dotX,\x20dotY);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20offset\x20=\x20(dMax\x20-\x20dMin)\x20/\x20(dMax\x20+\x20dMin);\x0a\x20\x20\x20\x20\x20\x20\x20\x20offset\x20=\x20clamp(offset,\x200.0,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20d\x20=\x20dMax\x20*\x20(1.0\x20-\x20offset)\x20+\x20dMin\x20*\x20offset;\x0a\x20\x20\x20\x20\x20\x20\x20\x20mipLevel\x20=\x200.5\x20*\x20log2(d);\x0a\x20\x20\x20\x20\x20\x20\x20\x20mipLevel\x20=\x20clamp(mipLevel,\x200.0,\x20fMaxMip\x20-\x201.62);\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20void\x20calculateMipLevel(in\x20vec2\x20inTexCoord,\x20in\x20vec2\x20vecTile,\x20in\x20float\x20fMaxMip,\x20inout\x20float\x20mipLevel)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20dx\x20=\x20dFdx(inTexCoord\x20*\x20vecTile.x);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20dy\x20=\x20dFdy(inTexCoord\x20*\x20vecTile.y);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dotX\x20=\x20dot(dx,\x20dx);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dotY\x20=\x20dot(dy,\x20dy);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dMax\x20=\x20max(dotX,\x20dotY);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dMin\x20=\x20min(dotX,\x20dotY);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20offset\x20=\x20(dMax\x20-\x20dMin)\x20/\x20(dMax\x20+\x20dMin);\x0a\x20\x20\x20\x20\x20\x20\x20\x20offset\x20=\x20clamp(offset,\x200.0,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20d\x20=\x20dMax\x20*\x20(1.0\x20-\x20offset)\x20+\x20dMin\x20*\x20offset;\x0a\x20\x20\x20\x20\x20\x20\x20\x20mipLevel\x20=\x200.5\x20*\x20log2(d);\x0a\x20\x20\x20\x20\x20\x20\x20\x20mipLevel\x20=\x20clamp(mipLevel,\x200.0,\x20fMaxMip\x20-\x201.62);\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20void\x20calculateTexCoord(in\x20vec3\x20inTexCoord,\x20in\x20float\x20scale,\x20in\x20float\x20XTran,\x20in\x20float\x20YTran,\x20in\x20float\x20fTile,\x20in\x20float\x20mipLevel,\x20inout\x20vec2\x20outTexCoord)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(inTexCoord.z\x20<\x20-9000.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20outTexCoord\x20=\x20inTexCoord.xy;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20fTexCoord\x20=\x20fract(inTexCoord.xy);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20float\x20offset\x20=\x201.0\x20*\x20pow(2.0,\x20mipLevel)\x20/\x20fTile;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20fTexCoord\x20=\x20clamp(fTexCoord,\x20offset,\x201.0\x20-\x20offset);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20outTexCoord.x\x20=\x20(fTexCoord.x\x20+\x20XTran)\x20*\x20scale;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20outTexCoord.y\x20=\x20(fTexCoord.y\x20+\x20YTran)\x20*\x20scale;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20vec4\x20getTexColorForS3M(sampler2D\x20curTexture,\x20vec3\x20oriTexCoord,\x20float\x20texTileWidth,\x20float\x20fMaxMipLev,\x20float\x20fTexCoordScale,\x20vec2\x20vecTexCoordTranslate)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20color\x20=\x20vec4(1.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20mipLevel\x20=\x200.0;\x0a\x20\x20\x20\x20#ifdef\x20GL_OES_standard_derivatives\x0a\x20\x20\x20\x20\x20\x20\x20\x20calculateMipLevel(oriTexCoord.xy,\x20texTileWidth,\x20fMaxMipLev,\x20mipLevel);\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20realTexCoord;\x0a\x20\x20\x20\x20\x20\x20\x20\x20calculateTexCoord(oriTexCoord,\x20fTexCoordScale,\x20vecTexCoordTranslate.x,\x20vecTexCoordTranslate.y,\x20texTileWidth,\x20mipLevel,\x20realTexCoord);\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(oriTexCoord.z\x20<\x20-9000.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color\x20=\x20texture2D(curTexture,\x20realTexCoord.xy);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#ifdef\x20GL_EXT_shader_texture_lod\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color\x20=\x20texture2DLodEXT(curTexture,\x20realTexCoord.xy,\x20mipLevel);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color\x20=\x20texture2D(curTexture,\x20realTexCoord.xy,\x20mipLevel);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20color;\x0a\x20\x20\x20\x20}\x0a#ifdef\x20COMPUTE_TEXCOORD\x0a#ifdef\x20TextureAtlas\x0a\x20\x20\x20\x20vec4\x20getTextureAtlasColor(sampler2D\x20texture,\x20vec2\x20uv,\x20vec2\x20texDim,\x20vec2\x20texTran,\x20vec2\x20texScale,\x20float\x20maxMipLevel)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(maxMipLevel\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20vec4(1.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20colorCeil\x20=\x20vec4(1.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20mipLevel\x20=\x200.0;\x0a\x20\x20\x20\x20#ifdef\x20GL_OES_standard_derivatives\x0a\x20\x20\x20\x20\x20\x20\x20\x20calculateMipLevel(uv,\x20texDim,\x20maxMipLevel,\x20mipLevel);\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20ceilMipLevel\x20=\x20ceil(mipLevel);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20translate\x20=\x20vec2(texTran.x,\x20texTran.y);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20temp;\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(ceilMipLevel\x20>\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20translate.x\x20=\x20texTran.x\x20+\x20texScale.x;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20temp\x20=\x20pow(2.0,\x20ceilMipLevel\x20-\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20translate.y\x20=\x20texTran.y\x20+\x20texScale.y\x20*\x20(temp\x20-\x201.0)\x20/\x20temp;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20scale\x20=\x201.0\x20/\x20pow(2.0,\x20ceilMipLevel);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20texcoord\x20=\x20fract(uv);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20offsetX\x20=\x20pow(2.0,\x20ceilMipLevel)\x20/\x20texDim.x;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20offsetY\x20=\x20pow(2.0,\x20ceilMipLevel)\x20/\x20texDim.y;\x0a\x20\x20\x20\x20\x20\x20\x20\x20texcoord.x\x20=\x20clamp(texcoord.x,\x200.0\x20+\x20offsetX,\x201.0\x20-\x20offsetX);\x0a\x20\x20\x20\x20\x20\x20\x20\x20texcoord.y\x20=\x20clamp(texcoord.y,\x200.0\x20+\x20offsetY,\x201.0\x20-\x20offsetY);\x0a\x20\x20\x20\x20\x20\x20\x20\x20texcoord.x\x20=\x20texcoord.x\x20*\x20texScale.x\x20*\x20scale\x20+\x20translate.x;\x0a\x20\x20\x20\x20\x20\x20\x20\x20texcoord.y\x20=\x20texcoord.y\x20*\x20texScale.y\x20*\x20scale\x20+\x20translate.y;\x0a\x20\x20\x20\x20#ifdef\x20GL_EXT_shader_texture_lod\x0a\x20\x20\x20\x20\x20\x20\x20\x20colorCeil\x20=\x20texture2DLodEXT(texture,\x20texcoord.xy,\x200.0);\x0a\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20colorCeil\x20=\x20texture2D(texture,\x20texcoord.xy,\x200.0);\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20colorFloor\x20=\x20vec4(1.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20floorMipLevel\x20=\x20floor(mipLevel);\x0a\x20\x20\x20\x20\x20\x20\x20\x20translate\x20=\x20vec2(texTran.x,\x20texTran.y);\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(floorMipLevel\x20>\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20translate.x\x20=\x20texTran.x\x20+\x20texScale.x;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20temp\x20=\x20pow(2.0,\x20floorMipLevel\x20-\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20translate.y\x20=\x20texTran.y\x20+\x20texScale.y\x20*\x20(temp\x20-\x201.0)\x20/\x20temp;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20scale\x20=\x201.0\x20/\x20pow(2.0,\x20floorMipLevel);\x0a\x20\x20\x20\x20\x20\x20\x20\x20texcoord\x20=\x20fract(uv);\x0a\x20\x20\x20\x20\x20\x20\x20\x20offsetX\x20=\x20pow(2.0,\x20floorMipLevel)\x20/\x20texDim.x;\x0a\x20\x20\x20\x20\x20\x20\x20\x20offsetY\x20=\x20pow(2.0,\x20floorMipLevel)\x20/\x20texDim.y;\x0a\x20\x20\x20\x20\x20\x20\x20\x20texcoord.x\x20=\x20clamp(texcoord.x,\x200.0\x20+\x20offsetX,\x201.0\x20-\x20offsetX);\x0a\x20\x20\x20\x20\x20\x20\x20\x20texcoord.y\x20=\x20clamp(texcoord.y,\x200.0\x20+\x20offsetY,\x201.0\x20-\x20offsetY);\x0a\x20\x20\x20\x20\x20\x20\x20\x20texcoord.x\x20=\x20texcoord.x\x20*\x20texScale.x\x20*\x20scale\x20+\x20translate.x;\x0a\x20\x20\x20\x20\x20\x20\x20\x20texcoord.y\x20=\x20texcoord.y\x20*\x20texScale.y\x20*\x20scale\x20+\x20translate.y;\x0a\x20\x20\x20\x20#ifdef\x20GL_EXT_shader_texture_lod\x0a\x20\x20\x20\x20\x20\x20\x20\x20colorFloor\x20=\x20texture2DLodEXT(texture,\x20texcoord.xy,\x200.0);\x0a\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20colorFloor\x20=\x20texture2D(texture,\x20texcoord.xy,\x200.0);\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20color\x20=\x20colorCeil\x20*\x200.5\x20+\x20colorFloor\x20*\x200.5;\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20color;\x0a\x20\x20\x20\x20}\x0a#else\x0a\x20\x20\x20\x20vec4\x20getTextureColor()\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(vTexMatrix.z\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20vec4(1.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20texTileWidth0\x20=\x20vTexMatrix.z\x20*\x20uTexture0Width;\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20realTexCoord\x20=\x20vec3(vTexCoord.xy,\x20vTexCoordTransform.x);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20FColor\x20=\x20getTexColorForS3M(uTexture,\x20realTexCoord,\x20texTileWidth0,\x20vTexMatrix.w,\x20vTexMatrix.z,\x20vTexMatrix.xy);\x0a\x20\x20\x20\x20#ifdef\x20TexCoord2\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20texTileWidth1\x20=\x20vTexMatrix2.z\x20*\x20uTexture1Width;\x0a\x20\x20\x20\x20\x20\x20\x20\x20realTexCoord\x20=\x20vec3(vTexCoord.zw,\x20vTexCoordTransform.y);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20SColor\x20=\x20getTexColorForS3M(uTexture2,\x20realTexCoord,\x20texTileWidth1,\x20vTexMatrix2.w,\x20vTexMatrix2.z,\x20vTexMatrix2.xy);\x0a\x20\x20\x20\x20\x20\x20\x20\x20SColor.r\x20=\x20clamp(SColor.r,\x200.0,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20SColor.g\x20=\x20clamp(SColor.g,\x200.0,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20SColor.b\x20=\x20clamp(SColor.b,\x200.0,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20FColor\x20*\x20SColor;\x0a\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20FColor;\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20}\x0a#endif\x0a#endif\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20const\x20float\x20M_PI\x20=\x203.141592653589793;\x0a\x20\x20\x20\x20vec3\x20SRGBtoLINEAR3(vec3\x20srgbIn)\x20\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20pow(srgbIn,\x20vec3(2.2));\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20vec4\x20SRGBtoLINEAR4(vec4\x20srgbIn)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20srgbIn\x20=\x20srgbIn\x20;\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20linearOut\x20=\x20pow(srgbIn.rgb,\x20vec3(2.2));\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20vec4(linearOut,\x20srgbIn.a);\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20vec3\x20LINEARtoSRGB(vec3\x20linearIn)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20#ifndef\x20HDR\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20pow(linearIn,\x20vec3(1.0/2.2));\x0a\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20linearIn;\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20vec3\x20lambertianDiffuse(vec3\x20diffuseColor)\x20\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20diffuseColor\x20/\x20M_PI;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20vec3\x20fresnelSchlick2(vec3\x20f0,\x20vec3\x20f90,\x20float\x20VdotH)\x20\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20f0\x20+\x20(f90\x20-\x20f0)\x20*\x20pow(clamp(1.0\x20-\x20VdotH,\x200.0,\x201.0),\x205.0);\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20float\x20smithVisibilityG1(float\x20NdotV,\x20float\x20roughness)\x20\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20k\x20=\x20(roughness\x20+\x201.0)\x20*\x20(roughness\x20+\x201.0)\x20/\x208.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20NdotV\x20/\x20(NdotV\x20*\x20(1.0\x20-\x20k)\x20+\x20k);\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20float\x20smithVisibilityGGX(float\x20roughness,\x20float\x20NdotL,\x20float\x20NdotV)\x20\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20smithVisibilityG1(NdotL,\x20roughness)\x20*\x20smithVisibilityG1(NdotV,\x20roughness);\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20float\x20GGX(float\x20roughness,\x20float\x20NdotH)\x20\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20roughnessSquared\x20=\x20roughness\x20*\x20roughness;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20f\x20=\x20(NdotH\x20*\x20roughnessSquared\x20-\x20NdotH)\x20*\x20NdotH\x20+\x201.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20roughnessSquared\x20/\x20(M_PI\x20*\x20f\x20*\x20f);\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20vec3\x20applyTonemapping(vec3\x20linearIn)\x20\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20#ifndef\x20HDR\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20czm_acesTonemapping(linearIn);\x0a\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20linearIn;\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20}\x0a#ifdef\x20CLIP\x0a\x20\x20\x20\x20uniform\x20float\x20uClipMode;\x0a\x20\x20\x20\x20uniform\x20vec4\x20uClipPlanes[6];\x0a\x20\x20\x20\x20float\x20clipBehindAllPlane(float\x20fBorderWidth,\x20vec4\x20vertex)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20distance\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20result\x20=\x20-1.0;\x0a\x20\x20\x20\x20#ifdef\x20CLIPPLANE\x0a\x20\x20\x20\x20\x20\x20\x20\x20distance\x20=\x20czm_planeDistance(uClipPlanes[0].xyz,\x20uClipPlanes[0].w,\x20vertex.xyz);\x0a\x20\x20\x20\x20\x20\x20\x20\x20if\x20(distance\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x201.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x20if\x20(distance\x20<\x20fBorderWidth)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20result\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20for(int\x20i\x20=\x200;\x20i\x20<\x206;\x20i++)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20distance\x20=\x20czm_planeDistance(uClipPlanes[i].xyz,\x20uClipPlanes[i].w,\x20vertex.xyz);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20if(distance\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x201.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(distance\x20<\x20fBorderWidth)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20result\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20result;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20float\x20clipBehindAnyPlane(float\x20fBorderWidth,\x20vec4\x20vertex)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20result\x20=\x201.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20for(int\x20i\x20=\x200;\x20i\x20<\x206;\x20i++)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20float\x20distance\x20=\x20czm_planeDistance(uClipPlanes[i].xyz,\x20uClipPlanes[i].w,\x20vertex.xyz);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20if((distance\x20+\x20fBorderWidth)\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20-1.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(distance\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20result\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20result;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20float\x20clipAnythingButLine(float\x20fBorderWidth,\x20vec4\x20vertex)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20result\x20=\x20-1.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20for(int\x20i\x20=\x200;\x20i\x20<\x206;\x20i++)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20float\x20distance\x20=\x20czm_planeDistance(uClipPlanes[i].xyz,\x20uClipPlanes[i].w,\x20vertex.xyz);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20if(distance\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20-1.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(distance\x20<\x20fBorderWidth)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20result\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20result;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20vec4\x20clip(vec4\x20vertex)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(uClipMode\x20<\x200.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20vec4(1.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20#ifdef\x20GL_OES_standard_derivatives\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dxc\x20=\x20abs(dFdx(vertex.x));\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dyc\x20=\x20abs(dFdy(vertex.y));\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20fBorderWidth\x20=\x20max(dxc,\x20dyc);\x0a\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20fBorderWidth\x20=\x201.0;\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20clipResult\x20=\x201.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(uClipMode\x20<\x201.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20clipResult\x20=\x20clipBehindAnyPlane(fBorderWidth,\x20vertex);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(uClipMode\x20<\x202.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20clipResult\x20=\x20clipBehindAllPlane(fBorderWidth,\x20vertex);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(uClipMode\x20<\x203.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20clipResult\x20=\x20clipAnythingButLine(fBorderWidth,\x20vertex);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(clipResult\x20<\x20-0.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20discard;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(clipResult\x20<\x200.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20vec4(1.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20vec4(1.0);\x0a\x20\x20\x20\x20}\x0a#endif\x0a\x0a#ifdef\x20HYPSOMETRIC\x0a\x20\x20\x20\x20uniform\x20sampler2D\x20uHypsometricTexture;\x0a\x20\x20\x20\x20uniform\x20vec4\x20uMinMaxValue;\x0a\x20\x20\x20\x20uniform\x20vec4\x20uOpacityIntervalFillMode;\x0a\x20\x20\x20\x20uniform\x20vec4\x20uHypLineColor;\x0a\x20\x20\x20\x20uniform\x20vec4\x20uNoValueColor;\x0a\x20\x20\x20\x20varying\x20float\x20wValue;\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20float\x20computeMixCon(float\x20fValue)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20distanceToContour;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20minVisibleValue\x20=\x20uMinMaxValue.z;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20maxVisibleValue\x20=\x20uMinMaxValue.w;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20interval\x20=\x20uOpacityIntervalFillMode.y;\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(abs(maxVisibleValue\x20-\x20minVisibleValue)\x20>\x200.1)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20if(fValue\x20<\x200.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20distanceToContour\x20=\x20mod(fValue\x20-\x200.0002,\x20interval);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20else\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20float\x20t\x20=\x20floor(fValue\x20/\x20interval);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20distanceToContour\x20=\x20abs(fValue\x20-\x20(t\x20*\x20interval)\x20-\x200.1);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20distanceToContour\x20=\x20abs(fValue\x20-\x20maxVisibleValue);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dxc\x20=\x20abs(dFdx(fValue));\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dyc\x20=\x20abs(dFdy(fValue));\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dF\x20=\x20max(dxc,\x20dyc);\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20distanceToContour\x20<\x20dF\x20?\x201.0\x20:\x200.0;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20vec4\x20computeContourMapColor(float\x20fValue)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20floorValue\x20=\x20uMinMaxValue.x;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20ceilValue\x20=\x20uMinMaxValue.y;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20threshold\x20=\x20abs(ceilValue\x20-\x20floorValue);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20contourRate\x20=\x20(fValue\x20-\x20floorValue)\x20/\x20threshold;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20finalCoord\x20=\x20clamp(contourRate,\x200.0,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20count\x20=\x20floor(finalCoord\x20*\x2016.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20y\x20=\x20(count*2.0\x20+\x201.0)/32.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20x\x20=\x20fract(finalCoord*16.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(y\x20>\x201.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20x\x20=\x201.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20contourCoord\x20=\x20vec2(x,\x20y);\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20texture2D(uHypsometricTexture,\x20contourCoord);\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20vec4\x20getContourMapColor(vec4\x20oriColor,\x20float\x20fValue)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20contourMapColor\x20=\x20vec4(0.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20finalOpacity\x20=\x20uOpacityIntervalFillMode.x;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20minVisibleValue\x20=\x20uMinMaxValue.z;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20maxVisibleValue\x20=\x20uMinMaxValue.w;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20fillMode\x20=\x20uOpacityIntervalFillMode.z;\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(fValue\x20>\x20maxVisibleValue\x20+\x204.0\x20||\x20fValue\x20<\x20minVisibleValue\x20-\x204.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20uNoValueColor\x20*\x20oriColor;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(fillMode\x20>\x202.9)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20float\x20mix_con\x20=\x20computeMixCon(fValue);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20contourMapColor\x20=\x20mix(computeContourMapColor(fValue),\x20uHypLineColor,\x20mix_con);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(fillMode\x20>\x201.9)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20finalOpacity\x20=\x20computeMixCon(fValue);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20contourMapColor\x20=\x20uHypLineColor;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(fillMode\x20>\x200.9)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20contourMapColor\x20=\x20computeContourMapColor(fValue);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20finalOpacity\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20finalColor\x20=\x20mix(oriColor,\x20contourMapColor,\x20finalOpacity);\x0a\x20\x20\x20\x20#ifdef\x20PT_CLOUD\x0a\x20\x20\x20\x20\x20\x20\x20\x20finalColor\x20=\x20mix(vec4(1.0,1.0,1.0,1.0),\x20contourMapColor,\x20finalOpacity);\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20finalColor;\x0a\x20\x20\x20\x20}\x0a#endif\x0a\x20\x20\x0a#ifdef\x20APPLY_SWIPE\x0a\x20\x20\x20\x20uniform\x20vec4\x20uSwipeRegion;\x0a\x20\x20\x20\x20void\x20rollerShutter(vec2\x20coord,\x20vec4\x20region)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20f\x20=\x20step(region.xw,\x20coord);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20s\x20=\x20step(coord,\x20region.zy);\x0a\x20\x20\x20\x20\x20\x20\x20\x20if\x20(f.x\x20*\x20f.y\x20*\x20s.x\x20*\x20s.y\x20<\x201.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20discard;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20}\x0a#endif\x0a\x20\x20\x20\x20vec3\x20computeNormal(in\x20vec3\x20oriVertex)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20normal\x20=\x20cross(vec3(dFdx(oriVertex.x),\x20dFdx(oriVertex.y),\x20dFdx(oriVertex.z)),\x20vec3(dFdy(oriVertex.x),\x20dFdy(oriVertex.y),\x20dFdy(oriVertex.z)));\x0a\x20\x20\x20\x20\x20\x20\x20\x20normal\x20=\x20normalize(normal);\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20normal;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20void\x20main()\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(vColor.a\x20<\x200.1)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20discard;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x20\x0a\x20\x20\x20\x20#ifdef\x20APPLY_SWIPE\x0a\x20\x20\x20\x20\x20\x20\x20\x20rollerShutter(gl_FragCoord.xy,\x20uSwipeRegion);\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20baseColorWithAlpha\x20=\x20vColor;\x0a\x20\x20\x20\x20#ifdef\x20COMPUTE_TEXCOORD\x0a\x20\x20\x20\x20#ifdef\x20TextureAtlas\x0a\x20\x20\x20\x20\x20\x20\x20\x20baseColorWithAlpha\x20*=\x20getTextureAtlasColor(uTexture,\x20vTexCoord.xy,\x20vTexAtlasSize.xy,\x20vTexAtlasTran.xy,\x20vTexAtlasScale.xy,\x20vMaxMipLevel.x);\x0a\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20baseColorWithAlpha\x20*=\x20getTextureColor();\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(baseColorWithAlpha.a\x20<\x200.1)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20discard;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec4\x20outColor\x20=\x20baseColorWithAlpha;\x0a\x20\x20\x20\x20#ifndef\x20USE_LINECOLOR\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20baseColorWithAlpha\x20=\x20SRGBtoLINEAR4(baseColorWithAlpha);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20ng\x20=\x20vec3(0.0);\x0a\x20\x20\x20\x20#ifdef\x20VertexNormal\x0a\x20\x20\x20\x20\x20\x20\x20\x20ng\x20=\x20normalize(vNormalEC);\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20ng\x20=\x20length(ng)\x20>\x200.1\x20?\x20ng\x20:\x20computeNormal(vPositionMC.xyz);\x0a\x20\x20\x20\x20#ifdef\x20HAS_NORMAL_TEXTURE\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20pos_dx\x20=\x20dFdx(vPositionEC);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20pos_dy\x20=\x20dFdy(vPositionEC);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20tex_dx\x20=\x20dFdx(vec3(vTexCoord.xy,\x200.0));\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20tex_dy\x20=\x20dFdy(vec3(vTexCoord.xy,\x200.0));\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20t\x20=\x20(tex_dy.t\x20*\x20pos_dx\x20-\x20tex_dx.t\x20*\x20pos_dy)\x20/\x20(tex_dx.s\x20*\x20tex_dy.t\x20-\x20tex_dy.s\x20*\x20tex_dx.t);\x0a\x20\x20\x20\x20\x20\x20\x20\x20t\x20=\x20normalize(t\x20-\x20ng\x20*\x20dot(ng,\x20t));\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20b\x20=\x20normalize(cross(ng,\x20t));\x0a\x20\x20\x20\x20\x20\x20\x20\x20mat3\x20tbn\x20=\x20mat3(t,\x20b,\x20ng);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20n\x20=\x20texture2D(uNormalTexture,\x20vTexCoord.xy).rgb;\x0a\x20\x20\x20\x20\x20\x20\x20\x20n\x20=\x20normalize(tbn\x20*\x20(2.0\x20*\x20n\x20-\x201.0));\x0a\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20n\x20=\x20ng;\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20baseColor\x20=\x20baseColorWithAlpha.rgb;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20roughness\x20=\x201.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20metalness\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20v\x20=\x20-normalize(vPositionEC);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20lightColorHdr\x20=\x20vec3(5.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20l\x20=\x20normalize(czm_lightDirectionEC);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20h\x20=\x20normalize(v\x20+\x20l);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20NdotL\x20=\x20clamp(dot(n,\x20l),\x200.001,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20NdotV\x20=\x20abs(dot(n,\x20v))\x20+\x200.001;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20NdotH\x20=\x20clamp(dot(n,\x20h),\x200.0,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20LdotH\x20=\x20clamp(dot(l,\x20h),\x200.0,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20VdotH\x20=\x20clamp(dot(v,\x20h),\x200.0,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20f0\x20=\x20vec3(0.04);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20diffuseColor\x20=\x20baseColor\x20*\x20(1.0\x20-\x20metalness)\x20*\x20(1.0\x20-\x20f0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20specularColor\x20=\x20mix(f0,\x20baseColor,\x20metalness);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20alpha\x20=\x20roughness\x20*\x20roughness;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20reflectance\x20=\x20max(max(specularColor.r,\x20specularColor.g),\x20specularColor.b);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20r90\x20=\x20vec3(clamp(reflectance\x20*\x2025.0,\x200.0,\x201.0));\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20r0\x20=\x20specularColor.rgb;\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20F\x20=\x20fresnelSchlick2(r0,\x20r90,\x20VdotH);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20G\x20=\x20smithVisibilityGGX(alpha,\x20NdotL,\x20NdotV);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20D\x20=\x20GGX(alpha,\x20NdotH);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20diffuseContribution\x20=\x20(1.0\x20-\x20F)\x20*\x20lambertianDiffuse(diffuseColor);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20specularContribution\x20=\x20F\x20*\x20G\x20*\x20D\x20/\x20(4.0\x20*\x20NdotL\x20*\x20NdotV);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20color\x20=\x20NdotL\x20*\x20lightColorHdr\x20*\x20(diffuseContribution\x20+\x20specularContribution);\x0a\x20\x20\x20\x20#ifndef\x20IBL\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20positionWC\x20=\x20vec3(czm_inverseView\x20*\x20vec4(vPositionEC,\x201.0));\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20r\x20=\x20normalize(czm_inverseViewRotation\x20*\x20normalize(reflect(v,\x20n)));\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20vertexRadius\x20=\x20length(positionWC);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20horizonDotNadir\x20=\x201.0\x20-\x20min(1.0,\x20czm_ellipsoidRadii.x\x20/\x20vertexRadius);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20reflectionDotNadir\x20=\x20dot(r,\x20normalize(positionWC));\x0a\x20\x20\x20\x20\x20\x20\x20\x20r.x\x20=\x20-r.x;\x0a\x20\x20\x20\x20\x20\x20\x20\x20r\x20=\x20-normalize(czm_temeToPseudoFixed\x20*\x20r);\x0a\x20\x20\x20\x20\x20\x20\x20\x20r.x\x20=\x20-r.x;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20inverseRoughness\x20=\x201.04\x20-\x20roughness;\x0a\x20\x20\x20\x20\x20\x20\x20\x20inverseRoughness\x20*=\x20inverseRoughness;\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20sceneSkyBox\x20=\x20textureCube(czm_environmentMap,\x20r).rgb\x20*\x20inverseRoughness;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20atmosphereHeight\x20=\x200.05;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20blendRegionSize\x20=\x200.1\x20*\x20((1.0\x20-\x20inverseRoughness)\x20*\x208.0\x20+\x201.1\x20-\x20horizonDotNadir);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20blendRegionOffset\x20=\x20roughness\x20*\x20-1.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20farAboveHorizon\x20=\x20clamp(horizonDotNadir\x20-\x20blendRegionSize\x20*\x200.5\x20+\x20blendRegionOffset,\x201.0e-10\x20-\x20blendRegionSize,\x200.99999);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20aroundHorizon\x20=\x20clamp(horizonDotNadir\x20+\x20blendRegionSize\x20*\x200.5,\x201.0e-10\x20-\x20blendRegionSize,\x200.99999);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20farBelowHorizon\x20=\x20clamp(horizonDotNadir\x20+\x20blendRegionSize\x20*\x201.5,\x201.0e-10\x20-\x20blendRegionSize,\x200.99999);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20smoothstepHeight\x20=\x20smoothstep(0.0,\x20atmosphereHeight,\x20horizonDotNadir);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20belowHorizonColor\x20=\x20mix(vec3(0.1,\x200.15,\x200.25),\x20vec3(0.4,\x200.7,\x200.9),\x20smoothstepHeight);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20nadirColor\x20=\x20belowHorizonColor\x20*\x200.5;\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20aboveHorizonColor\x20=\x20mix(vec3(0.9,\x201.0,\x201.2),\x20belowHorizonColor,\x20roughness\x20*\x200.5);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20blueSkyColor\x20=\x20mix(vec3(0.18,\x200.26,\x200.48),\x20aboveHorizonColor,\x20reflectionDotNadir\x20*\x20inverseRoughness\x20*\x200.5\x20+\x200.75);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20zenithColor\x20=\x20mix(blueSkyColor,\x20sceneSkyBox,\x20smoothstepHeight);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20blueSkyDiffuseColor\x20=\x20vec3(0.7,\x200.85,\x200.9);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20diffuseIrradianceFromEarth\x20=\x20(1.0\x20-\x20horizonDotNadir)\x20*\x20(reflectionDotNadir\x20*\x200.25\x20+\x200.75)\x20*\x20smoothstepHeight;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20diffuseIrradianceFromSky\x20=\x20(1.0\x20-\x20smoothstepHeight)\x20*\x20(1.0\x20-\x20(reflectionDotNadir\x20*\x200.25\x20+\x200.25));\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20diffuseIrradiance\x20=\x20blueSkyDiffuseColor\x20*\x20clamp(diffuseIrradianceFromEarth\x20+\x20diffuseIrradianceFromSky,\x200.0,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20notDistantRough\x20=\x20(1.0\x20-\x20horizonDotNadir\x20*\x20roughness\x20*\x200.8);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20specularIrradiance\x20=\x20mix(zenithColor,\x20aboveHorizonColor,\x20smoothstep(farAboveHorizon,\x20aroundHorizon,\x20reflectionDotNadir)\x20*\x20notDistantRough);\x0a\x20\x20\x20\x20\x20\x20\x20\x20specularIrradiance\x20=\x20mix(specularIrradiance,\x20belowHorizonColor,\x20smoothstep(aroundHorizon,\x20farBelowHorizon,\x20reflectionDotNadir)\x20*\x20inverseRoughness);\x0a\x20\x20\x20\x20\x20\x20\x20\x20specularIrradiance\x20=\x20mix(specularIrradiance,\x20nadirColor,\x20smoothstep(farBelowHorizon,\x201.0,\x20reflectionDotNadir)\x20*\x20inverseRoughness);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20float\x20LdotZenith\x20=\x20clamp(dot(normalize(czm_inverseViewRotation\x20*\x20l),\x20normalize(positionWC\x20*\x20-1.0)),\x200.001,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20S\x20=\x20acos(LdotZenith);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20NdotZenith\x20=\x20clamp(dot(normalize(czm_inverseViewRotation\x20*\x20n),\x20normalize(positionWC\x20*\x20-1.0)),\x200.001,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20gamma\x20=\x20acos(NdotL);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20numerator\x20=\x20((0.91\x20+\x2010.0\x20*\x20exp(-3.0\x20*\x20gamma)\x20+\x200.45\x20*\x20pow(NdotL,\x202.0))\x20*\x20(1.0\x20-\x20exp(-0.32\x20/\x20NdotZenith)));\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20denominator\x20=\x20(0.91\x20+\x2010.0\x20*\x20exp(-3.0\x20*\x20S)\x20+\x200.45\x20*\x20pow(LdotZenith,2.0))\x20*\x20(1.0\x20-\x20exp(-0.32));\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20luminance\x20=\x200.2\x20*\x20(numerator\x20/\x20denominator);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20brdfLut\x20=\x20texture2D(czm_brdfLut,\x20vec2(NdotV,\x20roughness)).rg;\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20IBLColor\x20=\x20(diffuseIrradiance\x20*\x20diffuseColor\x20*\x201.0)\x20+\x20(specularIrradiance\x20*\x20SRGBtoLINEAR3(specularColor\x20*\x20brdfLut.x\x20+\x20brdfLut.y)\x20*\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20maximumComponent\x20=\x20max(max(lightColorHdr.x,\x20lightColorHdr.y),\x20lightColorHdr.z);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20lightColor\x20=\x20lightColorHdr\x20/\x20max(maximumComponent,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20IBLColor\x20*=\x20lightColor;\x0a\x20\x20\x20\x20\x20\x20\x20\x20color\x20+=\x20IBLColor\x20*\x20luminance;\x0a\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20mat3\x20fixedToENU\x20=\x20mat3(czm_modelView[0][0],\x20czm_modelView[1][0],\x20czm_modelView[2][0],\x20czm_modelView[0][1],\x20czm_modelView[1][1],\x20czm_modelView[2][1],\x20czm_modelView[0][2],\x20czm_modelView[1][2],\x20czm_modelView[2][2]);\x0a\x20\x20\x20\x20\x20\x20\x20\x20const\x20mat3\x20yUpToZUp\x20=\x20mat3(-1.0,\x200.0,\x200.0,\x200.0,\x200.0,\x20-1.0,\x200.0,\x201.0,\x200.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20cubeDir\x20=\x20normalize(yUpToZUp\x20*\x20fixedToENU\x20*\x20reflect(-v,\x20n));\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20diffuseIrradiance\x20=\x20czm_sphericalHarmonics(cubeDir,\x20czm_sphericalHarmonicCoefficients);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20brdfLut\x20=\x20texture2D(czm_brdfLut,\x20vec2(NdotV,\x20roughness)).rg;\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec3\x20specularIBL\x20=\x20czm_sampleOctahedralProjection(czm_specularEnvironmentMaps,\x20czm_specularEnvironmentMapSize,\x20cubeDir,\x20\x20roughness\x20*\x20czm_specularEnvironmentMapsMaximumLOD,\x20czm_specularEnvironmentMapsMaximumLOD);\x0a\x20\x20\x20\x20\x20\x20\x20\x20specularIBL\x20*=\x20F\x20*\x20brdfLut.x\x20+\x20brdfLut.y;\x0a\x20\x20\x20\x20\x20\x20\x20\x20color\x20+=\x20diffuseIrradiance\x20*\x20diffuseColor\x20+\x20specularColor\x20*\x20specularIBL;\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20color\x20=\x20applyTonemapping(color);\x0a\x20\x20\x20\x20\x20\x20\x20\x20color\x20=\x20LINEARtoSRGB(color);\x0a\x20\x20\x20\x20\x20\x20\x20\x20outColor\x20=\x20vec4(color,\x20baseColorWithAlpha.a);\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20#ifdef\x20HYPSOMETRIC\x0a\x20\x20\x20\x20\x20\x20\x20\x20outColor\x20=\x20getContourMapColor(outColor,\x20wValue);\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20#ifdef\x20CLIP\x0a\x20\x20\x20\x20\x20\x20\x20\x20outColor\x20*=\x20clip(vec4(vPositionEC,\x201.0));\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20gl_FragColor\x20=\x20outColor;\x0a\x20\x20\x20\x20}\x0a','3rCcmtA','83273IAiMHc','5ePEbGY','1KWZCOX','75303vuMMhR','97wubmyY','1CtOGHI','266983vMQijH'];var _0x468426=_0x308c;function _0x308c(_0x50759a,_0x5af293){_0x50759a=_0x50759a-0x130;var _0x5dc3d3=_0x5dc3[_0x50759a];return _0x5dc3d3;}(function(_0x3a6d26,_0x40549d){var _0x3851ef=_0x308c;while(!![]){try{var _0x2a3541=parseInt(_0x3851ef(0x138))*parseInt(_0x3851ef(0x137))+parseInt(_0x3851ef(0x130))*-parseInt(_0x3851ef(0x13d))+-parseInt(_0x3851ef(0x134))*parseInt(_0x3851ef(0x13c))+-parseInt(_0x3851ef(0x13b))*parseInt(_0x3851ef(0x139))+parseInt(_0x3851ef(0x132))*parseInt(_0x3851ef(0x13a))+parseInt(_0x3851ef(0x135))*-parseInt(_0x3851ef(0x133))+parseInt(_0x3851ef(0x131));if(_0x2a3541===_0x40549d)break;else _0x3a6d26['push'](_0x3a6d26['shift']());}catch(_0x5c63d0){_0x3a6d26['push'](_0x3a6d26['shift']());}}}(_0x5dc3,0x33ccc));var _0x5c0b8e = _0x468426(0x136);

    var _0x1bd2=['142690UlDDbP','5056RJbgMS','precision\x20highp\x20float;\x0aconst\x20float\x20uPixelRatio\x20=\x201.0;\x0a//\x20Inputs\x0aattribute\x20vec3\x20aPosition0;\x0aattribute\x20vec3\x20aPosition1;\x0a//attribute\x20float\x20aVariantOffset;\x0a//attribute\x20float\x20aVariantStroke;\x0a//attribute\x20float\x20aVariantExtension;\x0a\x0a#ifdef\x20SILHOUETTE\x0aattribute\x20vec3\x20aNormalA;\x0aattribute\x20vec3\x20aNormalB;\x0a#else\x20/*\x20SILHOUETTE\x20*/\x0aattribute\x20vec3\x20aNormal;\x0a#endif\x20/*\x20SILHOUETTE\x20*/\x0a\x0aattribute\x20vec2\x20aSideness;\x0a//attribute\x20vec2\x20aPackedAttributes;\x0a\x0astruct\x20UnpackedAttributes\x0a{\x0a\x20\x20\x20\x20vec2\x20sideness;\x0a\x20\x20\x20\x20vec2\x20sidenessNorm;\x0a\x20\x20\x20\x20float\x20lineWidthPixels;\x0a\x20\x20\x20\x20float\x20extensionLengthPixels;\x0a#if\x20(MODE\x20==\x202)\x0a\x20\x20\x20\x20float\x20type;\x0a#endif\x0a};\x0a\x0a//\x20Output\x20required\x20to\x20compute\x20color\x0avarying\x20vec4\x20vColor;\x0a//\x20Output\x20required\x20to\x20compute\x20distance\x20to\x20line/caps\x0avarying\x20vec3\x20vPosition;\x20\x0avarying\x20vec3\x20vViewPosition;\x0avarying\x20float\x20vRadius;\x0avarying\x20float\x20vLineLengthPixels;\x0avarying\x20float\x20vSizeFalloffFactor;\x0avarying\x20float\x20vDistanceFromEye;\x0a\x0auniform\x20float\x20uLineWidth;\x0auniform\x20vec4\x20uLineColor;\x0aconst\x20vec2\x20uDepthBias\x20=\x20vec2(0.5,\x20-4e-4);\x0a\x0a//\x20Utility\x20function\x20to\x20check\x20for\x20NaN\x20values\x0abool\x20isNaN(float\x20val)\x0a{\x0a\x20\x20\x20\x20return\x20(\x20val\x20<\x200.0\x20||\x200.0\x20<\x20val\x20||\x20val\x20==\x200.0\x20)\x20?\x20false\x20:\x20true;\x0a\x20\x20\x20\x20//\x20important:\x20some\x20nVidias\x20failed\x20to\x20cope\x20with\x20version\x20below.\x0a\x20\x20\x20\x20//\x20Probably\x20wrong\x20optimization.\x0a\x20\x20\x20\x20/*return\x20(\x20val\x20<=\x200.0\x20||\x200.0\x20<=\x20val\x20)\x20?\x20false\x20:\x20true;*/\x0a}\x0a\x0avec2\x20calculateProjectedBiasXY(vec4\x20projPos,\x20vec3\x20worldNormal)\x0a{\x0a\x20\x20\x20\x20float\x20offsetXY\x20=\x20uDepthBias.x;\x0a\x20\x20\x20\x20float\x20offsetZ\x20\x20=\x20uDepthBias.y;\x0a\x20\x20\x20\x20vec4\x20projNormal\x20=\x20czm_projection\x20*\x20czm_view\x20*\x20vec4(worldNormal,\x200.0);\x0a\x20\x20\x20\x20return\x20offsetXY\x20*\x20projPos.w\x20*\x202.0\x20/\x20czm_viewport.zw\x20*\x20normalize(projNormal.xyz).xy;\x0a}\x0a\x0a//\x20A\x20z-offset,\x20using\x20a\x20depth\x20based\x20heuristic.\x0afloat\x20calculateProjectedBiasZ(vec4\x20projPos)\x0a{\x0a\x20\x20\x20\x20float\x20fProjZ\x20=\x20projPos.z\x20/\x20projPos.w;\x0a\x20\x20\x20\x20if(fProjZ\x20<\x200.1)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x200.0;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20float\x20offsetZ\x20=\x20uDepthBias.y;\x0a\x20\x20\x20\x20return\x20sqrt(projPos.z)\x20*\x20offsetZ;\x0a}\x0a\x0avec4\x20adjustProjectedPosition(vec4\x20projPos,\x20vec3\x20worldNormal,\x20float\x20lineWidth)\x0a{\x0a\x20\x20\x20\x20vec2\x20offsetXY\x20=\x20calculateProjectedBiasXY(projPos,\x20worldNormal);\x0a\x20\x20\x20\x20//\x20we\x20currently\x20have\x20to\x20do\x20this\x20check\x20because\x20some\x20geometries\x20come\x20with\x200\x20length\x20edge\x20normals.\x0a\x20\x20\x20\x20if\x20(!isNaN(offsetXY.x)\x20&&\x20!isNaN(offsetXY.y))\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20projPos.xy\x20+=\x20offsetXY;\x0a\x20\x20\x20\x20}\x0a#ifdef\x20LOG_DEPTH\x0a\x20\x20\x20\x20vDistanceFromEye\x20=\x20projPos.w;\x0a#else\x0a\x20\x20\x20\x20projPos.z\x20+=\x20calculateProjectedBiasZ(projPos);\x0a#endif\x0a\x20\x20\x20\x20return\x20projPos;\x0a}\x0a\x0a#if\x20(MODE\x20==\x202\x20||\x20MODE\x20==\x201)\x0auniform\x20vec2\x20uStrokesTextureScale;\x0auniform\x20float\x20uStrokesLog2Resolution;\x0auniform\x20float\x20uStrokeVariants;\x0avarying\x20vec2\x20vStrokeUV;\x0avarying\x20float\x20vLineIndex;\x0avoid\x20calculateStyleOutputsSketch(float\x20lineLength,\x20UnpackedAttributes\x20unpackedAttributes)\x0a{\x0a\x20\x20\x20\x20vec2\x20sidenessNorm\x20=\x20unpackedAttributes.sidenessNorm;\x0a\x20\x20\x20\x20float\x20lineIndex\x20=\x20clamp(ceil(log2(lineLength)),\x200.0,\x20uStrokesLog2Resolution);\x0a\x20\x20\x20\x20vStrokeUV\x20=\x20vec2(exp2(lineIndex)\x20*\x20sidenessNorm.y,\x20lineIndex\x20*\x20uStrokeVariants\x20+\x20aVariantStroke\x20+\x200.5)\x20*\x20uStrokesTextureScale;\x0a\x20\x20\x20\x20vStrokeUV.x\x20+=\x20aVariantOffset;\x0a\x20\x20\x20\x20vLineIndex\x20=\x20lineIndex;\x0a}\x0a#endif\x0a\x0a#if\x20(MODE\x20==\x200)\x0avoid\x20calculateStyleOutputs(vec4\x20viewPosV0,\x20vec4\x20viewPosV1,\x20vec4\x20worldPosV0,\x20vec4\x20worldPosV1,\x20vec4\x20projPos,\x20vec3\x20worldNormal,\x20UnpackedAttributes\x20unpackedAttributes)\x0a{}\x0a#elif\x20(MODE\x20==\x201)\x0avoid\x20calculateStyleOutputs(vec4\x20viewPosV0,\x20vec4\x20viewPosV1,\x20vec4\x20worldPosV0,\x20vec4\x20worldPosV1,\x20vec4\x20projPos,\x20vec3\x20worldNormal,\x20UnpackedAttributes\x20unpackedAttributes)\x0a{\x0a\x20\x20\x20\x20calculateStyleOutputsSketch(vLineLengthPixels,\x20unpackedAttributes);\x0a}\x0a#elif\x20(MODE\x20==\x202)\x0avarying\x20float\x20vType;\x0avoid\x20calculateStyleOutputs(vec4\x20viewPosV0,\x20vec4\x20viewPosV1,\x20vec4\x20worldPosV0,\x20vec4\x20worldPosV1,\x20vec4\x20projPos,\x20vec3\x20worldNormal,\x20UnpackedAttributes\x20unpackedAttributes)\x0a{\x0a\x20\x20\x20\x20vType\x20=\x20unpackedAttributes.type;\x0a\x20\x20\x20\x20if\x20(unpackedAttributes.type\x20<=\x200.0)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20calculateStyleOutputsSketch(vLineLengthPixels,\x20unpackedAttributes);\x0a\x20\x20\x20\x20}\x0a}\x0a#endif\x0a\x0a\x0a//\x20Solid\x0a#if\x20(MODE\x20==\x202\x20||\x20MODE\x20==\x200)\x0afloat\x20calculateLineAmplitudeSolid()\x0a{\x0a\x20\x20\x20\x20return\x200.0;\x0a}\x0a#endif\x0a#if\x20(MODE\x20==\x200)\x0afloat\x20calculateLineAmplitude(UnpackedAttributes\x20unpackedAttributes)\x0a{\x0a\x20\x20\x20\x20return\x20calculateLineAmplitudeSolid();\x0a}\x0a#endif\x0a//\x20Sketch\x0a#if\x20(MODE\x20==\x202\x20||\x20MODE\x20==\x201)\x0a\x20\x20\x20\x20uniform\x20float\x20uStrokesAmplitude;\x0afloat\x20calculateLineAmplitudeSketch()\x0a{\x0a\x20\x20\x20\x20return\x20uStrokesAmplitude;\x0a}\x0a#endif\x0a#if\x20(MODE\x20==\x201)\x0afloat\x20calculateLineAmplitude(UnpackedAttributes\x20unpackedAttributes)\x0a{\x0a\x20\x20\x20\x20return\x20calculateLineAmplitudeSketch();\x0a}\x0a#endif\x0a//\x20Uber\x0a#if\x20(MODE\x20==\x202)\x0afloat\x20calculateLineAmplitude(UnpackedAttributes\x20unpackedAttributes)\x0a{\x0a\x20\x20\x20\x20float\x20type\x20=\x20unpackedAttributes.type;\x0a\x20\x20\x20\x20if\x20(type\x20<=\x200.0)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20calculateLineAmplitudeSketch();\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20else\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20calculateLineAmplitudeSolid();\x0a\x20\x20\x20\x20}\x0a}\x0a#endif\x0a\x0a\x0auniform\x20float\x20uDistanceFalloffFactor;\x0afloat\x20distanceBasedPerspectiveFactor(float\x20distance)\x0a{\x0a\x20\x20\x20\x20return\x20clamp(sqrt(uDistanceFalloffFactor\x20/\x20distance),\x200.0,\x201.0);\x0a}\x0a\x0a#define\x20COMPONENT_COLOR_FIELD_OFFSET\x200.0\x0a#define\x20COMPONENT_OTHER_FIELDS_OFFSET\x201.0\x0a#define\x20COMPONENT_FIELD_COUNT\x202.0\x0a#define\x20LINE_WIDTH_FRACTION_FACTOR\x208.0\x0a#define\x20EXTENSION_LENGTH_OFFSET\x20128.0\x0a#define\x20COMPONENT_TEX_WIDTH\x204096.0\x0a\x0astruct\x20ComponentData\x0a{\x0a\x20\x20\x20\x20float\x20lineWidth;\x0a\x20\x20\x20\x20float\x20extensionLength;\x0a\x20\x20\x20\x20float\x20type;\x0a};\x0a\x0a\x0aComponentData\x20readComponentData()\x0a{\x0a\x20\x20\x20\x20return\x20ComponentData(uLineWidth,\x200.0,\x200.0);\x0a}\x0a\x0avec3\x20modelToWorldNormal(vec3\x20normal)\x0a{\x0a\x20\x20\x20\x20return\x20(czm_model\x20*\x20vec4(normal,\x200.0)).xyz;\x0a}\x0a\x0avec3\x20silhouetteWorldNormal(vec3\x20normalA,\x20vec3\x20normalB)\x0a{\x0a\x20\x20\x20\x20return\x20modelToWorldNormal(normalize(normalA\x20+\x20normalB));\x0a}\x0a\x0a//\x20Fall-off\x20extension\x20length\x20for\x20shorter\x20strokes,\x20starting\x20from\x20strokes\x20that\x20are\x20256\x20size,\x0a//\x20fall-off\x20exponentially\x0afloat\x20calculateExtensionLength(float\x20extensionLength,\x20float\x20lineLength)\x0a{\x0a\x20\x20\x20\x20return\x20extensionLength\x20/\x20(log2(max(1.0,\x20256.0\x20/\x20lineLength))\x20*\x200.2\x20+\x201.0);\x0a}\x0a\x0a#ifdef\x20SILHOUETTE\x0a//\x20#uniforms:\x20czm_view,\x20czm_model\x0abool\x20isSilhouetteEdge(vec4\x20viewPos,\x20vec3\x20normalA,\x20vec3\x20normalB)\x0a{\x0a//\x20transform\x20the\x20two\x20face\x20normals\x0a\x20\x20\x20\x20vec3\x20viewNormalA\x20=\x20(czm_view\x20*\x20czm_model\x20*\x20vec4(normalA,\x200.0)).xyz;\x0a\x20\x20\x20\x20vec3\x20viewNormalB\x20=\x20(czm_view\x20*\x20czm_model\x20*\x20vec4(normalB,\x200.0)).xyz;\x0a//\x20compute\x20the\x20direction\x20from\x20the\x20edge\x20to\x20the\x20camera\x0a\x20\x20\x20\x20vec3\x20viewDir\x20=\x20-viewPos.xyz;\x0a//\x20check\x20which\x20of\x20the\x20two\x20faces\x20are\x20visible\x0a//\x20display\x20the\x20edge\x20if\x20exactly\x20one\x20of\x20the\x20two\x20is\x20visible\x0a\x20\x20\x20\x20float\x20faceAVisible\x20=\x20dot(viewDir,\x20viewNormalA);\x0a//\x20positive\x20if\x20visible\x0a\x20\x20\x20\x20float\x20faceBVisible\x20=\x20dot(viewDir,\x20viewNormalB);\x0a//\x20positive\x20if\x20visible\x0a//\x201\x20if\x20exactly\x20one\x20face\x20visible,\x200\x20otherwise\x0a\x20\x20\x20\x20return\x20faceAVisible\x20*\x20faceBVisible\x20<\x200.0;\x0a}\x0a#endif\x20/*\x20SILHOUETTE\x20*/\x0a\x0avoid\x20clipLineSegmentToNearPlane(vec3\x20p0,vec3\x20p1,out\x20bool\x20clipped,out\x20bool\x20culledByNearPlane,out\x20vec4\x20clippedPositionEC)\x0a{\x0a\x20\x20\x20\x20culledByNearPlane\x20=\x20false;\x0a\x20\x20\x20\x20clipped\x20=\x20false;\x0a\x20\x20\x20\x20vec3\x20p0ToP1\x20=\x20p1\x20-\x20p0;\x0a\x20\x20\x20\x20float\x20magnitude\x20=\x20length(p0ToP1);\x0a\x20\x20\x20\x20vec3\x20direction\x20=\x20normalize(p0ToP1);\x0a\x20\x20\x20\x20float\x20endPoint0Distance\x20=\x20\x20czm_currentFrustum.x\x20+\x20p0.z;\x0a\x20\x20\x20\x20float\x20denominator\x20=\x20-direction.z;\x0a\x20\x20\x20\x20if\x20(endPoint0Distance\x20>\x200.0\x20&&\x20abs(denominator)\x20<\x20czm_epsilon7)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20culledByNearPlane\x20=\x20true;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20else\x20if\x20(endPoint0Distance\x20>\x200.0)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20t\x20=\x20endPoint0Distance\x20/\x20denominator;\x0a\x20\x20\x20\x20\x20\x20\x20\x20if\x20(t\x20<\x200.0\x20||\x20t\x20>\x20magnitude)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20culledByNearPlane\x20=\x20true;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20p0\x20=\x20p0\x20+\x20t\x20*\x20direction;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20p0.z\x20=\x20min(p0.z,\x20-czm_currentFrustum.x);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20clipped\x20=\x20true;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20clippedPositionEC\x20=\x20vec4(p0,\x201.0);\x0a}\x0a\x0afloat\x20writeNonPerspective(float\x20value,\x20float\x20w)\x20{\x0a\x20\x20\x20\x20return\x20value\x20*\x20w;\x0a}\x0a\x0avec2\x20writeNonPerspective(vec2\x20value,\x20float\x20w)\x20{\x0a\x20\x20\x20\x20return\x20value\x20*\x20w;\x0a}\x0a\x0avec3\x20writeNonPerspective(vec3\x20value,\x20float\x20w)\x20{\x0a\x20\x20\x20\x20return\x20value\x20*\x20w;\x0a}\x0a\x0avec4\x20writeNonPerspective(vec4\x20value,\x20float\x20w)\x20{\x0a\x20\x20\x20\x20return\x20value\x20*\x20w;\x0a}\x0a\x0avec4\x20calculateGeometricOutputs(vec4\x20viewPosV0,\x20vec4\x20viewPosV1,\x20vec4\x20worldPosV0,\x20vec4\x20worldPosV1,\x20vec3\x20worldNormal,\x20UnpackedAttributes\x20unpackedAttributes)\x0a{\x0a\x20\x20\x20\x20vec2\x20sideness\x20=\x20unpackedAttributes.sideness;\x0a\x20\x20\x20\x20vec2\x20sidenessNorm\x20=\x20unpackedAttributes.sidenessNorm;\x0a\x20\x20\x20\x20vec4\x20clippedViewPosV0;\x20\x20\x20\x20bool\x20clippedV0,culledV0;\x20\x20\x20\x20clipLineSegmentToNearPlane(viewPosV0.xyz,\x20viewPosV1.xyz,\x20clippedV0,\x20culledV0,\x20clippedViewPosV0);\x20\x20\x20\x20vec4\x20clippedViewPosV1;\x20\x20\x20\x20bool\x20clippedV1,\x20culledV1;\x20\x20\x20\x20clipLineSegmentToNearPlane(viewPosV1.xyz,\x20viewPosV0.xyz,\x20clippedV1,\x20culledV1,\x20clippedViewPosV1);\x20\x20\x20\x20vec4\x20viewPos\x20=\x20mix(clippedViewPosV0,\x20clippedViewPosV1,\x20sidenessNorm.y);\x0a\x20\x20\x20\x20vViewPosition\x20=\x20viewPos.xyz\x20/\x20viewPos.w;\x0a\x20\x20\x20\x20vec4\x20projPosV0\x20=\x20czm_projection\x20*\x20clippedViewPosV0;\x0a\x20\x20\x20\x20vec4\x20projPosV1\x20=\x20czm_projection\x20*\x20clippedViewPosV1;\x0a\x20\x20\x20\x20vec4\x20projPos\x20=\x20czm_projection\x20*\x20viewPos;\x0a\x20\x20\x20\x20vec3\x20screenSpaceLineNDC\x20=\x20(projPosV1.xyz\x20/\x20projPosV1.w\x20-\x20projPosV0.xyz\x20/\x20projPosV0.w);\x0a\x20\x20\x20\x20vec2\x20uNDCToPixel\x20=\x20vec2(czm_viewport.z\x20/\x202.0,\x20czm_viewport.w\x20/\x202.0);\x0a\x20\x20\x20\x20vec2\x20screenSpaceLinePixels\x20=\x20screenSpaceLineNDC.xy\x20*\x20uNDCToPixel;\x0a\x20\x20\x20\x20float\x20lineLengthPixels\x20=\x20length(screenSpaceLinePixels);\x0a\x20\x20\x20\x20float\x20dzPerPixel\x20=\x20screenSpaceLineNDC.z\x20/\x20lineLengthPixels;\x0a\x20\x20\x20\x20vec2\x20screenSpaceDirection\x20=\x20screenSpaceLinePixels\x20/\x20lineLengthPixels;\x0a\x20\x20\x20\x20vec2\x20perpendicularScreenSpaceDirection\x20=\x20vec2(screenSpaceDirection.y,\x20-screenSpaceDirection.x)\x20*\x20sideness.x;\x0a\x20\x20\x20\x20float\x20falloffFactor\x20=\x20distanceBasedPerspectiveFactor(-viewPos.z)\x20*\x20uPixelRatio;\x0a\x20\x20\x20\x20float\x20lineWidthPixels\x20=\x20unpackedAttributes.lineWidthPixels\x20*\x20falloffFactor;\x0a\x20\x20\x20\x20float\x20extensionLengthPixels\x20=\x20calculateExtensionLength(unpackedAttributes.extensionLengthPixels,\x20lineLengthPixels)\x20*\x20falloffFactor;\x0a\x20\x20\x20\x20float\x20lineAmplitudePixels\x20=\x20calculateLineAmplitude(unpackedAttributes)\x20*\x20uPixelRatio;\x0a\x20\x20\x20\x20vSizeFalloffFactor\x20=\x20falloffFactor;\x0a\x20\x20\x20\x20float\x20lineWidthAndAmplitudePixels\x20=\x20lineWidthPixels\x20+\x20lineAmplitudePixels\x20+\x20lineAmplitudePixels;\x0a\x20\x20\x20\x20float\x20extendedLineLengthPixels\x20=\x20lineLengthPixels\x20+\x20extensionLengthPixels\x20+\x20extensionLengthPixels;\x0a#ifdef\x20ANTIALIASING\x0a\x20\x20\x20\x20const\x20float\x20aaPaddingPixels\x20=\x201.0;\x0a\x20\x20\x20\x20//\x20Line\x20size\x20with\x20padding\x0a\x20\x20\x20\x20float\x20halfAAPaddedLineWidthAndAmplitudePixels\x20=\x20lineWidthAndAmplitudePixels\x20*\x200.5\x20+\x20aaPaddingPixels;\x0a\x20\x20\x20\x20float\x20aaPaddedRoundedCapSizePixels\x20=\x20lineWidthPixels\x20*\x200.5\x20+\x20aaPaddingPixels;\x0a\x20\x20\x20\x20//\x20Line\x20length\x20with\x20padding\x0a\x20\x20\x20\x20float\x20aaPaddedLineLengthPixels\x20=\x20extendedLineLengthPixels\x20+\x20aaPaddingPixels\x20+\x20aaPaddingPixels;\x0a\x20\x20\x20\x20float\x20halfAAPaddedLineLengthPixels\x20=\x20aaPaddedLineLengthPixels\x20*\x200.5;\x0a#else\x20/*\x20ANTIALIASING\x20*/\x0a\x20\x20\x20\x20//\x20Even\x20if\x20there\x20is\x20no\x20AA,\x20we\x20still\x20want\x20to\x20do\x20proper\x20<1px\x20rendering,\x0a\x20\x20\x20\x20//\x20so\x20we\x20effectively\x20clamp\x20the\x20pixel\x20sizes\x20to\x20minimum\x20of\x201px\x20and\x20compute\x0a\x20\x20\x20\x20//\x20coverage\x20in\x20the\x20fragment\x20shader\x20\x20\x20\x0a\x20\x20\x20\x20float\x20halfAAPaddedLineWidthAndAmplitudePixels\x20=\x20max(lineWidthAndAmplitudePixels,\x201.0)\x20*\x200.5;\x0a\x20\x20\x20\x20float\x20aaPaddedRoundedCapSizePixels\x20=\x20max(lineWidthPixels,\x201.0)\x20*\x200.5;\x0a\x20\x20\x20\x20float\x20halfAAPaddedLineLengthPixels\x20=\x20max(extendedLineLengthPixels,\x201.0)\x20*\x200.5;\x0a#endif\x20/*\x20ANTIALIASING\x20*/\x0a\x20\x20\x20\x20//\x20Half\x20line\x20width\x20in\x20NDC\x20including\x20padding\x20for\x20anti\x20aliasing\x0a\x20\x20\x20\x20vec2\x20uPixelToNDC\x20=\x20vec2(2.0\x20/\x20czm_viewport.z,\x202.0\x20/\x20czm_viewport.w);\x0a\x20\x20\x20\x20vec2\x20halfAAPaddedLineWidthAndAmplitudeNDC\x20=\x20halfAAPaddedLineWidthAndAmplitudePixels\x20*\x20uPixelToNDC;\x0a\x20\x20\x20\x20vec2\x20aaPaddedRoundedCapSizeNDC\x20=\x20aaPaddedRoundedCapSizePixels\x20*\x20uPixelToNDC;\x0a\x20\x20\x20\x20vec2\x20extensionLengthNDC\x20=\x20extensionLengthPixels\x20*\x20uPixelToNDC;\x0a\x20\x20\x20\x20//\x20Compute\x20screen\x20space\x20position\x20of\x20vertex,\x20offsetting\x20for\x20line\x20size\x20and\x20end\x20caps\x0a\x20\x20\x20\x20vec2\x20ndcOffset\x20=\x20(screenSpaceDirection\x20*\x20sideness.y\x20*\x20(aaPaddedRoundedCapSizeNDC\x20+\x20extensionLengthNDC)\x20+\x20perpendicularScreenSpaceDirection\x20*\x20halfAAPaddedLineWidthAndAmplitudeNDC);\x0a\x20\x20\x20\x20projPos.xy\x20+=\x20ndcOffset\x20*\x20projPos.w;\x0a\x20\x20\x20\x20projPos.z\x20+=\x20(dzPerPixel\x20*\x20(aaPaddedRoundedCapSizePixels\x20+\x20extensionLengthPixels))\x20*\x20sideness.y\x20*\x20projPos.w;\x0a\x20\x20\x20\x20projPos\x20=\x20adjustProjectedPosition(projPos,\x20worldNormal,\x201.0\x20+\x20max((lineWidthAndAmplitudePixels\x20-\x201.0)\x20*\x200.5,\x200.0));\x0a\x20\x20\x20\x20//\x20Line\x20length\x20with\x20end\x20caps\x0a\x20\x20\x20\x20float\x20aaPaddedLineWithCapsLengthPixels\x20=\x20extendedLineLengthPixels\x20+\x20aaPaddedRoundedCapSizePixels\x20+\x20aaPaddedRoundedCapSizePixels;\x0a\x20\x20\x20\x20float\x20pixelPositionAlongLine\x20=\x20aaPaddedLineWithCapsLengthPixels\x20*\x20sidenessNorm.y\x20-\x20aaPaddedRoundedCapSizePixels;\x0a\x20\x20\x20\x20//\x20Position\x20in\x20pixels\x20with\x20origin\x20at\x20first\x20vertex\x20of\x20line\x20segment\x0a\x20\x20\x20\x20//\x20The\x20line\x20width\x20radius\x20in\x20pixels\x0a\x20\x20\x20\x20vRadius\x20=\x20lineWidthPixels\x20*\x200.5;\x0a\x20\x20\x20\x20vLineLengthPixels\x20=\x20extendedLineLengthPixels;\x0a\x20\x20\x20\x20vPosition\x20=\x20writeNonPerspective(vec3(halfAAPaddedLineWidthAndAmplitudePixels\x20*\x20sideness.x,\x20pixelPositionAlongLine,\x20pixelPositionAlongLine\x20/\x20extendedLineLengthPixels),\x20projPos.w);\x0a#ifdef\x20SILHOUETTE\x0a\x20\x20\x20\x20gl_Position\x20=\x20isSilhouetteEdge(viewPosV0,\x20aNormalA,\x20aNormalB)\x20?\x20projPos\x20:\x20vec4(10.0,\x2010.0,\x2010.0,\x201.0);\x0a#else\x20/*\x20SILHOUETTE\x20*/\x0a\x20\x20\x20\x20gl_Position\x20=\x20projPos;\x0a#endif\x20/*\x20SILHOUETTE\x20*/\x0a\x0a#if\x20(MODE\x20==\x202)\x0a\x20\x20\x20\x20if\x20(unpackedAttributes.type\x20<=\x200.0\x20&&\x20lineLengthPixels\x20<=\x203.0)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20gl_Position\x20=\x20vec4(10.0,\x2010.0,\x2010.0,\x201.0);\x0a\x20\x20\x20\x20}\x0a#elif\x20(MODE\x20==\x201)\x0a\x20\x20\x20\x20if\x20(lineLengthPixels\x20<=\x203.0)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20gl_Position\x20=\x20vec4(10.0,\x2010.0,\x2010.0,\x201.0);\x20\x0a\x20\x20\x20\x20}\x0a#endif\x0a\x20\x20\x20\x20return\x20projPos;\x0a}\x0a\x0a\x0a#if\x20(MODE\x20==\x202)\x0aUnpackedAttributes\x20unpackAttributes(ComponentData\x20component)\x0a{\x0a\x20\x20\x20\x20vec2\x20sidenessNorm\x20=\x20aSideness;\x0a\x20\x20\x20\x20vec2\x20sideness\x20=\x20sidenessNorm\x20*\x202.0\x20-\x201.0;\x0a\x20\x20\x20\x20float\x20fType\x20=\x20component.type;\x0a\x20\x20\x20\x20float\x20extensionLengthPixels\x20=\x20component.extensionLength;\x0a\x20\x20\x20\x20float\x20lineWidth\x20=\x20component.lineWidth;\x0a\x20\x20\x20\x20if\x20(fType\x20<=\x200.0)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20extensionLengthPixels\x20*=\x20aVariantExtension\x20*\x202.0\x20-\x201.0;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20return\x20UnpackedAttributes(sideness,\x20sidenessNorm,\x20lineWidth,\x20extensionLengthPixels,\x20fType);\x0a}\x0a#else\x20/*\x20(MODE\x20==\x202)\x20*/\x0aUnpackedAttributes\x20unpackAttributes(ComponentData\x20component)\x0a{\x0a\x20\x20\x20\x20vec2\x20sidenessNorm\x20=\x20aSideness;\x0a\x20\x20\x20\x20vec2\x20sideness\x20=\x20sidenessNorm\x20*\x202.0\x20-\x201.0;\x0a\x20\x20\x20\x20float\x20extensionLengthPixels\x20=\x20component.extensionLength;\x0a#if\x20(MODE\x20==\x201)\x0a\x20\x20\x20\x20extensionLengthPixels\x20*=\x20aVariantExtension\x20*\x202.0\x20-\x201.0;\x0a#endif\x0a\x20\x20\x20\x20float\x20lineWidth\x20=\x20component.lineWidth;\x0a\x20\x20\x20\x20return\x20UnpackedAttributes(sideness,\x20sidenessNorm,\x20lineWidth,\x20extensionLengthPixels);\x0a}\x0a#endif\x20/*\x20(MODE\x20==\x202)\x20*/\x0a\x0avarying\x20float\x20fSelected;\x0avoid\x20main()\x0a{\x0a\x20\x20\x20\x20fSelected\x20=\x200.0;\x0a\x20\x20\x20\x20ComponentData\x20component\x20=\x20readComponentData();\x0a\x20\x20\x20\x20UnpackedAttributes\x20unpackedAttributes\x20=\x20unpackAttributes(component);\x0a\x20\x20\x20\x20vec4\x20worldPosV0\x20=\x20czm_model\x20*\x20vec4(aPosition0,\x201.0);\x0a\x20\x20\x20\x20vec4\x20worldPosV1\x20=\x20czm_model\x20*\x20vec4(aPosition1,\x201.0);\x0a\x20\x20\x20\x20vec4\x20viewPosV0\x20=\x20czm_modelView\x20*\x20vec4(aPosition0,\x201.0);\x0a\x20\x20\x20\x20vec4\x20viewPosV1\x20=\x20czm_modelView\x20*\x20vec4(aPosition1,\x201.0);\x0a#ifdef\x20SILHOUETTE\x0a\x20\x20\x20\x20vec3\x20worldNormal\x20=\x20silhouetteWorldNormal(aNormalA,\x20aNormalB);\x0a#else\x20/*\x20SILHOUETTE\x20*/\x0a\x20\x20\x20\x20vec3\x20worldNormal\x20=\x20modelToWorldNormal(aNormal);\x0a#endif\x20/*\x20SILHOUETTE\x20*/\x0a\x20\x20\x20\x20//\x20General\x20geometric\x20computation\x20for\x20all\x20types\x20of\x20edges\x0a\x20\x20\x20\x20vec4\x20projPos\x20=\x20calculateGeometricOutputs(viewPosV0,\x20viewPosV1,\x20worldPosV0,\x20worldPosV1,\x20worldNormal,\x20unpackedAttributes);\x0a\x20\x20\x20\x20vColor\x20=\x20uLineColor;\x0a}','2802NesfVy','4HHXXWE','1rdtBMZ','59671gTQude','598163YmnQnJ','52jiKQRJ','355920KxYSVR','1XvWWny','124007GAYhZt'];var _0x3314ef=_0x4455;(function(_0x12277e,_0x5a49cb){var _0x18e1fa=_0x4455;while(!![]){try{var _0x4de1fa=-parseInt(_0x18e1fa(0x1b1))*-parseInt(_0x18e1fa(0x1ae))+parseInt(_0x18e1fa(0x1ad))+parseInt(_0x18e1fa(0x1b0))+parseInt(_0x18e1fa(0x1ab))*-parseInt(_0x18e1fa(0x1aa))+-parseInt(_0x18e1fa(0x1b3))+parseInt(_0x18e1fa(0x1b2))*-parseInt(_0x18e1fa(0x1ac))+-parseInt(_0x18e1fa(0x1a8))*parseInt(_0x18e1fa(0x1af));if(_0x4de1fa===_0x5a49cb)break;else _0x12277e['push'](_0x12277e['shift']());}catch(_0x3eece6){_0x12277e['push'](_0x12277e['shift']());}}}(_0x1bd2,0x73769));function _0x4455(_0x5d9b53,_0x14a1b7){_0x5d9b53=_0x5d9b53-0x1a8;var _0x1bd282=_0x1bd2[_0x5d9b53];return _0x1bd282;}var _0x524135 = _0x3314ef(0x1a9);

    var _0x2af0=['117841SsPtWr','83204modYjP','423596raHqZP','17vZikbY','28165Qianjn','87833anNdXA','1QAWpAu','\x0a#ifdef\x20GL_OES_standard_derivatives\x0a#extension\x20GL_OES_standard_derivatives\x20:\x20enable\x0a#endif\x0aprecision\x20highp\x20float;\x0avarying\x20vec4\x20vColor;\x0avarying\x20float\x20vRadius;\x0avarying\x20vec3\x20vPosition;\x0avarying\x20vec3\x20vViewPosition;\x0avarying\x20float\x20vLineLengthPixels;\x0avarying\x20float\x20vSizeFalloffFactor;\x0avarying\x20float\x20vLineIndex;\x0avarying\x20float\x20vDistanceFromEye;\x0a\x0a//\x20At\x20which\x20coverage\x20threshold\x20we\x20discard\x20a\x20fragment\x20completely\x0a#define\x20COVERAGE_TEST_THRESHOLD\x200.01\x0aconst\x20float\x20nearRange\x20=\x201000.0;\x0aconst\x20float\x20farRange\x20=\x2020000.0;\x0a\x0a//\x20Sketch\x0a#if\x20(MODE\x20==\x202\x20||\x20MODE\x20==\x201)\x0a//uniform\x20sampler2D\x20uStrokesTexture;\x0a//uniform\x20float\x20uStrokesNormalizationScale;\x0avarying\x20vec2\x20vStrokeUV;\x0a\x0afloat\x20calculateLineOffsetSketch()\x0a{\x0a\x20\x20\x20\x20//float\x20offsetNorm\x20=\x20rgba2float(texture2D(uStrokesTexture,\x20vStrokeUV));\x0a\x20\x20\x20\x20//return\x20(offsetNorm\x20-\x200.5)\x20*\x20uStrokesNormalizationScale;\x0a\x20\x20\x20\x20return\x201.0;\x0a}\x0a\x0afloat\x20calculateLinePressureSketch()\x0a{\x0a\x20\x20\x20\x20//return\x20rgba2float(texture2D(uStrokesTexture,\x20vStrokeUV\x20+\x20vec2(0.0,\x200.5)));\x0a\x20\x20\x20\x20return\x201.0;\x0a}\x0a#endif\x0a\x0a#if\x20(MODE\x20==\x201)\x0afloat\x20calculateLineOffset()\x0a{\x0a\x20\x20\x20\x20return\x20calculateLineOffsetSketch();\x0a}\x0afloat\x20calculateLinePressure()\x0a{\x0a\x20\x20\x20\x20return\x20calculateLinePressureSketch();\x0a}\x0a#endif\x0a\x0a//\x20Solid\x0a#if\x20(MODE\x20==\x202\x20||\x20MODE\x20==\x200)\x0afloat\x20calculateLineOffsetSolid()\x0a{\x0a\x20\x20\x20\x20return\x200.0;\x0a}\x0afloat\x20calculateLinePressureSolid()\x0a{\x0a\x20\x20\x20\x20return\x201.0;\x0a}\x0a#endif\x0a\x0a#if\x20(MODE\x20==\x200)\x0afloat\x20calculateLineOffset()\x0a{\x0a\x20\x20\x20\x20return\x20calculateLineOffsetSolid();\x0a}\x0afloat\x20calculateLinePressure()\x0a{\x0a\x20\x20\x20\x20return\x20calculateLinePressureSolid();\x0a}\x0a#endif\x0a\x0a//\x20Uber\x0a#if\x20(MODE\x20==\x202)\x0avarying\x20float\x20vType;\x0afloat\x20calculateLineOffset()\x0a{\x0a\x20\x20\x20\x20if\x20(vType\x20<=\x200.0)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20calculateLineOffsetSketch();\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20else\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20calculateLineOffsetSolid();\x0a\x20\x20\x20\x20}\x0a}\x0a\x0afloat\x20calculateLinePressure()\x0a{\x0a\x20\x20\x20\x20if\x20(vType\x20<=\x200.0)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20calculateLinePressureSketch();\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20else\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20calculateLinePressureSolid();\x0a\x20\x20\x20\x20}\x0a}\x0a#endif\x0a\x0avec2\x20lineWithCapsDistance(float\x20radius,\x20vec2\x20position,\x20float\x20lineLength)\x0a{\x0a\x20\x20\x20\x20float\x20lineOffset\x20=\x20calculateLineOffset();\x0a\x20\x20\x20\x20float\x20positionX\x20=\x20position.x\x20-\x20lineOffset;\x0a\x20\x20\x20\x20if\x20(radius\x20<\x201.0)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20coverageX\x20=\x20clamp(min(radius,\x20positionX\x20+\x200.5)\x20-\x20max(-radius,\x20positionX\x20-\x200.5),\x200.0,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20coverageY\x20=\x20clamp(min(lineLength,\x20position.y\x20+\x200.5)\x20-\x20max(0.0,\x20position.y\x20-\x200.5),\x200.0,\x201.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20coverage\x20=\x20min(coverageX,\x20coverageY);\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20vec2(0.5\x20-\x20coverage,\x200.0);\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20else\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20//\x20Between\x20-radius\x20->\x200\x20for\x20start\x20cap,\x200\x20for\x20line,\x200\x20->\x20radius\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20positionOnCap\x20=\x20position.y\x20-\x20clamp(position.y,\x200.0,\x20lineLength);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20lineToPosition\x20=\x20vec2(positionX,\x20positionOnCap);\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20vec2(length(lineToPosition)\x20-\x20radius,\x20positionOnCap\x20/\x20radius);\x0a\x20\x20\x20\x20}\x0a}\x0a\x0a#ifdef\x20CLIP\x0a\x20\x20\x20\x20uniform\x20float\x20uClipMode;\x0a\x20\x20\x20\x20uniform\x20vec4\x20uClipPlanes[6];\x0a\x20\x20\x20\x20float\x20getClipDistance(vec3\x20pos,\x20vec3\x20planeNormal,\x20float\x20disToOrigin)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20dot(planeNormal,\x20pos)\x20+\x20disToOrigin;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20float\x20clipBehindAllPlane(float\x20fBorderWidth,\x20vec4\x20vertex)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20distance\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20result\x20=\x20-1.0;\x0a\x20\x20\x20\x20#ifdef\x20CLIPPLANE\x0a\x20\x20\x20\x20\x20\x20\x20\x20distance\x20=\x20getClipDistance(vertex.xyz,\x20uClipPlanes[0].xyz,\x20uClipPlanes[0].w);\x0a\x20\x20\x20\x20\x20\x20\x20\x20if\x20(distance\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x201.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x20if\x20(distance\x20<\x20fBorderWidth)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20result\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20for(int\x20i\x20=\x200;\x20i\x20<\x206;\x20i++)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20distance\x20=\x20getClipDistance(vertex.xyz,\x20uClipPlanes[i].xyz,\x20uClipPlanes[i].w);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20if(distance\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x201.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(distance\x20<\x20fBorderWidth)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20result\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20result;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20float\x20clipBehindAnyPlane(float\x20fBorderWidth,\x20vec4\x20vertex)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20result\x20=\x201.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20for(int\x20i\x20=\x200;\x20i\x20<\x206;\x20i++)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20float\x20distance\x20=\x20getClipDistance(vertex.xyz,\x20uClipPlanes[i].xyz,\x20uClipPlanes[i].w);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20if((distance\x20+\x20fBorderWidth)\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20-1.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(distance\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20result\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20result;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20float\x20clipAnythingButLine(float\x20fBorderWidth,\x20vec4\x20vertex)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20result\x20=\x20-1.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20for(int\x20i\x20=\x200;\x20i\x20<\x206;\x20i++)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20float\x20distance\x20=\x20getClipDistance(vertex.xyz,\x20uClipPlanes[i].xyz,\x20uClipPlanes[i].w);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20if(distance\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20-1.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(distance\x20<\x20fBorderWidth)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20result\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20result;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20vec4\x20clip(vec4\x20vertex)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(uClipMode\x20<\x200.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20vec4(1.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20#ifdef\x20GL_OES_standard_derivatives\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dxc\x20=\x20abs(dFdx(vertex.x));\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dyc\x20=\x20abs(dFdy(vertex.y));\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20fBorderWidth\x20=\x20max(dxc,\x20dyc);\x0a\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20fBorderWidth\x20=\x201.0;\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20clipResult\x20=\x201.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(uClipMode\x20<\x201.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20clipResult\x20=\x20clipBehindAnyPlane(fBorderWidth,\x20vertex);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(uClipMode\x20<\x202.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20clipResult\x20=\x20clipBehindAllPlane(fBorderWidth,\x20vertex);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(uClipMode\x20<\x203.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20clipResult\x20=\x20clipAnythingButLine(fBorderWidth,\x20vertex);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(clipResult\x20<\x20-0.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20discard;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(clipResult\x20<\x200.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20vec4(1.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20vec4(1.0);\x0a\x20\x20\x20\x20}\x0a#endif\x0a\x0a#ifdef\x20APPLY_SWIPE\x0a\x20\x20\x20\x20uniform\x20vec4\x20uSwipeRegion;\x0a\x20\x20\x20\x20void\x20rollerShutter(vec2\x20coord,\x20vec4\x20region)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20f\x20=\x20step(region.xw,\x20coord);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20s\x20=\x20step(coord,\x20region.zy);\x0a\x20\x20\x20\x20\x20\x20\x20\x20if\x20(f.x\x20*\x20f.y\x20*\x20s.x\x20*\x20s.y\x20<\x201.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20discard;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20}\x0a#endif\x0a\x0afloat\x20readNonPerspective(float\x20value,\x20float\x20oneOverW)\x20{\x0a\x20\x20\x20\x20return\x20value\x20*\x20oneOverW;\x0a}\x0a\x0avec2\x20readNonPerspective(vec2\x20value,\x20float\x20oneOverW)\x20{\x0a\x20\x20\x20\x20return\x20value\x20*\x20oneOverW;\x0a}\x0a\x0avec3\x20readNonPerspective(vec3\x20value,\x20float\x20oneOverW)\x20{\x0a\x20\x20\x20\x20return\x20value\x20*\x20oneOverW;\x0a}\x0a\x0avec4\x20readNonPerspective(vec4\x20value,\x20float\x20oneOverW)\x20{\x0a\x20\x20\x20\x20return\x20value\x20*\x20oneOverW;\x0a}\x0a\x0avoid\x20main()\x0a{\x0a\x20\x20\x20\x20vec3\x20realPosition\x20=\x20readNonPerspective(vPosition,\x20gl_FragCoord.w);\x0a\x20\x20\x20\x20float\x20radius\x20=\x20vRadius\x20*\x20calculateLinePressure();\x0a\x20\x20\x20\x20vec2\x20distance\x20=\x20lineWithCapsDistance(radius,\x20realPosition.xy,\x20vLineLengthPixels);\x0a\x20\x20\x20\x20float\x20coverage\x20=\x20clamp(0.5\x20-\x20distance.x,\x200.0,\x201.0);\x0a#ifdef\x20ANTIALIASING\x0a\x20\x20\x20\x20const\x20float\x20coverageLimit\x20=\x20COVERAGE_TEST_THRESHOLD;\x0a#else\x0a\x20\x20\x20\x20/*\x20ANTIALIASING\x20*/\x0a\x20\x20\x20\x20//\x20Use\x20subpixel\x20coverage\x20computation\x20when\x20lines\x20get\x20subpixel\x20widths\x0a\x20\x20\x20\x20//\x20so\x20we\x20still\x20render\x20them\x20appropriately.\x20Otherwise\x20discard\x20anything\x0a\x20\x20\x20\x20//\x20that\x20is\x20not\x20fully\x20within\x20the\x20line\x0a\x20\x20\x20\x20float\x20coverageLimit\x20=\x20radius\x20<=\x200.5\x20?\x20COVERAGE_TEST_THRESHOLD\x20:\x200.75;\x0a#endif\x20/*\x20ANTIALIASING\x20*/\x0a\x20\x20\x20\x20if\x20(coverage\x20<\x20coverageLimit)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20discard;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20float\x20alpha\x20=\x20vColor.a\x20*\x20coverage;\x0a\x20\x20\x20\x20gl_FragColor\x20=\x20vec4(vColor.rgb,\x20alpha);\x0a#ifdef\x20APPLY_SWIPE\x0a\x20\x20\x20\x20\x20rollerShutter(gl_FragCoord.xy,\x20uSwipeRegion);\x0a#endif\x0a\x0a#ifdef\x20CLIP\x0a\x20\x20\x20\x20\x20gl_FragColor\x20*=\x20clip(vec4(vViewPosition,\x201.0),\x201.0);\x0a#endif\x0a\x0a\x20\x20\x20\x20\x20float\x20attenuation\x20=\x201.0\x20-\x20smoothstep(nearRange,\x20farRange,\x20vDistanceFromEye);\x0a\x20\x20\x20\x20\x20gl_FragColor.a\x20*=\x20attenuation;\x0a\x20\x20\x20\x20\x20czm_writeLogDepth();\x0a}','1nDxeCX','29147QmGxAQ','576147pfSwFA'];var _0x1909aa=_0x2330;function _0x2330(_0x4a16b4,_0x500cb8){_0x4a16b4=_0x4a16b4-0x1ca;var _0x2af0af=_0x2af0[_0x4a16b4];return _0x2af0af;}(function(_0x4b1224,_0x44294b){var _0x3cf9f3=_0x2330;while(!![]){try{var _0x24df80=-parseInt(_0x3cf9f3(0x1d1))*parseInt(_0x3cf9f3(0x1d2))+-parseInt(_0x3cf9f3(0x1cc))+parseInt(_0x3cf9f3(0x1cd))+-parseInt(_0x3cf9f3(0x1d0))+parseInt(_0x3cf9f3(0x1d4))*parseInt(_0x3cf9f3(0x1ce))+parseInt(_0x3cf9f3(0x1cb))+parseInt(_0x3cf9f3(0x1cf))*-parseInt(_0x3cf9f3(0x1ca));if(_0x24df80===_0x44294b)break;else _0x4b1224['push'](_0x4b1224['shift']());}catch(_0x3cfd08){_0x4b1224['push'](_0x4b1224['shift']());}}}(_0x2af0,0x56549));var _0x16f8f5 = _0x1909aa(0x1d3);

    const _0x2bc4=['1011629wkrYyc','yOffset','subTextureInfo','xOffset','init','width','41evyIix','execute','158koCjnl','context','54696gSMgrQ','4853bEawsO','3PBRuus','972260cCdGYf','1015553LRWXxh','5063ZfNPjo','texture','1jRmGep','model','163837zRfcZt','arrayBufferView'];const _0x1c65cc=_0x1109;(function(_0x337131,_0x4c2c6e){const _0x26f7c6=_0x1109;while(!![]){try{const _0x525dea=-parseInt(_0x26f7c6(0x86))+parseInt(_0x26f7c6(0x81))*parseInt(_0x26f7c6(0x84))+parseInt(_0x26f7c6(0x88))*parseInt(_0x26f7c6(0x7f))+-parseInt(_0x26f7c6(0x79))+parseInt(_0x26f7c6(0x85))*parseInt(_0x26f7c6(0x8c))+-parseInt(_0x26f7c6(0x8a))*-parseInt(_0x26f7c6(0x83))+parseInt(_0x26f7c6(0x87));if(_0x525dea===_0x4c2c6e)break;else _0x337131['push'](_0x337131['shift']());}catch(_0x5903b9){_0x337131['push'](_0x337131['shift']());}}}(_0x2bc4,0x86d24));function SubTextureUploadJob(){const _0x221acb=_0x1109;this['model']=undefined,this[_0x221acb(0x82)]=undefined,this[_0x221acb(0x89)]=undefined,this[_0x221acb(0x7b)]=undefined;}SubTextureUploadJob['prototype']['set']=function(_0x14eade,_0x2dff72,_0x393379,_0x138781){const _0x3be161=_0x1109;this[_0x3be161(0x8b)]=_0x2dff72,this[_0x3be161(0x82)]=_0x14eade,this[_0x3be161(0x89)]=_0x393379,this[_0x3be161(0x7b)]=_0x138781;},SubTextureUploadJob['prototype'][_0x1c65cc(0x80)]=function(){const _0x5ab7f3=_0x1c65cc;let _0x5992a5=this[_0x5ab7f3(0x7b)];!this['texture']['ready']&&this['texture'][_0x5ab7f3(0x7d)](),this[_0x5ab7f3(0x89)]['copyFrom']({'xOffset':_0x5992a5[_0x5ab7f3(0x7c)],'yOffset':_0x5992a5[_0x5ab7f3(0x7a)],'width':_0x5992a5[_0x5ab7f3(0x7e)],'height':_0x5992a5['height'],'arrayBufferView':_0x5992a5[_0x5ab7f3(0x78)]});};function _0x1109(_0x296863,_0x2cb940){_0x296863=_0x296863-0x78;let _0x2bc434=_0x2bc4[_0x296863];return _0x2bc434;}

    const _0xfd82=['dequeue','isDestroyed','bTransparentSorting','material','CLIPPLANE','pickColorIdentifier','ancestorTexture','_hypsometric','LineInterval','TRANSLUCENT','width','primitiveType','edgeTotalLength','157784Afxgdg','222882MdEkFS','clone','TRIANGLES','DepthFunction','1020282YwkyNX','edgeCount','drawingBufferHeight','vertexArray','_addRenderedEdge','createBuffers','colorCommand','vertexPackage','POLYGON_OFFSET','Cartesian2','shaderProgram','1123CeakJD','batchTableBake','defines','BlendingState','isTexBlock','_edgeDistanceFalloffFactor','_clipPlane','batchTable','ShaderSource','edgeGeometry','lineColor','style3D','silhouetteEdgeCommand','createPickIds','_swipeRegion','POINTS','_textureStep','26000sQGllc','ColorTableMinKey','_enableClipPlane','arrIndexPackage','ALPHA_BLEND','drawingBufferWidth','APPLY_SWIPE','height','ColorTableMaxKey','subTexturesToUpload','fillStyle','createShaderProgram','push','initTexture','ready','batchTableDirty','LESS_OR_EQUAL','getUniformMapCallback','textures','call','uniformMap','fromCache','VertexArray','createSilhouetteEdgeAttributes','269CQxzdK','attributes','RenderState','vertexBufferToCreate','836643YyvTPn','Fill','attributeLocations','swipeEnabled','length','MODE\x20','instanceCount','bounds','requestSubTextures','texMatrix','indexBuffer','indexBufferToCreate','OPAQUE','LINES','combine','Pass','renderable','invGeoMatrix','SILHOUETTE','_texture','prototype','edgeSP','boundingVolume','TEXTURE','layer','geoMatrix','createRegularEdgeAttributes','execute','_enableClip','ANTIALIASING','DrawCommand','set','modelMatrix','createOneEdgeCommand','subTextureInfo','commandList','76932tOLjcP','regular','_flattenPar','silhouette','createWireFrame','edgeLength','noValueColor','initLayerSetting','useLineColor','JobType','setting','destroy','shaderProgramToCreate','PrimitiveType','MaxVisibleValue','updateMaterialBatchTable','edgeVA','selectedColor','pickInfo','update','BoundingSphere','createCommand','Cartesian4','context','vertexAttributes','regularEdgeCommand','ShaderProgram','_clipMode'];function _0x34ea(_0x2148bd,_0x103412){_0x2148bd=_0x2148bd-0x18b;let _0xfd82e=_0xfd82[_0x2148bd];return _0xfd82e;}const _0x5d3bc7=_0x34ea;(function(_0x1a5d8d,_0x3df23d){const _0x1ec51a=_0x34ea;while(!![]){try{const _0x2ec176=-parseInt(_0x1ec51a(0x1eb))+-parseInt(_0x1ec51a(0x1c7))+parseInt(_0x1ec51a(0x18b))+parseInt(_0x1ec51a(0x1c3))*parseInt(_0x1ec51a(0x19a))+parseInt(_0x1ec51a(0x1ab))+-parseInt(_0x1ec51a(0x214))+parseInt(_0x1ec51a(0x18f));if(_0x2ec176===_0x3df23d)break;else _0x1a5d8d['push'](_0x1a5d8d['shift']());}catch(_0xc0f43d){_0x1a5d8d['push'](_0x1a5d8d['shift']());}}}(_0xfd82,0x7a0b4));function S3MCacheFileRenderEntity(_0x37db72){const _0x22ba07=_0x34ea;RenderEntity[_0x22ba07(0x1be)](this,_0x37db72),this['vs']=_0x5ab4ab,this['fs']=_0x5c0b8e,this['edgeVA']=undefined,this[_0x22ba07(0x1dc)]=undefined,this['regularEdgeCommand']=undefined,this[_0x22ba07(0x1a6)]=undefined,this[_0x22ba07(0x1f3)]=![];}S3MCacheFileRenderEntity[_0x5d3bc7(0x1db)]=Object['create'](RenderEntity[_0x5d3bc7(0x1db)]),S3MCacheFileRenderEntity['prototype']['constructor']=RenderEntity;function getOpaqueRenderState$1(){const _0xf9fee3=_0x5d3bc7;return Cesium['RenderState']['fromCache']({'cull':{'enabled':![]},'depthTest':{'enabled':!![],'func':Cesium[_0xf9fee3(0x18e)]['LESS_OR_EQUAL']},'blending':Cesium['BlendingState']['ALPHA_BLEND']});}function getTransparentRenderState$1(){const _0x1379fa=_0x5d3bc7;return Cesium['RenderState'][_0x1379fa(0x1c0)]({'cull':{'enabled':!![]},'depthTest':{'enabled':!![],'func':Cesium['DepthFunction'][_0x1379fa(0x1bb)]},'blending':Cesium[_0x1379fa(0x19d)][_0x1379fa(0x1af)]});}let hypMinMaxValueScratch$1=new Cesium['Cartesian4'](),hypOpacityIntervalFillModeScratch$1=new Cesium[(_0x5d3bc7(0x201))](),swipRegionScratch$1=new Cesium[(_0x5d3bc7(0x201))](),texDimScratch=new Cesium['Cartesian4']();function getUniformMap$1(_0x18a455,_0x1e96bd,_0xaa1b8d){return {'uGeoMatrix':function(){const _0x242b9f=_0x34ea;return _0xaa1b8d[_0x242b9f(0x1e0)];},'uTexMatrix':function(){const _0x53b41d=_0x34ea;return _0x18a455[_0x53b41d(0x1d0)];},'uFillForeColor':function(){const _0x4aad82=_0x34ea;if(_0xaa1b8d['useLineColor'])return _0x1e96bd[_0x4aad82(0x1a5)][_0x4aad82(0x1a4)];return _0x1e96bd[_0x4aad82(0x1a5)]['fillForeColor'];},'uInverseGeoMatrix':function(){const _0x21bf1f=_0x34ea;return _0xaa1b8d[_0x21bf1f(0x1d8)];},'uTexture':function(){const _0x55d454=_0x34ea;let _0x3d8bea=_0x18a455[_0x55d454(0x1bd)][0x0];if(_0x3d8bea[_0x55d454(0x19e)])return _0x3d8bea[_0x55d454(0x1d7)]&&_0x3d8bea[_0x55d454(0x1b9)]?_0x3d8bea:_0x18a455[_0x55d454(0x20d)]?_0x18a455[_0x55d454(0x20d)]:_0x3d8bea;return _0x18a455['textures'][0x0];},'uTexture2':function(){const _0x1d0d7b=_0x34ea;return _0x18a455[_0x1d0d7b(0x1bd)][0x1];},'uTexAtlasDim':function(){const _0x127edb=_0x34ea;let _0x280958=_0x18a455[_0x127edb(0x1bd)][0x0][_0x127edb(0x1d7)]?_0x18a455[_0x127edb(0x1bd)][0x0]:_0x18a455[_0x127edb(0x20d)]?_0x18a455['ancestorTexture']:_0x18a455[_0x127edb(0x1bd)][0x0];texDimScratch['x']=_0x280958[_0x127edb(0x211)],texDimScratch['y']=_0x280958[_0x127edb(0x1b2)];if(_0x18a455['textures'][0x1]){let _0x18d952=_0x18a455['textures'][0x1][_0x127edb(0x1d7)]?_0x18a455[_0x127edb(0x1bd)][0x1]:_0x18a455['ancestorTextureBake']?_0x18a455['ancestorTextureBake']:_0x18a455[_0x127edb(0x1bd)][0x1];texDimScratch['z']=_0x18d952[_0x127edb(0x211)],texDimScratch['w']=_0x18d952[_0x127edb(0x1b2)];}return texDimScratch;},'batchTextureAtlas':function(){const _0x3200a3=_0x34ea;return _0x18a455['batchTable'][_0x3200a3(0x1da)];},'batchTextureAtlasStep':function(){const _0x29d827=_0x34ea;return _0x18a455[_0x29d827(0x1a1)][_0x29d827(0x1aa)];},'batchTextureAtlasSec':function(){const _0x109a8d=_0x34ea;return _0x18a455[_0x109a8d(0x19b)][_0x109a8d(0x1da)];},'batchTextureAtlasStepSec':function(){const _0x195c31=_0x34ea;return _0x18a455[_0x195c31(0x19b)][_0x195c31(0x1aa)];},'uTexture0Width':function(){const _0x351677=_0x34ea;return _0x18a455['textures'][0x0][_0x351677(0x211)];},'uTexture1Width':function(){const _0x3fa47a=_0x34ea;return _0x18a455[_0x3fa47a(0x1bd)][0x1][_0x3fa47a(0x211)];},'uSelectedColor':function(){const _0x587862=_0x34ea;return _0x1e96bd[_0x587862(0x1fc)];},'uClipMode':function(){const _0x538a66=_0x34ea;return _0x1e96bd[_0x538a66(0x206)];},'uClipPlanes':function(){const _0x9b758f=_0x34ea;return _0x1e96bd[_0x9b758f(0x1a0)];},'uHypsometricTexture':function(){const _0x58418b=_0x34ea;return _0x1e96bd[_0x58418b(0x20e)]['texture'];},'uHypLineColor':function(){const _0x4e5a83=_0x34ea;return _0x1e96bd[_0x4e5a83(0x20e)][_0x4e5a83(0x1f5)]['LineColor'];},'uNoValueColor':function(){const _0x121922=_0x34ea;return _0x1e96bd[_0x121922(0x20e)][_0x121922(0x1f5)][_0x121922(0x1f1)];},'uMinMaxValue':function(){const _0x37b2ec=_0x34ea;let _0x3aab40=_0x1e96bd[_0x37b2ec(0x20e)][_0x37b2ec(0x1f5)];return hypMinMaxValueScratch$1['x']=_0x3aab40[_0x37b2ec(0x1ac)],hypMinMaxValueScratch$1['y']=_0x3aab40[_0x37b2ec(0x1b3)],hypMinMaxValueScratch$1['z']=_0x3aab40['MinVisibleValue'],hypMinMaxValueScratch$1['w']=_0x3aab40[_0x37b2ec(0x1f9)],hypMinMaxValueScratch$1;},'uOpacityIntervalFillMode':function(){const _0x5dca9b=_0x34ea;let _0x43c4c5=_0x1e96bd[_0x5dca9b(0x20e)][_0x5dca9b(0x1f5)];return hypOpacityIntervalFillModeScratch$1['x']=_0x43c4c5['Opacity'],hypOpacityIntervalFillModeScratch$1['y']=_0x43c4c5[_0x5dca9b(0x20f)],hypOpacityIntervalFillModeScratch$1['z']=_0x43c4c5['DisplayMode'],hypOpacityIntervalFillModeScratch$1;},'uFlattenRect':function(){const _0x585d33=_0x34ea;return _0x1e96bd[_0x585d33(0x1ed)][_0x585d33(0x1ce)];},'uFlattenTexture':function(){const _0x551d46=_0x34ea;return _0x1e96bd[_0x551d46(0x1ed)]['texture'];},'uSwipeRegion':function(){const _0x2707f5=_0x34ea,_0x427ec6=_0x1e96bd[_0x2707f5(0x202)];return swipRegionScratch$1['x']=_0x1e96bd[_0x2707f5(0x1a8)]['x']*_0x427ec6['drawingBufferWidth'],swipRegionScratch$1['y']=(0x1-_0x1e96bd[_0x2707f5(0x1a8)]['y'])*_0x427ec6[_0x2707f5(0x191)],swipRegionScratch$1['z']=_0x1e96bd[_0x2707f5(0x1a8)]['z']*_0x427ec6[_0x2707f5(0x1b0)],swipRegionScratch$1['w']=(0x1-_0x1e96bd['_swipeRegion']['w'])*_0x427ec6['drawingBufferHeight'],swipRegionScratch$1;}};}S3MCacheFileRenderEntity[_0x5d3bc7(0x1db)][_0x5d3bc7(0x1e8)]=function(_0x452ec7,_0x40bdd1,_0x2f72ac,_0x132047,_0x5c59ff){const _0x548e92=_0x5d3bc7;if(!_0x2f72ac[_0x548e92(0x1c4)]||_0x2f72ac['attributes'][_0x548e92(0x1cb)]==0x0||!_0x2f72ac[_0x548e92(0x1cd)]||_0x2f72ac[_0x548e92(0x1cd)]===0x0)return null;let _0x5762e0=new Cesium[(_0x548e92(0x1e5))]({'primitiveType':Cesium[_0x548e92(0x1f8)][_0x548e92(0x18d)],'modelMatrix':this['modelMatrix'],'boundingVolume':this[_0x548e92(0x1dd)],'pass':Cesium[_0x548e92(0x1d6)]['OPAQUE'],'owner':this,'cull':!![]});this['edgeVA']=new Cesium['VertexArray']({'context':_0x452ec7,'attributes':_0x2f72ac[_0x548e92(0x1c4)],'indexBuffer':_0x132047}),_0x5762e0['vertexArray']=this[_0x548e92(0x1fb)],_0x5762e0[_0x548e92(0x1cd)]=_0x2f72ac[_0x548e92(0x1cd)];let _0x4ed4c9,_0x842d3b;_0x4ed4c9=new Cesium['ShaderSource']({'sources':[_0x524135]}),_0x842d3b=new Cesium[(_0x548e92(0x1a2))]({'sources':[_0x16f8f5]});!_0x5c59ff&&(_0x4ed4c9['defines'][_0x548e92(0x1b7)](_0x548e92(0x1d9)),_0x842d3b[_0x548e92(0x19c)][_0x548e92(0x1b7)](_0x548e92(0x1d9)));_0x4ed4c9[_0x548e92(0x19c)][_0x548e92(0x1b7)](_0x548e92(0x1e4)),_0x842d3b[_0x548e92(0x19c)][_0x548e92(0x1b7)](_0x548e92(0x1e4)),_0x4ed4c9[_0x548e92(0x19c)][_0x548e92(0x1b7)](_0x548e92(0x197)),_0x842d3b['defines']['push'](_0x548e92(0x197));_0x40bdd1[_0x548e92(0x1ca)]&&_0x842d3b[_0x548e92(0x19c)][_0x548e92(0x1b7)](ProgramDefines[_0x548e92(0x1b1)]);_0x40bdd1[_0x548e92(0x1e3)]&&_0x842d3b[_0x548e92(0x19c)]['push']('CLIP');_0x40bdd1[_0x548e92(0x1ad)]&&_0x842d3b[_0x548e92(0x19c)][_0x548e92(0x1b7)](_0x548e92(0x20b));let _0x128469=0x0;_0x4ed4c9[_0x548e92(0x19c)]['push'](_0x548e92(0x1cc)+_0x128469),_0x842d3b[_0x548e92(0x19c)][_0x548e92(0x1b7)](_0x548e92(0x1cc)+_0x128469),this[_0x548e92(0x1dc)]=Cesium[_0x548e92(0x205)]['fromCache']({'context':_0x452ec7,'vertexShaderSource':_0x4ed4c9,'fragmentShaderSource':_0x842d3b,'attributeLocations':_0x2f72ac[_0x548e92(0x1c9)]}),_0x5762e0[_0x548e92(0x199)]=this[_0x548e92(0x1dc)],_0x5762e0['renderState']=Cesium[_0x548e92(0x1c5)][_0x548e92(0x1c0)]({'depthTest':{'enabled':!![],'func':Cesium[_0x548e92(0x18e)]['LESS_OR_EQUAL']},'cull':{'enabled':!![]},'blending':Cesium[_0x548e92(0x19d)][_0x548e92(0x1af)]});let _0x53a13f={'uLineColor':function(){const _0x59713c=_0x548e92;return _0x40bdd1[_0x59713c(0x1a5)][_0x59713c(0x1a4)];},'uLineWidth':function(){const _0x56cbdb=_0x548e92;return _0x40bdd1[_0x56cbdb(0x1a5)]['lineWidth'];},'uDistanceFalloffFactor':function(){const _0x56c3ff=_0x548e92;return _0x40bdd1[_0x56c3ff(0x19f)];},'u_polygonOffset':function(){const _0x29d49f=_0x548e92;return new Cesium[(_0x29d49f(0x198))](-0x5,-0x5);}};return _0x5762e0['uniformMap']=Cesium[_0x548e92(0x1d5)](_0x53a13f,this[_0x548e92(0x195)][_0x548e92(0x1bf)]),_0x5762e0['edgeTotalLength']=_0x2f72ac[_0x548e92(0x1f0)],_0x5762e0['edgeCount']=_0x2f72ac[_0x548e92(0x1cd)],_0x5762e0;},S3MCacheFileRenderEntity['prototype'][_0x5d3bc7(0x200)]=function(){const _0x280b1c=_0x5d3bc7;if(Cesium['defined'](this[_0x280b1c(0x195)])||this[_0x280b1c(0x1c6)][_0x280b1c(0x1cb)]!==0x0||this[_0x280b1c(0x1d2)][_0x280b1c(0x1cb)]!==0x0||this[_0x280b1c(0x1f7)][_0x280b1c(0x1cb)]!==0x0)return;let _0x53dbd6=this['layer'],_0x4fd6ed=_0x53dbd6['context'],_0x2b72a9=this['vertexPackage'],_0x25cb4d=this[_0x280b1c(0x1ae)],_0x5821a4=_0x2b72a9[_0x280b1c(0x203)];if(_0x25cb4d[_0x280b1c(0x1cb)]<0x1)return;let _0x42d6df=_0x25cb4d[0x0],_0x53445c=this[_0x280b1c(0x20a)];this['vertexArray']=new Cesium[(_0x280b1c(0x1c1))]({'context':_0x4fd6ed,'attributes':_0x5821a4,'indexBuffer':_0x42d6df[_0x280b1c(0x1d1)]});let _0x88b574=Cesium[_0x280b1c(0x1f8)]['TRIANGLES'];switch(_0x42d6df[_0x280b1c(0x212)]){case 0x1:_0x88b574=Cesium[_0x280b1c(0x1f8)][_0x280b1c(0x1a9)];break;case 0x2:_0x88b574=Cesium[_0x280b1c(0x1f8)][_0x280b1c(0x1d4)];break;case 0x4:_0x88b574=Cesium[_0x280b1c(0x1f8)][_0x280b1c(0x18d)];break;}this[_0x280b1c(0x1f3)]=_0x88b574===Cesium[_0x280b1c(0x1f8)][_0x280b1c(0x1d4)],this[_0x280b1c(0x195)]=new Cesium[(_0x280b1c(0x1e5))]({'primitiveType':_0x88b574,'modelMatrix':this['modelMatrix'],'boundingVolume':Cesium[_0x280b1c(0x1ff)][_0x280b1c(0x18c)](this['boundingVolume']),'pickId':this[_0x280b1c(0x20c)],'vertexArray':this[_0x280b1c(0x192)],'shaderProgram':this[_0x280b1c(0x199)],'pass':_0x53445c[_0x280b1c(0x209)]?Cesium[_0x280b1c(0x1d6)][_0x280b1c(0x210)]:Cesium[_0x280b1c(0x1d6)][_0x280b1c(0x1d3)],'renderState':_0x53445c[_0x280b1c(0x209)]?getTransparentRenderState$1():getOpaqueRenderState$1(),'instanceCount':_0x2b72a9[_0x280b1c(0x1cd)]});let _0x1b8608=getUniformMap$1(_0x53445c,_0x53dbd6,this);this['batchTable']&&(_0x1b8608=this['batchTable'][_0x280b1c(0x1bc)]()(_0x1b8608)),_0x53445c[_0x280b1c(0x1a1)]&&(_0x1b8608=_0x53445c['batchTable'][_0x280b1c(0x1bc)]()(_0x1b8608)),this['colorCommand'][_0x280b1c(0x1bf)]=_0x1b8608,this[_0x280b1c(0x196)]=undefined,this[_0x280b1c(0x1ae)]=undefined,this['vs']=undefined,this['fs']=undefined,this[_0x280b1c(0x1b9)]=!![];},S3MCacheFileRenderEntity['prototype'][_0x5d3bc7(0x1ef)]=function(_0x2ff55e){const _0x2f11c8=_0x5d3bc7;if(!this['colorCommand']||!this[_0x2f11c8(0x1a3)]||this[_0x2f11c8(0x204)])return;let _0x406a27=this[_0x2f11c8(0x1df)][_0x2f11c8(0x202)],_0x18aa9e=this[_0x2f11c8(0x1a3)];S3MEdgeProcessor[_0x2f11c8(0x1e1)](_0x406a27,_0x18aa9e[_0x2f11c8(0x1ec)]),S3MEdgeProcessor[_0x2f11c8(0x1c2)](_0x406a27,_0x18aa9e[_0x2f11c8(0x1ee)]);let _0x1a66a3=S3MEdgeProcessor['createIndexBuffer'](_0x406a27);this[_0x2f11c8(0x204)]=this[_0x2f11c8(0x1e8)](_0x406a27,this[_0x2f11c8(0x1df)],_0x18aa9e[_0x2f11c8(0x1ec)],_0x1a66a3,!![]),this[_0x2f11c8(0x1a6)]=this[_0x2f11c8(0x1e8)](_0x406a27,this[_0x2f11c8(0x1df)],_0x18aa9e['silhouette'],_0x1a66a3,![]);};let scratchSubTextureUploadJob=new SubTextureUploadJob();S3MCacheFileRenderEntity[_0x5d3bc7(0x1db)][_0x5d3bc7(0x1fa)]=function(_0x524389){const _0x281b08=_0x5d3bc7;this[_0x281b08(0x20a)][_0x281b08(0x1b8)](),this[_0x281b08(0x20a)][_0x281b08(0x1cf)](_0x524389,this['layer']);let _0x341c32=this['material'][_0x281b08(0x1b4)];while(_0x341c32[_0x281b08(0x1cb)]){let _0x595f28=_0x341c32['peek'](),_0x2e2cb9=_0x595f28['texture'],_0x1f42bd=_0x595f28[_0x281b08(0x1e9)];scratchSubTextureUploadJob[_0x281b08(0x1e6)](_0x524389['context'],this,_0x2e2cb9,_0x1f42bd);if(!_0x524389['jobScheduler'][_0x281b08(0x1e2)](scratchSubTextureUploadJob,Cesium[_0x281b08(0x1f4)][_0x281b08(0x1de)]))break;_0x341c32[_0x281b08(0x207)]();}_0x341c32[_0x281b08(0x1cb)]===0x0&&this[_0x281b08(0x20a)]['enableTextureRenderable'](),this[_0x281b08(0x20a)]['batchTable'][_0x281b08(0x1fe)](_0x524389);},S3MCacheFileRenderEntity['prototype']['update']=function(_0x311a1f,_0x54c7a9){const _0x508a09=_0x5d3bc7;if(!this[_0x508a09(0x1b9)]){this['createBatchTable'](_0x311a1f),this[_0x508a09(0x1a7)](),this[_0x508a09(0x194)](_0x311a1f),this[_0x508a09(0x1b6)](_0x311a1f),this[_0x508a09(0x200)](_0x311a1f),this['createWireFrame'](_0x311a1f),this[_0x508a09(0x1f2)](_0x54c7a9);return;}this[_0x508a09(0x1ba)]&&(this['updateBatchTableAttributes'](),this[_0x508a09(0x1ba)]=![]),this[_0x508a09(0x1a1)]&&this[_0x508a09(0x1a1)][_0x508a09(0x1fe)](_0x311a1f),this[_0x508a09(0x20a)][_0x508a09(0x1a1)]&&this[_0x508a09(0x1fa)](_0x311a1f),_0x54c7a9[_0x508a09(0x1a5)][_0x508a09(0x1b5)]!==_0x1b29d4['WireFrame']&&_0x311a1f[_0x508a09(0x1ea)][_0x508a09(0x1b7)](this[_0x508a09(0x195)]),_0x54c7a9[_0x508a09(0x1a5)][_0x508a09(0x1b5)]!==_0x1b29d4[_0x508a09(0x1c8)]&&(this[_0x508a09(0x204)]&&(_0x311a1f[_0x508a09(0x1ea)][_0x508a09(0x1b7)](this[_0x508a09(0x204)]),_0x54c7a9[_0x508a09(0x193)](this[_0x508a09(0x204)][_0x508a09(0x213)],this['regularEdgeCommand'][_0x508a09(0x190)])),this[_0x508a09(0x1a6)]&&(_0x311a1f[_0x508a09(0x1ea)][_0x508a09(0x1b7)](this['silhouetteEdgeCommand']),_0x54c7a9[_0x508a09(0x193)](this[_0x508a09(0x1a6)][_0x508a09(0x213)],this[_0x508a09(0x1a6)][_0x508a09(0x190)])));},S3MCacheFileRenderEntity['prototype'][_0x5d3bc7(0x208)]=function(){return ![];},S3MCacheFileRenderEntity['prototype'][_0x5d3bc7(0x1f6)]=function(){const _0x55b8a0=_0x5d3bc7;return this['shaderProgram']=this[_0x55b8a0(0x199)]&&!this[_0x55b8a0(0x199)]['isDestroyed']()&&this['shaderProgram'][_0x55b8a0(0x1f6)](),this[_0x55b8a0(0x192)]=this[_0x55b8a0(0x192)]&&!this[_0x55b8a0(0x192)][_0x55b8a0(0x208)]()&&this['vertexArray']['destroy'](),this[_0x55b8a0(0x20a)]=this['material']&&!this['material'][_0x55b8a0(0x208)]()&&this[_0x55b8a0(0x20a)][_0x55b8a0(0x1f6)](),this[_0x55b8a0(0x1a1)]=this[_0x55b8a0(0x1a1)]&&!this[_0x55b8a0(0x1a1)][_0x55b8a0(0x208)]()&&this[_0x55b8a0(0x1a1)][_0x55b8a0(0x1f6)](),this[_0x55b8a0(0x1fb)]=this[_0x55b8a0(0x1fb)]&&!this['edgeVA']['isDestroyed']()&&this[_0x55b8a0(0x1fb)]['destroy'](),this['edgeSP']=this[_0x55b8a0(0x1dc)]&&!this[_0x55b8a0(0x1dc)][_0x55b8a0(0x208)]()&&this[_0x55b8a0(0x1dc)][_0x55b8a0(0x1f6)](),this['colorCommand']=undefined,this[_0x55b8a0(0x196)]=null,this[_0x55b8a0(0x1ae)]=null,this[_0x55b8a0(0x1e7)]=undefined,this[_0x55b8a0(0x1fd)]=undefined,this['selectionInfoMap']=undefined,this['vs']=undefined,this['fs']=undefined,Cesium['destroyObject'](this);};

    var _0x9b65=['68YxNmnH','124586cLUoFg','1269HtaJoI','197246awpYYu','1dijVTr','3fzPxmO','5717nsSuDB','72383tkCqnv','3284aeYEjF','46EvdWtD','49459pikEKN','attribute\x20vec4\x20aPosition;\x0aattribute\x20vec4\x20aColor;\x0auniform\x20float\x20uPointCloudSize;\x0avarying\x20float\x20vPixelDistance;\x0a#ifdef\x20COMPRESS_VERTEX\x0a\x20\x20\x20\x20uniform\x20vec4\x20decode_position_min;\x0a\x20\x20\x20\x20uniform\x20float\x20decode_position_normConstant;\x0a#endif\x0a#ifdef\x20HYPSOMETRIC\x0a\x20\x20\x20\x20uniform\x20sampler2D\x20uHypsometricTexture;\x0a\x20\x20\x20\x20uniform\x20vec4\x20uMinMaxValue;\x0a\x20\x20\x20\x20uniform\x20vec4\x20uOpacityIntervalFillMode;\x0a\x20\x20\x20\x20uniform\x20vec4\x20uHypLineColor;\x0a\x20\x20\x20\x20uniform\x20vec4\x20uNoValueColor;\x0a\x20\x20\x20\x20uniform\x20float\x20uUseWValue;\x0a\x20\x20\x20\x20uniform\x20float\x20uBottom;\x0a#endif\x0a\x20\x20\x20\x20uniform\x20vec4\x20uFillForeColor;\x0a\x20\x20\x20\x20varying\x20vec4\x20vColor;\x0a\x20\x20\x20\x20varying\x20vec4\x20vPositionMC;\x0a\x0a#ifdef\x20HYPSOMETRIC\x0a\x0afloat\x20computeWValue(vec4\x20vertexPos){\x0a\x20\x20\x20\x20float\x20realWValue\x20=\x20vertexPos.w;\x0a#ifdef\x20TEXTURE_COORD_ONE_IS_W\x0a\x20\x20\x20\x20realWValue\x20=\x20aTexCoord0.x;\x0a#endif\x0a\x20\x20\x20\x20if(uUseWValue\x20>\x200.1)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20realWValue\x20+\x20uBottom;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20return\x20vertexPos.z\x20+\x20uBottom;\x0a}\x0a\x0avec4\x20computeContourMapColor(float\x20fValue)\x0a{\x0a\x20\x20\x20\x20float\x20floorValue\x20=\x20uMinMaxValue.x;\x0a\x20\x20\x20\x20float\x20ceilValue\x20=\x20uMinMaxValue.y;\x0a\x20\x20\x20\x20float\x20threshold\x20=\x20clamp(abs(ceilValue\x20-\x20floorValue),\x200.000001,\x2020000.0);\x0a\x20\x20\x20\x20float\x20contourRate\x20=\x20(fValue\x20-\x20floorValue)\x20/\x20threshold;\x0a\x20\x20\x20\x20float\x20finalCoord\x20=\x20clamp(contourRate,\x200.0,\x201.0);\x0a\x20\x20\x20\x20float\x20count\x20=\x20floor(finalCoord\x20*\x2016.0);\x0a\x20\x20\x20\x20float\x20y\x20=\x20(count*2.0\x20+\x201.0)/32.0;\x0a\x20\x20\x20\x20float\x20x\x20=\x20fract(finalCoord*16.0);\x0a\x20\x20\x20\x20if(y\x20>\x201.0)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20x\x20=\x201.0;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20return\x20texture2D(uHypsometricTexture,\x20vec2(x,\x20y)).rgba;\x0a}\x0avec4\x20getHypsometricColor(vec4\x20oriColor,\x20float\x20fValue)\x0a{\x0a\x20\x20\x20\x20vec4\x20contourMapColor\x20=\x20vec4(0.0);\x0a\x20\x20\x20\x20float\x20finalOpacity\x20=\x20uOpacityIntervalFillMode.x;\x0a\x20\x20\x20\x20float\x20fillMode\x20=\x20uOpacityIntervalFillMode.z;\x0a\x20\x20\x20\x20float\x20minVisibleValue\x20=\x20uMinMaxValue.z;\x0a\x20\x20\x20\x20float\x20maxVisibleValue\x20=\x20uMinMaxValue.w;\x0a\x20\x20\x20\x20if(fValue\x20>\x20maxVisibleValue\x20||\x20fValue\x20<\x20minVisibleValue)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20uNoValueColor\x20*\x20oriColor;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20contourMapColor\x20=\x20computeContourMapColor(fValue);\x0a\x20\x20\x20\x20finalOpacity\x20*=\x20sign(fillMode);\x0a\x20\x20\x20\x20vec4\x20mixColor\x20=\x20mix(vec4(1.0,1.0,1.0,1.0),\x20contourMapColor,\x20finalOpacity);\x0a\x20\x20\x20\x20return\x20mixColor;\x0a}\x0a#endif\x0a\x0avoid\x20main()\x0a{\x0a#ifdef\x20COMPRESS_VERTEX\x0a\x20\x20\x20\x20vec4\x20vertexPos\x20=\x20vec4(1.0);\x0a\x20\x20\x20\x20vertexPos\x20=\x20decode_position_min\x20+\x20aPosition\x20*\x20decode_position_normConstant;\x0a#else\x0a\x20\x20\x20\x20vec4\x20vertexPos\x20=\x20aPosition;\x0a#endif\x0a\x20\x20\x20\x20vertexPos.w\x20=\x201.0;\x0a\x20\x20\x20\x20vec4\x20vertexColor\x20=\x20aColor;\x0a\x20\x20\x20\x20vColor\x20=\x20vertexColor\x20*\x20uFillForeColor;\x0a\x20\x20\x20\x20vPositionMC.xyz\x20=\x20vertexPos.xyz;\x0a\x20\x20\x20\x20vPositionMC.w\x20=\x200.0;\x0a\x20\x20\x20\x20gl_Position\x20=\x20czm_modelViewProjection\x20*\x20vertexPos;\x0a#ifdef\x20HYPSOMETRIC\x0a\x20\x20\x20\x20float\x20wValue\x20=\x20computeWValue(vertexPos);\x0a\x20\x20\x20\x20vColor\x20=\x20getHypsometricColor(vColor,\x20wValue);\x0a#endif\x0a\x20\x20\x20\x20vPixelDistance\x20=\x202.0\x20/\x20uPointCloudSize;\x0a\x20\x20\x20\x20gl_PointSize\x20=\x20uPointCloudSize;\x0a}'];function _0x3f39(_0x47c5cf,_0x3d54d2){_0x47c5cf=_0x47c5cf-0x1a6;var _0x9b6562=_0x9b65[_0x47c5cf];return _0x9b6562;}var _0x42df81=_0x3f39;(function(_0x393c6c,_0x4f9b30){var _0xdd9b17=_0x3f39;while(!![]){try{var _0x8fd2b9=parseInt(_0xdd9b17(0x1ad))*-parseInt(_0xdd9b17(0x1ae))+parseInt(_0xdd9b17(0x1b0))+parseInt(_0xdd9b17(0x1af))*parseInt(_0xdd9b17(0x1b1))+parseInt(_0xdd9b17(0x1a7))*parseInt(_0xdd9b17(0x1a6))+-parseInt(_0xdd9b17(0x1aa))*parseInt(_0xdd9b17(0x1ac))+parseInt(_0xdd9b17(0x1a8))+parseInt(_0xdd9b17(0x1ab));if(_0x8fd2b9===_0x4f9b30)break;else _0x393c6c['push'](_0x393c6c['shift']());}catch(_0x301a86){_0x393c6c['push'](_0x393c6c['shift']());}}}(_0x9b65,0x408f5));var _0x28d577 = _0x42df81(0x1a9);

    var _0x2b4f=['719yujHsb','135947sSqGnl','582821FdxAZS','442569vxwJYq','175513DvZzIU','234100qzZsih','#ifdef\x20GL_OES_standard_derivatives\x0a#extension\x20GL_OES_standard_derivatives\x20:\x20enable\x0a#endif\x0a\x20\x20\x20\x20varying\x20vec4\x20vColor;\x0a\x20\x20\x20\x20varying\x20vec4\x20vPositionMC;\x0a\x20\x20\x20\x20varying\x20float\x20vPixelDistance;\x0a#ifdef\x20APPLY_SWIPE\x0a\x20\x20\x20\x20uniform\x20vec4\x20uSwipeRegion;\x0a\x20\x20\x20\x20void\x20rollerShutter(vec2\x20coord,\x20vec4\x20region)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20f\x20=\x20step(region.xw,\x20coord);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20s\x20=\x20step(coord,\x20region.zy);\x0a\x20\x20\x20\x20\x20\x20\x20\x20if\x20(f.x\x20*\x20f.y\x20*\x20s.x\x20*\x20s.y\x20<\x201.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20discard;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20}\x0a#endif\x0avoid\x20main()\x0a{\x0a#ifdef\x20APPLY_SWIPE\x20\x0a\x20\x20\x20\x20rollerShutter(gl_FragCoord.xy,\x20uSwipeRegion);\x0a#endif\x0a\x09if(vColor.a\x20<\x200.1)\x0a\x09{\x0a\x09\x09discard;\x0a\x09}\x0a\x20\x20\x20\x20gl_FragColor\x20=\x20vColor;\x0a\x20\x20\x20\x20float\x20distanceToCenter\x20=\x20length(gl_PointCoord\x20-\x20vec2(0.5));\x0a\x20\x20\x20\x20float\x20maxDistance\x20=\x20max(0.0,\x200.5\x20-\x20vPixelDistance);\x0a\x20\x20\x20\x20float\x20wholeAlpha\x20=\x201.0\x20-\x20smoothstep(maxDistance,\x200.5,\x20distanceToCenter);\x0a\x20\x20\x20\x20gl_FragColor.a\x20*=\x20wholeAlpha;\x0a\x09if(gl_FragColor.a\x20<\x200.1)\x0a\x09{\x0a\x09\x09discard;\x0a\x09}\x0a#ifdef\x20CLIP\x0a\x20\x20\x20\x20gl_FragColor\x20*=\x20czm_clip(czm_modelView\x20*\x20vec4(vPositionMC.xyz,\x201.0),\x201.0);\x0a#endif\x0a\x20\x20\x20\x20gl_FragColor\x20=\x20czm_gammaCorrect(gl_FragColor);\x0a}','5gGiudT','663AsCnOa','1EiMysE','40691UpxyQK'];var _0x506657=_0x4fff;function _0x4fff(_0x21f711,_0x4dc568){_0x21f711=_0x21f711-0xed;var _0x2b4fc5=_0x2b4f[_0x21f711];return _0x2b4fc5;}(function(_0x3dd6ff,_0x1d459e){var _0x2b0743=_0x4fff;while(!![]){try{var _0x40c940=parseInt(_0x2b0743(0xed))+-parseInt(_0x2b0743(0xf4))+-parseInt(_0x2b0743(0xf3))*parseInt(_0x2b0743(0xf0))+-parseInt(_0x2b0743(0xf5))+-parseInt(_0x2b0743(0xf6))*-parseInt(_0x2b0743(0xf1))+-parseInt(_0x2b0743(0xf2))+-parseInt(_0x2b0743(0xf7))*-parseInt(_0x2b0743(0xef));if(_0x40c940===_0x1d459e)break;else _0x3dd6ff['push'](_0x3dd6ff['shift']());}catch(_0x4c76bf){_0x3dd6ff['push'](_0x3dd6ff['shift']());}}}(_0x2b4f,0x4da7e));var _0x54129d = _0x506657(0xee);

    const _0x491b=['_clipPlane','Pass','Cartesian4','decode_texCoord4_normConstant','decode_texCoord6_min','320959hYDHkX','layer','shaderProgramToCreate','invGeoMatrix','decode_texCoord7_min','decode_texCoord3_min','fromCache','MinVisibleValue','context','LineInterval','OPAQUE','length','push','RenderState','MaxVisibleValue','vertexAttributes','defined','decode_texCoord0_normConstant','1079563knsPUj','22483jAJRoj','verticesCount','arrIndexPackage','SVC_Normal','fillForeColor','style3D','noValueColor','decode_texCoord0_min','_clipMode','47750SotWWt','SVC_Vertex','ready','drawingBufferWidth','SVC_TexutreCoord','drawingBufferHeight','decode_texCoord5_normConstant','vertexArray','1024752PhJTHC','decode_position_min','3981HdeRJF','278xhrEUS','vertexPackage','PrimitiveType','minTexCoordValue','createBuffers','1QfVEwT','decode_texCoord3_normConstant','update','6eSxfIL','_swipeRegion','decode_texCoord1_normConstant','prototype','clone','material','isDestroyed','1845849eVlvdr','texture','destroy','decode_texCoord4_min','POINTS','createCommand','LineColor','BoundingSphere','useWValue','DepthFunction','decode_texCoord5_min','call','texCoordCompressConstant','normal_rangeConstant','shaderProgram','createShaderProgram','vertCompressConstant','decode_position_normConstant','destroyObject','_hypsometric','ColorTableMinKey','constructor','boundingVolume','modelMatrix','ColorTableMaxKey','colorCommand','decode_texCoord7_normConstant','setting','decode_texCoord2_min'];function _0x34ea$1(_0x1e5a84,_0x3a2d6b){_0x1e5a84=_0x1e5a84-0xb7;let _0x491b24=_0x491b[_0x1e5a84];return _0x491b24;}const _0x1b9162=_0x34ea$1;(function(_0x2d7329,_0x4d44ea){const _0xf63740=_0x34ea$1;while(!![]){try{const _0x1d900e=-parseInt(_0xf63740(0x104))*-parseInt(_0xf63740(0xe8))+parseInt(_0xf63740(0xfc))*-parseInt(_0xf63740(0xfb))+-parseInt(_0xf63740(0xf9))+parseInt(_0xf63740(0xd5))*-parseInt(_0xf63740(0x101))+-parseInt(_0xf63740(0xf1))+parseInt(_0xf63740(0xe7))+parseInt(_0xf63740(0x10b));if(_0x1d900e===_0x4d44ea)break;else _0x2d7329['push'](_0x2d7329['shift']());}catch(_0x589cf1){_0x2d7329['push'](_0x2d7329['shift']());}}}(_0x491b,0x88c03));function S3MPointCloudRenderEntity(_0x40c382){const _0x441449=_0x34ea$1;RenderEntity[_0x441449(0xbe)](this,_0x40c382),this['vs']=_0x28d577,this['fs']=_0x54129d;}S3MPointCloudRenderEntity[_0x1b9162(0x107)]=Object['create'](RenderEntity[_0x1b9162(0x107)]),S3MPointCloudRenderEntity[_0x1b9162(0x107)][_0x1b9162(0xc8)]=RenderEntity;function getOpaqueRenderState$2(){const _0x1a35dd=_0x1b9162;return Cesium[_0x1a35dd(0xe2)][_0x1a35dd(0xdb)]({'cull':{'enabled':!![]},'depthTest':{'enabled':!![],'func':Cesium[_0x1a35dd(0xbc)]['LESS_OR_EQUAL']}});}let hypMinMaxValueScratch$2=new Cesium[(_0x1b9162(0xd2))](),hypOpacityIntervalFillModeScratch$2=new Cesium[(_0x1b9162(0xd2))](),swipRegionScratch$2=new Cesium[(_0x1b9162(0xd2))]();function getUniformMap$2(_0x442c77,_0x20ec11){const _0x5898cd=_0x1b9162;let _0xb149d5=_0x20ec11[_0x5898cd(0xfd)],_0x1753ca={'uGeoMatrix':function(){return _0x20ec11['geoMatrix'];},'uInverseGeoMatrix':function(){const _0x498801=_0x5898cd;return _0x20ec11[_0x498801(0xd8)];},'uClipMode':function(){const _0x2d60ed=_0x5898cd;return _0x442c77[_0x2d60ed(0xf0)];},'uClipPlanes':function(){const _0x5928b1=_0x5898cd;return _0x442c77[_0x5928b1(0xd0)];},'uUseWValue':function(){const _0x1a1cae=_0x5898cd;return _0x20ec11[_0x1a1cae(0xbb)];},'uHypsometricTexture':function(){const _0x2f44b1=_0x5898cd;return _0x442c77[_0x2f44b1(0xc6)][_0x2f44b1(0x10c)];},'uHypLineColor':function(){const _0x2e8142=_0x5898cd;return _0x442c77[_0x2e8142(0xc6)]['setting'][_0x2e8142(0xb9)];},'uNoValueColor':function(){const _0xcfcfd7=_0x5898cd;return _0x442c77[_0xcfcfd7(0xc6)][_0xcfcfd7(0xce)][_0xcfcfd7(0xee)];},'uMinMaxValue':function(){const _0x8fab79=_0x5898cd;let _0x4f3737=_0x442c77[_0x8fab79(0xc6)]['setting'];return hypMinMaxValueScratch$2['x']=_0x4f3737[_0x8fab79(0xc7)],hypMinMaxValueScratch$2['y']=_0x4f3737[_0x8fab79(0xcb)],hypMinMaxValueScratch$2['z']=_0x4f3737[_0x8fab79(0xdc)],hypMinMaxValueScratch$2['w']=_0x4f3737[_0x8fab79(0xe3)],hypMinMaxValueScratch$2;},'uOpacityIntervalFillMode':function(){const _0x1c635c=_0x5898cd;let _0xb2d374=_0x442c77[_0x1c635c(0xc6)][_0x1c635c(0xce)];return hypOpacityIntervalFillModeScratch$2['x']=_0xb2d374['Opacity'],hypOpacityIntervalFillModeScratch$2['y']=_0xb2d374[_0x1c635c(0xde)],hypOpacityIntervalFillModeScratch$2['z']=_0xb2d374['DisplayMode'],hypOpacityIntervalFillModeScratch$2;},'uSwipeRegion':function(){const _0x2a4a6c=_0x5898cd,_0x4a61f3=_0x442c77[_0x2a4a6c(0xdd)];return swipRegionScratch$2['x']=_0x442c77[_0x2a4a6c(0x105)]['x']*_0x4a61f3[_0x2a4a6c(0xf4)],swipRegionScratch$2['y']=(0x1-_0x442c77[_0x2a4a6c(0x105)]['y'])*_0x4a61f3[_0x2a4a6c(0xf6)],swipRegionScratch$2['z']=_0x442c77[_0x2a4a6c(0x105)]['z']*_0x4a61f3['drawingBufferWidth'],swipRegionScratch$2['w']=(0x1-_0x442c77['_swipeRegion']['w'])*_0x4a61f3[_0x2a4a6c(0xf6)],swipRegionScratch$2;},'uBottom':function(){const _0x352c71=_0x5898cd;return _0x442c77[_0x352c71(0xed)]['bottomAltitude'];},'uFillForeColor':function(){const _0x119f29=_0x5898cd;return _0x442c77[_0x119f29(0xed)][_0x119f29(0xec)];},'uPointCloudSize':function(){return _0x442c77['style3D']['pointSize'];}},_0x539bce=_0xb149d5['compressOptions'];return (_0x539bce&_0x6ea6a9[_0x5898cd(0xf2)])===_0x6ea6a9['SVC_Vertex']&&(_0x1753ca[_0x5898cd(0xfa)]=function(){return _0xb149d5['minVerticesValue'];},_0x1753ca[_0x5898cd(0xc4)]=function(){const _0x4a2857=_0x5898cd;return _0xb149d5[_0x4a2857(0xc3)];}),(_0x539bce&_0x6ea6a9[_0x5898cd(0xeb)])===_0x6ea6a9[_0x5898cd(0xeb)]&&(_0x1753ca[_0x5898cd(0xc0)]=function(){return _0xb149d5['normalRangeConstant'];}),(_0x539bce&_0x6ea6a9[_0x5898cd(0xf5)])===_0x6ea6a9[_0x5898cd(0xf5)]&&(_0xb149d5[_0x5898cd(0xbf)][_0x5898cd(0xe0)]>0x0&&(_0x1753ca[_0x5898cd(0xef)]=function(){const _0x354ed0=_0x5898cd;return _0xb149d5[_0x354ed0(0xff)][0x0];},_0x1753ca[_0x5898cd(0xe6)]=function(){const _0x489707=_0x5898cd;return _0xb149d5[_0x489707(0xbf)][0x0];}),_0xb149d5['texCoordCompressConstant'][_0x5898cd(0xe0)]>0x1&&(_0x1753ca['decode_texCoord1_min']=function(){const _0x5171af=_0x5898cd;return _0xb149d5[_0x5171af(0xff)][0x1];},_0x1753ca[_0x5898cd(0x106)]=function(){const _0x5bab57=_0x5898cd;return _0xb149d5[_0x5bab57(0xbf)][0x1];}),_0xb149d5[_0x5898cd(0xbf)][_0x5898cd(0xe0)]>0x2&&(_0x1753ca[_0x5898cd(0xcf)]=function(){return _0xb149d5['minTexCoordValue'][0x2];},_0x1753ca['decode_texCoord2_normConstant']=function(){const _0x236d5d=_0x5898cd;return _0xb149d5[_0x236d5d(0xbf)][0x2];}),_0xb149d5[_0x5898cd(0xbf)][_0x5898cd(0xe0)]>0x3&&(_0x1753ca[_0x5898cd(0xda)]=function(){const _0x479a8d=_0x5898cd;return _0xb149d5[_0x479a8d(0xff)][0x3];},_0x1753ca[_0x5898cd(0x102)]=function(){const _0x335708=_0x5898cd;return _0xb149d5[_0x335708(0xbf)][0x3];}),_0xb149d5[_0x5898cd(0xbf)][_0x5898cd(0xe0)]>0x4&&(_0x1753ca[_0x5898cd(0x10e)]=function(){return _0xb149d5['minTexCoordValue'][0x4];},_0x1753ca[_0x5898cd(0xd3)]=function(){const _0x48eaa3=_0x5898cd;return _0xb149d5[_0x48eaa3(0xbf)][0x4];}),_0xb149d5[_0x5898cd(0xbf)][_0x5898cd(0xe0)]>0x5&&(_0x1753ca[_0x5898cd(0xbd)]=function(){const _0x422fea=_0x5898cd;return _0xb149d5[_0x422fea(0xff)][0x5];},_0x1753ca[_0x5898cd(0xf7)]=function(){const _0x44f8e6=_0x5898cd;return _0xb149d5[_0x44f8e6(0xbf)][0x5];}),_0xb149d5[_0x5898cd(0xbf)][_0x5898cd(0xe0)]>0x6&&(_0x1753ca[_0x5898cd(0xd4)]=function(){const _0x4cca05=_0x5898cd;return _0xb149d5[_0x4cca05(0xff)][0x6];},_0x1753ca['decode_texCoord6_normConstant']=function(){return _0xb149d5['texCoordCompressConstant'][0x6];}),_0xb149d5[_0x5898cd(0xbf)][_0x5898cd(0xe0)]>0x7&&(_0x1753ca[_0x5898cd(0xd9)]=function(){const _0x2df3bd=_0x5898cd;return _0xb149d5[_0x2df3bd(0xff)][0x7];},_0x1753ca[_0x5898cd(0xcd)]=function(){return _0xb149d5['texCoordCompressConstant'][0x7];})),_0x1753ca;}S3MPointCloudRenderEntity[_0x1b9162(0x107)]['createCommand']=function(){const _0x14fa5b=_0x1b9162;if(Cesium[_0x14fa5b(0xe5)](this[_0x14fa5b(0xcc)])||this['vertexBufferToCreate'][_0x14fa5b(0xe0)]!==0x0||this['indexBufferToCreate']['length']!==0x0||this[_0x14fa5b(0xd7)][_0x14fa5b(0xe0)]!==0x0)return;let _0x45fffc=this[_0x14fa5b(0xd6)],_0x320c70=_0x45fffc[_0x14fa5b(0xdd)],_0x22ba0e=this['vertexPackage'],_0x33e97d=this[_0x14fa5b(0xea)],_0x5480fe=_0x22ba0e[_0x14fa5b(0xe4)];this[_0x14fa5b(0xf8)]=new Cesium['VertexArray']({'context':_0x320c70,'attributes':_0x5480fe}),this[_0x14fa5b(0xcc)]=new Cesium['DrawCommand']({'primitiveType':Cesium[_0x14fa5b(0xfe)][_0x14fa5b(0xb7)],'modelMatrix':this['modelMatrix'],'boundingVolume':Cesium[_0x14fa5b(0xba)][_0x14fa5b(0x108)](this[_0x14fa5b(0xc9)]),'vertexArray':this[_0x14fa5b(0xf8)],'shaderProgram':this[_0x14fa5b(0xc1)],'pass':Cesium[_0x14fa5b(0xd1)][_0x14fa5b(0xdf)],'renderState':getOpaqueRenderState$2(),'count':_0x22ba0e[_0x14fa5b(0xe9)]}),this[_0x14fa5b(0xcc)]['uniformMap']=getUniformMap$2(_0x45fffc,this),this[_0x14fa5b(0xfd)]=undefined,this[_0x14fa5b(0xea)]=undefined,this['vs']=undefined,this['fs']=undefined,this[_0x14fa5b(0xf3)]=!![];},S3MPointCloudRenderEntity[_0x1b9162(0x107)][_0x1b9162(0x103)]=function(_0x426aa7,_0x166859){const _0x4ba5ed=_0x1b9162;if(!this[_0x4ba5ed(0xf3)]){this[_0x4ba5ed(0x100)](_0x426aa7),this[_0x4ba5ed(0xc2)](_0x426aa7),this[_0x4ba5ed(0xb8)](_0x426aa7);return;}_0x426aa7['commandList'][_0x4ba5ed(0xe1)](this[_0x4ba5ed(0xcc)]);},S3MPointCloudRenderEntity[_0x1b9162(0x107)][_0x1b9162(0x10a)]=function(){return ![];},S3MPointCloudRenderEntity[_0x1b9162(0x107)]['destroy']=function(){const _0x245865=_0x1b9162;return this[_0x245865(0xc1)]=this[_0x245865(0xc1)]&&!this[_0x245865(0xc1)][_0x245865(0x10a)]()&&this[_0x245865(0xc1)][_0x245865(0x10d)](),this[_0x245865(0xf8)]=this['vertexArray']&&!this[_0x245865(0xf8)][_0x245865(0x10a)]()&&this['vertexArray'][_0x245865(0x10d)](),this['material']=this[_0x245865(0x109)]&&!this[_0x245865(0x109)][_0x245865(0x10a)]()&&this['material'][_0x245865(0x10d)](),this[_0x245865(0xcc)]=undefined,this[_0x245865(0xfd)]=null,this[_0x245865(0xea)]=null,this[_0x245865(0xca)]=undefined,this['vs']=undefined,this['fs']=undefined,Cesium[_0x245865(0xc5)](this);};

    var _0x939d=['583618nYFSeZ','176135kskQXc','585404NZMsUg','687281NkCXjC','364887iAZFtg','34453RRHqNC','178853JBefna','attribute\x20vec4\x20aPosition;\x0aattribute\x20vec3\x20aNormal;\x0aattribute\x20vec4\x20aTexCoord0;\x0aattribute\x20vec4\x20aColor;\x0auniform\x20float\x20uTimeVal;\x0auniform\x20float\x20uScale;\x0auniform\x20float\x20uScroll;\x0auniform\x20vec2\x20uBumpSpeed;\x0auniform\x20mat4\x20uGeoMatrix;\x0a\x0avarying\x20vec2\x20vNoiseCoord;\x0avarying\x20vec3\x20vProjectionCoord;\x0avarying\x20vec3\x20vEyeDir;\x0avarying\x20vec3\x20vNormal;\x0avarying\x20vec4\x20vColor;\x0avarying\x20vec4\x20vPositionMC;\x0avarying\x20float\x20fSelected;\x0avarying\x20vec3\x20vPositionEC;\x0a\x0avoid\x20main()\x0a{\x0a\x09vec4\x20oPos\x20=\x20czm_modelViewProjection\x20*\x20aPosition;\x0a\x09vPositionMC\x20=\x20uGeoMatrix\x20*\x20aPosition;\x0a\x09vPositionEC\x20=\x20(czm_modelView\x20*\x20vPositionMC).xyz;\x0a\x09mat4\x20scalemat\x20=\x20mat4(0.5,\x200.0,\x200.0,\x200.0,\x0a\x09\x09\x090.0,\x200.5,\x200.0,\x200.0,\x0a\x09\x09\x090.0,\x200.0,\x200.5,\x200.0,\x0a\x09\x09\x090.5,\x200.5,\x200.5,\x201.0);\x0a\x09vec4\x20proj\x20=\x20scalemat\x20*\x20oPos;\x0a\x09vProjectionCoord\x20=\x20proj.xyw;\x0a\x09vNoiseCoord.xy\x20=\x20aTexCoord0.xy\x20*\x20uScale\x20+\x20uBumpSpeed\x20*\x20uTimeVal;\x0a\x09vec4\x20cameraPos\x20=\x20czm_inverseModel\x20*\x20vec4(czm_viewerPositionWC,\x201.0);\x0a\x09vEyeDir\x20=\x20aPosition.xyz\x20-\x20cameraPos.xyz;\x0a\x09vNormal\x20=\x20aNormal.xyz;\x0a\x09gl_Position\x20=\x20oPos;\x0a\x09vec4\x20vertexColor\x20=\x20vec4(1.0);\x0a\x20\x20\x20\x20vertexColor\x20=\x20aColor;\x0a\x20\x20\x20\x20vColor\x20=\x20vertexColor;\x0a}'];function _0x2ba8(_0x3450ad,_0x40fc60){_0x3450ad=_0x3450ad-0xa9;var _0x939d27=_0x939d[_0x3450ad];return _0x939d27;}var _0x487bf5=_0x2ba8;(function(_0x3df416,_0x56cf94){var _0x1ffe20=_0x2ba8;while(!![]){try{var _0x5b8a85=parseInt(_0x1ffe20(0xaf))+parseInt(_0x1ffe20(0xab))+-parseInt(_0x1ffe20(0xae))+parseInt(_0x1ffe20(0xb0))+-parseInt(_0x1ffe20(0xa9))+parseInt(_0x1ffe20(0xaa))+-parseInt(_0x1ffe20(0xad));if(_0x5b8a85===_0x56cf94)break;else _0x3df416['push'](_0x3df416['shift']());}catch(_0x54e23a){_0x3df416['push'](_0x3df416['shift']());}}}(_0x939d,0x58387));var _0x2e55b9 = _0x487bf5(0xac);

    var _0x599e=['378542CeQWao','88500OGeods','655088pFpPJJ','2ayjFLS','434593myQqDs','441911RvvvBa','15YFIafL','6XNeBsW','14243NBMdyT','31731oCwper'];function _0x43ee(_0xb737cc,_0x419a62){_0xb737cc=_0xb737cc-0xe9;var _0x599e02=_0x599e[_0xb737cc];return _0x599e02;}(function(_0x4111ef,_0x2f878c){var _0x5976e0=_0x43ee;while(!![]){try{var _0x41908a=-parseInt(_0x5976e0(0xe9))+-parseInt(_0x5976e0(0xea))*parseInt(_0x5976e0(0xed))+-parseInt(_0x5976e0(0xef))+-parseInt(_0x5976e0(0xec))+parseInt(_0x5976e0(0xf0))*parseInt(_0x5976e0(0xf2))+-parseInt(_0x5976e0(0xeb))+parseInt(_0x5976e0(0xee))*parseInt(_0x5976e0(0xf1));if(_0x41908a===_0x2f878c)break;else _0x4111ef['push'](_0x4111ef['shift']());}catch(_0x295f73){_0x4111ef['push'](_0x4111ef['shift']());}}}(_0x599e,0xcec29));var _0x6129f3 = 'uniform\x20sampler2D\x20uReflectMap;\x0auniform\x20sampler2D\x20uNoiseMap;\x0auniform\x20vec4\x20uTintColour;\x0auniform\x20vec4\x20uWaterColour;\x0auniform\x20vec4\x20uFillForeColor;\x0auniform\x20float\x20uFresnelPower;\x0auniform\x20float\x20uMinFresnel;\x0auniform\x20float\x20uMaxFresnel;\x0auniform\x20float\x20uNoiseScale;\x0auniform\x20float\x20uWaterBrightness;\x0avarying\x20vec2\x20vNoiseCoord;\x0avarying\x20vec3\x20vProjectionCoord;\x0avarying\x20vec3\x20vEyeDir;\x0avarying\x20vec3\x20vNormal;\x0avarying\x20vec4\x20vColor;\x0avarying\x20vec4\x20vSecondColor;\x0avarying\x20vec4\x20vPositionMC;\x0avarying\x20vec3\x20vPositionEC;\x0a\x0a#ifdef\x20APPLY_SWIPE\x0a\x20\x20\x20\x20uniform\x20vec4\x20uSwipeRegion;\x0a#endif\x0a\x0a#ifdef\x20APPLY_SWIPE\x0a\x20\x20\x20\x20uniform\x20vec4\x20uSwipeRegion;\x0a\x20\x20\x20\x20void\x20rollerShutter(vec2\x20coord,\x20vec4\x20region)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20f\x20=\x20step(region.xw,\x20coord);\x0a\x20\x20\x20\x20\x20\x20\x20\x20vec2\x20s\x20=\x20step(coord,\x20region.zy);\x0a\x20\x20\x20\x20\x20\x20\x20\x20if\x20(f.x\x20*\x20f.y\x20*\x20s.x\x20*\x20s.y\x20<\x201.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20discard;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20}\x0a#endif\x0a\x0a#ifdef\x20CLIP\x0a\x20\x20\x20\x20uniform\x20float\x20uClipMode;\x0a\x20\x20\x20\x20uniform\x20vec4\x20uClipPlanes[6];\x0a\x20\x20\x20\x20float\x20getClipDistance(vec3\x20pos,\x20vec3\x20planeNormal,\x20float\x20disToOrigin)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20dot(planeNormal,\x20pos)\x20+\x20disToOrigin;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20float\x20clipBehindAllPlane(float\x20fBorderWidth,\x20vec4\x20vertex)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20distance\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20result\x20=\x20-1.0;\x0a\x20\x20\x20\x20#ifdef\x20CLIPPLANE\x0a\x20\x20\x20\x20\x20\x20\x20\x20distance\x20=\x20getClipDistance(vertex.xyz,\x20uClipPlanes[0].xyz,\x20uClipPlanes[0].w);\x0a\x20\x20\x20\x20\x20\x20\x20\x20if\x20(distance\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x201.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x20if\x20(distance\x20<\x20fBorderWidth)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20result\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20for(int\x20i\x20=\x200;\x20i\x20<\x206;\x20i++)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20distance\x20=\x20getClipDistance(vertex.xyz,\x20uClipPlanes[i].xyz,\x20uClipPlanes[i].w);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20if(distance\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x201.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(distance\x20<\x20fBorderWidth)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20result\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20result;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20float\x20clipBehindAnyPlane(float\x20fBorderWidth,\x20vec4\x20vertex)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20result\x20=\x201.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20for(int\x20i\x20=\x200;\x20i\x20<\x206;\x20i++)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20float\x20distance\x20=\x20getClipDistance(vertex.xyz,\x20uClipPlanes[i].xyz,\x20uClipPlanes[i].w);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20if((distance\x20+\x20fBorderWidth)\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20-1.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(distance\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20result\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20result;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20float\x20clipAnythingButLine(float\x20fBorderWidth,\x20vec4\x20vertex)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20result\x20=\x20-1.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20for(int\x20i\x20=\x200;\x20i\x20<\x206;\x20i++)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20float\x20distance\x20=\x20getClipDistance(vertex.xyz,\x20uClipPlanes[i].xyz,\x20uClipPlanes[i].w);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20if(distance\x20<\x200.0)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20-1.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(distance\x20<\x20fBorderWidth)\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20result\x20=\x200.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20result;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20vec4\x20clip(vec4\x20vertex)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(uClipMode\x20<\x200.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20vec4(1.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20#ifdef\x20GL_OES_standard_derivatives\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dxc\x20=\x20abs(dFdx(vertex.x));\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20dyc\x20=\x20abs(dFdy(vertex.y));\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20fBorderWidth\x20=\x20max(dxc,\x20dyc);\x0a\x20\x20\x20\x20#else\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20fBorderWidth\x20=\x201.0;\x0a\x20\x20\x20\x20#endif\x0a\x20\x20\x20\x20\x20\x20\x20\x20float\x20clipResult\x20=\x201.0;\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(uClipMode\x20<\x201.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20clipResult\x20=\x20clipBehindAnyPlane(fBorderWidth,\x20vertex);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(uClipMode\x20<\x202.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20clipResult\x20=\x20clipBehindAllPlane(fBorderWidth,\x20vertex);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(uClipMode\x20<\x203.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20clipResult\x20=\x20clipAnythingButLine(fBorderWidth,\x20vertex);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20if(clipResult\x20<\x20-0.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20discard;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20else\x20if(clipResult\x20<\x200.5)\x0a\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20vec4(1.0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20return\x20vec4(1.0);\x0a\x20\x20\x20\x20}\x0a#endif\x0a\x0avec4\x20AdjSaturation(in\x20vec4\x20inputColor,\x20in\x20float\x20saturation)\x0a{\x0a\x09vec3\x20lumCoeff\x20=\x20vec3(0.2125,\x200.7154,\x200.0721);\x0a\x09vec3\x20intensity\x20=\x20vec3(dot(inputColor.rgb,\x20lumCoeff));\x0a\x09vec3\x20tempColor\x20=\x20mix(intensity,\x20inputColor.rgb,\x20saturation);\x0a\x09return\x20vec4(tempColor,\x201.0);\x0a}\x0avoid\x20main()\x0a{\x0a#ifdef\x20APPLY_SWIPE\x20\x0a\x20\x20\x20\x20rollerShutter(gl_FragCoord.xy,\x20uSwipeRegion);\x0a#endif\x0a\x20\x20\x20\x20if(vColor.a\x20<\x200.1)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20discard;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20gl_FragColor\x20=\x20vColor;\x0a\x20\x20\x20\x20vec2\x20final\x20=\x20vProjectionCoord.xy\x20/\x20vProjectionCoord.z;\x0a\x20\x20\x20\x20vec3\x20noiseNormal\x20=\x20(texture2D(uNoiseMap,\x20(vNoiseCoord.xy\x20/\x205.0)).rgb\x20-\x200.5).rbg\x20*\x20uNoiseScale;\x0a\x20\x20\x20\x20final\x20+=\x20noiseNormal.xz;\x0a\x20\x20\x20\x20float\x20realMinFresnel,\x20realMaxFresnel;\x0a\x20\x20\x20\x20if(uMinFresnel\x20<\x20uMaxFresnel)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20realMinFresnel\x20=\x20uMinFresnel;\x0a\x20\x20\x20\x20\x20\x20\x20\x20realMaxFresnel\x20=\x20uMaxFresnel;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20else\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20realMinFresnel\x20=\x20uMaxFresnel;\x0a\x20\x20\x20\x20\x20\x20\x20\x20realMaxFresnel\x20=\x20uMinFresnel;\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20\x20float\x20fresnelBias\x20=\x20realMinFresnel;\x0a\x20\x20\x20\x20float\x20fresnelScale\x20=\x20(realMaxFresnel\x20-\x20realMinFresnel)\x20/\x201.0;\x0a\x20\x20\x20\x20float\x20fresnel\x20=\x20fresnelBias\x20+\x20fresnelScale\x20*\x20pow(1.0\x20+\x20dot(normalize(vEyeDir),\x20vNormal),\x20uFresnelPower);\x0a\x20\x20\x20\x20fresnel\x20=\x20clamp(fresnel,\x200.05,\x200.95);\x0a\x20\x20\x20\x20vec4\x20reflectionColour\x20=\x20texture2D(uReflectMap,\x20final);\x0a\x20\x20\x20\x20vec4\x20refractionColour\x20=\x20reflectionColour\x20+\x20uTintColour;\x0a\x20\x20\x20\x20vec4\x20resultColour\x20=\x20mix(uWaterColour,\x20reflectionColour,\x20fresnel);\x0a\x20\x20\x20\x20resultColour\x20=\x20AdjSaturation(resultColour,\x201.0);\x0a\x20\x20\x20\x20resultColour\x20=\x20resultColour\x20*\x20uWaterBrightness;\x0a\x20\x20\x20\x20resultColour.a\x20=\x20uWaterColour.a;\x0a\x20\x20\x20\x20resultColour\x20*=\x20uFillForeColor;\x0a\x20\x20\x20\x20gl_FragColor\x20=\x20gl_FragColor\x20*\x20resultColour;\x0a#ifdef\x20CLIP\x0a\x20\x20\x20\x20gl_FragColor\x20*=\x20clip(vec4(vPositionEC,\x201.0));\x0a#endif\x0a\x20\x20\x20\x20if(gl_FragColor.a\x20<\x200.1)\x0a\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20discard;\x0a\x20\x20\x20\x20}\x0a\x0a}';

    const _0x20f1=['createShaderProgram','clone','ready','scroll','530648JpMIbS','constructor','sceneFramebuffer','destroyObject','OPAQUE','DepthFunction','bTransparentSorting','pickInfo','vertexBufferToCreate','batchTable','initLayerSetting','730182rGfjAe','8209IBKrFr','getFramebuffer','length','bReflect','124522JSLCnj','scale','averageHeight','destroy','push','createPickIds','createBatchTable','create','BlendingState','shaderProgramToCreate','_clipPlane','243019MbgvsM','material','VertexArray','modelMatrix','bumpSpeed','reflectFramebuffer','Pass','context','colorCommand','DrawCommand','_swipeRegion','69911pJDwOG','shaderProgram','drawingBufferWidth','RenderState','boundingVolume','defaultTexture','_waterParameters','vertexArray','maxFresnel','selectedColor','call','waterTime','drawingBufferHeight','noiseScale','createBuffers','arrIndexPackage','minFresnel','isDestroyed','fillForeColor','ALPHA_BLEND','timeVal','3ctYnyP','primitiveType','waterBrightness','waterColour','25rCKKrZ','style3D','_clipMode','Cartesian4','addWaterPlane','29yIvzgw','getColorTexture','tintColour','layer','defined','13873KFAppC','removeWaterPlane','vertexPackage','createCommand','prototype','vertexAttributes','geoMatrix','uniformMap','update','batchTableDirty','waterIndex'];const _0xfe3da1=_0x400b;(function(_0x342e2a,_0x567aa4){const _0x39e590=_0x400b;while(!![]){try{const _0x5932e8=-parseInt(_0x39e590(0x1bc))+-parseInt(_0x39e590(0x1ad))*-parseInt(_0x39e590(0x1a3))+-parseInt(_0x39e590(0x19f))*parseInt(_0x39e590(0x18a))+-parseInt(_0x39e590(0x1d7))+parseInt(_0x39e590(0x1a8))*parseInt(_0x39e590(0x1c8))+parseInt(_0x39e590(0x1cc))+parseInt(_0x39e590(0x1c7));if(_0x5932e8===_0x567aa4)break;else _0x342e2a['push'](_0x342e2a['shift']());}catch(_0x370c97){_0x342e2a['push'](_0x342e2a['shift']());}}}(_0x20f1,0x6f5fe));function S3MWaterRenderEntity(_0x585c20){const _0x103395=_0x400b;RenderEntity[_0x103395(0x194)](this,_0x585c20),this['vs']=_0x2e55b9,this['fs']=_0x6129f3,this[_0x103395(0x1b7)]=-0x1,this['waterTime']=0x0;}S3MWaterRenderEntity[_0xfe3da1(0x1b1)]=Object[_0xfe3da1(0x1d3)](RenderEntity[_0xfe3da1(0x1b1)]),S3MWaterRenderEntity[_0xfe3da1(0x1b1)][_0xfe3da1(0x1bd)]=RenderEntity;function getOpaqueRenderState$3(){const _0x229798=_0xfe3da1;return Cesium[_0x229798(0x18d)]['fromCache']({'cull':{'enabled':!![]},'depthTest':{'enabled':!![],'func':Cesium[_0x229798(0x1c1)]['LESS_OR_EQUAL']},'blending':Cesium[_0x229798(0x1d4)][_0x229798(0x19d)]});}let swipRegionScratch$3=new Cesium[(_0xfe3da1(0x1a6))]();function _0x400b(_0x1d583c,_0x2a0e49){_0x1d583c=_0x1d583c-0x183;let _0x20f100=_0x20f1[_0x1d583c];return _0x20f100;}function getUniformMap$3(_0x22fb76,_0xb19f8e,_0x316438){return {'uGeoMatrix':function(){const _0x20c34b=_0x400b;return _0x316438[_0x20c34b(0x1b3)];},'uFillForeColor':function(){const _0x16b6d4=_0x400b;return _0xb19f8e[_0x16b6d4(0x1a4)][_0x16b6d4(0x19c)];},'uSelectedColor':function(){const _0x31ead7=_0x400b;return _0xb19f8e[_0x31ead7(0x193)];},'uClipMode':function(){const _0x2034f1=_0x400b;return _0xb19f8e[_0x2034f1(0x1a5)];},'uClipPlanes':function(){const _0x58bd00=_0x400b;return _0xb19f8e[_0x58bd00(0x1d6)];},'uSwipeRegion':function(){const _0x5fe976=_0x400b,_0x565b97=_0xb19f8e[_0x5fe976(0x186)];return swipRegionScratch$3['x']=_0xb19f8e[_0x5fe976(0x189)]['x']*_0x565b97[_0x5fe976(0x18c)],swipRegionScratch$3['y']=(0x1-_0xb19f8e['_swipeRegion']['y'])*_0x565b97[_0x5fe976(0x196)],swipRegionScratch$3['z']=_0xb19f8e[_0x5fe976(0x189)]['z']*_0x565b97[_0x5fe976(0x18c)],swipRegionScratch$3['w']=(0x1-_0xb19f8e[_0x5fe976(0x189)]['w'])*_0x565b97[_0x5fe976(0x196)],swipRegionScratch$3;},'uReflectMap':function(){const _0x585b91=_0x400b;let _0x10c296=_0xb19f8e[_0x585b91(0x186)][_0x585b91(0x184)][_0x585b91(0x1be)][_0x585b91(0x1c9)]();if(!_0x10c296)return _0xb19f8e['context'][_0x585b91(0x18f)];return _0x10c296[_0x585b91(0x1a9)](0x0);},'uNoiseMap':function(){const _0x44a1f0=_0x400b;return _0xb19f8e[_0x44a1f0(0x186)]['defaultTexture'];},'uTimeVal':function(){const _0x5dd6aa=_0x400b;let _0x75b02d=_0xb19f8e[_0x5dd6aa(0x190)][_0x5dd6aa(0x19e)]*0.01;return _0x316438[_0x5dd6aa(0x195)]=_0x316438[_0x5dd6aa(0x195)]>0x1?_0x75b02d:_0x316438[_0x5dd6aa(0x195)]+_0x75b02d,_0x316438[_0x5dd6aa(0x195)];},'uScale':function(){const _0x1892f2=_0x400b;return _0xb19f8e[_0x1892f2(0x190)][_0x1892f2(0x1cd)];},'uScroll':function(){const _0x28de47=_0x400b;return _0xb19f8e[_0x28de47(0x190)][_0x28de47(0x1bb)];},'uNoise':function(){const _0x33f905=_0x400b;return _0xb19f8e[_0x33f905(0x190)]['noise'];},'uBumpSpeed':function(){const _0x46f687=_0x400b;return _0xb19f8e['_waterParameters'][_0x46f687(0x183)];},'uFresnelPower':function(){const _0x23cc0f=_0x400b;return _0xb19f8e[_0x23cc0f(0x190)]['fresnelPower'];},'uMinFresnel':function(){const _0x2194bc=_0x400b;return _0xb19f8e[_0x2194bc(0x190)][_0x2194bc(0x19a)];},'uMaxFresnel':function(){const _0xf6da34=_0x400b;return _0xb19f8e[_0xf6da34(0x190)][_0xf6da34(0x192)];},'uTintColour':function(){const _0x2e1483=_0x400b;return _0xb19f8e['_waterParameters'][_0x2e1483(0x1aa)];},'uNoiseScale':function(){const _0x282b07=_0x400b;return _0xb19f8e[_0x282b07(0x190)][_0x282b07(0x197)];},'uWaterColour':function(){const _0x280b9b=_0x400b;return _0xb19f8e[_0x280b9b(0x190)][_0x280b9b(0x1a2)];},'uWaterBrightness':function(){const _0x4530a0=_0x400b;return _0xb19f8e[_0x4530a0(0x190)][_0x4530a0(0x1a1)];}};}S3MWaterRenderEntity[_0xfe3da1(0x1b1)][_0xfe3da1(0x1b0)]=function(){const _0x5631e9=_0xfe3da1;if(Cesium[_0x5631e9(0x1ac)](this[_0x5631e9(0x187)])||this[_0x5631e9(0x1c4)][_0x5631e9(0x1ca)]!==0x0||this['indexBufferToCreate'][_0x5631e9(0x1ca)]!==0x0||this[_0x5631e9(0x1d5)]['length']!==0x0)return;let _0x4e3dc5=this[_0x5631e9(0x1ab)],_0x41633f=_0x4e3dc5[_0x5631e9(0x186)],_0x6e30eb=this[_0x5631e9(0x1af)],_0x3947e6=this[_0x5631e9(0x199)],_0x539149=_0x6e30eb[_0x5631e9(0x1b2)];if(_0x3947e6[_0x5631e9(0x1ca)]<0x1)return;let _0x248dbb=_0x3947e6[0x0],_0x3de7a2=this[_0x5631e9(0x1d8)];this[_0x5631e9(0x191)]=new Cesium[(_0x5631e9(0x1d9))]({'context':_0x41633f,'attributes':_0x539149,'indexBuffer':_0x248dbb['indexBuffer']}),this['colorCommand']=new Cesium[(_0x5631e9(0x188))]({'primitiveType':_0x248dbb[_0x5631e9(0x1a0)],'modelMatrix':this[_0x5631e9(0x1da)],'boundingVolume':Cesium['BoundingSphere'][_0x5631e9(0x1b9)](this[_0x5631e9(0x18e)]),'vertexArray':this[_0x5631e9(0x191)],'shaderProgram':this[_0x5631e9(0x18b)],'pass':_0x3de7a2[_0x5631e9(0x1c2)]?Cesium[_0x5631e9(0x185)]['TRANSLUCENT']:Cesium['Pass'][_0x5631e9(0x1c0)],'renderState':_0x3de7a2[_0x5631e9(0x1c2)]?getTransparentRenderState():getOpaqueRenderState$3(),'instanceCount':_0x6e30eb['instanceCount']});let _0x3ed3fd=getUniformMap$3(_0x3de7a2,_0x4e3dc5,this);this[_0x5631e9(0x187)][_0x5631e9(0x1b4)]=this[_0x5631e9(0x1c5)]['getUniformMapCallback']()(_0x3ed3fd),this[_0x5631e9(0x1af)]=undefined,this['arrIndexPackage']=undefined,this['vs']=undefined,this['fs']=undefined,this[_0x5631e9(0x1ba)]=!![];};function addWaterPlane(_0x2f94fd,_0x3a76fa){const _0x596fe6=_0xfe3da1;let _0x4bbabb={'boundingVolume':_0x2f94fd[_0x596fe6(0x18e)],'distance':_0x3a76fa['style3D']['bottomAltitude']+_0x3a76fa[_0x596fe6(0x190)][_0x596fe6(0x1ce)]};_0x2f94fd['waterIndex']=_0x3a76fa[_0x596fe6(0x1a7)](_0x4bbabb);}S3MWaterRenderEntity[_0xfe3da1(0x1b1)][_0xfe3da1(0x1b5)]=function(_0x4e0cfa,_0xcca908){const _0xfd3199=_0xfe3da1;if(_0x4e0cfa['camera'][_0xfd3199(0x1cb)])return;if(!this[_0xfd3199(0x1ba)]){this[_0xfd3199(0x1d2)](_0x4e0cfa),this[_0xfd3199(0x1d1)](),this[_0xfd3199(0x198)](_0x4e0cfa),this[_0xfd3199(0x1b8)](_0x4e0cfa),this[_0xfd3199(0x1b0)](_0x4e0cfa),this[_0xfd3199(0x1c6)](_0xcca908),addWaterPlane(this,_0xcca908);return;}this[_0xfd3199(0x1b6)]&&(this['updateBatchTableAttributes'](),this[_0xfd3199(0x1b6)]=![]),this['batchTable'][_0xfd3199(0x1b5)](_0x4e0cfa),_0x4e0cfa['commandList'][_0xfd3199(0x1d0)](this[_0xfd3199(0x187)]);},S3MWaterRenderEntity['prototype'][_0xfe3da1(0x19b)]=function(){return ![];},S3MWaterRenderEntity[_0xfe3da1(0x1b1)]['destroy']=function(){const _0x2b3237=_0xfe3da1;return this['shaderProgram']=this[_0x2b3237(0x18b)]&&!this['shaderProgram'][_0x2b3237(0x19b)]()&&this[_0x2b3237(0x18b)]['destroy'](),this[_0x2b3237(0x191)]=this[_0x2b3237(0x191)]&&!this['vertexArray']['isDestroyed']()&&this[_0x2b3237(0x191)][_0x2b3237(0x1cf)](),this['material']=this['material']&&!this['material'][_0x2b3237(0x19b)]()&&this[_0x2b3237(0x1d8)][_0x2b3237(0x1cf)](),this[_0x2b3237(0x1c5)]=this[_0x2b3237(0x1c5)]&&!this['batchTable'][_0x2b3237(0x19b)]()&&this[_0x2b3237(0x1c5)][_0x2b3237(0x1cf)](),this[_0x2b3237(0x1b7)]>-0x1&&this[_0x2b3237(0x1ab)][_0x2b3237(0x1ae)](this[_0x2b3237(0x1b7)]),this[_0x2b3237(0x187)]=undefined,this[_0x2b3237(0x1af)]=null,this[_0x2b3237(0x199)]=null,this[_0x2b3237(0x1da)]=undefined,this[_0x2b3237(0x1c3)]=undefined,this['selectionInfoMap']=undefined,this['vs']=undefined,this['fs']=undefined,Cesium[_0x2b3237(0x1bf)](this);};

    const _0x8714=['32BElIYT','77566hFRRpL','86671FgSeft','225413ymPrBA','5774LUioCM','134219bBtUae','500622cPyFmL','3LLnDhH','84811NupJsi','1CHGLhF','1muUkGk'];(function(_0x20da5a,_0x1a79ca){const _0x3c54c6=_0xd795;while(!![]){try{const _0x27156e=parseInt(_0x3c54c6(0x83))+-parseInt(_0x3c54c6(0x80))*parseInt(_0x3c54c6(0x7d))+-parseInt(_0x3c54c6(0x7f))+-parseInt(_0x3c54c6(0x86))*-parseInt(_0x3c54c6(0x85))+-parseInt(_0x3c54c6(0x7e))*-parseInt(_0x3c54c6(0x82))+-parseInt(_0x3c54c6(0x81))*-parseInt(_0x3c54c6(0x7c))+-parseInt(_0x3c54c6(0x84));if(_0x27156e===_0x1a79ca)break;else _0x20da5a['push'](_0x20da5a['shift']());}catch(_0x10c552){_0x20da5a['push'](_0x20da5a['shift']());}}}(_0x8714,0x20b56));function _0xd795(_0x5d57dd,_0x3c31f2){_0x5d57dd=_0x5d57dd-0x7c;let _0x8714c9=_0x8714[_0x5d57dd];return _0x8714c9;}let S3MContentFactory={'OSGBFile':function(_0x28d0bb){return new S3MObliqueRenderEntity(_0x28d0bb);},'OSGBCacheFile':function(_0x3be877){return new S3MCacheFileRenderEntity(_0x3be877);},'PointCloudFile':function(_0x1b3df6){return new S3MPointCloudRenderEntity(_0x1b3df6);},'OSGBCacheFile_Water':function(_0x22cc91){return new S3MWaterRenderEntity(_0x22cc91);}};

    const _0x1f72=['fromBoundingSpheres','shininess','instanceIndex','materialCode','Color','Cartesian3','diffuseColor','667275TjoGFS','arrayBufferView','minVerticesValue','specular','componentsPerAttribute','addressmode','addTexture','center','sphere','2UTCUmq','transform','rangeDataList','material','Carteisan3','modelMatrix','verticesCount','fileName','boundingVolume','length','TextureWrap','materials','textureunitstates','buffer','geodes','matrix','parse','SVC_Vertex','rangeList','typedArray','childTile','hasOwnProperty','keys','textureCache','arrIndexPackage','Matrix4','11603coHZaH','texturePackage','boundingSphere','textures','geoMap','distance','isLeafTile','groupNode','bTransparentSorting','3345lHIJLu','push','fromPoints','fileType','CLAMP_TO_EDGE','381653JgVgXF','179267FFyyWG','vertexAttributes','2qMbfJE','unpack','rangeMode','ambientColor','fromArray','byteOffset','429412IAAGgA','textureunitstate','BoundingSphere','lerp','defined','pickInfo','radius','REPEAT','transparentsorting','wrapT','add','483267QsgCpK','byteLength','113AKnsWI','31AqEOrY','pageLods','compressOptions','texMatrix'];const _0x21dc2d=_0x11ef;function _0x11ef(_0x4040cd,_0x51c8c0){_0x4040cd=_0x4040cd-0x13e;let _0x1f7240=_0x1f72[_0x4040cd];return _0x1f7240;}(function(_0x41a8a1,_0x4dfd84){const _0x1916b7=_0x11ef;while(!![]){try{const _0x3893b6=-parseInt(_0x1916b7(0x15a))*-parseInt(_0x1916b7(0x176))+-parseInt(_0x1916b7(0x168))*-parseInt(_0x1916b7(0x18a))+-parseInt(_0x1916b7(0x15f))*parseInt(_0x1916b7(0x162))+-parseInt(_0x1916b7(0x181))+parseInt(_0x1916b7(0x160))+-parseInt(_0x1916b7(0x173))+parseInt(_0x1916b7(0x175))*parseInt(_0x1916b7(0x151));if(_0x3893b6===_0x4dfd84)break;else _0x41a8a1['push'](_0x41a8a1['shift']());}catch(_0x31418f){_0x41a8a1['push'](_0x41a8a1['shift']());}}}(_0x1f72,0x839c5));function S3MContentParser(){}function parseMaterial$2(_0x7d4c1c,_0x4e3080,_0x5e886d){const _0x2246da=_0x11ef;let _0xe7eb27={},_0x6a6f3a=_0x4e3080[_0x2246da(0x142)]['material'];for(let _0x56dd49=0x0,_0x1cc544=_0x6a6f3a[_0x2246da(0x140)];_0x56dd49<_0x1cc544;_0x56dd49++){let _0x2f4360=_0x6a6f3a[_0x56dd49][_0x2246da(0x18d)],_0x59eb9a=_0x2f4360['id'],_0x5e7318=new MaterialPass();_0xe7eb27[_0x59eb9a]=_0x5e7318;let _0x44e329=_0x2f4360['ambient'];_0x5e7318[_0x2246da(0x165)]=new Cesium[(_0x2246da(0x17e))](_0x44e329['r'],_0x44e329['g'],_0x44e329['b'],_0x44e329['a']);let _0x45dc25=_0x2f4360['diffuse'];_0x5e7318[_0x2246da(0x180)]=new Cesium['Color'](_0x45dc25['r'],_0x45dc25['g'],_0x45dc25['b'],_0x45dc25['a']);let _0x141567=_0x2f4360[_0x2246da(0x184)];_0x5e7318['specularColor']=new Cesium[(_0x2246da(0x17e))](_0x141567['r'],_0x141567['g'],_0x141567['b'],_0x141567['a']),_0x5e7318[_0x2246da(0x17b)]=_0x2f4360['shininess'],_0x5e7318[_0x2246da(0x159)]=_0x2f4360[_0x2246da(0x170)];let _0x51f4bb=_0x2f4360[_0x2246da(0x143)],_0x13f495=_0x51f4bb[_0x2246da(0x140)];for(let _0x3a4063=0x0;_0x3a4063<_0x13f495;_0x3a4063++){let _0x2f015f=_0x51f4bb[_0x3a4063][_0x2246da(0x169)],_0x42947a=_0x2f015f['id'],_0x224a5d=_0x2f015f['addressmode']['u']===0x0?Cesium[_0x2246da(0x141)][_0x2246da(0x16f)]:Cesium[_0x2246da(0x141)][_0x2246da(0x15e)],_0x45cb6a=_0x2f015f[_0x2246da(0x186)]['v']===0x0?Cesium[_0x2246da(0x141)]['REPEAT']:Cesium['TextureWrap'][_0x2246da(0x15e)];_0x5e7318[_0x2246da(0x179)]=Cesium[_0x2246da(0x150)][_0x2246da(0x163)](_0x2f015f['texmodmatrix']);let _0x31d1f6=_0x4e3080[_0x2246da(0x152)][_0x42947a];if(Cesium[_0x2246da(0x16c)](_0x31d1f6)&&_0x31d1f6[_0x2246da(0x182)][_0x2246da(0x174)]>0x0){_0x31d1f6['wrapS']=_0x224a5d,_0x31d1f6[_0x2246da(0x171)]=_0x45cb6a;let _0x27c184=_0x5e886d[_0x2246da(0x13e)]+_0x42947a,_0xb177be=_0x7d4c1c[_0x2246da(0x14e)]['getTexture'](_0x27c184);!Cesium[_0x2246da(0x16c)](_0xb177be)&&(_0x31d1f6['isTexBlock']=![],_0xb177be=new DDSTexture(_0x7d4c1c,_0x42947a,_0x31d1f6),_0x7d4c1c[_0x2246da(0x14e)][_0x2246da(0x187)](_0x27c184,_0xb177be)),_0x5e7318[_0x2246da(0x154)][_0x2246da(0x15b)](_0xb177be);}}}return _0xe7eb27;}function calcBoundingVolumeForNormal(_0x1203c2,_0x13da17){const _0x3cc024=_0x11ef;let _0x1845c8=new Cesium[(_0x3cc024(0x16a))](),_0x1616c8=new Cesium['Cartesian3'](),_0x2d827b=_0x1203c2[_0x3cc024(0x161)][0x0],_0xdebdff=_0x2d827b[_0x3cc024(0x185)],_0x2f7027=Cesium[_0x3cc024(0x16c)](_0x1203c2['compressOptions'])&&(_0x1203c2[_0x3cc024(0x178)]&_0x6ea6a9[_0x3cc024(0x148)])===_0x6ea6a9[_0x3cc024(0x148)],_0x1e2c5c=0x1,_0x33fa96,_0x2f7315;_0x2f7027?(_0x1e2c5c=_0x1203c2['vertCompressConstant'],_0x33fa96=new Cesium[(_0x3cc024(0x17f))](_0x1203c2['minVerticesValue']['x'],_0x1203c2['minVerticesValue']['y'],_0x1203c2[_0x3cc024(0x183)]['z']),_0x2f7315=new Uint16Array(_0x2d827b['typedArray'][_0x3cc024(0x144)],_0x2d827b[_0x3cc024(0x14a)][_0x3cc024(0x167)],_0x2d827b[_0x3cc024(0x14a)]['byteLength']/0x2)):_0x2f7315=new Float32Array(_0x2d827b[_0x3cc024(0x14a)]['buffer'],_0x2d827b[_0x3cc024(0x14a)][_0x3cc024(0x167)],_0x2d827b['typedArray'][_0x3cc024(0x174)]/0x4);let _0x18e956=[];for(let _0x2ee389=0x0;_0x2ee389<_0x1203c2[_0x3cc024(0x190)];_0x2ee389++){Cesium[_0x3cc024(0x17f)][_0x3cc024(0x166)](_0x2f7315,_0xdebdff*_0x2ee389,_0x1616c8),_0x2f7027&&(_0x1616c8=Cesium[_0x3cc024(0x17f)]['multiplyByScalar'](_0x1616c8,_0x1e2c5c,_0x1616c8),_0x1616c8=Cesium[_0x3cc024(0x17f)][_0x3cc024(0x172)](_0x1616c8,_0x33fa96,_0x1616c8)),_0x18e956[_0x3cc024(0x15b)](Cesium[_0x3cc024(0x17f)]['clone'](_0x1616c8));}return Cesium[_0x3cc024(0x16a)][_0x3cc024(0x15c)](_0x18e956,_0x1845c8),Cesium['BoundingSphere']['transform'](_0x1845c8,_0x13da17,_0x1845c8),_0x18e956[_0x3cc024(0x140)]=0x0,_0x1845c8;}let scratchCenter=new Cesium[(_0x21dc2d(0x17f))]();function calcBoundingVolumeForInstance(_0x4b33dc){const _0x46bc5d=_0x21dc2d;let _0x46613d=new Cesium[(_0x46bc5d(0x16a))](),_0x12e85c=_0x4b33dc['instanceBounds'];if(!Cesium[_0x46bc5d(0x16c)](_0x12e85c))return _0x46613d;let _0x4ee5b7=new Cesium['Cartesian3'](_0x12e85c[0x0],_0x12e85c[0x1],_0x12e85c[0x2]),_0x3d92f=new Cesium[(_0x46bc5d(0x18e))](_0x12e85c[0x3],_0x12e85c[0x4],_0x12e85c[0x5]),_0x36a3cb=new Cesium[(_0x46bc5d(0x17f))][(_0x46bc5d(0x16b))](_0x4ee5b7,_0x3d92f,0.5,scratchCenter),_0x15a7a6=new Cesium[(_0x46bc5d(0x17f))][(_0x46bc5d(0x156))](_0x36a3cb,_0x4ee5b7);return _0x46613d[_0x46bc5d(0x188)]=_0x36a3cb,_0x46613d[_0x46bc5d(0x16e)]=_0x15a7a6,_0x46613d;}function calcBoundingVolume(_0x34eade,_0x263770){const _0x56aa9d=_0x21dc2d;if(_0x34eade[_0x56aa9d(0x17c)]>-0x1)return calcBoundingVolumeForInstance(_0x34eade);return calcBoundingVolumeForNormal(_0x34eade,_0x263770);}function parseGeodes(_0x587ff3,_0x833e3d,_0x3c61bb,_0x40a87e,_0x20dd16){const _0x2311b8=_0x21dc2d;let _0x270c1c={},_0x2d37f7=_0x40a87e[_0x2311b8(0x145)];for(let _0xd441cf=0x0,_0x56ed50=_0x2d37f7[_0x2311b8(0x140)];_0xd441cf<_0x56ed50;_0xd441cf++){let _0x3b6f12=_0x2d37f7[_0xd441cf],_0x382d69=_0x3b6f12[_0x2311b8(0x146)],_0x209378=Cesium[_0x2311b8(0x150)]['multiply'](_0x587ff3[_0x2311b8(0x18f)],_0x382d69,new Cesium['Matrix4']()),_0x428b80;Cesium[_0x2311b8(0x16c)](_0x20dd16[_0x2311b8(0x13f)])&&(_0x428b80=new Cesium['BoundingSphere'](_0x20dd16[_0x2311b8(0x13f)][_0x2311b8(0x189)][_0x2311b8(0x188)],_0x20dd16[_0x2311b8(0x13f)][_0x2311b8(0x189)][_0x2311b8(0x16e)]),Cesium[_0x2311b8(0x16a)][_0x2311b8(0x18b)](_0x428b80,_0x587ff3[_0x2311b8(0x18f)],_0x428b80));let _0x170f22=_0x3b6f12['skeletonNames'];for(let _0x4c57b0=0x0,_0x42cb63=_0x170f22[_0x2311b8(0x140)];_0x4c57b0<_0x42cb63;_0x4c57b0++){let _0x9a2818=_0x170f22[_0x4c57b0],_0x1ccf11=_0x833e3d['geoPackage'][_0x9a2818],_0x18eacf=_0x1ccf11['vertexPackage'],_0x1882f7=_0x1ccf11[_0x2311b8(0x14f)],_0x14e204=_0x1ccf11[_0x2311b8(0x16d)],_0x3b0cdf;_0x1882f7[_0x2311b8(0x140)]>0x0&&(_0x3b0cdf=_0x3c61bb[_0x1882f7[0x0][_0x2311b8(0x17d)]]);let _0x32bffa=Cesium[_0x2311b8(0x16c)](_0x428b80)?_0x428b80:calcBoundingVolume(_0x18eacf,_0x209378);_0x270c1c[_0x9a2818]=S3MContentFactory[_0x587ff3[_0x2311b8(0x15d)]]({'layer':_0x587ff3,'vertexPackage':_0x18eacf,'arrIndexPackage':_0x1882f7,'pickInfo':_0x14e204,'modelMatrix':_0x209378,'geoMatrix':_0x382d69,'boundingVolume':_0x32bffa,'material':_0x3b0cdf,'edgeGeometry':_0x1ccf11['edgeGeometry'],'geoName':_0x9a2818});}}if(Object[_0x2311b8(0x14d)](_0x270c1c)['length']<0x1)return;if(!Cesium[_0x2311b8(0x16c)](_0x20dd16['boundingVolume'])){let _0x2f72b4=[];for(let _0x2187f9 in _0x270c1c){_0x270c1c[_0x2311b8(0x14c)](_0x2187f9)&&_0x2f72b4[_0x2311b8(0x15b)](_0x270c1c[_0x2187f9][_0x2311b8(0x13f)]);}_0x20dd16['boundingVolume']={'sphere':Cesium['BoundingSphere'][_0x2311b8(0x17a)](_0x2f72b4)};}_0x20dd16[_0x2311b8(0x155)]=_0x270c1c;}function parsePagelods(_0x36a329,_0x561195,_0x1a3bb7){const _0x1795ba=_0x21dc2d;let _0x497fe1=_0x561195[_0x1795ba(0x158)],_0x427b22=[];for(let _0x16ad83=0x0,_0x37622f=_0x497fe1[_0x1795ba(0x177)][_0x1795ba(0x140)];_0x16ad83<_0x37622f;_0x16ad83++){let _0x242b7a={},_0x314b8f=_0x497fe1[_0x1795ba(0x177)][_0x16ad83];_0x242b7a[_0x1795ba(0x164)]=_0x314b8f[_0x1795ba(0x164)],_0x242b7a[_0x1795ba(0x18c)]=_0x314b8f[_0x1795ba(0x14b)],_0x242b7a['rangeList']=_0x314b8f[_0x1795ba(0x149)];let _0x599567=_0x314b8f[_0x1795ba(0x153)][_0x1795ba(0x188)],_0x1e24c7=_0x314b8f[_0x1795ba(0x153)]['radius'];_0x242b7a[_0x1795ba(0x18c)]!==''?_0x242b7a[_0x1795ba(0x13f)]={'sphere':{'center':new Cesium['Cartesian3'](_0x599567['x'],_0x599567['y'],_0x599567['z']),'radius':_0x1e24c7}}:_0x242b7a[_0x1795ba(0x157)]=!![],parseGeodes(_0x36a329,_0x561195,_0x1a3bb7,_0x314b8f,_0x242b7a),Cesium[_0x1795ba(0x16c)](_0x242b7a[_0x1795ba(0x155)])&&_0x427b22[_0x1795ba(0x15b)](_0x242b7a);}return _0x427b22;}S3MContentParser[_0x21dc2d(0x147)]=function(_0x259bfa,_0x201362,_0x329dec){const _0xa74af2=_0x21dc2d;if(!Cesium[_0xa74af2(0x16c)](_0x201362))return;let _0x1da6e5=parseMaterial$2(_0x259bfa['context'],_0x201362,_0x329dec),_0x5f5a93=parsePagelods(_0x259bfa,_0x201362,_0x1da6e5);return _0x5f5a93;};

    const _0x5cc6=['compressType','textureId','1aaCHhT','getCache','929012gioPfQ','layerId','destroy','pixelFormat','827519DccEXj','21SrBtrn','970264yBqVPj','Queue','height','584551fupmLl','3549qCuXdG','internalFormat','contextId','1yBZFGf','2295UfZfXh','cache','rootName','14555nNwVqe','301rhnnkn','273stiNeS','arrayBufferView'];const _0x88a5ad=_0x4562;(function(_0x5aab18,_0x3fd655){const _0x511dd5=_0x4562;while(!![]){try{const _0x2ebfe4=-parseInt(_0x511dd5(0x1e4))+-parseInt(_0x511dd5(0x1cf))*-parseInt(_0x511dd5(0x1e1))+parseInt(_0x511dd5(0x1df))*-parseInt(_0x511dd5(0x1d9))+-parseInt(_0x511dd5(0x1d5))*parseInt(_0x511dd5(0x1e5))+parseInt(_0x511dd5(0x1d4))*parseInt(_0x511dd5(0x1d0))+parseInt(_0x511dd5(0x1e0))*parseInt(_0x511dd5(0x1d3))+parseInt(_0x511dd5(0x1db));if(_0x2ebfe4===_0x3fd655)break;else _0x5aab18['push'](_0x5aab18['shift']());}catch(_0x4c3923){_0x5aab18['push'](_0x5aab18['shift']());}}}(_0x5cc6,0x7dadb));function _0x4562(_0x38eab3,_0x14dac2){_0x38eab3=_0x38eab3-0x1cd;let _0x5cc66a=_0x5cc6[_0x38eab3];return _0x5cc66a;}let TextureManager={'cache':{},'cacheSize':0x0,'freeCache':{},'freeQueue':new Cesium[(_0x88a5ad(0x1e2))](),'freeCacheSize':0x0,'throttleSize':0x32*0x400*0x400,'getCache':function(_0x4d0a33,_0x1f54b1,_0x1593e1){const _0x112229=_0x88a5ad;let _0x4cf332=this['cache'][_0x4d0a33];!_0x4cf332&&(_0x4cf332=this[_0x112229(0x1d1)][_0x4d0a33]={});let _0x41d8e9=_0x4cf332[_0x1f54b1];!_0x41d8e9&&(_0x41d8e9=_0x4cf332[_0x1f54b1]={});let _0x195e3b=_0x41d8e9[_0x1593e1];return !_0x195e3b&&(_0x195e3b=_0x41d8e9[_0x1593e1]={}),_0x195e3b;},'get':function(_0x23c37a,_0x33cd81,_0x5df743,_0x33227d){let _0x32eb1e=this['getCache'](_0x23c37a,_0x33cd81,_0x5df743),_0xa26f1f=_0x32eb1e[_0x33227d];if(!_0xa26f1f)return undefined;return _0xa26f1f['refCount']++,_0xa26f1f;},'create':function(_0x1581b9){const _0x53e2fd=_0x88a5ad;let _0x10eacf=_0x1581b9['context'],_0x1073aa=_0x10eacf['id'],_0x36aba2=_0x1581b9[_0x53e2fd(0x1dc)],_0x29ec11=_0x1581b9[_0x53e2fd(0x1d2)],_0x385f5b=_0x1581b9['textureId'],_0x47deb3=this['getCache'](_0x1073aa,_0x36aba2,_0x29ec11),_0x560964=_0x47deb3[_0x385f5b];if(_0x560964)return _0x560964['refCount']++,_0x560964;let _0x53d71e=_0x1581b9['width'],_0x2d3fbd=_0x1581b9[_0x53e2fd(0x1e3)],_0x258b66=_0x1581b9[_0x53e2fd(0x1d7)],_0x2b8227=_0x1581b9[_0x53e2fd(0x1de)],_0x5391ac=_0x1581b9[_0x53e2fd(0x1d6)],_0x504218=_0x1581b9[_0x53e2fd(0x1cd)];return _0x560964=new DDSTexture(_0x10eacf,_0x385f5b,{'context':_0x10eacf,'layerId':_0x36aba2,'rootName':_0x29ec11,'textureId':_0x385f5b,'width':_0x53d71e,'height':_0x2d3fbd,'compressType':_0x258b66,'pixelFormat':_0x2b8227,'internalFormat':_0x504218,'isTexBlock':!![],'arrayBufferView':_0x5391ac}),_0x47deb3[_0x385f5b]=_0x560964,_0x560964;},'del':function(_0x14be54){const _0x374953=_0x88a5ad;if(!_0x14be54['contextId'])return;let _0x32af77=this[_0x374953(0x1da)](_0x14be54[_0x374953(0x1ce)],_0x14be54[_0x374953(0x1dc)],_0x14be54[_0x374953(0x1d2)]);if(!_0x32af77[_0x14be54[_0x374953(0x1d8)]])return;--_0x14be54['refCount']===0x0&&(delete _0x32af77[_0x14be54[_0x374953(0x1d8)]],_0x14be54[_0x374953(0x1dd)]());}};

    const _0x3ab2=['offsetY','setBatchedAttribute','get','isCrnTexture','renderable','isRoot','requestNames','lastIndexOf','769SkBXRP','1398609tLMjzw','create','PixelFormat','enableTextureRenderable','contentResource','cache','indexOf','ComponentDatatype','isDestroyed','context','_materialManager','oriTexture','rootName','oriTextureBake','defined','textures','_subTexInfos','batchTable','subBatchValues','specularColor','destroyObject','rootTextureName','RGBA_DXT5','initBakeTexture','hasOwnProperty','textureInfo','height','prototype','subTexInfos','name','textureInitilized','czm_batchTable_xywh2','isRootTile','refCount','shininess','FLOAT','2326grWrUR','subTextureNames','textureRenderableFlag','subTextureNamesBake','subTexturesToUpload','substring','init','textureParameterBake','textureId','Cartesian4','subRequested','1671WhqWdC','_supportCompressType','format','178qMjfdw','update','compressType','3jcxGXF','push','initTexture','617101kaGtFC','textureData','ancestorMap','textureParameter','createdBaker','textureBakeRenderableFlag','offsetX','%23','_id','_subBatchValuesBake','splice','subRequestedBaker','subRequestNames','suffix','substr','arrayBufferView','url','1874733ZIwxoD','length','createTexture','tile','ancestorTexture','isLeaf','created','1085482KhvvBp','destroy','_subTextureManager','batchTableBake','Tex','subTextureManager','351079SFwGmk','subRequestNamesBake','width','del','keys','textureBakeInitilized','CRN_DXT5','curTextureName','_ancestorTextureBake','subName','Queue','diffuseColor','result','layerId','BatchTable','ambientColor','rootBatchIdMap','createBakeTexture','_subTexInfosBake','split','requestBakeSubTextures'];const _0x91ff55=_0x26d8;(function(_0x3cc2a1,_0x36592e){const _0x2ded90=_0x26d8;while(!![]){try{const _0x47acb3=parseInt(_0x2ded90(0x140))+-parseInt(_0x2ded90(0x151))+-parseInt(_0x2ded90(0x15e))*-parseInt(_0x2ded90(0x13d))+parseInt(_0x2ded90(0x108))+-parseInt(_0x2ded90(0x13a))*parseInt(_0x2ded90(0x12c))+-parseInt(_0x2ded90(0x158))+parseInt(_0x2ded90(0x137))*parseInt(_0x2ded90(0x107));if(_0x47acb3===_0x36592e)break;else _0x3cc2a1['push'](_0x3cc2a1['shift']());}catch(_0x222238){_0x3cc2a1['push'](_0x3cc2a1['shift']());}}}(_0x3ab2,0xef2f7));function _0x26d8(_0x269f1a,_0x32d95b){_0x269f1a=_0x269f1a-0xff;let _0x3ab28c=_0x3ab2[_0x269f1a];return _0x3ab28c;}function MaterialExt(){const _0x312038=_0x26d8;this[_0x312038(0x104)]=![],this[_0x312038(0x156)]=![],this[_0x312038(0x16b)]=undefined,this[_0x312038(0x154)]=undefined,this['refCount']=0x0,this['id']=undefined,this[_0x312038(0x16d)]=new Cesium[(_0x312038(0x135))](0x1,0x1,0x1,0x1),this[_0x312038(0x169)]=new Cesium[(_0x312038(0x135))](0x1,0x1,0x1,0x1),this[_0x312038(0x11b)]=new Cesium[(_0x312038(0x135))](0x0),this[_0x312038(0x12a)]=0x32,this['bTransparentSorting']=![],this[_0x312038(0x117)]=[],this[_0x312038(0x157)]=![],this[_0x312038(0x144)]=![],this['subRequested']=![],this[_0x312038(0x14b)]=![],this[_0x312038(0x14c)]=undefined,this[_0x312038(0x15f)]=undefined,this['subTextureNames']=undefined,this[_0x312038(0x12f)]=undefined,this[_0x312038(0x11a)]=undefined,this[_0x312038(0x115)]=undefined,this[_0x312038(0x119)]=undefined,this['batchTableBake']=undefined,this['ancestorTexture']=undefined,this[_0x312038(0x113)]=undefined,this[_0x312038(0x143)]=undefined,this[_0x312038(0x133)]=undefined,this[_0x312038(0x126)]=![],this['textureBakeInitilized']=![],this[_0x312038(0x12e)]=![],this[_0x312038(0x145)]=![],this[_0x312038(0x102)]=![],this[_0x312038(0x130)]=new Cesium[(_0x312038(0x168))]();}let _descriptionMap={};function updateTextureBatchTable(_0x18d045,_0x447823,_0x4f7ef5){const _0x195e5f=_0x26d8;for(let _0x5e637a in _0x4f7ef5){if(_0x4f7ef5[_0x195e5f(0x120)](_0x5e637a)){let _0x58d10b=_0x4f7ef5[_0x5e637a],_0x494f7c=Number(_0x5e637a);_0x447823[_0x195e5f(0x100)](_0x494f7c,0x0,_0x58d10b);}}_0x447823[_0x195e5f(0x13b)](_0x18d045);}function getAncestorTexture(_0x3d22c1,_0x24dbda,_0x133791,_0x5eb95e,_0x376285,_0x178113){const _0x2219df=_0x26d8;let _0x149dd4=_0x376285[_0x5eb95e];if(!_0x149dd4)return undefined;let _0x43d9db=TextureManager[_0x2219df(0x101)](_0x3d22c1,_0x24dbda,_0x133791,_0x149dd4);while(_0x149dd4&&_0x43d9db&&!_0x43d9db[_0x2219df(0x103)]){_0x43d9db['refCount']--,_0x149dd4=_0x376285[_0x149dd4],_0x43d9db=TextureManager[_0x2219df(0x101)](_0x3d22c1,_0x24dbda,_0x133791,_0x149dd4);}return _0x178113[_0x2219df(0x125)]=_0x149dd4,_0x43d9db;}function getName(_0x18894b){const _0x1257ef=_0x26d8;let _0x300020=_0x18894b['indexOf']('.');return _0x18894b[_0x1257ef(0x14e)](0x0,_0x300020);}MaterialExt[_0x91ff55(0x123)][_0x91ff55(0x16f)]=function(_0x5d5b5c,_0x437e44,_0x38e6ea,_0x4a4142,_0x1a159f,_0x4995ca,_0x52b15a,_0x26b104){const _0x13a0b9=_0x91ff55;if(this[_0x13a0b9(0x144)])return undefined;this[_0x13a0b9(0x133)]={'context':_0x5d5b5c,'layer':_0x437e44,'isRoot':_0x38e6ea,'rootName':_0x4a4142,'curTextureName':_0x1a159f,'textureInfo':_0x4995ca,'rootBatchIdMap':_0x52b15a,'ancestorMap':_0x26b104},this['createdBaker']=!![],this[_0x13a0b9(0x14b)]=_0x38e6ea;let _0x21c2f2=_0x4995ca['textureData'],_0x30ad28=PixelFormat['RGBA_DXT5'],_0x463507=TextureManager[_0x13a0b9(0x109)]({'context':_0x5d5b5c,'layerId':_0x437e44['id'],'rootName':_0x4a4142,'textureId':_0x4995ca['id'],'width':_0x4995ca[_0x13a0b9(0x160)],'height':_0x4995ca[_0x13a0b9(0x122)],'compressType':_0x4995ca[_0x13a0b9(0x13c)],'pixelFormat':_0x4995ca[_0x13a0b9(0x139)],'internalFormat':_0x30ad28,'arrayBufferView':_0x21c2f2});_0x463507['renderable']=_0x38e6ea;let _0x2be774=_0x4995ca[_0x13a0b9(0x124)][_0x13a0b9(0x152)],_0x4fa54c=_0x4995ca[_0x13a0b9(0x11d)],_0x4c9745=_0x52b15a[_0x4fa54c];this[_0x13a0b9(0x117)]['push'](_0x463507);let _0x64361f=[{'functionName':_0x13a0b9(0x127),'componentDatatype':ComponentDatatype[_0x13a0b9(0x12b)],'componentsPerAttribute':0x4}],_0x1d3b3c=defined(_0x4c9745)?Object[_0x13a0b9(0x162)](_0x4c9745)[_0x13a0b9(0x152)]:_0x2be774;this['batchTableBake']=new BatchTable(_0x5d5b5c,_0x64361f,_0x1d3b3c),this[_0x13a0b9(0x15b)][_0x13a0b9(0x14d)]='_2';let _0x5aa82f=_descriptionMap[_0x437e44[_0x13a0b9(0x125)]];!defined(_0x5aa82f)&&(_0x5aa82f=_descriptionMap[_0x437e44[_0x13a0b9(0x125)]]={});let _0x3241a1=_0x5aa82f[_0x4a4142];!defined(_0x3241a1)&&(_0x3241a1=_0x5aa82f[_0x4a4142]={});let _0x3c4f00=_0x3241a1[_0x1a159f];!defined(_0x3c4f00)&&(_0x3c4f00=_0x3241a1[_0x1a159f]={});let _0x3ebf7a=_0x4995ca[_0x13a0b9(0x124)];for(let _0x13dfb8=0x0;_0x13dfb8<_0x2be774;_0x13dfb8++){let _0x3ad57d=_0x3ebf7a[_0x13dfb8],_0x281e77=_0x3ad57d[_0x13a0b9(0x167)][_0x13a0b9(0x171)]('_')[0x0],_0x3a30d8=_0x3ad57d[_0x13a0b9(0x146)],_0x3ff920=_0x3ad57d['offsetY'],_0x3b9860=_0x3ad57d[_0x13a0b9(0x160)],_0x47600e=_0x3ad57d[_0x13a0b9(0x122)],_0x9392=new Cartesian4(_0x3a30d8,_0x3ff920,_0x3b9860,_0x47600e);_0x3c4f00[_0x281e77]=_0x9392;}if(!_0x38e6ea){this['subRequestNamesBake']=[];for(let _0x3f9fdc=0x0;_0x3f9fdc<_0x4995ca['requestNames'][_0x13a0b9(0x152)];_0x3f9fdc++){let _0x43bc32=_0x4995ca[_0x13a0b9(0x105)][_0x3f9fdc],_0x1178c7=getName(_0x43bc32);if(_0x1178c7[_0x13a0b9(0x171)]('_')[0x0]===_0x13a0b9(0x15c)){let _0x3013af=_0x43bc32['split']('#'),_0x598faa=getName(_0x3013af[0x0]);if(_0x3013af[_0x13a0b9(0x152)]>0x1){let _0x32c7ec=_0x3013af[0x1],_0x30ae10=_0x32c7ec['length'];for(let _0x188fed=0x0;_0x188fed<_0x30ae10;_0x188fed+=0x3){let _0x547816=_0x32c7ec[_0x13a0b9(0x131)](_0x188fed,_0x188fed+0x3),_0x5096b1=_0x598faa+'_'+_0x547816;this[_0x13a0b9(0x15f)][_0x13a0b9(0x13e)](_0x5096b1);}}}else this['subRequestNamesBake'][_0x13a0b9(0x13e)](_0x1178c7);}}return this[_0x13a0b9(0x115)]=_0x463507,_0x463507;},MaterialExt[_0x91ff55(0x123)][_0x91ff55(0x13f)]=function(){const _0xc3ae56=_0x91ff55;if(this[_0xc3ae56(0x126)]||!this['textureParameter'])return;this[_0xc3ae56(0x126)]=!![];let _0x205682=this[_0xc3ae56(0x143)][_0xc3ae56(0x111)],_0x4e35c7=this['textureParameter']['layer'],_0x54756c=this[_0xc3ae56(0x143)][_0xc3ae56(0x104)],_0x14aa35=this['textureParameter'][_0xc3ae56(0x114)],_0x31ec1f=this[_0xc3ae56(0x143)][_0xc3ae56(0x165)],_0x4f34e0=this['textureParameter'][_0xc3ae56(0x121)],_0x13cf56=this[_0xc3ae56(0x143)]['rootBatchIdMap'],_0x571c8d=this[_0xc3ae56(0x143)][_0xc3ae56(0x142)];this[_0xc3ae56(0x143)]=undefined;let _0x2d1dd2={},_0x4cdb81=_0x4f34e0[_0xc3ae56(0x11d)],_0x12dda1=_0x13cf56[_0x4cdb81],_0x2dcdd7=_0x54756c?undefined:getAncestorTexture(_0x205682['id'],_0x4e35c7['id'],_0x14aa35,_0x31ec1f,_0x571c8d,_0x2d1dd2),_0x3d1f6d=_descriptionMap[_0x4e35c7['name']];!_0x3d1f6d&&(_0x3d1f6d=_descriptionMap[_0x4e35c7[_0xc3ae56(0x125)]]={});let _0x517f7b=_0x3d1f6d[_0x14aa35];!_0x517f7b&&(_0x517f7b=_0x3d1f6d[_0x14aa35]={});let _0x1661bd=_0x517f7b[_0x31ec1f];!_0x1661bd&&(_0x1661bd=_0x517f7b[_0x31ec1f]={});let _0x5cec9f=_0x54756c?undefined:_0x2d1dd2['name']?_0x517f7b[_0x2d1dd2[_0xc3ae56(0x125)]]:undefined,_0x595ca4={},_0x4555a5=_0x4f34e0['subTexInfos'],_0x452db1=[],_0x2159ea=_0x4f34e0[_0xc3ae56(0x124)]['length'];for(let _0x3bc923=0x0;_0x3bc923<_0x2159ea;_0x3bc923++){let _0x13c248=_0x4555a5[_0x3bc923],_0x4ab38b=_0x13c248[_0xc3ae56(0x167)][_0xc3ae56(0x171)]('_')[0x0],_0x3d6373=_0x13c248[_0xc3ae56(0x146)],_0x5c1e56=_0x13c248[_0xc3ae56(0xff)],_0x56c003=_0x13c248[_0xc3ae56(0x160)],_0x2023b9=_0x13c248['height'],_0x34cad7=new Cesium[(_0xc3ae56(0x135))](_0x3d6373,_0x5c1e56,_0x56c003,_0x2023b9),_0x400a1d=_0x12dda1?_0x12dda1[_0x4ab38b]:_0x3bc923,_0x1299d5=_0x54756c?undefined:_0x5cec9f?_0x5cec9f[_0x4ab38b]:undefined,_0x306c09=_0x1299d5?_0x1299d5:_0x34cad7;this['batchTable']['setBatchedAttribute'](_0x400a1d,0x0,_0x306c09),_0x595ca4[_0x400a1d]=_0x34cad7,_0x1661bd[_0x4ab38b]=_0x34cad7,_0x452db1[_0xc3ae56(0x13e)](_0x13c248[_0xc3ae56(0x167)]);}this[_0xc3ae56(0x124)]=_0x4555a5,this[_0xc3ae56(0x12d)]=_0x452db1,this[_0xc3ae56(0x11a)]=_0x595ca4,this['ancestorTexture']=_0x2dcdd7;},MaterialExt[_0x91ff55(0x123)][_0x91ff55(0x11f)]=function(){const _0x3e0123=_0x91ff55;if(this[_0x3e0123(0x163)]||!defined(this[_0x3e0123(0x133)]))return;this[_0x3e0123(0x163)]=!![];let _0x34c349=this['textureParameterBake'][_0x3e0123(0x111)],_0x459071=this[_0x3e0123(0x133)]['layer'],_0x45f2c2=this[_0x3e0123(0x133)][_0x3e0123(0x104)],_0x583fc8=this[_0x3e0123(0x133)][_0x3e0123(0x114)],_0x4d8123=this[_0x3e0123(0x133)]['curTextureName'],_0x1f2053=this['textureParameterBake'][_0x3e0123(0x121)],_0x28b36c=this[_0x3e0123(0x133)][_0x3e0123(0x16e)],_0x4f84d7=this[_0x3e0123(0x133)]['ancestorMap'];this['textureParameterBake']=undefined;let _0x1648c0={},_0x470ba9=_0x1f2053[_0x3e0123(0x11d)],_0x34da58=_0x28b36c[_0x470ba9],_0x19a85a=_0x45f2c2?undefined:getAncestorTexture(_0x34c349['id'],_0x459071['id'],_0x583fc8,_0x4d8123,_0x4f84d7,_0x1648c0),_0x33e744=_descriptionMap[_0x459071['name']];!defined(_0x33e744)&&(_0x33e744=_descriptionMap[_0x459071['name']]={});let _0x2e9498=_0x33e744[_0x583fc8];!defined(_0x2e9498)&&(_0x2e9498=_0x33e744[_0x583fc8]={});let _0x598cd9=_0x2e9498[_0x4d8123];!defined(_0x598cd9)&&(_0x598cd9=_0x2e9498[_0x4d8123]={});let _0x3c9793=_0x45f2c2?undefined:defined(_0x1648c0[_0x3e0123(0x125)])?_0x2e9498[_0x1648c0[_0x3e0123(0x125)]]:undefined,_0x5027e0={},_0x1bfb1d=_0x1f2053[_0x3e0123(0x124)],_0x568f94=[],_0x4aec4e=_0x1f2053[_0x3e0123(0x124)][_0x3e0123(0x152)];for(let _0x4e9711=0x0;_0x4e9711<_0x4aec4e;_0x4e9711++){let _0x4100e4=_0x1bfb1d[_0x4e9711],_0x3f6cc6=_0x4100e4[_0x3e0123(0x167)][_0x3e0123(0x171)]('_')[0x0],_0x42a426=_0x4100e4[_0x3e0123(0x146)],_0x4d964b=_0x4100e4[_0x3e0123(0xff)],_0x558fd0=_0x4100e4[_0x3e0123(0x160)],_0x393d72=_0x4100e4[_0x3e0123(0x122)],_0x1ddc0f=new Cartesian4(_0x42a426,_0x4d964b,_0x558fd0,_0x393d72),_0x525a4b=defined(_0x34da58)?_0x34da58[_0x3f6cc6]:_0x4e9711,_0x5a9d81=_0x45f2c2?undefined:defined(_0x3c9793)?_0x3c9793[_0x3f6cc6]:undefined,_0x17056a=defined(_0x5a9d81)?_0x5a9d81:_0x1ddc0f;this[_0x3e0123(0x15b)]['setBatchedAttribute'](_0x525a4b,0x0,_0x17056a),_0x5027e0[_0x525a4b]=_0x1ddc0f,_0x598cd9[_0x3f6cc6]=_0x1ddc0f,_0x568f94[_0x3e0123(0x13e)](_0x4100e4['subName']);}this[_0x3e0123(0x170)]=_0x1bfb1d,this['subTextureNamesBake']=_0x568f94,this[_0x3e0123(0x149)]=_0x5027e0,this[_0x3e0123(0x166)]=_0x19a85a;},MaterialExt['prototype'][_0x91ff55(0x153)]=function(_0x1a2031,_0x1313cc,_0x446229,_0x181c17,_0x206968){const _0xe1e98b=_0x91ff55;if(this[_0xe1e98b(0x157)])return undefined;let _0x307276=_0x1a2031[_0xe1e98b(0x111)],_0x59d1d9=_0x446229['id'],_0x198ffe=_0x206968['rootBatchIdMap'],_0x36643e=_0x206968['ancestorMap'];this[_0xe1e98b(0x102)]=_0x446229['compressType']===_0xaa1cd8[_0xe1e98b(0x164)],this[_0xe1e98b(0x143)]={'context':_0x307276,'layer':_0x1a2031,'isRoot':_0x1313cc[_0xe1e98b(0x128)],'rootName':_0x1313cc[_0xe1e98b(0x114)],'curTextureName':_0x59d1d9,'textureInfo':_0x446229,'rootBatchIdMap':_0x198ffe,'ancestorMap':_0x36643e},this[_0xe1e98b(0x104)]=_0x1313cc[_0xe1e98b(0x128)],this[_0xe1e98b(0x157)]=!![],this['subRequested']=_0x1313cc[_0xe1e98b(0x128)];let _0x44662b=_0x446229[_0xe1e98b(0x141)],_0x249b64=Cesium[_0xe1e98b(0x10a)][_0xe1e98b(0x11e)],_0x7b732d=TextureManager['create']({'context':_0x307276,'layerId':_0x1a2031['id'],'rootName':_0x1313cc['rootName'],'textureId':_0x446229['id'],'width':_0x446229['width'],'height':_0x446229['height'],'compressType':_0x446229[_0xe1e98b(0x13c)],'supportCompressType':_0x1a2031[_0xe1e98b(0x138)],'pixelFormat':_0x446229[_0xe1e98b(0x139)],'internalFormat':_0x249b64,'arrayBufferView':_0x44662b});_0x7b732d[_0xe1e98b(0x103)]=_0x1313cc[_0xe1e98b(0x128)];let _0x263ace=_0x446229[_0xe1e98b(0x124)][_0xe1e98b(0x152)],_0x3aee29=_0x446229[_0xe1e98b(0x11d)],_0x29fc21=_0x198ffe[_0x3aee29];this[_0xe1e98b(0x117)][_0xe1e98b(0x13e)](_0x7b732d);let _0x5b0db2=[{'functionName':'atlas_batchTable_xywh','componentDatatype':Cesium[_0xe1e98b(0x10f)][_0xe1e98b(0x12b)],'componentsPerAttribute':0x4}],_0x26b99a=_0x29fc21?Object[_0xe1e98b(0x162)](_0x29fc21)[_0xe1e98b(0x152)]:_0x263ace;this[_0xe1e98b(0x119)]=new Cesium[(_0xe1e98b(0x16c))](_0x307276,_0x5b0db2,_0x26b99a);let _0x2120d7=_descriptionMap[_0x1a2031[_0xe1e98b(0x125)]];!_0x2120d7&&(_0x2120d7=_descriptionMap[_0x1a2031['name']]={});let _0x5b8b45=_0x2120d7[_0x1313cc[_0xe1e98b(0x114)]];!_0x5b8b45&&(_0x5b8b45=_0x2120d7[_0x1313cc['rootName']]={});let _0x3414ba=_0x5b8b45[_0x59d1d9];!_0x3414ba&&(_0x3414ba=_0x5b8b45[_0x59d1d9]={});let _0x28c220=_0x446229[_0xe1e98b(0x124)];for(let _0x28ba1e=0x0;_0x28ba1e<_0x263ace;_0x28ba1e++){let _0x326536=_0x28c220[_0x28ba1e],_0x177a01=_0x326536['subName']['split']('_')[0x0],_0x395f19=_0x326536[_0xe1e98b(0x146)],_0x58012f=_0x326536[_0xe1e98b(0xff)],_0x3818fe=_0x326536[_0xe1e98b(0x160)],_0x53d423=_0x326536[_0xe1e98b(0x122)],_0x9ccab2=new Cesium[(_0xe1e98b(0x135))](_0x395f19,_0x58012f,_0x3818fe,_0x53d423);_0x3414ba[_0x177a01]=_0x9ccab2;}if(!_0x1313cc['isRootTile']){this[_0xe1e98b(0x14c)]=[];for(let _0x4cecb0=0x0;_0x4cecb0<_0x446229[_0xe1e98b(0x105)]['length'];_0x4cecb0++){let _0x2bfb99=_0x446229[_0xe1e98b(0x105)][_0x4cecb0],_0x1e7364=getName(_0x2bfb99);if(_0x1e7364['split']('_')[0x0]===_0xe1e98b(0x15c)){let _0x7e2ecb=_0x2bfb99['split']('#'),_0x8c8706=getName(_0x7e2ecb[0x0]);if(_0x7e2ecb[_0xe1e98b(0x152)]>0x1){let _0x394194=_0x7e2ecb[0x1],_0x59f3c5=_0x394194[_0xe1e98b(0x152)];for(let _0x519790=0x0;_0x519790<_0x59f3c5;_0x519790+=0x3){let _0x4aba13=_0x394194[_0xe1e98b(0x131)](_0x519790,_0x519790+0x3),_0x5a416d=_0x8c8706+'_'+_0x4aba13;this[_0xe1e98b(0x14c)][_0xe1e98b(0x13e)](_0x5a416d);}}}else this[_0xe1e98b(0x14c)][_0xe1e98b(0x13e)](_0x1e7364);}}return this['isLeaf']=!_0x1313cc[_0xe1e98b(0x128)]&&!(_0x446229['requestNames']['length']===0x1&&_0x446229[_0xe1e98b(0x105)][0x0]===_0x59d1d9),this[_0xe1e98b(0x113)]=_0x7b732d,_0x7b732d;},MaterialExt[_0x91ff55(0x123)]['requestSubTextures']=function(_0x2bc38,_0x3d017d){const _0x43ce90=_0x91ff55;if(this[_0x43ce90(0x136)])return;if(!this[_0x43ce90(0x14c)])return;let _0x262b99=_0x3d017d[_0x43ce90(0x111)],_0x575aef=this[_0x43ce90(0x14c)],_0x593878=this[_0x43ce90(0x124)],_0x3590c9=this['subTextureNames'],_0x3d5b2a=this[_0x43ce90(0x11a)],_0xabdb6=this[_0x43ce90(0x113)],_0x1cec34=[],_0x560748=this[_0x43ce90(0x154)][_0x43ce90(0x10c)][_0x43ce90(0x150)][_0x43ce90(0x131)](0x0,this[_0x43ce90(0x154)][_0x43ce90(0x10c)][_0x43ce90(0x150)][_0x43ce90(0x106)]('/')+0x1),_0x2c0584=_0x3d017d[_0x43ce90(0x15a)],_0xf32c67=this[_0x43ce90(0x130)];for(let _0x1d11fb=0x0,_0x315981=_0x575aef[_0x43ce90(0x152)];_0x1d11fb<_0x315981;_0x1d11fb++){let _0x112a45=_0x575aef[_0x1d11fb],_0x48dbf4=_0x2c0584['get'](_0x3d017d['id'],_0x560748,_0x112a45,this,this[_0x43ce90(0x154)]);if(!_0x48dbf4)continue;let _0x4db44b=_0x48dbf4[_0x43ce90(0x16a)];_0x1cec34[_0x43ce90(0x13e)](_0x1d11fb);for(let _0x1e6033 in _0x4db44b){if(_0x4db44b[_0x43ce90(0x120)](_0x1e6033)){let _0xf78c8a=_0x4db44b[_0x1e6033],_0x3b7fc8=_0x3590c9[_0x43ce90(0x10e)](_0x1e6033);if(_0x3b7fc8<0x0&&this[_0x43ce90(0x156)])continue;let _0x98aa4d=0x0,_0x3212bc=0x0,_0x5f5024=_0xf78c8a[_0x43ce90(0x160)],_0x3de53d=_0xf78c8a['height'];if(_0x3b7fc8>=0x0){let _0x544718=_0x593878[_0x3b7fc8];_0x98aa4d=_0x544718[_0x43ce90(0x146)],_0x3212bc=_0x544718[_0x43ce90(0xff)];}!this[_0x43ce90(0x156)]?_0xabdb6[_0x43ce90(0x14f)]=_0xf78c8a[_0x43ce90(0x14f)]:_0xf32c67['enqueue']({'texture':_0xabdb6,'subTextureInfo':{'xOffset':_0x98aa4d,'yOffset':_0x3212bc,'width':_0x5f5024,'height':_0x3de53d,'arrayBufferView':_0xf78c8a[_0x43ce90(0x14f)]}});}}}if(_0x1cec34[_0x43ce90(0x152)]===_0x575aef[_0x43ce90(0x152)])_0x575aef[_0x43ce90(0x152)]=0x0;else {let _0x19b14f=0x0;for(let _0x3a7037=0x0,_0x5eb0e0=_0x1cec34[_0x43ce90(0x152)];_0x3a7037<_0x5eb0e0;_0x3a7037++){_0x575aef[_0x43ce90(0x14a)](_0x1cec34[_0x3a7037]-_0x19b14f,0x1),_0x19b14f++;}}_0x575aef[_0x43ce90(0x152)]===0x0&&(this[_0x43ce90(0x12e)]=!![],!this[_0x43ce90(0x156)]&&_0xabdb6[_0x43ce90(0x132)](),updateTextureBatchTable(_0x2bc38,this['batchTable'],_0x3d5b2a),this[_0x43ce90(0x136)]=!![],this[_0x43ce90(0x14c)]=undefined,this[_0x43ce90(0x12d)]=undefined,this['subBatchValues']=undefined,this[_0x43ce90(0x124)]=undefined);},MaterialExt[_0x91ff55(0x123)][_0x91ff55(0x172)]=function(_0x27c011,_0x549449,_0x2a3954,_0x5cdd15){const _0xe334e5=_0x91ff55;if(this[_0xe334e5(0x14b)])return;if(!defined(this['subRequestNamesBake']))return;let _0x5aadc4=this['subRequestNamesBake'],_0x56ea09=this['_subTexInfosBake'],_0x2bf950=this[_0xe334e5(0x12f)],_0x1aca6a=this[_0xe334e5(0x149)],_0x1b5dbc=this[_0xe334e5(0x115)],_0x4dd31f=[],_0x275cd7=_0x2a3954['_baseUri'],_0x51aba1=_0x2a3954['subTextureManager'];for(let _0x4fe3a3=0x0,_0x11f580=_0x5aadc4[_0xe334e5(0x152)];_0x4fe3a3<_0x11f580;_0x4fe3a3++){let _0x24e975=_0x5aadc4[_0x4fe3a3],_0x2d2efd=_0x51aba1[_0xe334e5(0x101)](_0x2a3954[_0xe334e5(0x148)],_0x275cd7,_0x24e975,this);if(!_0x2d2efd)continue;let _0x42f4ba=_0x2d2efd[_0xe334e5(0x16a)];_0x4dd31f[_0xe334e5(0x13e)](_0x4fe3a3);for(let _0x40d46a in _0x42f4ba){if(_0x42f4ba[_0xe334e5(0x120)](_0x40d46a)){let _0x3587a5=_0x42f4ba[_0x40d46a],_0x5a1476=_0x2bf950[_0xe334e5(0x10e)](_0x40d46a);if(_0x5a1476<0x0&&this[_0xe334e5(0x156)])continue;let _0x3c3cc5=0x0,_0x70c292=0x0,_0x4e50b9=_0x3587a5['width'],_0x280088=_0x3587a5[_0xe334e5(0x122)];if(_0x5a1476>=0x0){let _0x5dd67d=_0x56ea09[_0x5a1476];_0x3c3cc5=_0x5dd67d[_0xe334e5(0x146)],_0x70c292=_0x5dd67d[_0xe334e5(0xff)];}_0x5cdd15['enqueue']({'texture':_0x1b5dbc,'subTextureInfo':{'xOffset':_0x3c3cc5,'yOffset':_0x70c292,'width':_0x4e50b9,'height':_0x280088,'arrayBufferView':_0x3587a5['arrayBufferView']}});}}}if(_0x4dd31f['length']===_0x5aadc4[_0xe334e5(0x152)])_0x5aadc4['length']=0x0;else {let _0xff3ea2=0x0;for(let _0x2a9fd7=0x0,_0x3de087=_0x4dd31f['length'];_0x2a9fd7<_0x3de087;_0x2a9fd7++){_0x5aadc4[_0xe334e5(0x14a)](_0x4dd31f[_0x2a9fd7]-_0xff3ea2,0x1),_0xff3ea2++;}}_0x5aadc4[_0xe334e5(0x152)]===0x0&&(this[_0xe334e5(0x145)]=!![],!this['isLeaf']&&_0x1b5dbc[_0xe334e5(0x132)](),this['subRequestedBaker']=!![],this[_0xe334e5(0x15f)]=undefined,this[_0xe334e5(0x12f)]=undefined,this[_0xe334e5(0x149)]=undefined,this[_0xe334e5(0x170)]=undefined,updateTextureBatchTable(_0x27c011,this[_0xe334e5(0x15b)],_0x1aca6a));},MaterialExt[_0x91ff55(0x123)][_0x91ff55(0x10b)]=function(){const _0x27ef3f=_0x91ff55;if(!this[_0x27ef3f(0x12e)])return;this[_0x27ef3f(0x12e)]=![];let _0x2a4da2=this['oriTexture'];_0x2a4da2[_0x27ef3f(0x103)]=!![],this['ancestorTexture']&&this[_0x27ef3f(0x155)][_0x27ef3f(0x134)]!==_0x2a4da2[_0x27ef3f(0x134)]&&TextureManager[_0x27ef3f(0x161)](this[_0x27ef3f(0x155)]),this[_0x27ef3f(0x117)][0x0]=_0x2a4da2,this[_0x27ef3f(0x113)]=undefined,this[_0x27ef3f(0x155)]=undefined;},MaterialExt[_0x91ff55(0x123)]['enableBakeTextureRenderable']=function(){const _0x1bf959=_0x91ff55;if(!this[_0x1bf959(0x145)])return;this['textureBakeRenderableFlag']=![];let _0x398b6d=this[_0x1bf959(0x115)];_0x398b6d[_0x1bf959(0x103)]=!![],defined(this['_ancestorTextureBake'])&&this[_0x1bf959(0x166)][_0x1bf959(0x134)]!==_0x398b6d[_0x1bf959(0x134)]&&TextureManager[_0x1bf959(0x161)](this[_0x1bf959(0x166)]),this[_0x1bf959(0x117)][0x1]=_0x398b6d,this[_0x1bf959(0x115)]=undefined,this[_0x1bf959(0x166)]=undefined;},MaterialExt[_0x91ff55(0x123)][_0x91ff55(0x110)]=function(){return ![];},MaterialExt[_0x91ff55(0x123)][_0x91ff55(0x159)]=function(){const _0x1619bd=_0x91ff55;if(--this[_0x1619bd(0x129)]>0x0)return;let _0x5e0d38=this[_0x1619bd(0x154)]['layer'],_0x4dc482=_0x5e0d38[_0x1619bd(0x112)];delete _0x4dc482[_0x1619bd(0x10d)][this['id']],this[_0x1619bd(0x16d)]=null,this[_0x1619bd(0x169)]=null,this['specularColor']=null;for(let _0x2711ed=0x0,_0x954ef6=this['textures']['length'];_0x2711ed<_0x954ef6;_0x2711ed++){let _0x8b45d3=this[_0x1619bd(0x117)][_0x2711ed];TextureManager['del'](_0x8b45d3);}this[_0x1619bd(0x117)][_0x1619bd(0x152)]=0x0,this[_0x1619bd(0x119)]=this['batchTable']&&this[_0x1619bd(0x119)][_0x1619bd(0x159)](),this[_0x1619bd(0x15b)]=this[_0x1619bd(0x15b)]&&this[_0x1619bd(0x15b)][_0x1619bd(0x159)](),this[_0x1619bd(0x118)]=undefined,this[_0x1619bd(0x12d)]=undefined,this[_0x1619bd(0x11a)]=undefined,this['subTextureNamesBake']=undefined,this[_0x1619bd(0x170)]=undefined;Cesium[_0x1619bd(0x116)](this[_0x1619bd(0x155)])&&this[_0x1619bd(0x155)][_0x1619bd(0x134)]!==this[_0x1619bd(0x113)][_0x1619bd(0x134)]&&TextureManager[_0x1619bd(0x161)](this[_0x1619bd(0x155)]);this['oriTexture']=undefined,this[_0x1619bd(0x155)]=undefined,this[_0x1619bd(0x154)]=undefined,this['textureParameter']=undefined,this[_0x1619bd(0x115)]=undefined;if(Cesium['defined'](this[_0x1619bd(0x14c)])){for(let _0x198ca8=0x0,_0x561f3b=this[_0x1619bd(0x14c)][_0x1619bd(0x152)];_0x198ca8<_0x561f3b;_0x198ca8++){let _0xcb4de0=this[_0x1619bd(0x14c)][_0x198ca8],_0x106c0c=_0xcb4de0[_0x1619bd(0x171)]('.')[0x0],_0x416f80=_0xcb4de0[_0x1619bd(0x10e)](_0x1619bd(0x147));_0x106c0c=_0x416f80>-0x1?_0x106c0c+_0xcb4de0[_0x1619bd(0x131)](_0x416f80):_0x106c0c,_0x5e0d38['_subTextureManager'][_0x1619bd(0x161)](_0x5e0d38['id'],_0x106c0c);}this[_0x1619bd(0x14c)]=undefined;}if(Cesium[_0x1619bd(0x116)](this[_0x1619bd(0x15f)])){for(i=0x0,j=this[_0x1619bd(0x15f)][_0x1619bd(0x152)];i<j;i++){let _0xf6b331=this[_0x1619bd(0x15f)][i],_0x306155=_0xf6b331[_0x1619bd(0x171)]('.')[0x0],_0x5d8ee9=_0xf6b331[_0x1619bd(0x10e)](_0x1619bd(0x147));_0x306155=_0x5d8ee9>-0x1?_0x306155+_0xf6b331[_0x1619bd(0x131)](_0x5d8ee9):_0x306155,_0x5e0d38[_0x1619bd(0x15d)][_0x1619bd(0x161)](_0x5e0d38['id'],_0x306155);}this[_0x1619bd(0x14c)]=undefined;}return Cesium[_0x1619bd(0x11c)](this);};

    const _0x42a8=['1SlHRwy','65011UQMsZy','860356KLZpUl','4705icIJlP','447969Mcpqpv','640954YzqOvu','refCount','50680xvtcRW','2FNmaIp','65pLIpxl','1YhHBnF','prototype','create','cache','free','13281LatVDU','25aEfrkd'];const _0x451d18=_0x7ca2;(function(_0x2e50ee,_0x3fa1b9){const _0x50a2fe=_0x7ca2;while(!![]){try{const _0x2524fa=parseInt(_0x50a2fe(0x87))*parseInt(_0x50a2fe(0x8d))+-parseInt(_0x50a2fe(0x91))+parseInt(_0x50a2fe(0x96))+parseInt(_0x50a2fe(0x92))*parseInt(_0x50a2fe(0x8e))+-parseInt(_0x50a2fe(0x86))*-parseInt(_0x50a2fe(0x90))+parseInt(_0x50a2fe(0x93))*-parseInt(_0x50a2fe(0x88))+parseInt(_0x50a2fe(0x8f))*parseInt(_0x50a2fe(0x94));if(_0x2524fa===_0x3fa1b9)break;else _0x2e50ee['push'](_0x2e50ee['shift']());}catch(_0x3e2aaa){_0x2e50ee['push'](_0x2e50ee['shift']());}}}(_0x42a8,0x78a8d));function MaterialManager(){const _0x3fd9d1=_0x7ca2;this[_0x3fd9d1(0x8b)]={};}MaterialManager[_0x451d18(0x89)][_0x451d18(0x8a)]=function(_0x1d323e){const _0x35d284=_0x451d18;let _0x15a09a=this[_0x35d284(0x8b)][_0x1d323e];return _0x15a09a?_0x15a09a[_0x35d284(0x95)]++:(_0x15a09a=new MaterialExt(),this[_0x35d284(0x8b)][_0x1d323e]=_0x15a09a),_0x15a09a;},MaterialManager['prototype'][_0x451d18(0x8c)]=function(_0xef5e1f){const _0x10738d=_0x451d18;let _0x53fd1c=this[_0x10738d(0x8b)][_0xef5e1f];if(!_0x53fd1c)return;--_0x53fd1c[_0x10738d(0x95)]===0x0&&(delete this[_0x10738d(0x8b)][_0xef5e1f],_0x53fd1c['destroy']());};function _0x7ca2(_0x4b5f1c,_0x3f758f){_0x4b5f1c=_0x4b5f1c-0x86;let _0x42a8a8=_0x42a8[_0x4b5f1c];return _0x42a8a8;}

    const _0x29d2=['processRequests','promisePack','push','7602XePxit','73742ZMtIeC','requestHeapPack','quadKeyPack','defer','when','prototype','get','otherwise','startPackRequest','115uprYQY','reject','63419GzPecJ','tile','resolve','state','buffer','item','name','byteLength','Failed','BYTES_PER_ELEMENT','quadKeyIndexPack','fetchArrayBuffer','slice','3WwycnC','326862XdOMnA','inflate','cancelled','52BVHsiR','197slstnZ','deferred','length','Resource','getUint32','Loading','1360lJiwdF','.texblock','next','_singleInstance','list','sort','quadKey','defined','DoublyLinkedList','Loaded','priority','add','keyWord','cache','pendingRequests','splice','4FDfQTO','UnLoad','getSingleInstance','then','url','Ready','getStringFromTypedArray','join','providerName','promise','head','quadKeyIndex','request','2997FEIeQb','prepareRequest','287782DJKiMp'];const _0x10588c=_0x38f1;(function(_0x3b4a34,_0x57f1c8){const _0x47315e=_0x38f1;while(!![]){try{const _0x9a8237=parseInt(_0x47315e(0x164))*parseInt(_0x47315e(0x157))+-parseInt(_0x47315e(0x169))*-parseInt(_0x47315e(0x16f))+-parseInt(_0x47315e(0x18e))+-parseInt(_0x47315e(0x155))*parseInt(_0x47315e(0x18c))+parseInt(_0x47315e(0x165))+parseInt(_0x47315e(0x14c))*-parseInt(_0x47315e(0x17f))+-parseInt(_0x47315e(0x14b))*-parseInt(_0x47315e(0x168));if(_0x9a8237===_0x57f1c8)break;else _0x3b4a34['push'](_0x3b4a34['shift']());}catch(_0x58bb6d){_0x3b4a34['push'](_0x3b4a34['shift']());}}}(_0x29d2,0x3dc0a));function _0x38f1(_0x319ee6,_0x28e41a){_0x319ee6=_0x319ee6-0x149;let _0x29d2ac=_0x29d2[_0x319ee6];return _0x29d2ac;}function SubTextureManager(){const _0x2af3aa=_0x38f1;this[_0x2af3aa(0x15a)]={},this['cache']={},this[_0x2af3aa(0x173)]=new Cesium[(_0x2af3aa(0x177))](),this[_0x2af3aa(0x17d)]=[],this[_0x2af3aa(0x149)]={},this[_0x2af3aa(0x14e)]={},this[_0x2af3aa(0x161)]={},this[_0x2af3aa(0x14d)]={};}const _State={'UnLoad':0x0,'Loading':0x1,'Loaded':0x2,'Parsing':0x3,'Ready':0x4,'Failed':0x5};let _cacheSize=0x0;const _throttleSize=0xc8*0x400*0x400;SubTextureManager[_0x10588c(0x151)][_0x10588c(0x18d)]=function(_0x1e1869,_0x217e3f,_0x5513a8,_0x29939c,_0x10f9ed){const _0x4c44d4=_0x10588c;let _0x453133=_0x1e1869+'_'+_0x5513a8,_0x440f87=_0x217e3f+_0x5513a8+_0x4c44d4(0x170),_0x311893=new Cesium['Request']({'url':_0x440f87,'throttle':!![],'throttleByServer':!![],'priorityFunction':function(){return _0x29939c['distanceToCamera'];}});_0x311893['quadKey']=_0x5513a8,_0x311893[_0x4c44d4(0x187)]=_0x10f9ed[_0x4c44d4(0x158)]['layer'][_0x4c44d4(0x15d)],_0x311893[_0x4c44d4(0x17b)]=_0x453133,this[_0x4c44d4(0x17d)]['push'](_0x311893);};let comparator=function(_0x180312,_0x44f88c){const _0x12a4c2=_0x10588c;return _0x180312['priority']-_0x44f88c[_0x12a4c2(0x179)];};SubTextureManager[_0x10588c(0x151)][_0x10588c(0x18f)]=function(){const _0x314d07=_0x10588c;if(this[_0x314d07(0x17d)][_0x314d07(0x16b)]<0x1)return;this[_0x314d07(0x17d)][_0x314d07(0x174)](comparator),this[_0x314d07(0x154)]();for(let _0x2592c5=0x0,_0x23aad6=this[_0x314d07(0x17d)][_0x314d07(0x16b)];_0x2592c5<_0x23aad6;_0x2592c5++){let _0x307836=this[_0x314d07(0x17d)][_0x2592c5];this['request'](_0x307836);}this['pendingRequests'][_0x314d07(0x16b)]=0x0;};function combineQuadkey(_0xb35801){const _0x5eab9d=_0x10588c;let _0x1529a0=[],_0xde6e0f={},_0x3d2518=0x0;for(let _0x24898a=0x0,_0x2906d5=_0xb35801[_0x5eab9d(0x16b)];_0x24898a<_0x2906d5;_0x24898a++){let _0x33a978=_0xb35801[_0x24898a];if(_0x33a978[_0x5eab9d(0x167)])continue;let _0x409ca2=_0x33a978[_0x5eab9d(0x175)];if(_0xde6e0f[_0x409ca2])continue;_0xde6e0f[_0x409ca2]=!![],_0x1529a0[_0x5eab9d(0x14a)](_0x409ca2),_0x33a978[_0x5eab9d(0x18a)]=_0x3d2518++;}return _0x1529a0;}SubTextureManager['prototype']['startPackRequest']=function(){const _0x56813a=_0x10588c;let _0x1f1781=combineQuadkey(this[_0x56813a(0x17d)]),_0x29adaf=_0x1f1781[_0x56813a(0x186)](';'),_0x10c6d4=this[_0x56813a(0x17d)][0x0][_0x56813a(0x183)],_0x502c40=new Cesium[(_0x56813a(0x16c))]({'url':_0x10c6d4,'queryParameters':{'extratiles':_0x29adaf}}),_0xead87=Cesium[_0x56813a(0x150)][_0x56813a(0x14f)](),_0x5a39f1=_0x502c40[_0x56813a(0x162)]();if(!_0x5a39f1)return;for(let _0x5e034e=0x0,_0x29b050=this[_0x56813a(0x17d)][_0x56813a(0x16b)];_0x5e034e<_0x29b050;_0x5e034e++){let _0x1eb977=this[_0x56813a(0x17d)][_0x5e034e];_0x1eb977[_0x56813a(0x16a)]=_0xead87;}_0x5a39f1[_0x56813a(0x182)](function(_0x4643ba){const _0x27217b=_0x56813a;_0xead87[_0x27217b(0x159)](_0x4643ba);})[_0x56813a(0x153)](function(_0x30536f){const _0x4f9e6e=_0x56813a;_0xead87[_0x4f9e6e(0x156)](_0x30536f);});};function decodePackedBuffer(_0x2ec7a6,_0x37bcd8){const _0x39fa49=_0x10588c;let _0x586499=new DataView(_0x2ec7a6),_0x505e5a=0x0,_0x1265a5=_0x586499['getUint32'](_0x505e5a,!![]);if(_0x37bcd8>_0x1265a5-0x1||_0x1265a5>0x100)return undefined;_0x505e5a+=0x4;let _0x216868=[],_0x572125,_0xfb133d;for(_0x572125=0x0;_0x572125<_0x1265a5;_0x572125++){_0xfb133d=_0x586499['getUint32'](_0x505e5a,!![]),_0x216868[_0x39fa49(0x14a)](_0xfb133d),_0x505e5a+=0x4;}for(_0x572125=0x0;_0x572125<_0x1265a5;_0x572125++){_0xfb133d=_0x216868[_0x572125];if(_0x572125===_0x37bcd8){if(_0xfb133d===0x0)return;return new Uint8Array(_0x2ec7a6)[_0x39fa49(0x163)](_0x505e5a,_0x505e5a+_0xfb133d)[_0x39fa49(0x15b)];}_0x505e5a+=_0xfb133d;}return undefined;}SubTextureManager[_0x10588c(0x151)][_0x10588c(0x18b)]=function(_0x271906){const _0xf3c561=_0x10588c;let _0x284aa1=_0x271906['keyWord'],_0x2ebb98=_0x271906[_0xf3c561(0x16a)][_0xf3c561(0x188)];this[_0xf3c561(0x15a)][_0x284aa1]=_State[_0xf3c561(0x16e)];let _0x3658ef=this;_0x2ebb98[_0xf3c561(0x182)](function(_0xe2b91e){const _0x3c4c60=_0xf3c561;if(!Cesium[_0x3c4c60(0x176)](_0x3658ef[_0x3c4c60(0x15a)][_0x284aa1]))return;_0x3658ef['state'][_0x284aa1]=_State[_0x3c4c60(0x178)];let _0x55dde8=decodePackedBuffer(_0xe2b91e,_0x271906[_0x3c4c60(0x18a)]);if(!_0x55dde8){_0x3658ef[_0x3c4c60(0x15a)][_0x284aa1]=_State[_0x3c4c60(0x15f)];return;}let _0x3c2daf=new Uint8Array(_0x55dde8),_0x308718=new DataView(_0x55dde8),_0x43d44b=0x0,_0x482417=_0x308718[_0x3c4c60(0x16d)](_0x43d44b,!![]);_0x43d44b+=Uint32Array['BYTES_PER_ELEMENT'];let _0x5afeff={};for(let _0x120500=0x0;_0x120500<_0x482417;_0x120500++){let _0x5b372f=_0x308718[_0x3c4c60(0x16d)](_0x43d44b,!![]);_0x43d44b+=Uint32Array['BYTES_PER_ELEMENT'];let _0xe3f314=Cesium[_0x3c4c60(0x185)](_0x3c2daf,_0x43d44b,_0x5b372f);_0x43d44b+=_0x5b372f;let _0x405fc0=_0x308718[_0x3c4c60(0x16d)](_0x43d44b,!![]);_0x43d44b+=Uint32Array['BYTES_PER_ELEMENT'];let _0x396d6c=_0x308718[_0x3c4c60(0x16d)](_0x43d44b,!![]);_0x43d44b+=Uint32Array[_0x3c4c60(0x160)];let _0x42aa58=new Uint8Array(_0x55dde8,_0x43d44b,_0x396d6c),_0x362fd3=_0x1a0f6f[_0x3c4c60(0x166)](_0x42aa58)['buffer'];_0x43d44b+=_0x396d6c;let _0x27a766=new DataView(_0x362fd3),_0x671a20=0x0,_0x4b822e=_0x27a766[_0x3c4c60(0x16d)](_0x671a20,!![]);_0x671a20+=Uint32Array[_0x3c4c60(0x160)];let _0x29a8a0=_0x27a766[_0x3c4c60(0x16d)](_0x671a20,!![]);_0x671a20+=Uint32Array[_0x3c4c60(0x160)];let _0xfb724f=_0x27a766['getUint32'](_0x671a20,!![]);_0x671a20+=Uint32Array['BYTES_PER_ELEMENT'];let _0x579536=_0x27a766['getUint32'](_0x671a20,!![]);_0x671a20+=Uint32Array[_0x3c4c60(0x160)];let _0x4f10f8=_0x27a766[_0x3c4c60(0x16d)](_0x671a20,!![]);_0x671a20+=Uint32Array['BYTES_PER_ELEMENT'];let _0x1a258c=new Uint8Array(_0x362fd3,_0x671a20,_0x4f10f8);_0x5afeff[_0xe3f314]={'width':_0x29a8a0,'height':_0xfb724f,'arrayBufferView':_0x1a258c};}let _0x167d46={'keyWord':_0x284aa1,'result':_0x5afeff,'byteLength':_0x55dde8[_0x3c4c60(0x15e)]},_0x2e227a=_0x3658ef[_0x3c4c60(0x173)][_0x3c4c60(0x17a)](_0x167d46);_0x3658ef[_0x3c4c60(0x17c)][_0x284aa1]=_0x2e227a,_0x3658ef[_0x3c4c60(0x15a)][_0x284aa1]=_State[_0x3c4c60(0x184)],delete _0x3658ef[_0x3c4c60(0x15a)][_0x284aa1],_cacheSize+=_0x55dde8[_0x3c4c60(0x15e)];let _0x36a86d=_0x3658ef[_0x3c4c60(0x173)][_0x3c4c60(0x189)];while(_cacheSize>_throttleSize){let _0x47d7f2=_0x36a86d[_0x3c4c60(0x15c)],_0x469ee6=_0x36a86d,_0x23c96e=_0x47d7f2[_0x3c4c60(0x17b)],_0x681cf2=_0x3658ef[_0x3c4c60(0x17c)][_0x23c96e],_0x9cbabb=_0x681cf2[_0x3c4c60(0x15c)];_cacheSize-=_0x9cbabb['byteLength'],delete _0x3658ef['cache'][_0x23c96e],_0x36a86d=_0x36a86d[_0x3c4c60(0x171)],_0x3658ef[_0x3c4c60(0x173)]['remove'](_0x469ee6);}},function(_0x442411){const _0x7c0505=_0xf3c561;_0x3658ef[_0x7c0505(0x15a)][_0x284aa1]=_0x442411?_State['Failed']:_State[_0x7c0505(0x180)];});},SubTextureManager['prototype'][_0x10588c(0x152)]=function(_0xe174e,_0x4a4193,_0x5b26fb,_0x5a2803){const _0x2733e6=_0x10588c;let _0x2d985f=_0xe174e+'_'+_0x5b26fb,_0x56ddf9=this[_0x2733e6(0x17c)][_0x2d985f];if(_0x56ddf9)return this[_0x2733e6(0x173)][_0x2733e6(0x17e)](this[_0x2733e6(0x173)]['tail'],_0x56ddf9),_0x56ddf9['item'];let _0x48e9ec=this['state'][_0x2d985f];return !Cesium[_0x2733e6(0x176)](_0x48e9ec)&&(_0x48e9ec=this[_0x2733e6(0x15a)][_0x2d985f]=_State['UnLoad']),_0x48e9ec===_State[_0x2733e6(0x180)]&&this[_0x2733e6(0x18d)](_0xe174e,_0x4a4193,_0x5b26fb,_0x5a2803[_0x2733e6(0x158)],_0x5a2803),undefined;},SubTextureManager['prototype']['del']=function(_0xf5df3f,_0x537a6f){const _0x8fe3d0=_0x10588c;let _0x413a97=_0xf5df3f+'_'+_0x537a6f;delete this[_0x8fe3d0(0x15a)][_0x413a97];},SubTextureManager[_0x10588c(0x172)]=undefined,SubTextureManager[_0x10588c(0x181)]=function(){const _0x2638e3=_0x10588c;return !SubTextureManager[_0x2638e3(0x172)]&&(SubTextureManager[_0x2638e3(0x172)]=new SubTextureManager()),SubTextureManager[_0x2638e3(0x172)];};

    const _0x3123=['isLeafTile','hasOwnProperty','lerp','transparentsorting','distance','transform','ambient','textureunitstate','layerId','minVerticesValue','TextureWrap','728412JlopPv','byteLength','rangeList','fromPoints','917340eyfOvS','center','CLAMP_TO_EDGE','groupNode','shininess','Cartesian3','BoundingSphere','push','pageLods','add','materials','getSingleInstance','27332wYsoQW','createTexture','material','texMatrix','create','buffer','wrapT','_subTextureManager','1073069xIJXQM','vertexAttributes','geoPackage','addressmode','boundingVolume','fromBoundingSpheres','compressOptions','REPEAT','rangeMode','geodes','Matrix4','modelMatrix','matrix','vertexPackage','vertCompressConstant','multiply','Color','instanceBounds','diffuse','typedArray','534510amCvpR','ambientColor','37JHAeWD','geoMap','context','radius','defined','9363giyUwo','SVC_Vertex','fileType','byteOffset','rangeDataList','pickInfo','verticesCount','tile','250561tuVSVL','arrIndexPackage','instanceIndex','diffuseColor','fromArray','multiplyByScalar','48MFxqwq','length','_materialManager'];const _0x2b166b=_0x20ca;(function(_0x423231,_0x509ba6){const _0x29a291=_0x20ca;while(!![]){try{const _0x4c29fe=-parseInt(_0x29a291(0x129))+parseInt(_0x29a291(0x14c))+-parseInt(_0x29a291(0x160))+-parseInt(_0x29a291(0x13f))*parseInt(_0x29a291(0x144))+parseInt(_0x29a291(0x164))+parseInt(_0x29a291(0x13d))+-parseInt(_0x29a291(0x152))*-parseInt(_0x29a291(0x121));if(_0x4c29fe===_0x509ba6)break;else _0x423231['push'](_0x423231['shift']());}catch(_0x52386d){_0x423231['push'](_0x423231['shift']());}}}(_0x3123,0xd3883));function _0x20ca(_0x52069c,_0x86eb1){_0x52069c=_0x52069c-0x117;let _0x3123a1=_0x3123[_0x52069c];return _0x3123a1;}function S3MBlockContentParser(){}function parseMaterial$3(_0x35a703,_0x34e5e1,_0x3d4985){const _0x284eef=_0x20ca;let _0x4e480d=_0x35a703[_0x284eef(0x141)],_0x1306d2=_0x35a703[_0x284eef(0x154)];!_0x1306d2&&(_0x1306d2=_0x35a703[_0x284eef(0x154)]=new MaterialManager());let _0x584dee=_0x35a703[_0x284eef(0x128)];!_0x35a703['_subTextureManager']&&(_0x35a703[_0x284eef(0x128)]=SubTextureManager[_0x284eef(0x120)]());let _0x41081d=_0x34e5e1[_0x284eef(0x11f)][_0x284eef(0x123)];for(let _0x367620=0x0,_0x54a193=_0x41081d[_0x284eef(0x153)];_0x367620<_0x54a193;_0x367620++){let _0x28bcf6=_0x41081d[_0x367620]['material'],_0x49e73a=_0x28bcf6['id'],_0x2d78e2=_0x1306d2['create'](_0x49e73a);_0x2d78e2[_0x284eef(0x15d)]=_0x35a703['id'],_0x2d78e2[_0x284eef(0x14b)]=_0x3d4985;let _0x5eaea9=_0x28bcf6[_0x284eef(0x15b)];_0x2d78e2[_0x284eef(0x13e)]=new Cesium[(_0x284eef(0x139))](_0x5eaea9['r'],_0x5eaea9['g'],_0x5eaea9['b'],_0x5eaea9['a']);let _0x216b82=_0x28bcf6[_0x284eef(0x13b)];_0x2d78e2[_0x284eef(0x14f)]=new Cesium[(_0x284eef(0x139))](_0x216b82['r'],_0x216b82['g'],_0x216b82['b'],_0x216b82['a']);let _0x4a6220=_0x28bcf6['specular'];_0x2d78e2['specularColor']=new Cesium[(_0x284eef(0x139))](_0x4a6220['r'],_0x4a6220['g'],_0x4a6220['b'],_0x4a6220['a']),_0x2d78e2[_0x284eef(0x119)]=_0x28bcf6['shininess'],_0x2d78e2['bTransparentSorting']=_0x28bcf6[_0x284eef(0x158)],_0x2d78e2['id']=_0x49e73a;let _0x19a4d6=_0x28bcf6['textureunitstates'],_0x3ecb8f=_0x19a4d6[_0x284eef(0x153)];for(let _0x24bf41=0x0;_0x24bf41<0x1;_0x24bf41++){let _0x13dabf=_0x19a4d6[_0x24bf41][_0x284eef(0x15c)],_0x325397=_0x13dabf['id'],_0xa93161=_0x13dabf['addressmode']['u']===0x0?Cesium['TextureWrap']['REPEAT']:Cesium[_0x284eef(0x15f)][_0x284eef(0x117)],_0x56df3d=_0x13dabf[_0x284eef(0x12c)]['v']===0x0?Cesium[_0x284eef(0x15f)][_0x284eef(0x130)]:Cesium['TextureWrap'][_0x284eef(0x117)];_0x2d78e2[_0x284eef(0x124)]=Cesium[_0x284eef(0x133)]['unpack'](_0x13dabf['texmodmatrix']);let _0x22fdbf=_0x34e5e1['texturePackage'][_0x325397];_0x22fdbf&&(_0x22fdbf['wrapS']=_0xa93161,_0x22fdbf[_0x284eef(0x127)]=_0x56df3d,_0x2d78e2[_0x284eef(0x122)](_0x35a703,_0x3d4985,_0x22fdbf,_0x24bf41,_0x34e5e1));}}}function calcBoundingVolumeForNormal$1(_0x35d77b,_0x2da9d2){const _0x2eda35=_0x20ca;let _0x2d8271=new Cesium[(_0x2eda35(0x11b))](),_0x492872=new Cesium[(_0x2eda35(0x11a))](),_0x539bfa=_0x35d77b[_0x2eda35(0x12a)][0x0],_0x3aec41=_0x539bfa['componentsPerAttribute'],_0x4320bf=Cesium['defined'](_0x35d77b[_0x2eda35(0x12f)])&&(_0x35d77b[_0x2eda35(0x12f)]&_0x6ea6a9[_0x2eda35(0x145)])===_0x6ea6a9[_0x2eda35(0x145)],_0x4a3213=0x1,_0x1a5a8a,_0x1e5f78;_0x4320bf?(_0x4a3213=_0x35d77b[_0x2eda35(0x137)],_0x1a5a8a=new Cesium[(_0x2eda35(0x11a))](_0x35d77b[_0x2eda35(0x15e)]['x'],_0x35d77b[_0x2eda35(0x15e)]['y'],_0x35d77b[_0x2eda35(0x15e)]['z']),_0x1e5f78=new Uint16Array(_0x539bfa[_0x2eda35(0x13c)]['buffer'],_0x539bfa['typedArray']['byteOffset'],_0x539bfa[_0x2eda35(0x13c)][_0x2eda35(0x161)]/0x2)):_0x1e5f78=new Float32Array(_0x539bfa['typedArray'][_0x2eda35(0x126)],_0x539bfa[_0x2eda35(0x13c)][_0x2eda35(0x147)],_0x539bfa[_0x2eda35(0x13c)][_0x2eda35(0x161)]/0x4);let _0xf305=[];for(let _0x19e0fe=0x0;_0x19e0fe<_0x35d77b[_0x2eda35(0x14a)];_0x19e0fe++){Cesium[_0x2eda35(0x11a)][_0x2eda35(0x150)](_0x1e5f78,_0x3aec41*_0x19e0fe,_0x492872),_0x4320bf&&(_0x492872=Cesium['Cartesian3'][_0x2eda35(0x151)](_0x492872,_0x4a3213,_0x492872),_0x492872=Cesium[_0x2eda35(0x11a)][_0x2eda35(0x11e)](_0x492872,_0x1a5a8a,_0x492872)),_0xf305[_0x2eda35(0x11c)](Cesium['Cartesian3']['clone'](_0x492872));}return Cesium[_0x2eda35(0x11b)][_0x2eda35(0x163)](_0xf305,_0x2d8271),Cesium['BoundingSphere'][_0x2eda35(0x15a)](_0x2d8271,_0x2da9d2,_0x2d8271),_0xf305[_0x2eda35(0x153)]=0x0,_0x2d8271;}let scratchCenter$1=new Cesium[(_0x2b166b(0x11a))]();function calcBoundingVolumeForInstance$1(_0x38f9a1){const _0x24c56d=_0x2b166b;let _0x267ad1=new Cesium[(_0x24c56d(0x11b))](),_0x3f33df=_0x38f9a1[_0x24c56d(0x13a)];if(!Cesium[_0x24c56d(0x143)](_0x3f33df))return _0x267ad1;let _0x36a99f=new Cesium['Cartesian3'](_0x3f33df[0x0],_0x3f33df[0x1],_0x3f33df[0x2]),_0x52ef26=new Cesium['Carteisan3'](_0x3f33df[0x3],_0x3f33df[0x4],_0x3f33df[0x5]),_0x3cac34=new Cesium[(_0x24c56d(0x11a))][(_0x24c56d(0x157))](_0x36a99f,_0x52ef26,0.5,scratchCenter$1),_0x5a3276=new Cesium[(_0x24c56d(0x11a))][(_0x24c56d(0x159))](_0x3cac34,_0x36a99f);return _0x267ad1[_0x24c56d(0x165)]=_0x3cac34,_0x267ad1[_0x24c56d(0x142)]=_0x5a3276,_0x267ad1;}function calcBoundingVolume$1(_0x57c494,_0x28f0b1){const _0x511cc2=_0x2b166b;if(_0x57c494[_0x511cc2(0x14e)]>-0x1)return calcBoundingVolumeForInstance$1(_0x57c494);return calcBoundingVolumeForNormal$1(_0x57c494,_0x28f0b1);}function parseGeodes$1(_0x25ac97,_0x4ea1d5,_0x2c8a55,_0x1d7725){const _0x43eb45=_0x2b166b;let _0x43b37a={},_0x161146=_0x2c8a55[_0x43eb45(0x132)];for(let _0xdb806f=0x0,_0x3da339=_0x161146['length'];_0xdb806f<_0x3da339;_0xdb806f++){let _0x54be47=_0x161146[_0xdb806f],_0x2e3a79=_0x54be47[_0x43eb45(0x135)],_0x3ec2fc=Cesium[_0x43eb45(0x133)][_0x43eb45(0x138)](_0x25ac97['modelMatrix'],_0x2e3a79,new Cesium[(_0x43eb45(0x133))]()),_0x1ab940;Cesium[_0x43eb45(0x143)](_0x1d7725[_0x43eb45(0x12d)])&&(_0x1ab940=new Cesium['BoundingSphere'](_0x1d7725[_0x43eb45(0x12d)]['sphere'][_0x43eb45(0x165)],_0x1d7725[_0x43eb45(0x12d)]['sphere'][_0x43eb45(0x142)]),Cesium['BoundingSphere'][_0x43eb45(0x15a)](_0x1ab940,_0x25ac97[_0x43eb45(0x134)],_0x1ab940));let _0x1b8af8=_0x54be47['skeletonNames'];for(let _0x58da5d=0x0,_0x474f71=_0x1b8af8[_0x43eb45(0x153)];_0x58da5d<_0x474f71;_0x58da5d++){let _0x45cf7c=_0x1b8af8[_0x58da5d],_0xce7747=_0x4ea1d5[_0x43eb45(0x12b)][_0x45cf7c],_0x1a96cd=_0xce7747[_0x43eb45(0x136)],_0x2992d1=_0xce7747[_0x43eb45(0x14d)],_0x99cee9=_0xce7747[_0x43eb45(0x149)],_0x17164a;_0x2992d1[_0x43eb45(0x153)]>0x0&&(_0x17164a=_0x25ac97[_0x43eb45(0x154)][_0x43eb45(0x125)](_0x2992d1[0x0]['materialCode']));let _0x446646=Cesium[_0x43eb45(0x143)](_0x1ab940)?_0x1ab940:calcBoundingVolume$1(_0x1a96cd,_0x3ec2fc);_0x43b37a[_0x45cf7c]=S3MContentFactory[_0x25ac97[_0x43eb45(0x146)]]({'layer':_0x25ac97,'vertexPackage':_0x1a96cd,'arrIndexPackage':_0x2992d1,'pickInfo':_0x99cee9,'modelMatrix':_0x3ec2fc,'geoMatrix':_0x2e3a79,'boundingVolume':_0x446646,'material':_0x17164a,'edgeGeometry':_0xce7747['edgeGeometry'],'geoName':_0x45cf7c});}}if(Object['keys'](_0x43b37a)[_0x43eb45(0x153)]<0x1)return;if(!Cesium[_0x43eb45(0x143)](_0x1d7725[_0x43eb45(0x12d)])){let _0x86aabb=[];for(let _0x25b5fb in _0x43b37a){_0x43b37a[_0x43eb45(0x156)](_0x25b5fb)&&_0x86aabb[_0x43eb45(0x11c)](_0x43b37a[_0x25b5fb]['boundingVolume']);}let _0x6a1522=Cesium[_0x43eb45(0x11b)][_0x43eb45(0x12e)](_0x86aabb);_0x1d7725['boundingVolume']={'sphere':_0x6a1522};}_0x1d7725['geoMap']=_0x43b37a;}function parsePagelods$1(_0x258eb1,_0x43cc50){const _0x411a00=_0x2b166b;let _0x19b5d4=_0x43cc50[_0x411a00(0x118)],_0x45f76e=[];for(let _0x34f933=0x0,_0x4fd084=_0x19b5d4[_0x411a00(0x11d)][_0x411a00(0x153)];_0x34f933<_0x4fd084;_0x34f933++){let _0x3c90e2={},_0x187a2c=_0x19b5d4[_0x411a00(0x11d)][_0x34f933];_0x3c90e2[_0x411a00(0x131)]=_0x187a2c[_0x411a00(0x131)],_0x3c90e2[_0x411a00(0x148)]=_0x187a2c['childTile'],_0x3c90e2[_0x411a00(0x162)]=_0x187a2c[_0x411a00(0x162)];let _0x4f449f=_0x187a2c['boundingSphere']['center'],_0x1697ed=_0x187a2c['boundingSphere'][_0x411a00(0x142)];_0x3c90e2[_0x411a00(0x148)]!==''?_0x3c90e2[_0x411a00(0x12d)]={'sphere':{'center':new Cesium['Cartesian3'](_0x4f449f['x'],_0x4f449f['y'],_0x4f449f['z']),'radius':_0x1697ed}}:_0x3c90e2[_0x411a00(0x155)]=!![],parseGeodes$1(_0x258eb1,_0x43cc50,_0x187a2c,_0x3c90e2),Cesium[_0x411a00(0x143)](_0x3c90e2[_0x411a00(0x140)])&&_0x45f76e[_0x411a00(0x11c)](_0x3c90e2);}return _0x45f76e;}S3MBlockContentParser['parse']=function(_0xac9b07,_0x45b166,_0x2e9f0e){const _0x11b5b8=_0x2b166b;if(!Cesium[_0x11b5b8(0x143)](_0x2e9f0e))return;parseMaterial$3(_0xac9b07,_0x2e9f0e,_0x45b166);let _0x272373=parsePagelods$1(_0xac9b07,_0x2e9f0e);return _0x272373;};

    const _0x25cd=['getUrlComponent','context','parse','FAILED','shouldSelect','getPixel','rangeMode','getScale','createBoundingVolume','Request','EPSILON7','request','402427tZHbgC','update','updatedVisibilityFrame','contains','UNLOADED','_basePath','createIfNeeded','distanceToTileCenter','processFrame','TILES3D','fetchArrayBuffer','Math','updateVisibility','/rest/realspace','get','camera','_baseResource','touchedFrame','ready','distanceToTile','fileName','contentResource','sphere','finalResolution','freeBlock','abs','CANCELLED','defined','dot','lodRangeData','boundingVolume','isChildBlock','RequestScheduler','destroy','fileExtension','Resource','magnitude','min','fromCornerPoints','isAncestorBlock','visibilityPlaneMask','multiplyByScalar','renderEntities','getExtensionFromUri','_fovy','multiplyByPoint','radius','isDestroyed','prototype','defer','parent','add','hasOwnProperty','770593oaaNoo','children','932945mBeYol','maximumComponent','parseBuffer','positionWC','_minimumPriority','_isS3MBlock','MASK_OUTSIDE','Matrix4','otherwise','reject','BoundingSphere','getServerKey','RequestType','rootBatchIdMap','requestContent','directionWC','ancestorMap','normalize','pop','1129634Xgourz','Pixel','tan','isRootTile','priorityDeferred','distance','refines','serverKey','when','priorityHolder','Cartesian3','cacheNode','push','updatePriority','blockKey','length','READY','selected','visibleDistanceMin','contentReadyPromise','rootName','1eZEyfJ','contentState','lodRangeMode','cullingVolume','foveatedFactor','1325413XFQaVt','defaultValue','distanceToCamera','data/path/','replace','415980LFFTkx','rangeDataList','isLeafTile','visible','priority','requestedFrame','CullingVolume','drawingBufferHeight','box','canTraverse','263UEvfgU','depth','frustum','visibility','subtract','relativePath','selectedFrame','pixel','baseUri','free','MAX_VALUE','_cache','max','realspace','getBaseUri','RequestState','computeVisibilityWithPlaneMask','visibleDistanceMax','indexOf','center','3121DfEuLV','pow','layer','5Zbkklf','getDerivedResource','centerZDepth','s3m','rangeList','clone','TileBoundingSphere'];const _0x5441bd=_0xd439;(function(_0x557983,_0xcdad81){const _0x3f5e79=_0xd439;while(!![]){try{const _0x371177=parseInt(_0x3f5e79(0xab))+parseInt(_0x3f5e79(0xc0))*-parseInt(_0x3f5e79(0xca))+-parseInt(_0x3f5e79(0xd4))*-parseInt(_0x3f5e79(0xe8))+parseInt(_0x3f5e79(0xc5))+-parseInt(_0x3f5e79(0x98))+parseInt(_0x3f5e79(0x96))+parseInt(_0x3f5e79(0xfe))*-parseInt(_0x3f5e79(0xeb));if(_0x371177===_0xcdad81)break;else _0x557983['push'](_0x557983['shift']());}catch(_0x8b7b68){_0x557983['push'](_0x557983['shift']());}}}(_0x25cd,0xa755b));function S3MTile(_0x2419e9,_0x27688d,_0x5eec16,_0x653518,_0x5c2e07,_0x2f8897){const _0x35018f=_0xd439;this['layer']=_0x2419e9,this[_0x35018f(0x93)]=_0x27688d;let _0x42ace1=_0x653518[_0x35018f(0xc9)](/\\/g,'/');this[_0x35018f(0x83)]=Cesium[_0x35018f(0x8c)](_0x653518),this[_0x35018f(0xd9)]=getUrl(_0x42ace1,_0x2419e9),this[_0x35018f(0x75)]=_0x653518,this[_0x35018f(0xcc)]=_0x5c2e07===0x0,this['isRootTile']=![],this[_0x35018f(0x7f)]=this[_0x35018f(0xfa)](_0x5eec16,_0x2419e9['modelMatrix']);let _0x3d6dd3=Cesium[_0x35018f(0x84)][_0x35018f(0x104)](_0x2419e9[_0x35018f(0x10e)]);if(Cesium[_0x35018f(0x7c)](_0x27688d))this[_0x35018f(0xdc)]=_0x27688d['baseUri'];else {let _0x190118=new Cesium[(_0x35018f(0x84))](_0x42ace1);this[_0x35018f(0xdc)]=_0x190118[_0x35018f(0xe2)]();}this['contentResource']=_0x3d6dd3[_0x35018f(0xec)]({'url':this[_0x35018f(0xd9)]}),this[_0x35018f(0xb2)]=Cesium[_0x35018f(0x81)][_0x35018f(0xa3)](this['contentResource'][_0x35018f(0xf2)]()),this[_0x35018f(0xfd)]=undefined,this['cacheNode']=undefined,this['distanceToCamera']=0x0,this[_0x35018f(0xed)]=0x0,this[_0x35018f(0xdb)]=0x0,this[_0x35018f(0xd5)]=_0x27688d?_0x27688d['depth']+0x1:0x0,this[_0x35018f(0x89)]=0x0,this[_0x35018f(0xcd)]=![],this['children']=[],this['renderEntities']=[],this[_0x35018f(0x7e)]=Cesium[_0x35018f(0xc6)](_0x5c2e07,0x10),this[_0x35018f(0xc2)]=Cesium['defaultValue'](_0x2f8897,_0x54aefd[_0x35018f(0xac)]),this['contentState']=this['isLeafTile']?_0x1acc80[_0x35018f(0xbb)]:_0x1acc80[_0x35018f(0x102)],this[_0x35018f(0x10f)]=0x0,this[_0x35018f(0xcf)]=0x0,this[_0x35018f(0x106)]=0x0,this[_0x35018f(0xda)]=0x0,this[_0x35018f(0x100)]=0x0,this[_0x35018f(0xc4)]=0x0,this[_0x35018f(0xce)]=0x0,this[_0x35018f(0xb4)]=this,this['wasMinPriorityChild']=![],this[_0x35018f(0xf6)]=![],this[_0x35018f(0xbc)]=![],this[_0x35018f(0x78)]=!![],this[_0x35018f(0xb1)]=![],this[_0x35018f(0xbf)]=!_0x27688d?this['fileName']:_0x27688d['rootName'],this[_0x35018f(0xb9)]='',this[_0x35018f(0x88)]=![],this[_0x35018f(0x80)]=![],this[_0x35018f(0xa5)]={},this[_0x35018f(0xa8)]={};}Object['defineProperties'](S3MTile[_0x5441bd(0x91)],{'renderable':{'get':function(){const _0x25bcbb=_0x5441bd;let _0xa672c3=this[_0x25bcbb(0x8b)],_0x3b61eb=_0xa672c3['length'];if(_0x3b61eb===0x0)return ![];for(let _0x4cfa59=0x0;_0x4cfa59<_0x3b61eb;_0x4cfa59++){if(!_0xa672c3[_0x4cfa59][_0x25bcbb(0x110)])return ![];}return !![];}}});let scratchScale=new Cesium[(_0x5441bd(0xb5))]();function createSphere(_0x32b4f6,_0x2a2d81){const _0x100bf9=_0x5441bd;let _0x4ab13e=Cesium[_0x100bf9(0xb5)][_0x100bf9(0xf0)](_0x32b4f6['center']),_0x538feb=_0x32b4f6[_0x100bf9(0x8f)];_0x4ab13e=Cesium['Matrix4']['multiplyByPoint'](_0x2a2d81,_0x4ab13e,_0x4ab13e);let _0x3afd7b=Cesium[_0x100bf9(0x9f)][_0x100bf9(0xf9)](_0x2a2d81,scratchScale),_0x2bc992=Cesium['Cartesian3']['maximumComponent'](_0x3afd7b);return _0x538feb*=_0x2bc992,new Cesium[(_0x100bf9(0xf1))](_0x4ab13e,_0x538feb);}function getUrl(_0x585f54,_0x15ab7f){const _0x50545f=_0x5441bd;_0x585f54=_0x585f54[_0x50545f(0xc9)](/\+/g,'%2B');let _0x15a984=_0x15ab7f[_0x50545f(0x103)],_0x7e2932=_0x15ab7f[_0x50545f(0x103)][_0x50545f(0xe6)](_0x50545f(0xe1))>-0x1;if(!_0x7e2932)return _0x585f54;let _0x2660bb=_0x15a984[_0x50545f(0xc9)](/(.*realspace)/,''),_0x4889ea=_0x15a984[_0x50545f(0xc9)](/\/rest\/realspace/g,'')[_0x50545f(0xc9)](_0x2660bb,'');return _0x4889ea+_0x50545f(0x10b)+_0x2660bb+_0x50545f(0xc8)+_0x585f54[_0x50545f(0xc9)](/^\.*/,'')[_0x50545f(0xc9)](/^\//,'')[_0x50545f(0xc9)](/\/$/,'');}function createBoundingBox(_0x1de3e8,_0xcb4910){const _0x282f4a=_0x5441bd;let _0x2b16bb=new Cesium['Cartesian3'](_0x1de3e8[_0x282f4a(0x86)]['x'],_0x1de3e8[_0x282f4a(0x86)]['y'],_0x1de3e8[_0x282f4a(0x86)]['z']);Cesium[_0x282f4a(0x9f)]['multiplyByPoint'](_0xcb4910,_0x2b16bb,_0x2b16bb);let _0x96818e=new Cesium[(_0x282f4a(0xb5))](_0x1de3e8[_0x282f4a(0xe0)]['x'],_0x1de3e8['max']['y'],_0x1de3e8[_0x282f4a(0xe0)]['z']);Cesium[_0x282f4a(0x9f)][_0x282f4a(0x8e)](_0xcb4910,_0x96818e,_0x96818e);let _0x26615d=Cesium[_0x282f4a(0xa2)][_0x282f4a(0x87)](_0x2b16bb,_0x96818e,new Cesium['BoundingSphere']()),_0x4bb079=_0x26615d[_0x282f4a(0xe7)],_0x1fd2c2=_0x26615d[_0x282f4a(0x8f)],_0x5caaeb=Cesium[_0x282f4a(0x9f)][_0x282f4a(0xf9)](_0xcb4910,scratchScale),_0x1cfb10=Cesium[_0x282f4a(0xb5)][_0x282f4a(0x99)](_0x5caaeb);return _0x1fd2c2*=_0x1cfb10,new Cesium[(_0x282f4a(0xf1))](_0x4bb079,_0x1fd2c2);}S3MTile[_0x5441bd(0x91)]['createBoundingVolume']=function(_0x5f408d,_0x4b36da){const _0x3cb0a1=_0x5441bd;if(Cesium[_0x3cb0a1(0x7c)](_0x5f408d[_0x3cb0a1(0x77)]))return createSphere(_0x5f408d[_0x3cb0a1(0x77)],_0x4b36da);else {if(Cesium[_0x3cb0a1(0x7c)](_0x5f408d[_0x3cb0a1(0xd2)]))return createBoundingBox(_0x5f408d['box'],_0x4b36da);}return undefined;},S3MTile['prototype'][_0x5441bd(0xd3)]=function(){const _0x113dfd=_0x5441bd;if(this[_0x113dfd(0x97)][_0x113dfd(0xba)]===0x0||this[_0x113dfd(0xcc)])return ![];if(!Cesium[_0x113dfd(0x7c)](this[_0x113dfd(0x7e)]))return !![];return this[_0x113dfd(0xdb)]>this[_0x113dfd(0x7e)];};function getBoundingVolume(_0x51ced4,_0xc2960c){const _0x36fbde=_0x5441bd;return _0x51ced4[_0x36fbde(0x7f)];}S3MTile[_0x5441bd(0x91)][_0x5441bd(0xf7)]=function(_0x207cf3){const _0x3f3fb8=_0x5441bd;let _0x10e99b=this['boundingVolume'],_0xd81a3c=_0x10e99b[_0x3f3fb8(0x8f)],_0x3ac8e0=_0x10e99b[_0x3f3fb8(0xe7)],_0x522d68=Cesium[_0x3f3fb8(0xb5)][_0x3f3fb8(0xb0)](_0x207cf3[_0x3f3fb8(0x10d)][_0x3f3fb8(0x9b)],_0x3ac8e0),_0x55efaf=_0x207cf3[_0x3f3fb8(0xf3)][_0x3f3fb8(0xd1)],_0x32cc9d=_0x207cf3[_0x3f3fb8(0x10d)][_0x3f3fb8(0xd6)][_0x3f3fb8(0x8d)]*0.5,_0xf02508=_0x55efaf*0.5,_0x51a29c=_0xf02508/Math[_0x3f3fb8(0xad)](_0x32cc9d);return _0x51a29c*_0xd81a3c/_0x522d68;},S3MTile['prototype'][_0x5441bd(0x111)]=function(_0x458161){const _0x143d07=_0x5441bd;let _0x80770f=getBoundingVolume(this);return _0x80770f[_0x143d07(0xc7)](_0x458161);};function _0xd439(_0x38149d,_0x1856af){_0x38149d=_0x38149d-0x75;let _0x25cdaf=_0x25cd[_0x38149d];return _0x25cdaf;}let scratchToTileCenter=new Cesium[(_0x5441bd(0xb5))]();S3MTile['prototype'][_0x5441bd(0x105)]=function(_0x17014b){const _0x5d44ed=_0x5441bd,_0x511e16=getBoundingVolume(this),_0x4f4913=Cesium['Cartesian3'][_0x5d44ed(0xd8)](_0x511e16['center'],_0x17014b['camera']['positionWC'],scratchToTileCenter);return Cesium['Cartesian3'][_0x5d44ed(0x7d)](_0x17014b[_0x5d44ed(0x10d)][_0x5d44ed(0xa7)],_0x4f4913);},S3MTile[_0x5441bd(0x91)]['visibility']=function(_0x26480d,_0x1b6c45){const _0x42fb6a=_0x5441bd;let _0x344abc=getBoundingVolume(this);return _0x26480d[_0x42fb6a(0xc3)][_0x42fb6a(0xe4)](_0x344abc,_0x1b6c45);};let scratchCartesian=new Cesium[(_0x5441bd(0xb5))]();function priorityDeferred(_0xe6c179,_0x112f59){const _0x5f22c8=_0x5441bd;let _0x5a6225=_0x112f59['camera'],_0x4cc8d0=_0xe6c179[_0x5f22c8(0x7f)],_0x3b3741=_0x4cc8d0[_0x5f22c8(0x8f)],_0x4f5a5f=Cesium[_0x5f22c8(0xb5)][_0x5f22c8(0x8a)](_0x5a6225['directionWC'],_0xe6c179['centerZDepth'],scratchCartesian),_0x4dcc6b=Cesium['Cartesian3']['add'](_0x5a6225[_0x5f22c8(0x9b)],_0x4f5a5f,scratchCartesian),_0x1a0759=Cesium[_0x5f22c8(0xb5)][_0x5f22c8(0xd8)](_0x4dcc6b,_0x4cc8d0[_0x5f22c8(0xe7)],scratchCartesian),_0x4501ed=Cesium['Cartesian3'][_0x5f22c8(0x85)](_0x1a0759),_0x108e09=_0x4501ed>_0x3b3741;if(_0x108e09){let _0x8199b4=Cesium[_0x5f22c8(0xb5)][_0x5f22c8(0xa9)](_0x1a0759,scratchCartesian),_0x5979f0=Cesium[_0x5f22c8(0xb5)][_0x5f22c8(0x8a)](_0x8199b4,_0x3b3741,scratchCartesian),_0x2e911e=Cesium[_0x5f22c8(0xb5)][_0x5f22c8(0x94)](_0x4cc8d0[_0x5f22c8(0xe7)],_0x5979f0,scratchCartesian),_0x339af0=Cesium[_0x5f22c8(0xb5)][_0x5f22c8(0xd8)](_0x2e911e,_0x5a6225[_0x5f22c8(0x9b)],scratchCartesian),_0xf60273=Cesium['Cartesian3'][_0x5f22c8(0xa9)](_0x339af0,scratchCartesian);_0xe6c179[_0x5f22c8(0xc4)]=0x1-Math[_0x5f22c8(0x7a)](Cesium[_0x5f22c8(0xb5)][_0x5f22c8(0x7d)](_0x5a6225[_0x5f22c8(0xa7)],_0xf60273));}else _0xe6c179[_0x5f22c8(0xc4)]=0x0;}S3MTile['prototype'][_0x5441bd(0x10a)]=function(_0x4b1d5b,_0x2b1719){const _0x419ea8=_0x5441bd;let _0x465658=this[_0x419ea8(0x93)],_0x39eb30=Cesium[_0x419ea8(0x7c)](_0x465658)?_0x465658[_0x419ea8(0x89)]:Cesium['CullingVolume']['MASK_INDETERMINATE'];this['distanceToCamera']=this[_0x419ea8(0x111)](_0x4b1d5b),this[_0x419ea8(0xed)]=this[_0x419ea8(0x105)](_0x4b1d5b),this['pixel']=this['getPixel'](_0x4b1d5b),this['visibilityPlaneMask']=this[_0x419ea8(0xd7)](_0x4b1d5b,_0x39eb30),this['visible']=this[_0x419ea8(0x89)]!==Cesium[_0x419ea8(0xd0)][_0x419ea8(0x9e)]&&this[_0x419ea8(0xc7)]>=_0x2b1719[_0x419ea8(0xbd)]&&this['distanceToCamera']<=_0x2b1719[_0x419ea8(0xe5)],this[_0x419ea8(0xaf)]=priorityDeferred(this,_0x4b1d5b);};function createPriorityFunction(_0x3ffb3d){return function(){return _0x3ffb3d['priority'];};}function getContentFailedFunction(_0x152a1b){return function(_0x97f17d){const _0x4ca53c=_0xd439;_0x152a1b['contentState']=_0x1acc80[_0x4ca53c(0xf5)],_0x152a1b[_0x4ca53c(0xbe)]['reject'](_0x97f17d);};}function createChildren(_0x2f87f3,_0x271c3f){const _0x41cd9e=_0x5441bd;let _0x43a09e=_0x2f87f3[_0x41cd9e(0xea)],_0x4d3c2e=_0x271c3f['length'],_0x541782=Number[_0x41cd9e(0xde)],_0x179232=0x0,_0xa98428=_0x54aefd['Pixel'];for(let _0x47ba5f=0x0;_0x47ba5f<_0x4d3c2e;_0x47ba5f++){let _0x43e025=_0x271c3f[_0x47ba5f],_0x5bf693=_0x43e025[_0x41cd9e(0x7f)],_0x119115=_0x43e025[_0x41cd9e(0xcb)];_0x119115=_0x2f87f3[_0x41cd9e(0xdc)]+_0x119115;let _0x112427=_0x43e025[_0x41cd9e(0xef)],_0x5d709a=_0x43e025[_0x41cd9e(0xf8)],_0x4d7c7b=_0x43e025['geoMap'];if(_0x112427!==0x0){let _0x1abbe9=new S3MTile(_0x43a09e,_0x2f87f3,_0x5bf693,_0x119115,_0x112427,_0x5d709a);_0x2f87f3[_0x41cd9e(0x97)][_0x41cd9e(0xb7)](_0x1abbe9),_0x43a09e[_0x41cd9e(0xdf)][_0x41cd9e(0x94)](_0x1abbe9);}for(let _0x34d278 in _0x4d7c7b){_0x4d7c7b[_0x41cd9e(0x95)](_0x34d278)&&_0x2f87f3[_0x41cd9e(0x8b)][_0x41cd9e(0xb7)](_0x4d7c7b[_0x34d278]);}_0x541782=Math['min'](_0x541782,_0x112427),_0x179232=Math[_0x41cd9e(0xe0)](_0x179232,_0x112427),_0xa98428=_0x5d709a;}_0x2f87f3[_0x41cd9e(0xae)]&&(_0x2f87f3[_0x41cd9e(0x7e)]=_0xa98428===_0x54aefd[_0x41cd9e(0xac)]?_0x541782/0x2:_0x179232*0x2,_0x2f87f3[_0x41cd9e(0xc2)]=_0xa98428);}function parseChildGroup(_0x2ffacb,_0x23ca25,_0x10eb98){const _0x466799=_0x5441bd;let _0x522b86=_0x23ca25[_0x10eb98[_0x466799(0x75)]];if(!_0x522b86)return;_0x10eb98[_0x466799(0xb9)]=_0x10eb98[_0x466799(0x75)],_0x10eb98[_0x466799(0x88)]=!![];let _0x8098ae=S3MBlockContentParser[_0x466799(0xf4)](_0x2ffacb,_0x10eb98,_0x522b86);createChildren(_0x10eb98,_0x8098ae);let _0x60410d=[_0x10eb98];while(_0x60410d['length']){let _0x4016a5=_0x60410d[_0x466799(0xaa)](),_0x1c6d0b=_0x4016a5['children'];for(let _0x5e8c11=0x0,_0x4c266b=_0x1c6d0b[_0x466799(0xba)];_0x5e8c11<_0x4c266b;_0x5e8c11++){let _0x3950a6=_0x1c6d0b[_0x5e8c11],_0x3da838=_0x3950a6[_0x466799(0x75)];if(_0x3da838==='')continue;_0x3950a6[_0x466799(0xa5)]=_0x522b86['rootBatchIdMap'],_0x3950a6[_0x466799(0xa8)]=_0x522b86[_0x466799(0xa8)];let _0x3fe4e6=_0x23ca25[_0x3950a6[_0x466799(0x75)]];if(_0x3fe4e6){_0x3950a6[_0x466799(0xc1)]=_0x1acc80[_0x466799(0xbb)],_0x3950a6[_0x466799(0xb9)]=_0x4016a5[_0x466799(0xb9)],_0x3950a6[_0x466799(0x80)]=!![];let _0x1a811f=S3MBlockContentParser[_0x466799(0xf4)](_0x2ffacb,_0x3950a6,_0x3fe4e6);createChildren(_0x3950a6,_0x1a811f),_0x60410d[_0x466799(0xb7)](_0x3950a6);}else _0x3950a6[_0x466799(0x88)]=!![],_0x3950a6[_0x466799(0xb9)]=_0x3950a6[_0x466799(0x75)];}}}function contentReadyFunction(_0x4d1d11,_0x1b2d3f,_0x3a11ec){const _0x4a344d=_0x5441bd;_0x4d1d11['_cache']['add'](_0x1b2d3f);if(_0x4d1d11[_0x4a344d(0x9d)]){let _0x5d19cc=S3MBlockParser['parseBuffer'](_0x3a11ec,_0x1b2d3f);parseChildGroup(_0x4d1d11,_0x5d19cc,_0x1b2d3f),_0x1b2d3f[_0x4a344d(0xda)]=0x0,_0x1b2d3f[_0x4a344d(0xc1)]=_0x1acc80['READY'],_0x1b2d3f['contentReadyPromise']['resolve'](!![]);return;}let _0x495ec7;if(_0x1b2d3f[_0x4a344d(0x83)]==='s3mb')_0x495ec7=S3ModelParser[_0x4a344d(0x9a)](_0x3a11ec);else _0x1b2d3f[_0x4a344d(0x83)]===_0x4a344d(0xee)&&(_0x495ec7=S3ModelOldParser[_0x4a344d(0x9a)](_0x3a11ec));if(!_0x495ec7){_0x1b2d3f[_0x4a344d(0xc1)]=_0x1acc80['FAILED'],_0x1b2d3f[_0x4a344d(0xbe)][_0x4a344d(0xa1)]();return;}let _0x247788=S3MContentParser[_0x4a344d(0xf4)](_0x4d1d11,_0x495ec7,_0x1b2d3f);createChildren(_0x1b2d3f,_0x247788),_0x1b2d3f['selectedFrame']=0x0,_0x1b2d3f[_0x4a344d(0xc1)]=_0x1acc80['READY'],_0x1b2d3f[_0x4a344d(0xbe)]['resolve'](_0x495ec7);}S3MTile[_0x5441bd(0x91)][_0x5441bd(0xa6)]=function(){const _0x39fcff=_0x5441bd;let _0x141b26=this,_0xa8445e=this[_0x39fcff(0xea)];if(_0xa8445e[_0x39fcff(0x9d)]&&_0xa8445e['_blockCache'][_0x39fcff(0x101)](_0xa8445e['id'],this[_0x39fcff(0xb9)])){let _0x267ad3=_0xa8445e['_blockCache'][_0x39fcff(0x10c)](_0xa8445e['id'],this[_0x39fcff(0xb9)]);return this[_0x39fcff(0xbe)]=Cesium[_0x39fcff(0xb3)]['defer'](),contentReadyFunction(_0xa8445e,this,_0x267ad3),!![];}let _0x5c1c8b=this[_0x39fcff(0x76)][_0x39fcff(0xf0)](),_0x32939d=new Cesium[(_0x39fcff(0xfb))]({'throttle':!![],'throttleByServer':!![],'type':Cesium[_0x39fcff(0xa4)][_0x39fcff(0x107)],'priorityFunction':createPriorityFunction(this),'serverKey':this[_0x39fcff(0xb2)]});this[_0x39fcff(0xfd)]=_0x32939d,_0x5c1c8b['request']=_0x32939d;let _0x2c3d36=_0x5c1c8b[_0x39fcff(0x108)]();if(!Cesium[_0x39fcff(0x7c)](_0x2c3d36))return ![];this[_0x39fcff(0xc1)]=_0x1acc80['LOADING'],this['contentReadyPromise']=Cesium[_0x39fcff(0xb3)][_0x39fcff(0x92)]();let _0x12b391=getContentFailedFunction(this);return _0x2c3d36['then'](function(_0x58d3ec){const _0x2f1618=_0x39fcff;if(_0x141b26[_0x2f1618(0x90)]()){_0x12b391();return;}contentReadyFunction(_0xa8445e,_0x141b26,_0x58d3ec);})[_0x39fcff(0xa0)](function(_0x317d55){const _0x4ad686=_0x39fcff;if(_0x32939d['state']===Cesium[_0x4ad686(0xe3)][_0x4ad686(0x7b)]){_0x141b26['contentState']=_0x1acc80[_0x4ad686(0x102)];return;}_0x12b391(_0x317d55);}),!![];};function priorityNormalizeAndClamp(_0x48b13b,_0x42ec95,_0xc95eb2){const _0x20775d=_0x5441bd;return Math[_0x20775d(0xe0)](Cesium[_0x20775d(0x109)][_0x20775d(0xa9)](_0x48b13b,_0x42ec95,_0xc95eb2)-Cesium['Math'][_0x20775d(0xfc)],0x0);}function isolateDigits(_0x31b30d,_0xe23344,_0x20fcc7){const _0x189294=_0x5441bd;let _0x383914=_0x31b30d*Math[_0x189294(0xe9)](0xa,_0xe23344),_0x1dbb90=parseInt(_0x383914);return _0x1dbb90*Math[_0x189294(0xe9)](0xa,_0x20fcc7);}S3MTile[_0x5441bd(0x91)][_0x5441bd(0xb8)]=function(_0x2516ea,_0x228c4a){const _0x15512a=_0x5441bd;let _0x8ed05=_0x2516ea[_0x15512a(0x9c)],_0x564b8f=_0x2516ea['_maximumPriority'],_0x389c95=0x4,_0x271399=0x4,_0x50b01f=priorityNormalizeAndClamp(this[_0x15512a(0xc4)],_0x8ed05[_0x15512a(0xc4)],_0x564b8f[_0x15512a(0xc4)]),_0x53ba8f=isolateDigits(_0x50b01f,_0x271399,_0x389c95);_0x389c95=0x8;let _0x44ad2f=priorityNormalizeAndClamp(this[_0x15512a(0xdb)],_0x8ed05[_0x15512a(0xdb)],_0x564b8f[_0x15512a(0xdb)]),_0x490a13=isolateDigits(0x1-_0x44ad2f,_0x271399,_0x389c95);_0x389c95=0x0;let _0x2ad055=priorityNormalizeAndClamp(this['distanceToCamera'],_0x8ed05[_0x15512a(0xb0)],_0x564b8f['distance']),_0x4a30cd=isolateDigits(_0x2ad055,_0x271399,_0x389c95);this[_0x15512a(0xce)]=_0x53ba8f+_0x490a13+_0x4a30cd;},S3MTile[_0x5441bd(0x91)][_0x5441bd(0xff)]=function(_0x47c3d1,_0x4996c4){const _0x2dec56=_0x5441bd;for(let _0x2f56be=0x0,_0x35dab4=this[_0x2dec56(0x8b)][_0x2dec56(0xba)];_0x2f56be<_0x35dab4;_0x2f56be++){this['renderEntities'][_0x2f56be][_0x2dec56(0xff)](_0x47c3d1,_0x4996c4);}},S3MTile[_0x5441bd(0x91)]['free']=function(){const _0x344a12=_0x5441bd;this[_0x344a12(0xc1)]=_0x1acc80[_0x344a12(0x102)],this[_0x344a12(0xfd)]=undefined,this[_0x344a12(0xb6)]=undefined,this[_0x344a12(0xb4)]=undefined,this['contentReadyPromise']=undefined,this[_0x344a12(0xb4)]=undefined;for(let _0x5737b3=0x0,_0x36be67=this['renderEntities'][_0x344a12(0xba)];_0x5737b3<_0x36be67;_0x5737b3++){this[_0x344a12(0x8b)][_0x5737b3][_0x344a12(0x82)]();}this['renderEntities']['length']=0x0,this[_0x344a12(0x97)][_0x344a12(0xba)]=0x0;},S3MTile['prototype'][_0x5441bd(0x79)]=function(){const _0x4283cd=_0x5441bd;this[_0x4283cd(0xc1)]=_0x1acc80[_0x4283cd(0x102)],this[_0x4283cd(0xfd)]=undefined,this[_0x4283cd(0xb6)]=undefined,this[_0x4283cd(0xb4)]=undefined,this[_0x4283cd(0xbe)]=undefined,this[_0x4283cd(0xb4)]=undefined;for(let _0x436adf=0x0,_0x30c770=this[_0x4283cd(0x8b)][_0x4283cd(0xba)];_0x436adf<_0x30c770;_0x436adf++){this['renderEntities'][_0x436adf][_0x4283cd(0x82)]();}this[_0x4283cd(0x8b)][_0x4283cd(0xba)]=0x0;for(let _0x4db1f7=0x0,_0x1d070d=this[_0x4283cd(0x97)][_0x4283cd(0xba)];_0x4db1f7<_0x1d070d;_0x4db1f7++){let _0x7c96ce=this[_0x4283cd(0x97)][_0x4db1f7];!_0x7c96ce[_0x4283cd(0x88)]&&_0x7c96ce[_0x4283cd(0x79)]();}this[_0x4283cd(0x97)][_0x4283cd(0xba)]=0x0;},S3MTile['prototype'][_0x5441bd(0x90)]=function(){return ![];},S3MTile[_0x5441bd(0x91)][_0x5441bd(0x82)]=function(){const _0x351263=_0x5441bd;return this[_0x351263(0xdd)](),Cesium['destroyObject'](this);};

    const _0xb802=['1032493RZDngt','1TesIdV','UNLOADED','425045QIAuFX','wasMinPriorityChild','push','_maximumPriority','isRootTile','distance','305059wUJasV','READY','requestedFrame','_processTiles','pixel','max','renderable','updateVisibility','parent','_cache','processFrame','prototype','631403giRYhe','_minimumPriority','distanceToCamera','MAX_VALUE','lodRangeScale','refines','length','touchedFrame','lodRangeMode','745246gKTdTY','visible','foveatedFactor','frameNumber','depth','71507dxiaXt','lodRangeData','min','centerZDepth','sort','children','1HAQXZE','1DKvIKg','pop','selectedFrame','priorityHolder','schedule','_stack','_rootTiles','updatedVisibilityFrame','_selectedTiles','shouldSelect','_requestTiles','520362sqCLLz','selected','21bcOTQq','defined'];const _0x33f238=_0x279a;(function(_0x359667,_0x292421){const _0x10fffa=_0x279a;while(!![]){try{const _0x47386b=parseInt(_0x10fffa(0xf9))*parseInt(_0x10fffa(0x10c))+parseInt(_0x10fffa(0x105))+parseInt(_0x10fffa(0x112))*parseInt(_0x10fffa(0xfa))+parseInt(_0x10fffa(0x109))+-parseInt(_0x10fffa(0xee))+parseInt(_0x10fffa(0xe5))*parseInt(_0x10fffa(0x10a))+-parseInt(_0x10fffa(0xf3))*parseInt(_0x10fffa(0x107));if(_0x47386b===_0x292421)break;else _0x359667['push'](_0x359667['shift']());}catch(_0x4d7130){_0x359667['push'](_0x359667['shift']());}}}(_0xb802,0xa2f4d));function S3MLayerScheduler(){const _0x544d8d=_0x279a;this[_0x544d8d(0xff)]=[];}function sortComparator(_0x8ee892,_0x41aa0a){const _0x1eea81=_0x279a;if(_0x41aa0a[_0x1eea81(0xe7)]===0x0&&_0x8ee892[_0x1eea81(0xe7)]===0x0)return _0x41aa0a[_0x1eea81(0xf6)]-_0x8ee892[_0x1eea81(0xf6)];return _0x41aa0a[_0x1eea81(0xe7)]-_0x8ee892[_0x1eea81(0xe7)];}function updateChildren(_0x3e5f29,_0x14a86f,_0x334da4,_0x1b504f){const _0x414e2e=_0x279a;let _0x2bd8a8,_0x5a5835=_0x14a86f['children'],_0x14273c=_0x5a5835[_0x414e2e(0xeb)];for(_0x2bd8a8=0x0;_0x2bd8a8<_0x14273c;++_0x2bd8a8){updateTile(_0x1b504f,_0x3e5f29,_0x5a5835[_0x2bd8a8]);}_0x5a5835[_0x414e2e(0xf7)](sortComparator);let _0x16f54a=!![],_0x5de908=![],_0x42cf2c=-0x1,_0x2ad3ad=Number[_0x414e2e(0xe8)],_0x531333=!![];for(_0x2bd8a8=0x0;_0x2bd8a8<_0x14273c;++_0x2bd8a8){let _0x31e4cd=_0x5a5835[_0x2bd8a8];_0x31e4cd[_0x414e2e(0xf0)]<_0x2ad3ad&&(_0x42cf2c=_0x2bd8a8,_0x2ad3ad=_0x31e4cd[_0x414e2e(0xf0)]);_0x31e4cd[_0x414e2e(0xef)]?(_0x334da4[_0x414e2e(0x10e)](_0x31e4cd),_0x5de908=!![]):(loadTile(_0x3e5f29,_0x31e4cd,_0x1b504f),touchTile(_0x3e5f29,_0x31e4cd,_0x1b504f),processTile(_0x3e5f29,_0x31e4cd,_0x1b504f));let _0x321a28=_0x31e4cd[_0x414e2e(0x118)];_0x531333&&(_0x16f54a=_0x16f54a&&_0x321a28);}!_0x5de908&&(_0x16f54a=![]);if(_0x42cf2c!==-0x1){let _0x531972=_0x5a5835[_0x42cf2c];_0x531972[_0x414e2e(0x10d)]=!![];let _0x63e91d=(_0x14a86f['wasMinPriorityChild']||_0x14a86f[_0x414e2e(0x110)])&&_0x2ad3ad<=_0x14a86f[_0x414e2e(0xfd)]['foveatedFactor']?_0x14a86f[_0x414e2e(0xfd)]:_0x14a86f;_0x63e91d[_0x414e2e(0xf0)]=Math[_0x414e2e(0xf5)](_0x531972[_0x414e2e(0xf0)],_0x63e91d[_0x414e2e(0xf0)]),_0x63e91d[_0x414e2e(0xe7)]=Math[_0x414e2e(0xf5)](_0x531972[_0x414e2e(0xe7)],_0x63e91d[_0x414e2e(0xe7)]);for(_0x2bd8a8=0x0;_0x2bd8a8<_0x14273c;++_0x2bd8a8){let _0x361b85=_0x5a5835[_0x2bd8a8];_0x361b85[_0x414e2e(0xfd)]=_0x63e91d;}}return _0x16f54a;}function selectTile(_0x29c88e,_0x2cfe63,_0x1173ae){const _0x258e06=_0x279a;if(_0x2cfe63[_0x258e06(0xfc)]===_0x1173ae[_0x258e06(0xf1)]||!_0x2cfe63[_0x258e06(0x118)])return;_0x29c88e[_0x258e06(0x102)][_0x258e06(0x10e)](_0x2cfe63),_0x2cfe63[_0x258e06(0xfc)]=_0x1173ae[_0x258e06(0xf1)];}function loadTile(_0x285433,_0x28849f,_0x54daea){const _0x152e97=_0x279a;if(_0x28849f[_0x152e97(0x114)]===_0x54daea[_0x152e97(0xf1)]||_0x28849f['contentState']!==_0x1acc80[_0x152e97(0x10b)])return;_0x285433[_0x152e97(0x104)][_0x152e97(0x10e)](_0x28849f),_0x28849f['requestedFrame']=_0x54daea['frameNumber'];}function _0x279a(_0x2eba5c,_0x33f41a){_0x2eba5c=_0x2eba5c-0xe3;let _0xb80267=_0xb802[_0x2eba5c];return _0xb80267;}function processTile(_0x294907,_0x3ccc51,_0x502250){const _0x5f3cd0=_0x279a;if(_0x3ccc51[_0x5f3cd0(0xe3)]===_0x502250[_0x5f3cd0(0xf1)]||_0x3ccc51['contentState']!==_0x1acc80[_0x5f3cd0(0x113)]||_0x3ccc51[_0x5f3cd0(0x118)])return;_0x3ccc51[_0x5f3cd0(0xe3)]=_0x502250[_0x5f3cd0(0xf1)],_0x294907[_0x5f3cd0(0x115)][_0x5f3cd0(0x10e)](_0x3ccc51);}function touchTile(_0x2b8775,_0x163b22,_0x3c8389){const _0x4c3686=_0x279a;if(_0x163b22['touchedFrame']===_0x3c8389[_0x4c3686(0xf1)])return;_0x2b8775[_0x4c3686(0x11b)]['touch'](_0x163b22),_0x163b22[_0x4c3686(0xec)]=_0x3c8389[_0x4c3686(0xf1)];}function updateVisibility(_0xd36731,_0x29fe05,_0x93832b){const _0x3b8114=_0x279a;if(_0x29fe05[_0x3b8114(0x101)]===_0x93832b[_0x3b8114(0xf1)])return;_0x29fe05['updatedVisibilityFrame']=_0x93832b[_0x3b8114(0xf1)],_0x29fe05[_0x3b8114(0x119)](_0x93832b,_0xd36731);}function updateTileVisibility(_0xa0a5d2,_0x15b5c5,_0x378024){updateVisibility(_0x15b5c5,_0x378024,_0xa0a5d2);}function updateMinimumMaximumPriority(_0x214e93,_0x521e4b){const _0x4faa1e=_0x279a;_0x214e93[_0x4faa1e(0x10f)][_0x4faa1e(0x111)]=Math[_0x4faa1e(0x117)](_0x521e4b[_0x4faa1e(0xe7)],_0x214e93[_0x4faa1e(0x10f)][_0x4faa1e(0x111)]),_0x214e93['_minimumPriority'][_0x4faa1e(0x111)]=Math[_0x4faa1e(0xf5)](_0x521e4b[_0x4faa1e(0xe7)],_0x214e93[_0x4faa1e(0xe6)][_0x4faa1e(0x111)]),_0x214e93[_0x4faa1e(0x10f)][_0x4faa1e(0xf2)]=Math['max'](_0x521e4b[_0x4faa1e(0xf2)],_0x214e93['_maximumPriority'][_0x4faa1e(0xf2)]),_0x214e93['_minimumPriority'][_0x4faa1e(0xf2)]=Math['min'](_0x521e4b[_0x4faa1e(0xf2)],_0x214e93[_0x4faa1e(0xe6)][_0x4faa1e(0xf2)]),_0x214e93[_0x4faa1e(0x10f)][_0x4faa1e(0xf0)]=Math[_0x4faa1e(0x117)](_0x521e4b[_0x4faa1e(0xf0)],_0x214e93[_0x4faa1e(0x10f)][_0x4faa1e(0xf0)]),_0x214e93[_0x4faa1e(0xe6)][_0x4faa1e(0xf0)]=Math['min'](_0x521e4b[_0x4faa1e(0xf0)],_0x214e93[_0x4faa1e(0xe6)][_0x4faa1e(0xf0)]),_0x214e93['_maximumPriority'][_0x4faa1e(0x116)]=Math['max'](_0x521e4b['pixel'],_0x214e93[_0x4faa1e(0x10f)]['pixel']),_0x214e93[_0x4faa1e(0xe6)][_0x4faa1e(0x116)]=Math[_0x4faa1e(0xf5)](_0x521e4b['pixel'],_0x214e93[_0x4faa1e(0xe6)][_0x4faa1e(0x116)]);}function updateTile(_0x52a7fc,_0x414873,_0x342d8f){const _0x1c5944=_0x279a;updateTileVisibility(_0x52a7fc,_0x414873,_0x342d8f),_0x342d8f[_0x1c5944(0x10d)]=![],_0x342d8f['priorityHolder']=_0x342d8f,updateMinimumMaximumPriority(_0x414873,_0x342d8f),_0x342d8f[_0x1c5944(0x103)]=![],_0x342d8f[_0x1c5944(0x106)]=![];}function canTraverse(_0x3bee0f,_0x47f9c8){const _0x5ab441=_0x279a;if(_0x47f9c8[_0x5ab441(0xf8)][_0x5ab441(0xeb)]===0x0)return ![];if(_0x47f9c8[_0x5ab441(0xed)]===_0x54aefd['Pixel'])return _0x47f9c8[_0x5ab441(0x116)]/_0x3bee0f['lodRangeScale']>_0x47f9c8[_0x5ab441(0xf4)];return _0x47f9c8[_0x5ab441(0xe7)]*_0x3bee0f[_0x5ab441(0xe9)]<_0x47f9c8[_0x5ab441(0xf4)];}function traversal(_0xb720b2,_0x98e9f9,_0x178c1c){const _0x3cdbd0=_0x279a;while(_0x98e9f9[_0x3cdbd0(0xeb)]){let _0xa151ea=_0x98e9f9[_0x3cdbd0(0xfb)](),_0x1d5443=_0xa151ea[_0x3cdbd0(0x11a)],_0xceff20=!Cesium[_0x3cdbd0(0x108)](_0x1d5443)||_0x1d5443[_0x3cdbd0(0xea)],_0x20ffba=![];canTraverse(_0xb720b2,_0xa151ea)&&(_0x20ffba=updateChildren(_0xb720b2,_0xa151ea,_0x98e9f9,_0x178c1c)&&_0xceff20);let _0x1a4308=!_0x20ffba&&_0xceff20;loadTile(_0xb720b2,_0xa151ea,_0x178c1c),processTile(_0xb720b2,_0xa151ea,_0x178c1c),_0x1a4308&&selectTile(_0xb720b2,_0xa151ea,_0x178c1c),touchTile(_0xb720b2,_0xa151ea,_0x178c1c),_0xa151ea[_0x3cdbd0(0xea)]=_0x20ffba;}}function selectRootTiles(_0x3a2e7c,_0x746930,_0x267162){const _0x4acf3e=_0x279a;_0x746930['length']=0x0;for(let _0x5141df=0x0,_0x29e0cc=_0x3a2e7c[_0x4acf3e(0x100)][_0x4acf3e(0xeb)];_0x5141df<_0x29e0cc;_0x5141df++){let _0x8fb3e6=_0x3a2e7c[_0x4acf3e(0x100)][_0x5141df];updateTile(_0x267162,_0x3a2e7c,_0x8fb3e6);if(!_0x8fb3e6[_0x4acf3e(0xef)])continue;_0x746930[_0x4acf3e(0x10e)](_0x8fb3e6);}}function updatePriority(_0x535c85,_0x36f6a9){const _0xfb5c5=_0x279a;let _0x5c3530=_0x535c85[_0xfb5c5(0x104)],_0x15b8a0=_0x5c3530[_0xfb5c5(0xeb)];for(let _0x1df4a6=0x0;_0x1df4a6<_0x15b8a0;++_0x1df4a6){_0x5c3530[_0x1df4a6]['updatePriority'](_0x535c85,_0x36f6a9);}}S3MLayerScheduler[_0x33f238(0xe4)][_0x33f238(0xfe)]=function(_0x1ebb3f,_0x13db04){const _0x37427e=_0x33f238;let _0x3a0333=this[_0x37427e(0xff)];selectRootTiles(_0x1ebb3f,_0x3a0333,_0x13db04),traversal(_0x1ebb3f,_0x3a0333,_0x13db04),updatePriority(_0x1ebb3f,_0x13db04);};

    const _0x878c=['remove','children','5EfnCbu','reset','trim','_list','prototype','splice','isAncestorBlock','1420853jXdfqm','totalMemoryUsageInBytes','unloadTiles','push','unloadBlockTile','unloadTile','1OPcjVb','cacheNode','next','1dHGYsN','777531nlakSG','tail','_sentinel','522189mRYkMU','pop','add','defined','length','168377tpRfaw','head','373907uSwxQt','1136268bGPBaN','DoublyLinkedList','item','_trimTiles','822847fHCbTr'];const _0x513328=_0x4106;(function(_0x3accda,_0x34cd3b){const _0x41fe03=_0x4106;while(!![]){try{const _0x471534=parseInt(_0x41fe03(0x1c5))+parseInt(_0x41fe03(0x1b9))*parseInt(_0x41fe03(0x1b0))+-parseInt(_0x41fe03(0x1ba))+parseInt(_0x41fe03(0x1a6))+-parseInt(_0x41fe03(0x1bd))*parseInt(_0x41fe03(0x1b6))+-parseInt(_0x41fe03(0x1c2))*parseInt(_0x41fe03(0x1a9))+-parseInt(_0x41fe03(0x1c4));if(_0x471534===_0x34cd3b)break;else _0x3accda['push'](_0x3accda['shift']());}catch(_0x4839b4){_0x3accda['push'](_0x3accda['shift']());}}}(_0x878c,0xd30c8));function S3MLayerCache(){const _0x1f960a=_0x4106;this['_list']=new Cesium[(_0x1f960a(0x1a3))](),this['_sentinel']=this['_list'][_0x1f960a(0x1bf)](),this[_0x1f960a(0x1a5)]=![];}function _0x4106(_0x279ea6,_0x24ba34){_0x279ea6=_0x279ea6-0x1a3;let _0x878cf8=_0x878c[_0x279ea6];return _0x878cf8;}S3MLayerCache[_0x513328(0x1ad)][_0x513328(0x1aa)]=function(){const _0x1b00e1=_0x513328;this[_0x1b00e1(0x1ac)][_0x1b00e1(0x1ae)](this[_0x1b00e1(0x1ac)][_0x1b00e1(0x1bb)],this[_0x1b00e1(0x1bc)]);},S3MLayerCache[_0x513328(0x1ad)]['touch']=function(_0x35b18b){const _0x342fc3=_0x513328;let _0xb21ee9=_0x35b18b[_0x342fc3(0x1b7)];Cesium[_0x342fc3(0x1c0)](_0xb21ee9)&&this[_0x342fc3(0x1ac)][_0x342fc3(0x1ae)](this[_0x342fc3(0x1bc)],_0xb21ee9);},S3MLayerCache[_0x513328(0x1ad)]['add']=function(_0x2ae322){const _0x5bf47e=_0x513328;!Cesium['defined'](_0x2ae322[_0x5bf47e(0x1b7)])&&(_0x2ae322[_0x5bf47e(0x1b7)]=this[_0x5bf47e(0x1ac)][_0x5bf47e(0x1bf)](_0x2ae322));},S3MLayerCache[_0x513328(0x1ad)][_0x513328(0x1b5)]=function(_0x5559c3,_0x2054e0,_0x286c2f){const _0x51ad7a=_0x513328;let _0x3954f8=_0x2054e0[_0x51ad7a(0x1b7)];if(!Cesium[_0x51ad7a(0x1c0)](_0x3954f8))return;this[_0x51ad7a(0x1ac)][_0x51ad7a(0x1a7)](_0x3954f8),_0x2054e0['cacheNode']=undefined,_0x286c2f(_0x5559c3,_0x2054e0);},S3MLayerCache['prototype'][_0x513328(0x1b4)]=function(_0x1f5e24,_0x514d64,_0x2785e5){const _0x3fd9a7=_0x513328;let _0x53614a=[_0x514d64],_0x56b026=[_0x514d64];while(_0x53614a['length']){let _0x520630=_0x53614a[_0x3fd9a7(0x1be)]();for(let _0xcf5ac8=0x0,_0x32c079=_0x520630[_0x3fd9a7(0x1a8)][_0x3fd9a7(0x1c1)];_0xcf5ac8<_0x32c079;_0xcf5ac8++){let _0x2d2aca=_0x520630[_0x3fd9a7(0x1a8)][_0xcf5ac8];!_0x2d2aca['isAncestorBlock']&&(_0x53614a[_0x3fd9a7(0x1b3)](_0x2d2aca),_0x56b026[_0x3fd9a7(0x1b3)](_0x2d2aca));}}for(let _0x5e4578=0x0,_0x2285f0=_0x56b026['length'];_0x5e4578<_0x2285f0;_0x5e4578++){let _0x3c8037=_0x56b026[_0x5e4578];this[_0x3fd9a7(0x1b5)](_0x1f5e24,_0x3c8037,_0x2785e5);}},S3MLayerCache[_0x513328(0x1ad)][_0x513328(0x1b2)]=function(_0x43ca02,_0x741be3){const _0x2bfe16=_0x513328;let _0xdb18a6=this['_trimTiles'];this[_0x2bfe16(0x1a5)]=![];let _0xdc212f=this['_list'],_0x26448d=_0x43ca02['maximumMemoryUsage']*0x400*0x400,_0x5d4e90=this['_sentinel'],_0x51e1e6=_0xdc212f['head'];while(_0x51e1e6&&_0x51e1e6!==_0x5d4e90&&(_0x43ca02[_0x2bfe16(0x1b1)]>_0x26448d||_0xdb18a6)){let _0x4106e7=_0x51e1e6[_0x2bfe16(0x1a4)];_0x51e1e6=_0x51e1e6[_0x2bfe16(0x1b8)],this[_0x2bfe16(0x1b5)](_0x43ca02,_0x4106e7,_0x741be3);}},S3MLayerCache['prototype']['unloadBlockTiles']=function(_0x49db12,_0x4135c1){const _0x4cb810=_0x513328;let _0x1ee66b=this['_trimTiles'];this[_0x4cb810(0x1a5)]=![];let _0x550168=this[_0x4cb810(0x1ac)],_0x319b1c=_0x49db12['maximumMemoryUsage']*0x400*0x400,_0xee42db=this[_0x4cb810(0x1bc)],_0x5c1924=_0x550168[_0x4cb810(0x1c3)];while(_0x5c1924&&_0x5c1924!==_0xee42db&&(_0x49db12['totalMemoryUsageInBytes']>_0x319b1c||_0x1ee66b)){let _0x67e5a6=_0x5c1924[_0x4cb810(0x1a4)];_0x5c1924=_0x5c1924[_0x4cb810(0x1b8)],_0x67e5a6[_0x4cb810(0x1af)]&&this[_0x4cb810(0x1b4)](_0x49db12,_0x67e5a6,_0x4135c1);}},S3MLayerCache[_0x513328(0x1ad)][_0x513328(0x1ab)]=function(){const _0x3293b1=_0x513328;this[_0x3293b1(0x1a5)]=!![];};

    const _0x38a6=['673612rmNjzu','45791kTNSTz','517262tjkNtx','freeze','5563onPgxm','49sTPwTf','205867suFQQD','35zgOzbV','188658FJPVXs','261128TbqRSD'];const _0x5e5ded=_0x198c;function _0x198c(_0x28d0ff,_0x32d78c){_0x28d0ff=_0x28d0ff-0x78;let _0x38a61c=_0x38a6[_0x28d0ff];return _0x38a61c;}(function(_0x1666f9,_0x5d4e9f){const _0x1c5aad=_0x198c;while(!![]){try{const _0x21608c=-parseInt(_0x1c5aad(0x7e))+-parseInt(_0x1c5aad(0x7d))*-parseInt(_0x1c5aad(0x7c))+parseInt(_0x1c5aad(0x80))+-parseInt(_0x1c5aad(0x78))+-parseInt(_0x1c5aad(0x81))+-parseInt(_0x1c5aad(0x7a))+-parseInt(_0x1c5aad(0x79))*-parseInt(_0x1c5aad(0x7f));if(_0x21608c===_0x5d4e9f)break;else _0x1666f9['push'](_0x1666f9['shift']());}catch(_0x2abbee){_0x1666f9['push'](_0x1666f9['shift']());}}}(_0x38a6,0x6322d));const PLANECLIPMODE={'CLIP_NOTHING':0x0,'CLIP_BEHIND_ANY_PLANE':0x1,'CLIP_BEHIND_ALL_PLANE':0x2,'ONLY_KEEP_LINE':0x3};var _0x251bf8 = Object[_0x5e5ded(0x7b)](PLANECLIPMODE);

    const _0x4213=['freeze','16254zgWRXk','6034cVhfxU','95358OWlOtA','151477oVwCPM','2OokwJh','308635vrVoGB','11brwfDI','1hWgllo','55454jjoPID','30389wUjtoo','5XjPwpL'];const _0x2ccf6a=_0x16b7;(function(_0x11e59f,_0xc4eedc){const _0x56ac43=_0x16b7;while(!![]){try{const _0x4d156e=parseInt(_0x56ac43(0x1d4))+parseInt(_0x56ac43(0x1db))*parseInt(_0x56ac43(0x1d9))+-parseInt(_0x56ac43(0x1dc))+-parseInt(_0x56ac43(0x1d8))*parseInt(_0x56ac43(0x1d2))+parseInt(_0x56ac43(0x1d7))*parseInt(_0x56ac43(0x1dd))+parseInt(_0x56ac43(0x1d3))*parseInt(_0x56ac43(0x1d5))+-parseInt(_0x56ac43(0x1da));if(_0x4d156e===_0xc4eedc)break;else _0x11e59f['push'](_0x11e59f['shift']());}catch(_0x18c9ad){_0x11e59f['push'](_0x11e59f['shift']());}}}(_0x4213,0x3384f));const HypsometricSettingEnum={'DisplayMode':{'NONE':0x0,'FACE':0x1,'LINE':0x2,'FACE_AND_LINE':0x3},'AnalysisRegionMode':{'ARM_NONE':0x0,'ARM_ALL':0x1,'ARM_REGION':0x2},'FilterMode':{'LINEAR':0x0,'NEAREST':0x1}};function _0x16b7(_0x560f2e,_0x5e51c9){_0x560f2e=_0x560f2e-0x1d2;let _0x421338=_0x4213[_0x560f2e];return _0x421338;}var _0x44d4e8 = Object[_0x2ccf6a(0x1d6)](HypsometricSettingEnum);

    var _0x2846=['prototype','213206gqcVbC','destroy','6617aBKXjx','isUseColorByHeight','678271KRMHbP','85mtSNVH','minCategory','12pzHIQE','maxCategory','maxInstensity','analysisMode','regionUpdate','isUseRegion','572238yGiYss','isDestroyed','552719dGIocU','1aLSOsK','bounds','1BLEXnm','2tMxENB','238285jozaAJ','minInstensity','texture','AnalysisRegionMode','setting','region','21123iIEfag','1NifqYi','renderTexture','Cartesian4','1wTDBWC','isUseHypColorTable','minHeight','maxHeight'];var _0x343886=_0x5b18;function _0x5b18(_0x1b9d54,_0x254868){_0x1b9d54=_0x1b9d54-0x1d8;var _0x28460=_0x2846[_0x1b9d54];return _0x28460;}(function(_0x55accb,_0x126515){var _0x55f7d9=_0x5b18;while(!![]){try{var _0x186546=-parseInt(_0x55f7d9(0x1e5))*-parseInt(_0x55f7d9(0x1e8))+-parseInt(_0x55f7d9(0x1de))*-parseInt(_0x55f7d9(0x1f0))+parseInt(_0x55f7d9(0x1e3))*parseInt(_0x55f7d9(0x1f5))+-parseInt(_0x55f7d9(0x1ea))*parseInt(_0x55f7d9(0x1da))+-parseInt(_0x55f7d9(0x1e7))*-parseInt(_0x55f7d9(0x1f3))+-parseInt(_0x55f7d9(0x1f7))*parseInt(_0x55f7d9(0x1db))+-parseInt(_0x55f7d9(0x1f2))*parseInt(_0x55f7d9(0x1f6));if(_0x186546===_0x126515)break;else _0x55accb['push'](_0x55accb['shift']());}catch(_0x438fcd){_0x55accb['push'](_0x55accb['shift']());}}}(_0x2846,0x68ba1));function Hypsometric(_0x3a6f60){var _0x35dd85=_0x5b18;this[_0x35dd85(0x1d8)]=undefined,this['texture']=undefined,this[_0x35dd85(0x1dc)]=undefined,this[_0x35dd85(0x1d9)]=undefined,this[_0x35dd85(0x1f4)]=new Cesium[(_0x35dd85(0x1dd))](),this[_0x35dd85(0x1df)]=![],this[_0x35dd85(0x1ef)]=![],this[_0x35dd85(0x1ee)]=![],this[_0x35dd85(0x1ed)]=_0x44d4e8[_0x35dd85(0x1fa)]['ARM_NONE'],this[_0x35dd85(0x1ec)]=_0x3a6f60[_0x35dd85(0x1ec)],this['minInstensity']=_0x3a6f60[_0x35dd85(0x1f8)],this['maxHeight']=_0x3a6f60[_0x35dd85(0x1e1)],this['minHeight']=_0x3a6f60[_0x35dd85(0x1e0)],this[_0x35dd85(0x1eb)]=_0x3a6f60[_0x35dd85(0x1eb)],this[_0x35dd85(0x1e9)]=_0x3a6f60[_0x35dd85(0x1e9)],this[_0x35dd85(0x1e6)]=!![];}Hypsometric[_0x343886(0x1e2)][_0x343886(0x1f1)]=function(){return ![];},Hypsometric[_0x343886(0x1e2)]['destroy']=function(){var _0x483f31=_0x343886;this[_0x483f31(0x1d8)]=undefined,this[_0x483f31(0x1f9)]=this[_0x483f31(0x1f9)]&&!this[_0x483f31(0x1f9)]['isDestroyed']()&&this['texture']['destroy'](),this[_0x483f31(0x1dc)]=this['renderTexture']&&!this[_0x483f31(0x1dc)]['isDestroyed']()&&this['renderTexture'][_0x483f31(0x1e4)]();};

    const _0xf1c9=['_emissionTextureChanged','_loadedEmissionTexture','textureCoordinates','DisplayMode','Cartesian2','1OSGkBG','FACE','_updatePolygon','MAX_VALUE','_lineColor','getItem','119633yxmAVw','_updateColorDictTable','3688279DuOgUO','3cQmpLZ','1106955NrSQVs','USpeed','_visibleDistanceMax','VTiling','_emissionTextureUrl','destroy','count','_emissionTextureArray','_textureFilterMode','push','32989hDPZJO','37TmAspm','now','height','_ceiling','clone','_minVisibleAltitude','width','_getEmissionTexAtlasTilingAndOffset','defined','VSpeed','_dictColorTable','_minVisibleValue','min','max','_linesInterval','FilterMode','length','474023AGJRvD','_displayMode','1182070ZLuHuI','_emissionTexCoordScale','_opacity','_emissionTextureAtlas','_noValueColor','_coverageArea','_floor','_maxVisibleValue','_emissionTexCoordSpeed','Color','prototype','defineProperties','_visibleDistanceMin','_maxVisibleAltitude','39439xqDqMI','textureAtlasID'];function _0xb12d(_0x4a45e2,_0xdc7882){_0x4a45e2=_0x4a45e2-0x17b;let _0xf1c9c0=_0xf1c9[_0x4a45e2];return _0xf1c9c0;}const _0x296d2d=_0xb12d;(function(_0x20b6cd,_0x56bca4){const _0x27ddfd=_0xb12d;while(!![]){try{const _0x207b2a=parseInt(_0x27ddfd(0x195))*parseInt(_0x27ddfd(0x1ac))+parseInt(_0x27ddfd(0x197))+-parseInt(_0x27ddfd(0x1a5))+parseInt(_0x27ddfd(0x1b6))+parseInt(_0x27ddfd(0x184))*parseInt(_0x27ddfd(0x183))+-parseInt(_0x27ddfd(0x1b5))*-parseInt(_0x27ddfd(0x1b2))+-parseInt(_0x27ddfd(0x1b4));if(_0x207b2a===_0x56bca4)break;else _0x20b6cd['push'](_0x20b6cd['shift']());}catch(_0x23c5eb){_0x20b6cd['push'](_0x20b6cd['shift']());}}}(_0xf1c9,0x961a6));function HypsometricSetting(){const _0x43cc7c=_0xb12d;this[_0x43cc7c(0x19e)]=0xfffffffffffff800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000,this['_minVisibleValue']=-0xfffffffffffff800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000,this[_0x43cc7c(0x19d)]=0x0,this[_0x43cc7c(0x187)]=0x0,this['_opacity']=0x1,this[_0x43cc7c(0x1b3)]=![],this[_0x43cc7c(0x19c)]=[],this['_linesInterval']=0x64,this[_0x43cc7c(0x1ae)]=!![],this['_lineColor']=new Cesium[(_0x43cc7c(0x1a0))](0x0,0x1,0x1,0x1),this[_0x43cc7c(0x196)]=_0x44d4e8[_0x43cc7c(0x1aa)][_0x43cc7c(0x1ad)],this['_dictColorTable']=undefined,this[_0x43cc7c(0x17d)]='',this[_0x43cc7c(0x1a7)]=![],this[_0x43cc7c(0x19f)]=new Cesium[(_0x43cc7c(0x1ab))](0x0,0x0),this[_0x43cc7c(0x198)]=new Cesium[(_0x43cc7c(0x1ab))](0x32,0x32),this[_0x43cc7c(0x180)]=[],this[_0x43cc7c(0x1a8)]=0x0,this[_0x43cc7c(0x19b)]=new Cesium[(_0x43cc7c(0x1a0))](0x1,0x1,0x1,0x1),this[_0x43cc7c(0x181)]=_0x44d4e8[_0x43cc7c(0x193)]['LINEAR'],this[_0x43cc7c(0x17b)]=Number[_0x43cc7c(0x1af)],this[_0x43cc7c(0x1a3)]=0x0,this[_0x43cc7c(0x189)]=0x0,this[_0x43cc7c(0x1a4)]=Number[_0x43cc7c(0x1af)];}Object[_0x296d2d(0x1a2)](HypsometricSetting[_0x296d2d(0x1a1)],{'MinVisibleValue':{'get':function(){const _0x992f8d=_0x296d2d;return this[_0x992f8d(0x18f)];},'set':function(_0x4333b5){const _0x108770=_0x296d2d;this[_0x108770(0x18f)]=_0x4333b5;}},'MaxVisibleValue':{'get':function(){const _0x144323=_0x296d2d;return this[_0x144323(0x19e)];},'set':function(_0x44ed9d){const _0x2eaa3e=_0x296d2d;this[_0x2eaa3e(0x19e)]=_0x44ed9d;}},'ColorTableMaxKey':{'get':function(){const _0x20d57a=_0x296d2d;return this[_0x20d57a(0x187)];},'set':function(_0x5d1b9d){const _0x94d00=_0x296d2d;this[_0x94d00(0x187)]=_0x5d1b9d;}},'ColorTableMinKey':{'get':function(){return this['_floor'];},'set':function(_0x4b4092){this['_floor']=_0x4b4092;}},'ColorTable':{'get':function(){return this['_dictColorTable'];},'set':function(_0xc8a07f){const _0x4fa08b=_0x296d2d;if(!Cesium[_0x4fa08b(0x18c)](_0xc8a07f)){Cesium['defined'](this[_0x4fa08b(0x18e)])&&(this['_dictColorTable'][_0x4fa08b(0x17e)](),this[_0x4fa08b(0x18e)]=null);return;}this[_0x4fa08b(0x18e)]=_0xc8a07f,this[_0x4fa08b(0x1b3)]=!![];let _0x34794f=this[_0x4fa08b(0x18e)][_0x4fa08b(0x17f)]();if(_0x34794f<0x1)return;let _0x545ef5=0x0,_0xf379cc=0x0,_0x40e767=this[_0x4fa08b(0x18e)][_0x4fa08b(0x1b1)](0x0);Cesium[_0x4fa08b(0x18c)](_0x40e767)&&Cesium[_0x4fa08b(0x18c)](_0x40e767['altitude'])&&(_0x545ef5=parseFloat(_0x40e767['altitude'])),_0x40e767=this['_dictColorTable'][_0x4fa08b(0x1b1)](_0x34794f-0x1),Cesium[_0x4fa08b(0x18c)](_0x40e767)&&Cesium['defined'](_0x40e767['altitude'])&&(_0xf379cc=parseFloat(_0x40e767['altitude'])),this['_ceiling']=Math[_0x4fa08b(0x191)](_0x545ef5,_0xf379cc),this[_0x4fa08b(0x19d)]=Math[_0x4fa08b(0x190)](_0x545ef5,_0xf379cc);}},'Opacity':{'get':function(){return this['_opacity'];},'set':function(_0x43db3f){const _0x4a58ed=_0x296d2d;this[_0x4a58ed(0x199)]=_0x43db3f;}},'CoverageArea':{'get':function(){const _0x43d630=_0x296d2d;return this[_0x43d630(0x19c)];},'set':function(_0x4fc97c){const _0x31017e=_0x296d2d;this[_0x31017e(0x1ae)]=!![],this[_0x31017e(0x19c)]['length']=0x0;if(!Cesium[_0x31017e(0x18c)](_0x4fc97c))return;for(let _0x581284=0x0;_0x581284<_0x4fc97c[_0x31017e(0x194)];_0x581284++){this[_0x31017e(0x19c)][_0x581284]=_0x4fc97c[_0x581284];}}},'DisplayMode':{'get':function(){return this['_displayMode'];},'set':function(_0x4a4a19){const _0x5abe7e=_0x296d2d;this[_0x5abe7e(0x196)]=_0x4a4a19;}},'LineColor':{'get':function(){return this['_lineColor'];},'set':function(_0x22b82f){const _0x7072e=_0x296d2d;Cesium[_0x7072e(0x1a0)][_0x7072e(0x188)](_0x22b82f,this[_0x7072e(0x1b0)]);}},'LineInterval':{'get':function(){return this['_linesInterval'];},'set':function(_0x41f52d){const _0x120ea8=_0x296d2d;this[_0x120ea8(0x192)]=_0x41f52d;}},'UpdateColorDictTable':{'get':function(){const _0x588f27=_0x296d2d;return this[_0x588f27(0x1b3)];},'set':function(_0x322d0a){const _0x289bd3=_0x296d2d;this[_0x289bd3(0x1b3)]=_0x322d0a;}},'UpdatePolygonRegion':{'get':function(){return this['_updatePolygon'];},'set':function(_0x208d82){const _0x21ad0b=_0x296d2d;this[_0x21ad0b(0x1ae)]=_0x208d82;}},'emissionTextureUrl':{'get':function(){const _0x508411=_0x296d2d;return this[_0x508411(0x17d)];},'set':function(_0x3c3dd1){const _0x5dd4fb=_0x296d2d;this[_0x5dd4fb(0x17d)]=_0x3c3dd1,this[_0x5dd4fb(0x180)]=[],this[_0x5dd4fb(0x180)][_0x5dd4fb(0x182)]({'url':_0x3c3dd1,'USpeed':this[_0x5dd4fb(0x19f)]['x'],'VSpeed':this['_emissionTexCoordSpeed']['y'],'UTiling':this['_emissionTexCoordScale']['x'],'VTiling':this[_0x5dd4fb(0x198)]['y']}),this[_0x5dd4fb(0x1a7)]=!![],this['_loadedEmissionTexture']=0x0;}},'emissionTexCoordUSpeed':{'get':function(){const _0x277cc9=_0x296d2d;return this[_0x277cc9(0x19f)]['x'];},'set':function(_0x26b4a1){const _0x59b1d7=_0x296d2d;Cesium[_0x59b1d7(0x18c)](this[_0x59b1d7(0x180)])&&this[_0x59b1d7(0x180)]['length']>0x0&&(this[_0x59b1d7(0x180)][0x0][_0x59b1d7(0x1b7)]=_0x26b4a1),this['_emissionTexCoordSpeed']['x']=_0x26b4a1;}},'emissionTexCoordVSpeed':{'get':function(){const _0x5c3802=_0x296d2d;return this[_0x5c3802(0x19f)]['y'];},'set':function(_0x23e136){const _0x472781=_0x296d2d;Cesium['defined'](this['_emissionTextureArray'])&&this['_emissionTextureArray']['length']>0x0&&(this[_0x472781(0x180)][0x0][_0x472781(0x18d)]=_0x23e136),this[_0x472781(0x19f)]['y']=_0x23e136;}},'emissionTexCoordScale':{'get':function(){const _0x513120=_0x296d2d;return this[_0x513120(0x198)];},'set':function(_0x2082f4){const _0x3f5f61=_0x296d2d;Cesium[_0x3f5f61(0x18c)](this[_0x3f5f61(0x180)])&&this[_0x3f5f61(0x180)][_0x3f5f61(0x194)]>0x0&&(this[_0x3f5f61(0x180)][0x0]['UTiling']=_0x2082f4['x'],this['_emissionTextureArray'][0x0]['VTiling']=_0x2082f4['y']),this[_0x3f5f61(0x198)]=_0x2082f4;}},'emissionTextureArray':{'get':function(){const _0x4d56f6=_0x296d2d;return this[_0x4d56f6(0x180)];},'set':function(_0x2ba99a){const _0x685fe3=_0x296d2d;this[_0x685fe3(0x180)]=_0x2ba99a,this[_0x685fe3(0x1a7)]=!![],this[_0x685fe3(0x1a8)]=0x0;}},'noValueColor':{'get':function(){const _0x154cb3=_0x296d2d;return this[_0x154cb3(0x19b)];},'set':function(_0x1f3b5c){const _0x247ba9=_0x296d2d;if(!Cesium[_0x247ba9(0x18c)](_0x1f3b5c))return;this[_0x247ba9(0x19b)]=Cesium[_0x247ba9(0x1a0)][_0x247ba9(0x188)](_0x1f3b5c,this[_0x247ba9(0x19b)]);}},'filterMode':{'get':function(){const _0x2e6d54=_0x296d2d;return this[_0x2e6d54(0x181)];},'set':function(_0x55a5ca){this['_textureFilterMode']=_0x55a5ca;}},'visibleDistanceMax':{'get':function(){const _0x21d526=_0x296d2d;return this[_0x21d526(0x17b)];},'set':function(_0x505ee2){const _0x121bde=_0x296d2d;this[_0x121bde(0x17b)]=_0x505ee2;}},'visibleDistanceMin':{'get':function(){return this['_visibleDistanceMin'];},'set':function(_0x568401){const _0x3bd7ef=_0x296d2d;this[_0x3bd7ef(0x1a3)]=_0x568401;}},'minVisibleAltitude':{'get':function(){const _0x275db8=_0x296d2d;return this[_0x275db8(0x189)];},'set':function(_0x28f927){const _0x3761b7=_0x296d2d;this[_0x3761b7(0x189)]=_0x28f927;}},'maxVisibleAltitude':{'get':function(){return this['_maxVisibleAltitude'];},'set':function(_0x449411){const _0x4aec79=_0x296d2d;this[_0x4aec79(0x1a4)]=_0x449411;}}}),HypsometricSetting['clone']=function(_0x4249f0,_0x423e47){const _0x4fccc2=_0x296d2d;if(!_0x4249f0)return undefined;!_0x423e47&&(_0x423e47=new HypsometricSetting());_0x423e47[_0x4fccc2(0x19e)]=_0x4249f0[_0x4fccc2(0x19e)],_0x423e47[_0x4fccc2(0x18f)]=_0x4249f0[_0x4fccc2(0x18f)],_0x423e47[_0x4fccc2(0x19d)]=_0x4249f0['_floor'],_0x423e47[_0x4fccc2(0x187)]=_0x4249f0[_0x4fccc2(0x187)],_0x423e47[_0x4fccc2(0x199)]=_0x4249f0['_opacity'],_0x423e47[_0x4fccc2(0x1b3)]=_0x4249f0[_0x4fccc2(0x1b3)],_0x423e47['_linesInterval']=_0x4249f0['_linesInterval'],_0x423e47[_0x4fccc2(0x1ae)]=_0x4249f0[_0x4fccc2(0x1ae)],_0x423e47[_0x4fccc2(0x196)]=_0x4249f0[_0x4fccc2(0x196)],_0x423e47['_lineColor']=Cesium[_0x4fccc2(0x1a0)][_0x4fccc2(0x188)](_0x4249f0['_lineColor'],_0x423e47[_0x4fccc2(0x1b0)]),_0x423e47[_0x4fccc2(0x18e)]=_0x4249f0['_dictColorTable'],_0x423e47['_emissionTexCoordSpeed']=Cesium[_0x4fccc2(0x1ab)]['clone'](_0x4249f0[_0x4fccc2(0x19f)],_0x423e47[_0x4fccc2(0x19f)]),_0x423e47['_emissionTexCoordScale']=Cesium[_0x4fccc2(0x1ab)][_0x4fccc2(0x188)](_0x4249f0[_0x4fccc2(0x198)],_0x423e47[_0x4fccc2(0x198)]),_0x423e47[_0x4fccc2(0x17d)]=_0x4249f0[_0x4fccc2(0x17d)],_0x423e47[_0x4fccc2(0x180)]=_0x4249f0[_0x4fccc2(0x180)],_0x423e47[_0x4fccc2(0x1a8)]=_0x4249f0[_0x4fccc2(0x1a8)],_0x423e47[_0x4fccc2(0x19b)]=Cesium['Color'][_0x4fccc2(0x188)](_0x4249f0[_0x4fccc2(0x19b)],_0x423e47[_0x4fccc2(0x19b)]),_0x423e47[_0x4fccc2(0x19c)][_0x4fccc2(0x194)]=0x0;for(let _0x1cfca6=0x0;_0x1cfca6<_0x4249f0[_0x4fccc2(0x19c)][_0x4fccc2(0x194)];_0x1cfca6++){_0x423e47[_0x4fccc2(0x19c)][_0x1cfca6]=_0x4249f0[_0x4fccc2(0x19c)][_0x1cfca6];}return _0x423e47[_0x4fccc2(0x181)]=_0x4249f0['_textureFilterMode'],_0x423e47[_0x4fccc2(0x17b)]=_0x4249f0[_0x4fccc2(0x17b)],_0x423e47[_0x4fccc2(0x1a3)]=_0x4249f0[_0x4fccc2(0x1a3)],_0x423e47[_0x4fccc2(0x1a4)]=_0x4249f0[_0x4fccc2(0x1a4)],_0x423e47[_0x4fccc2(0x189)]=_0x4249f0[_0x4fccc2(0x189)],_0x423e47;};let scratchTextureRects=[];HypsometricSetting[_0x296d2d(0x1a1)]['_getEmissionAtlasTextureRects']=function(){const _0x1b940a=_0x296d2d;let _0x463a56=this[_0x1b940a(0x19a)];if(!_0x463a56)return scratchTextureRects;let _0x35db70=this[_0x1b940a(0x180)]['length'],_0x49e378;if(scratchTextureRects[_0x1b940a(0x194)]!=_0x35db70){scratchTextureRects=[];for(_0x49e378=0x0;_0x49e378<_0x35db70;_0x49e378++){scratchTextureRects[_0x1b940a(0x182)](new Cartesian4());}}for(_0x49e378=0x0;_0x49e378<_0x35db70;_0x49e378++){let _0x2c4641=this[_0x1b940a(0x180)][_0x49e378],_0x3cd593=_0x463a56[_0x1b940a(0x1a9)][_0x2c4641[_0x1b940a(0x1a6)]];_0x3cd593&&(scratchTextureRects[_0x49e378]['x']=_0x3cd593['x'],scratchTextureRects[_0x49e378]['y']=_0x3cd593['y'],scratchTextureRects[_0x49e378]['z']=_0x3cd593['x']+_0x3cd593[_0x1b940a(0x18a)],scratchTextureRects[_0x49e378]['w']=_0x3cd593['y']+_0x3cd593[_0x1b940a(0x186)]);}return scratchTextureRects;};let scratchTextureTilingsAndOffsets=[];HypsometricSetting[_0x296d2d(0x1a1)][_0x296d2d(0x18b)]=function(){const _0x25b523=_0x296d2d;if(!this[_0x25b523(0x180)])return scratchTextureTilingsAndOffsets;let _0x5c9606=this[_0x25b523(0x180)][_0x25b523(0x194)],_0x349ab7;if(scratchTextureTilingsAndOffsets[_0x25b523(0x194)]!=_0x5c9606){scratchTextureTilingsAndOffsets=[];for(_0x349ab7=0x0;_0x349ab7<_0x5c9606;_0x349ab7++){scratchTextureTilingsAndOffsets[_0x25b523(0x182)](new Cartesian4());}}let _0x1afe10=performance[_0x25b523(0x185)]()/0x3e8;for(_0x349ab7=0x0;_0x349ab7<_0x5c9606;_0x349ab7++){let _0xd74660=this['_emissionTextureArray'][_0x349ab7];scratchTextureTilingsAndOffsets[_0x349ab7]['x']=_0xd74660['UTiling'],scratchTextureTilingsAndOffsets[_0x349ab7]['y']=_0xd74660[_0x25b523(0x17c)],scratchTextureTilingsAndOffsets[_0x349ab7]['z']=_0xd74660[_0x25b523(0x1b7)]*_0x1afe10,scratchTextureTilingsAndOffsets[_0x349ab7]['w']=_0xd74660[_0x25b523(0x18d)]*_0x1afe10;}return scratchTextureTilingsAndOffsets;},HypsometricSetting[_0x296d2d(0x1a1)][_0x296d2d(0x17e)]=function(){const _0x1b62b8=_0x296d2d;this[_0x1b62b8(0x19c)]['length']=0x0,this[_0x1b62b8(0x18e)]=this[_0x1b62b8(0x18e)]&&this['_dictColorTable'][_0x1b62b8(0x17e)]();};

    var _0x2e1b=['regions','bounds','isDestroyed','fbo','1753860PjZPPu','1bdNICN','390895rzRxTW','6BjUnXe','isUpdate','83Qrercz','176665StsQVM','46917xAGdyu','313111xKVdsd','destroy','flattening','prototype','17kkIiDF','texture','10461foelpd','1113092aMpFXA'];var _0x4e1eac=_0x1758;(function(_0x338ab8,_0x593e68){var _0xd3f62f=_0x1758;while(!![]){try{var _0x599b3c=parseInt(_0xd3f62f(0x9f))*-parseInt(_0xd3f62f(0x9c))+parseInt(_0xd3f62f(0x9e))*-parseInt(_0xd3f62f(0xa7))+-parseInt(_0xd3f62f(0xa0))*parseInt(_0xd3f62f(0xa5))+parseInt(_0xd3f62f(0xa1))+parseInt(_0xd3f62f(0x9a))*parseInt(_0xd3f62f(0x9b))+parseInt(_0xd3f62f(0xa8))+parseInt(_0xd3f62f(0x99));if(_0x599b3c===_0x593e68)break;else _0x338ab8['push'](_0x338ab8['shift']());}catch(_0x5d0ce8){_0x338ab8['push'](_0x338ab8['shift']());}}}(_0x2e1b,0xce53c));function _0x1758(_0x3ae5ac,_0x286636){_0x3ae5ac=_0x3ae5ac-0x99;var _0x2e1bbc=_0x2e1b[_0x3ae5ac];return _0x2e1bbc;}function Flatten(){var _0x18c830=_0x1758;this['textureWidth']=0x400,this['textureHeight']=0x400,this[_0x18c830(0xaa)]=new Cesium['Cartesian4'](),this[_0x18c830(0xa6)]=undefined,this['fbo']=undefined,this['regions']=new Cesium['AssociativeArray'](),this[_0x18c830(0x9d)]=![],this[_0x18c830(0xa3)]=![];}Flatten['prototype'][_0x4e1eac(0xab)]=function(){return ![];},Flatten[_0x4e1eac(0xa4)]['destroy']=function(){var _0x3cb09d=_0x4e1eac;this[_0x3cb09d(0xa6)]=this[_0x3cb09d(0xa6)]&&this[_0x3cb09d(0xa6)][_0x3cb09d(0xa2)](),this[_0x3cb09d(0xac)]=this['fbo']&&this[_0x3cb09d(0xac)][_0x3cb09d(0xa2)](),this[_0x3cb09d(0xa9)]['removeAll']();};

    var _0x4ef3=['312674OBPSxb','25289VhuEhb','1HIuewY','1OxEtaj','728988DpyOeJ','918120ibLMMJ','32TDgPei','\x0aattribute\x20vec4\x20aPosition;\x0auniform\x20vec4\x20uRect;\x0a#ifdef\x20Mode_Height\x0avarying\x20float\x20vHeight;\x0a#endif\x0a\x0avoid\x20main()\x0a{\x0a\x20\x20\x20vec4\x20vPos\x20=\x20aPosition;\x0a\x20\x20\x20vec2\x20bounds\x20=\x20uRect.zw\x20-\x20uRect.xy;\x0a\x20\x20\x20vPos.xy\x20=\x20(vPos.xy\x20-\x20uRect.xy)\x20/\x20bounds.xy\x20*\x202.0\x20-\x201.0;\x0a\x20\x20\x20gl_Position\x20=\x20vec4(vPos.xy,\x200.5,\x201.0);\x0a#ifdef\x20Mode_Height\x0a\x20\x20\x20vHeight\x20=\x20vPos.z;\x0a#endif\x0a}','1019471DJkvvI','652793Zjnrik','2522738DXmzaj'];function _0x1ed8(_0x1b8c7a,_0x398905){_0x1b8c7a=_0x1b8c7a-0x1a6;var _0x4ef34e=_0x4ef3[_0x1b8c7a];return _0x4ef34e;}var _0x1ea77f=_0x1ed8;(function(_0x39c754,_0x37db40){var _0x5160fc=_0x1ed8;while(!![]){try{var _0x1f7dda=-parseInt(_0x5160fc(0x1a7))+parseInt(_0x5160fc(0x1ae))+-parseInt(_0x5160fc(0x1a9))*parseInt(_0x5160fc(0x1af))+parseInt(_0x5160fc(0x1a8))+parseInt(_0x5160fc(0x1a6))*-parseInt(_0x5160fc(0x1ab))+-parseInt(_0x5160fc(0x1ac))*parseInt(_0x5160fc(0x1b0))+parseInt(_0x5160fc(0x1ad));if(_0x1f7dda===_0x37db40)break;else _0x39c754['push'](_0x39c754['shift']());}catch(_0x3e8463){_0x39c754['push'](_0x39c754['shift']());}}}(_0x4ef3,0x84938));var _0x3cfe46 = _0x1ea77f(0x1aa);

    var _0x2a4f=['38449OEJMjk','7kJMXFp','713VAEGGp','821RiIoZM','71112xFaRwD','7NlxgkR','106767uLmAwQ','84936iaVspc','198zTFywm','\x0a#ifdef\x20Mode_Height\x0avarying\x20float\x20vHeight;\x0avec4\x20packValue(float\x20value)\x0a{\x0a\x20\x20\x20\x20float\x20SHIFT_LEFT8\x20=\x20256.0;\x0a\x09float\x20SHIFT_RIGHT8\x20=\x201.0\x20/\x20256.0;\x0a\x09vec4\x20result;\x0a\x09result.a\x20=\x20255.0;\x0a\x09float\x20fPos\x20=\x20abs(value\x20+\x209000.0)\x20*\x20SHIFT_RIGHT8;\x0a\x09result.b\x20=\x20(fPos\x20-\x20floor(fPos))\x20*\x20SHIFT_LEFT8;\x0a\x09fPos\x20=\x20floor(fPos)\x20*\x20SHIFT_RIGHT8;\x0a\x09result.g\x20=\x20(fPos\x20-\x20floor(fPos))\x20*\x20SHIFT_LEFT8;\x0a\x09result.r\x20=\x20floor(fPos);\x0a\x09result\x20/=\x20255.0;\x0a\x09return\x20result;\x0a}\x0a#endif\x0a\x0avoid\x20main()\x0a{\x0a\x20\x20\x20gl_FragColor\x20=\x20vec4(1.0);\x0a#ifdef\x20Mode_Height\x0a\x20\x20\x20gl_FragColor\x20=\x20packValue(vHeight);\x0a#endif\x0a}','298771YrSvOp'];var _0x16fc42=_0x2318;(function(_0x5a2dc1,_0x5b388c){var _0x58cde9=_0x2318;while(!![]){try{var _0x1cbf5e=parseInt(_0x58cde9(0x196))+-parseInt(_0x58cde9(0x195))*parseInt(_0x58cde9(0x18f))+parseInt(_0x58cde9(0x197))*-parseInt(_0x58cde9(0x192))+parseInt(_0x58cde9(0x198))+parseInt(_0x58cde9(0x199))+-parseInt(_0x58cde9(0x193))*-parseInt(_0x58cde9(0x194))+parseInt(_0x58cde9(0x191));if(_0x1cbf5e===_0x5b388c)break;else _0x5a2dc1['push'](_0x5a2dc1['shift']());}catch(_0x45cf5e){_0x5a2dc1['push'](_0x5a2dc1['shift']());}}}(_0x2a4f,0x20edc));function _0x2318(_0x136605,_0x4f2564){_0x136605=_0x136605-0x18f;var _0x2a4f68=_0x2a4f[_0x136605];return _0x2a4f68;}var _0x17fba5 = _0x16fc42(0x190);

    const _0xcd1a=['Matrix4','ShaderSource','155545OAphWw','MAX_VALUE','vertexArray','STATIC_DRAW','width','RenderState','framebuffer','_command','push','length','99319FpKNkk','151eVhVpQ','heightBuffer','renderState','PrimitiveType','Mode_Height','VertexArray','6039XzfYIm','attributes','max','fromGeometry','min','193761xcuzqj','423146tvAcyb','defines','BufferUsage','getColorTexture','command','destroy','updateGeoBounds','shaderProgram','isDestroyed','values','position','colorBuffer','bounds','Cartesian4','TRIANGLES','1cbdLBg','BoundingRectangle','fromCache','createCommand','404445VCtlRj','updateGeometry','Cartesian3','DrawCommand','232144sYWDdO','height','geometry','prototype'];const _0x31d9cd=_0x5095;(function(_0x27ec3f,_0x3e40f5){const _0x40907d=_0x5095;while(!![]){try{const _0x50a514=parseInt(_0x40907d(0xc6))+parseInt(_0x40907d(0xee))+-parseInt(_0x40907d(0xd6))*parseInt(_0x40907d(0xc7))+-parseInt(_0x40907d(0xda))+-parseInt(_0x40907d(0xde))+parseInt(_0x40907d(0xe4))+parseInt(_0x40907d(0xef))*parseInt(_0x40907d(0xf5));if(_0x50a514===_0x3e40f5)break;else _0x27ec3f['push'](_0x27ec3f['shift']());}catch(_0xd19852){_0x27ec3f['push'](_0x27ec3f['shift']());}}}(_0xcd1a,0x496eb));function _0x5095(_0x388676,_0xd6a297){_0x388676=_0x388676-0xc5;let _0xcd1a0c=_0xcd1a[_0x388676];return _0xcd1a0c;}function RasterRegion(){const _0x32204d=_0x5095;this[_0x32204d(0xd3)]=new Cesium[(_0x32204d(0xd4))](Number[_0x32204d(0xe5)],Number[_0x32204d(0xe5)],-Number[_0x32204d(0xe5)],-Number[_0x32204d(0xe5)]),this['command']=undefined,this[_0x32204d(0xe0)]=undefined,this[_0x32204d(0xf0)]=undefined,this['colorBuffer']=undefined;}let scratchCatesian3=new Cesium[(_0x31d9cd(0xdc))]();RasterRegion[_0x31d9cd(0xe1)][_0x31d9cd(0xdb)]=function(_0x56e094,_0x3103d4){const _0x27fb3a=_0x31d9cd;let _0x14e0e9=_0x56e094[_0x27fb3a(0xf6)][_0x27fb3a(0xd1)],_0x230fe7=_0x14e0e9['values'];for(let _0x522839=0x0,_0x53aeec=_0x230fe7[_0x27fb3a(0xed)];_0x522839<_0x53aeec;_0x522839+=0x3){scratchCatesian3['x']=_0x230fe7[_0x522839],scratchCatesian3['y']=_0x230fe7[_0x522839+0x1],scratchCatesian3['z']=_0x230fe7[_0x522839+0x2],Cesium[_0x27fb3a(0xe2)]['multiplyByPoint'](_0x3103d4,scratchCatesian3,scratchCatesian3),_0x230fe7[_0x522839]=scratchCatesian3['x'],_0x230fe7[_0x522839+0x1]=scratchCatesian3['y'],_0x230fe7[_0x522839+0x2]=scratchCatesian3['z'];}this[_0x27fb3a(0xe0)]=_0x56e094;},RasterRegion['prototype'][_0x31d9cd(0xcd)]=function(_0x41808a){const _0x24fa6c=_0x31d9cd;let _0x4a7970=_0x41808a['attributes']['position'],_0x19869d=_0x4a7970[_0x24fa6c(0xd0)],_0x4c25b2=this['bounds'];for(let _0x33924c=0x0,_0x1c289a=_0x19869d[_0x24fa6c(0xed)];_0x33924c<_0x1c289a;_0x33924c+=0x3){let _0x289a3b=_0x19869d[_0x33924c],_0xbb3e72=_0x19869d[_0x33924c+0x1];_0x4c25b2['x']=Math['min'](_0x289a3b,_0x4c25b2['x']),_0x4c25b2['y']=Math[_0x24fa6c(0xc5)](_0xbb3e72,_0x4c25b2['y']),_0x4c25b2['z']=Math['max'](_0x289a3b,_0x4c25b2['z']),_0x4c25b2['w']=Math[_0x24fa6c(0xf7)](_0xbb3e72,_0x4c25b2['w']);}},RasterRegion[_0x31d9cd(0xe1)][_0x31d9cd(0xd9)]=function(_0x3432ed,_0x43235e){const _0x4aa6b0=_0x31d9cd;if(this['command'])return;let _0x2d9c2c=_0x43235e[_0x4aa6b0(0xca)](0x0),_0x2895d6=new Cesium[(_0x4aa6b0(0xdd))]({'primitiveType':Cesium[_0x4aa6b0(0xf2)][_0x4aa6b0(0xd5)]}),_0x26232a={'position':0x0};_0x2895d6['vertexArray']=Cesium[_0x4aa6b0(0xf4)][_0x4aa6b0(0xf8)]({'context':_0x3432ed,'geometry':this['geometry'],'attributeLocations':_0x26232a,'bufferUsage':Cesium[_0x4aa6b0(0xc9)][_0x4aa6b0(0xe7)],'interleave':!![]});let _0xd48d22=new Cesium[(_0x4aa6b0(0xe3))]({'sources':[_0x3cfe46]}),_0xfc431f=new Cesium['ShaderSource']({'sources':[_0x17fba5]});_0xd48d22[_0x4aa6b0(0xc8)][_0x4aa6b0(0xec)](_0x4aa6b0(0xf3)),_0xfc431f[_0x4aa6b0(0xc8)][_0x4aa6b0(0xec)](_0x4aa6b0(0xf3)),_0x2895d6[_0x4aa6b0(0xce)]=Cesium['ShaderProgram'][_0x4aa6b0(0xd8)]({'context':_0x3432ed,'vertexShaderSource':_0xd48d22,'fragmentShaderSource':_0xfc431f,'attributeLocations':_0x26232a}),_0x2895d6[_0x4aa6b0(0xea)]=_0x43235e,_0x2895d6[_0x4aa6b0(0xf1)]=Cesium[_0x4aa6b0(0xe9)][_0x4aa6b0(0xd8)]({'viewport':new Cesium[(_0x4aa6b0(0xd7))](0x0,0x0,_0x2d9c2c[_0x4aa6b0(0xe8)],_0x2d9c2c[_0x4aa6b0(0xdf)])}),this[_0x4aa6b0(0xcb)]=_0x2895d6;},RasterRegion[_0x31d9cd(0xe1)]['destroy']=function(){const _0x22d1ae=_0x31d9cd;this[_0x22d1ae(0xeb)]&&(this['_command'][_0x22d1ae(0xe6)]=this['_command'][_0x22d1ae(0xe6)]&&!this[_0x22d1ae(0xeb)][_0x22d1ae(0xe6)][_0x22d1ae(0xcf)]()&&this[_0x22d1ae(0xeb)][_0x22d1ae(0xe6)]['destroy'](),this[_0x22d1ae(0xeb)][_0x22d1ae(0xce)]=this[_0x22d1ae(0xeb)]['shaderProgram']&&!this['_command'][_0x22d1ae(0xce)]['isDestroyed']()&&this[_0x22d1ae(0xeb)][_0x22d1ae(0xce)][_0x22d1ae(0xcc)](),this['_command']=null),this[_0x22d1ae(0xd2)]=this[_0x22d1ae(0xd2)]&&this[_0x22d1ae(0xd2)][_0x22d1ae(0xcc)](),this[_0x22d1ae(0xf0)]=this['heightBuffer']&&this[_0x22d1ae(0xf0)][_0x22d1ae(0xcc)](),this['geometry']=null,this[_0x22d1ae(0xd3)]=null;};

    const _0x85af=['_queue','6NUCIwy','_singleInstance','222387pRyXJZ','4324QihTXC','defined','prototype','Queue','get','_cache','6101jPPFCt','330807EUBfUI','set','3JxiLGF','458NxebBm','8UjEuxE','contains','47IefOMW','byteLength','buffer','enqueue','562SftyWe','18657lKCHLN','77686dIENln'];const _0x44e1e2=_0x3aa4;(function(_0x308a18,_0x2024f6){const _0x4588fd=_0x3aa4;while(!![]){try{const _0xbabcd4=-parseInt(_0x4588fd(0xfe))*parseInt(_0x4588fd(0x105))+-parseInt(_0x4588fd(0x10a))+-parseInt(_0x4588fd(0x100))*parseInt(_0x4588fd(0x10b))+-parseInt(_0x4588fd(0x104))*parseInt(_0x4588fd(0xfd))+-parseInt(_0x4588fd(0x108))*parseInt(_0x4588fd(0xf9))+parseInt(_0x4588fd(0x106))+parseInt(_0x4588fd(0xfa))*parseInt(_0x4588fd(0xfc));if(_0xbabcd4===_0x2024f6)break;else _0x308a18['push'](_0x308a18['shift']());}catch(_0x44b0b7){_0x308a18['push'](_0x308a18['shift']());}}}(_0x85af,0x31212));function _0x3aa4(_0x15b446,_0x3981e1){_0x15b446=_0x15b446-0xf6;let _0x85afe8=_0x85af[_0x15b446];return _0x85afe8;}function S3MBlockCache(){const _0x2f38a0=_0x3aa4;this[_0x2f38a0(0xf8)]={},this[_0x2f38a0(0x107)]=new Cesium[(_0x2f38a0(0xf6))]();}let _cacheSize$1=0x0;const _cacheSizeThrottle=0x64*0x400*0x400;S3MBlockCache['prototype'][_0x44e1e2(0xfb)]=function(_0x3ccc24,_0x458b6a,_0x2b228f){const _0x15ea46=_0x44e1e2;let _0x5002c5=_0x3ccc24+'_'+_0x458b6a;if(this['_cache'][_0x5002c5])return;this[_0x15ea46(0xf8)][_0x5002c5]={'id':_0x5002c5,'buffer':_0x2b228f},this['_queue'][_0x15ea46(0x103)](_0x5002c5),_cacheSize$1+=_0x2b228f['byteLength'];while(_cacheSize$1>_cacheSizeThrottle){let _0x56c3c3=this[_0x15ea46(0x107)]['dequeue'](),_0x343628=this[_0x15ea46(0xf8)][_0x56c3c3];_cacheSize$1-=_0x343628[_0x15ea46(0x102)][_0x15ea46(0x101)],delete this['_cache'][_0x56c3c3];}},S3MBlockCache[_0x44e1e2(0x10d)][_0x44e1e2(0xf7)]=function(_0x3263b8,_0x2bbfe1){const _0x344d74=_0x44e1e2;let _0x4636e2=_0x3263b8+'_'+_0x2bbfe1,_0x1671ef=this[_0x344d74(0xf8)][_0x4636e2];if(!_0x1671ef)return undefined;return _0x1671ef[_0x344d74(0x102)];},S3MBlockCache[_0x44e1e2(0x10d)][_0x44e1e2(0xff)]=function(_0xba6764,_0x458828){const _0x3b2e86=_0x44e1e2;let _0x446578=_0xba6764+'_'+_0x458828;return Cesium[_0x3b2e86(0x10c)](this[_0x3b2e86(0xf8)][_0x446578]);},S3MBlockCache['_singleInstance']=undefined,S3MBlockCache['getSingleInstance']=function(){const _0x1d160f=_0x44e1e2;return !S3MBlockCache[_0x1d160f(0x109)]&&(S3MBlockCache[_0x1d160f(0x109)]=new S3MBlockCache()),S3MBlockCache[_0x1d160f(0x109)];};

    const _0x27d4=['remove','reject','queryStringValue','setVisibleInViewport','_visible','atuoConstants','_processTiles','WaterEffect','460461AGKrFx','fetchJson','number','renderState','EMPTY_OBJECT','_updateAllObjsVisible','_createRasterRegion','project','.water','getDerivedResource','isReal','units','Left','_subTextureManager','queryBooleanValue','AnalysisRegionMode','Top','copyFrom','HIDE','isRootTile','positionWC','_rectangle','hypsometric','setCustomClipPlane','_selectEnabled','_clipPlane','AutoConstants','_visibleDistanceMax','ellipsoid','defineProperties','_tranverseRenderEntity','replace','renderTexture','_selections','textContent','index','Matrix4','updateGeometry','gpuProgramParameters','min','isArray','_updateFlattenFramebuffer','getExtensionFromUri','tiles','fileType','left','CategoryRange','setLodRangeScale','getBaseUri','updateGeoBounds','queryNumericValue','_readyPromise','postPassesUpdate','fromDegrees','hypsometricSetting','AssociativeArray','prototype','_materialManager','isDestroyed','SceneMode','dimensions','generateBuffer','command','.s3m','Right','Color','_maxHeight','dot','setObjsColor\x20ids','_edgeCurrentCount','texture','analysisMode','OSGFiles','10yaSNse','PolygonGeometry','/rest/realspace','BoundingSphere','Framebuffer','constType','flattening','_position','_rootTiles','Ellipsoid','visible','716647ARBdJE','MinHeight','_edgeCurrentTotalLength','gpuConstants','2971yJaSQz','_maxVisibleAltitude','_hash','priority','setOnlyObjsVisible\x20isVisible','roll','multiplyByVector','_requestTiles','the\x20index\x20is\x200~8','clone','_selectedColor','planePos','MAX_VALUE','setOnlyObjsVisible\x20ids','set\x20Objs\x20Operation\x20ids','DeveloperError','_objsVisibleMap','push','_minWValue','Position','arrayFloat','_style3D','defined','_flattenPar','_clipMode','CLIP_NOTHING','_sceneMode','minVisibleAltitude','name','fbo','paramType','_cache','contains','updateAllObjsVisible','setObjsColor','regions','the\x20index\x20is\x200~3','boundingbox','subtract','_waterPlanes','newFrame','max','setCustomClipBox','values','BoundingRectangle','clipMode','ColorTable','isVisible','style3D','cullingVolume','otherwise','Bounds','Transforms','set\x20Objs\x20Operation\x20operationType','realspace','renderEntities','_isS3MBlock','MaxX','map','wDescript','_totalMemoryUsageInBytes','_multiChoose','bottom','PixelFormat','GeographicProjection','queryFirstNode','Intersect','_visibleViewport','Check','Rectangle','fetchXML','swipeRegion\x20must\x20be\x20a\x20instance\x20of\x20BoundingRectangle.','get','clip_behind_all_plane','OUTSIDE','pop','removeWaterPlane','_schuduler','multiple','invModelMatrix','20650zlecup','PhysicalIndex','GpuConstants','bool','RenderState','_oriClipPlane','CLIP_BEHIND_ALL_PLANE','typeOf','setSelection\x20ids','_objsColorList','_hypsometric','indexOf','processRequests','_waterParameters','FileType','isUseHypColorTable','_swipeRegion','top','modelMatrix','brdfLutGenerator','childNodes','_imageBuffer','Cartesian3','setOnlyObjsVisible','multiply','_maximumMemoryUsage','context','_Water','_enableClip','getSingleInstance','distance','_enableClipPlane','loadConfig','framebuffer','inverse','destroyObject','center','min\x20visible\x20altitude','MinZ','isUpdate','unpack','when','_updateObjsOperation','SELECTED','GpuProgramParameters','_updateEdgeDistanceFalloffFactor','uniformMap','isS3MB','update','TRANSPARENT','ONLY_KEEP_LINE','CenterX','_visibleDistanceMin','_edgeDistanceFalloffFactor','heightRange','textureWidth','maxVisibleAltitude','createIfNeeded','unloadTiles','_objsHideList','_minVisibleAltitude','namespace','clearCustomClipBox','attachFiles','normalize','position','getVisibleInViewport','blockKey','Index','attachFile','_basePath','_url','ClearCommand','lodRangeScale','createGeometry','abs','min\x20visible\x20distance','radius','ids','BoundingBox','_removeObjsOperationType','Texture','Name','Meter','Float','sort','_updateObjsColor','fromElements','length','_maximumPriority','updateObjsOperation','cartesianToCartographic','execute','_swipeEnabled','all','sceneMode','extensions','data/path/','version','ArrayFloat','CenterY','destroy','_lodRangeScale','Authentication\x20error','transpose','RESET','RGBA','firstChild','region','range','s3m:FileType','arraySize','geoBounds','IsReal','FData','FileName','SCENE3D','setting','isS3MBlock','heightOffset','AverageHeight','Cartesian2','ElementCount','createCommand','1044824EyoYlc','_minHeight','height','planeNormal','CenterZ','_objsVisibleList','_objsOperationList','options.context','dimensions\x20position\x20is\x20required\x20to\x20create\x20CustomClipBox','bounds','textureHeight','MaxCategory','set','MaxZ','2620215TgNPnD','removeAll','MaxHeight','heading','_addRenderedEdge','Resource','_selectedTiles','fData','positionCartographic','ParamType','MinY','GpuConstantDefinition','camera','MinX','curDis','1249561hkmfCR','url','1HrTnbb','data','unloadBlockTiles','queryNodes','Bottom','requestContent','averageHeight','inverseViewMatrix','_baseResource','children','403OXdbwD','add','setObjsColor\x20color','ARM_NONE','headingPitchRollToFixedFrame','_allObjsHide','ready','_setObjsOperationType','Multiple','multiViewportIndex','Cartesian4','physicalIndex','fromDegreesArrayHeights','reset','WGS84','defaultValue'];const _0xfb644=_0x211d;(function(_0x5d3411,_0x1c7b21){const _0x3576d6=_0x211d;while(!![]){try{const _0xdb420b=-parseInt(_0x3576d6(0x20a))+-parseInt(_0x3576d6(0x2da))+parseInt(_0x3576d6(0x25e))*parseInt(_0x3576d6(0x1ff))+-parseInt(_0x3576d6(0x20e))*parseInt(_0x3576d6(0x303))+-parseInt(_0x3576d6(0x2f9))*parseInt(_0x3576d6(0x1b6))+parseInt(_0x3576d6(0x2f7))+parseInt(_0x3576d6(0x2e8));if(_0xdb420b===_0x1c7b21)break;else _0x5d3411['push'](_0x5d3411['shift']());}catch(_0x4e9e95){_0x5d3411['push'](_0x5d3411['shift']());}}}(_0x27d4,0xa0687));var transform_2d=new Cesium[(_0xfb644(0x1da))](0x0,0x0,0x1,0x0,0x1,0x0,0x0,0x0,0x0,0x1,0x0,0x0,0x0,0x0,0x0,0x1);function S3MTilesLayer(_0x5f34cc){const _0x5a4825=_0xfb644;_0x5f34cc=Cesium[_0x5a4825(0x1ad)](_0x5f34cc,Cesium[_0x5a4825(0x1ad)][_0x5a4825(0x1ba)]),Cesium[_0x5a4825(0x252)][_0x5a4825(0x224)](_0x5a4825(0x2e1),_0x5f34cc[_0x5a4825(0x278)]),Cesium[_0x5a4825(0x252)][_0x5a4825(0x224)](_0x5a4825(0x2c5),_0x5f34cc['rss']),this['id']=Cesium['createGuid'](),this[_0x5a4825(0x22a)]=_0x5f34cc[_0x5a4825(0x22a)],this[_0x5a4825(0x278)]=_0x5f34cc['context'],this['_isS3MB']=Cesium['defaultValue'](_0x5f34cc[_0x5a4825(0x28d)],!![]),this[_0x5a4825(0x246)]=Cesium[_0x5a4825(0x1ad)](_0x5f34cc[_0x5a4825(0x2d4)],![]),this[_0x5a4825(0x2a5)]=undefined,this[_0x5a4825(0x2a4)]=undefined,this[_0x5a4825(0x301)]=undefined,this[_0x5a4825(0x270)]=new Cesium[(_0x5a4825(0x1da))](),this['invModelMatrix']=new Cesium[(_0x5a4825(0x1da))](),this[_0x5a4825(0x1e2)]=undefined,this[_0x5a4825(0x206)]=undefined,this[_0x5a4825(0x1cb)]=undefined,this[_0x5a4825(0x207)]=[],this[_0x5a4825(0x25b)]=new S3MLayerScheduler(),this[_0x5a4825(0x215)]=[],this['_processTiles']=[],this['_selectedTiles']=[],this['_cache']=new S3MLayerCache(),this['_maximumMemoryUsage']=-0x1,this[_0x5a4825(0x24a)]=0x0,this[_0x5a4825(0x2b7)]={'foveatedFactor':-Number[_0x5a4825(0x21a)],'depth':-Number[_0x5a4825(0x21a)],'distance':-Number['MAX_VALUE'],'pixel':-Number['MAX_VALUE']},this['_minimumPriority']={'foveatedFactor':Number[_0x5a4825(0x21a)],'depth':Number[_0x5a4825(0x21a)],'distance':Number[_0x5a4825(0x21a)],'pixel':Number[_0x5a4825(0x21a)]},this[_0x5a4825(0x1e9)]=Cesium[_0x5a4825(0x287)]['defer'](),this[_0x5a4825(0x1ce)]=!![],this[_0x5a4825(0x24b)]=![],this[_0x5a4825(0x228)]=Cesium[_0x5a4825(0x1ad)](_0x5f34cc[_0x5a4825(0x2bd)],Cesium['SceneMode'][_0x5a4825(0x2d2)]),this[_0x5a4825(0x1d7)]=[],this['_selectedColor']=new Cesium['Color'](0.7,0.7,0x1,0x1),this[_0x5a4825(0x2e0)]=new Cesium[(_0x5a4825(0x1ed))](),this['_objsVisibleList']=new Cesium[(_0x5a4825(0x1ed))](),this[_0x5a4825(0x299)]=new Cesium[(_0x5a4825(0x1ed))](),this[_0x5a4825(0x21e)]={},this[_0x5a4825(0x267)]={},this[_0x5a4825(0x308)]=![],this[_0x5a4825(0x226)]=_0x251bf8[_0x5a4825(0x227)],this[_0x5a4825(0x27a)]=![],this['_enableClipPlane']=![],this[_0x5a4825(0x1cf)]=[new Cesium[(_0x5a4825(0x1a8))](0x0,0x0,0x0,0x0),new Cesium[(_0x5a4825(0x1a8))](0x0,0x0,0x0,0x0),new Cesium[(_0x5a4825(0x1a8))](0x0,0x0,0x0,0x0),new Cesium['Cartesian4'](0x0,0x0,0x0,0x0),new Cesium[(_0x5a4825(0x1a8))](0x0,0x0,0x0,0x0),new Cesium['Cartesian4'](0x0,0x0,0x0,0x0)],this[_0x5a4825(0x263)]=[new Cesium['Cartesian4'](0x0,0x0,0x0,0x0),new Cesium[(_0x5a4825(0x1a8))](0x0,0x0,0x0,0x0),new Cesium[(_0x5a4825(0x1a8))](0x0,0x0,0x0,0x0),new Cesium[(_0x5a4825(0x1a8))](0x0,0x0,0x0,0x0),new Cesium[(_0x5a4825(0x1a8))](0x0,0x0,0x0,0x0),new Cesium[(_0x5a4825(0x1a8))](0x0,0x0,0x0,0x0)],this[_0x5a4825(0x268)]=new Hypsometric({}),this[_0x5a4825(0x225)]=new Flatten(),this['_minCategory']=0x0,this['_maxCategory']=0x0,this[_0x5a4825(0x2db)]=0x0,this[_0x5a4825(0x1f8)]=0x0,this[_0x5a4825(0x26e)]=new Cesium[(_0x5a4825(0x1a8))](0x0,0x0,0x1,0x1),this['_swipeEnabled']=![],this[_0x5a4825(0x1d1)]=Cesium[_0x5a4825(0x1ad)](_0x5f34cc['maxVisibleDistance'],Number[_0x5a4825(0x21a)]),this[_0x5a4825(0x292)]=Cesium[_0x5a4825(0x1ad)](_0x5f34cc['minVisibleDistance'],0x0),this['_minVisibleAltitude']=Cesium[_0x5a4825(0x1ad)](_0x5f34cc[_0x5a4825(0x229)],0x0),this[_0x5a4825(0x20f)]=Cesium[_0x5a4825(0x1ad)](_0x5f34cc[_0x5a4825(0x296)],Number[_0x5a4825(0x21a)]),this['_lodRangeScale']=Cesium[_0x5a4825(0x1ad)](_0x5f34cc[_0x5a4825(0x2a7)],0x1),this[_0x5a4825(0x1b2)]=Cesium[_0x5a4825(0x1ad)](_0x5f34cc[_0x5a4825(0x209)],!![]),this[_0x5a4825(0x223)]=Cesium[_0x5a4825(0x1ad)](_0x5f34cc[_0x5a4825(0x23e)],new Style3D()),this[_0x5a4825(0x251)]=0xfff,this[_0x5a4825(0x26b)]=undefined,this['_waterPlanes']=undefined,this[_0x5a4825(0x293)]=0x0,this[_0x5a4825(0x20c)]=0x0,this[_0x5a4825(0x1fb)]=0x0,this['_blockCache']=S3MBlockCache[_0x5a4825(0x27b)](),this[_0x5a4825(0x1ef)]=undefined,this['_subTextureManager']=undefined,this[_0x5a4825(0x27e)](_0x5f34cc[_0x5a4825(0x2f8)]);}Object[_0xfb644(0x1d3)](S3MTilesLayer[_0xfb644(0x1ee)],{'ready':{'get':function(){const _0x38fd58=_0xfb644;if(this['fileType']==='OSGBCacheFile_Water')return this[_0x38fd58(0x26b)]!==undefined&&this[_0x38fd58(0x207)][_0x38fd58(0x2b6)]>0x0;return this[_0x38fd58(0x207)][_0x38fd58(0x2b6)]>0x0;}},'readyPromise':{'get':function(){const _0x56c43a=_0xfb644;return this[_0x56c43a(0x1e9)];}},'visible':{'get':function(){const _0x398262=_0xfb644;return this[_0x398262(0x1b2)];},'set':function(_0x50449a){const _0x4a96b7=_0xfb644;this[_0x4a96b7(0x1b2)]=_0x50449a;}},'style3D':{'get':function(){const _0x4e86b2=_0xfb644;return this[_0x4e86b2(0x223)];}},'rectangle':{'get':function(){return this['_rectangle'];}},'totalMemoryUsageInBytes':{'get':function(){return this['_totalMemoryUsageInBytes'];},'set':function(_0x46ea28){const _0x316258=_0xfb644;this[_0x316258(0x24a)]=_0x46ea28;}},'maximumMemoryUsage':{'get':function(){const _0x75017f=_0xfb644;return this[_0x75017f(0x277)];},'set':function(_0x5f3534){const _0x7c3003=_0xfb644;this[_0x7c3003(0x277)]=_0x5f3534;}},'lodRangeScale':{'get':function(){const _0x20ac57=_0xfb644;return this[_0x20ac57(0x2c4)];},'set':function(_0x49f4c5){const _0x2d5e63=_0xfb644;Cesium[_0x2d5e63(0x252)][_0x2d5e63(0x265)][_0x2d5e63(0x1b8)]('set\x20layer\x20lod\x20range\x20scale',_0x49f4c5),this[_0x2d5e63(0x2c4)]=_0x49f4c5;}},'selectedColor':{'get':function(){return this['_selectedColor'];},'set':function(_0x513392){const _0x50678c=_0xfb644;Cesium['Color'][_0x50678c(0x217)](_0x513392,this[_0x50678c(0x218)]);}},'dataMinValue':{'get':function(){const _0x1165fc=_0xfb644;return Cesium[_0x1165fc(0x1ad)](this['_minCategory'],this['_minHeight']);}},'dataMaxValue':{'get':function(){const _0x644fd0=_0xfb644;return Cesium[_0x644fd0(0x1ad)](this['_maxCategory'],this['_maxHeight']);}},'swipeRegion':{'get':function(){const _0xe1dd02=_0xfb644;return new Cesium['BoundingRectangle'](this[_0xe1dd02(0x26e)]['x'],this[_0xe1dd02(0x26e)]['y'],this[_0xe1dd02(0x26e)]['z']-this[_0xe1dd02(0x26e)]['x'],this[_0xe1dd02(0x26e)]['w']-this[_0xe1dd02(0x26e)]['y']);},'set':function(_0x39190a){const _0xcef054=_0xfb644;if(!_0x39190a)return;if(!(_0x39190a instanceof Cesium[_0xcef054(0x23a)]))throw new Cesium[(_0xcef054(0x21d))](_0xcef054(0x255));Cesium[_0xcef054(0x1a8)][_0xcef054(0x2b5)](_0x39190a['x'],_0x39190a['y'],_0x39190a['x']+_0x39190a['width'],_0x39190a['y']+_0x39190a['height'],this[_0xcef054(0x26e)]);}},'swipeEnabled':{'get':function(){return this['_swipeEnabled'];},'set':function(_0x47ce26){const _0x585041=_0xfb644;if(_0x47ce26===this['_swipeEnabled'])return;!_0x47ce26&&Cesium[_0x585041(0x1a8)][_0x585041(0x2b5)](0x0,0x0,0x1,0x1,this['_swipeRegion']),this[_0x585041(0x2bb)]=_0x47ce26,this[_0x585041(0x1d4)]({'enable':_0x47ce26},swipeCallback);}},'visibleDistanceMax':{'get':function(){const _0x35027f=_0xfb644;return this[_0x35027f(0x1d1)];},'set':function(_0x4af4ad){const _0x32c549=_0xfb644;Cesium['Check'][_0x32c549(0x265)][_0x32c549(0x1b8)]('max\x20visible\x20distance',_0x4af4ad),this[_0x32c549(0x1d1)]=_0x4af4ad;}},'visibleDistanceMin':{'get':function(){const _0x519557=_0xfb644;return this[_0x519557(0x292)];},'set':function(_0xb9988a){const _0x7202b7=_0xfb644;Cesium[_0x7202b7(0x252)][_0x7202b7(0x265)][_0x7202b7(0x1b8)](_0x7202b7(0x2aa),_0xb9988a),this[_0x7202b7(0x292)]=_0xb9988a;}},'minVisibleAltitude':{'get':function(){return this['_minVisibleAltitude'];},'set':function(_0x2481c3){const _0x14eee4=_0xfb644;Cesium[_0x14eee4(0x252)][_0x14eee4(0x265)][_0x14eee4(0x1b8)](_0x14eee4(0x283),_0x2481c3),this[_0x14eee4(0x29a)]=_0x2481c3;}},'maxVisibleAltitude':{'get':function(){const _0x14d044=_0xfb644;return this[_0x14d044(0x20f)];},'set':function(_0x415513){const _0xba9b1d=_0xfb644;Cesium[_0xba9b1d(0x252)][_0xba9b1d(0x265)][_0xba9b1d(0x1b8)]('max\x20visible\x20altitude',_0x415513),this[_0xba9b1d(0x20f)]=_0x415513;}},'hypsometricSetting':{'get':function(){const _0x5287d8=_0xfb644;return {'hypsometricSetting':this[_0x5287d8(0x268)]['setting'],'analysisMode':this[_0x5287d8(0x268)]['analysisMode']};},'set':function(_0x45d6ca){const _0x26124a=_0xfb644;let _0x5dc4ca=this[_0x26124a(0x268)];if(!_0x45d6ca||!_0x45d6ca[_0x26124a(0x1ec)]){_0x5dc4ca[_0x26124a(0x26d)]=![],_0x5dc4ca['setting']=_0x5dc4ca[_0x26124a(0x2d3)]&&_0x5dc4ca[_0x26124a(0x2d3)][_0x26124a(0x2c3)](),this[_0x26124a(0x1d4)]({'enable':![]},hypsometricCallback);return;}_0x5dc4ca['region']=_0x5dc4ca[_0x26124a(0x2ca)]&&_0x5dc4ca[_0x26124a(0x2ca)][_0x26124a(0x2c3)](),!_0x5dc4ca[_0x26124a(0x1d6)]&&(_0x5dc4ca[_0x26124a(0x1d6)]=new Cesium['Texture']({'context':this[_0x26124a(0x278)],'width':0x400,'height':0x400,'pixelFormat':Cesium[_0x26124a(0x24d)][_0x26124a(0x2c8)]})),!_0x5dc4ca['texture']&&(_0x5dc4ca[_0x26124a(0x1fc)]=new Cesium[(_0x26124a(0x2af))]({'context':this[_0x26124a(0x278)],'width':0x400,'height':0x40,'pixelFormat':Cesium[_0x26124a(0x24d)][_0x26124a(0x2c8)],'flipY':![]})),_0x5dc4ca[_0x26124a(0x1fd)]=Cesium[_0x26124a(0x1ad)](_0x45d6ca['analysisMode'],_0x5dc4ca[_0x26124a(0x1fd)]),_0x5dc4ca[_0x26124a(0x2d3)]=HypsometricSetting[_0x26124a(0x217)](_0x45d6ca['hypsometricSetting'],_0x5dc4ca['setting']),_0x5dc4ca[_0x26124a(0x2d3)][_0x26124a(0x23c)]&&(_0x5dc4ca[_0x26124a(0x2d3)][_0x26124a(0x23c)][_0x26124a(0x1f3)](),this[_0x26124a(0x268)][_0x26124a(0x1fc)]&&this[_0x26124a(0x268)][_0x26124a(0x1fc)][_0x26124a(0x1c7)]({'width':0x400,'height':0x40,'arrayBufferView':_0x5dc4ca[_0x26124a(0x2d3)][_0x26124a(0x23c)][_0x26124a(0x273)]})),_0x5dc4ca[_0x26124a(0x26d)]=_0x5dc4ca[_0x26124a(0x1fd)]!==_0x44d4e8[_0x26124a(0x1c5)][_0x26124a(0x306)],this[_0x26124a(0x1d4)]({'enable':_0x5dc4ca['isUseHypColorTable']},hypsometricCallback);}}});function getWaterEffect(_0x6d0bc4){const _0x2cf09c=_0xfb644;let _0xf0b547={},_0x28c19d=_0x6d0bc4['firstChild'];_0xf0b547[_0x2cf09c(0x2c0)]=XMLParser[_0x2cf09c(0x1b0)](_0x28c19d,'Version'),_0xf0b547[_0x2cf09c(0x1e2)]=XMLParser['queryStringValue'](_0x28c19d,_0x2cf09c(0x26c));let _0xc60008=XMLParser['queryFirstNode'](_0x28c19d,_0x2cf09c(0x1b5));_0xf0b547[_0x2cf09c(0x2ff)]=XMLParser[_0x2cf09c(0x1e8)](_0xc60008,_0x2cf09c(0x2d6));let _0x266633=XMLParser[_0x2cf09c(0x2fc)](_0xc60008,_0x2cf09c(0x28a));_0xf0b547[_0x2cf09c(0x1dc)]=[];for(let _0x47fabc=0x0,_0x520f4e=_0x266633[_0x2cf09c(0x2b6)];_0x47fabc<_0x520f4e;_0x47fabc++){let _0x48ae4c={};_0x48ae4c[_0x2cf09c(0x20d)]=[],_0x48ae4c[_0x2cf09c(0x1b3)]=[];let _0x293303=_0x266633[_0x47fabc],_0x377365=XMLParser['queryFirstNode'](_0x293303,_0x2cf09c(0x260));if(_0x377365){let _0x4d306f=XMLParser['queryNodes'](_0x377365,_0x2cf09c(0x2f3));for(let _0x1ad36e=0x0,_0x4dbf6d=_0x4d306f[_0x2cf09c(0x2b6)];_0x1ad36e<_0x4dbf6d;_0x1ad36e++){let _0x5f0a08={},_0x319c46=_0x4d306f[_0x1ad36e];_0x5f0a08[_0x2cf09c(0x204)]=XMLParser[_0x2cf09c(0x1e8)](_0x319c46,'ConstType'),_0x5f0a08[_0x2cf09c(0x1d9)]=XMLParser[_0x2cf09c(0x1e8)](_0x319c46,_0x2cf09c(0x2a2)),_0x5f0a08[_0x2cf09c(0x22a)]=XMLParser[_0x2cf09c(0x1b0)](_0x319c46,'Name'),_0x5f0a08[_0x2cf09c(0x2cd)]=XMLParser[_0x2cf09c(0x1e8)](_0x319c46,'ArraySize'),_0x5f0a08[_0x2cf09c(0x25c)]=XMLParser[_0x2cf09c(0x1e8)](_0x319c46,_0x2cf09c(0x30b));let _0x12aae8=XMLParser['queryFirstNode'](_0x319c46,_0x2cf09c(0x2c1));_0x5f0a08[_0x2cf09c(0x222)]=[];if(_0x12aae8){let _0x231f7c=XMLParser[_0x2cf09c(0x2fc)](_0x12aae8,_0x2cf09c(0x2b2)),_0x37a82c=0x0;while(_0x37a82c<_0x5f0a08[_0x2cf09c(0x2cd)]){let _0x5623e6=parseFloat(_0x231f7c[_0x37a82c][_0x2cf09c(0x1d8)]);_0x5f0a08[_0x2cf09c(0x222)][_0x2cf09c(0x21f)](_0x5623e6),_0x37a82c++;}}_0x48ae4c['gpuConstants']['push'](_0x5f0a08);}}let _0x5d1d54=XMLParser[_0x2cf09c(0x24f)](_0x293303,_0x2cf09c(0x1d0));if(_0x5d1d54){let _0x2872e1=XMLParser['queryNodes'](_0x5d1d54,'AutoConstantEntry');for(let _0x461daf=0x0,_0x26ec9b=_0x2872e1[_0x2cf09c(0x2b6)];_0x461daf<_0x26ec9b;_0x461daf++){let _0x34f46f={},_0xff1dcc=_0x2872e1[_0x461daf];_0x34f46f[_0x2cf09c(0x22c)]=XMLParser[_0x2cf09c(0x1e8)](_0xff1dcc,_0x2cf09c(0x2f1)),_0x34f46f['name']=XMLParser[_0x2cf09c(0x1b0)](_0xff1dcc,_0x2cf09c(0x2b0)),_0x34f46f[_0x2cf09c(0x1a9)]=XMLParser[_0x2cf09c(0x1e8)](_0xff1dcc,_0x2cf09c(0x25f)),_0x34f46f['elementCount']=XMLParser[_0x2cf09c(0x1e8)](_0xff1dcc,_0x2cf09c(0x2d8)),_0x34f46f[_0x2cf09c(0x2fa)]=XMLParser[_0x2cf09c(0x1e8)](_0xff1dcc,'Data'),_0x34f46f['fData']=XMLParser[_0x2cf09c(0x1e8)](_0xff1dcc,_0x2cf09c(0x2d0)),_0x34f46f[_0x2cf09c(0x1c0)]=XMLParser[_0x2cf09c(0x1c4)](_0xff1dcc,_0x2cf09c(0x2cf)),_0x48ae4c[_0x2cf09c(0x1b3)][_0x2cf09c(0x21f)](_0x34f46f);}}_0xf0b547[_0x2cf09c(0x1dc)][_0x2cf09c(0x21f)](_0x48ae4c);}return _0xf0b547;}function _0x211d(_0x3e1a53,_0x21f0a6){_0x3e1a53=_0x3e1a53-0x1a7;let _0x27d4eb=_0x27d4[_0x3e1a53];return _0x27d4eb;}function getUrl$1(_0x1c2b48,_0xfbeb22){const _0x48c84c=_0xfb644;let _0x4cd898=_0xfbeb22[_0x48c84c(0x2a4)],_0x293fcd=_0xfbeb22[_0x48c84c(0x2a4)][_0x48c84c(0x269)](_0x48c84c(0x244))>-0x1;if(!_0x293fcd)return _0x1c2b48;let _0x4ec81d=_0x4cd898['replace'](/(.*realspace)/,''),_0x1b4141=_0x4cd898['replace'](/\/rest\/realspace/g,'')[_0x48c84c(0x1d5)](_0x4ec81d,'');return _0x1b4141+_0x48c84c(0x201)+_0x4ec81d+_0x48c84c(0x2bf)+_0x1c2b48[_0x48c84c(0x1d5)](/^\.*/,'')[_0x48c84c(0x1d5)](/^\//,'')[_0x48c84c(0x1d5)](/\/$/,'');}function parseWaterParameters(_0x6c1b92,_0x3b3f0c){const _0x3c3948=_0xfb644;let _0x5f451b=_0x3b3f0c[_0x3c3948(0x2be)];if(!_0x5f451b||!_0x5f451b['attachFiles'])return;let _0x3682b0=_0x5f451b[_0x3c3948(0x29d)],_0x1e6b0d=[],_0x20f2f5=_0x6c1b92[_0x3c3948(0x2a4)],_0x23971f=![];for(let _0x15f0c2=0x0,_0x4211ee=_0x3682b0[_0x3c3948(0x2b6)];_0x15f0c2<_0x4211ee;_0x15f0c2++){let _0x5a2126=_0x3682b0[_0x15f0c2][_0x3c3948(0x2a3)];if(_0x5a2126[_0x3c3948(0x269)](_0x3c3948(0x1be))>0x0){let _0x4388c3=getUrl$1(_0x5a2126,_0x6c1b92),_0x321c70=_0x6c1b92['_baseResource'][_0x3c3948(0x1bf)]({'url':_0x4388c3});_0x1e6b0d[_0x3c3948(0x21f)](_0x321c70['fetchXML']()),_0x23971f=!![];}}if(!_0x1e6b0d[_0x3c3948(0x2b6)])return;Cesium[_0x3c3948(0x287)][_0x3c3948(0x2bc)](_0x1e6b0d,_0x70f59a=>{const _0x28c504=_0x3c3948;let _0x585c1d=[];for(let _0x505454=0x0,_0x2f6666=_0x70f59a[_0x28c504(0x2b6)];_0x505454<_0x2f6666;_0x505454++){let _0x148ad2=_0x70f59a[_0x505454];if(!_0x148ad2)break;let _0x3d86c1=getWaterEffect(_0x148ad2);_0x585c1d['push'](_0x3d86c1);}_0x6c1b92['_waterPlanes']=new Cesium['AssociativeArray'](),_0x6c1b92[_0x28c504(0x26b)]={};let _0x1ce8a5=_0x585c1d[0x0];_0x6c1b92[_0x28c504(0x26b)][_0x28c504(0x2ff)]=_0x1ce8a5[_0x28c504(0x2ff)];for(let _0x44b63c=0x0;_0x44b63c<_0x1ce8a5['gpuProgramParameters']['length'];_0x44b63c++){let _0x314d3c=_0x1ce8a5[_0x28c504(0x1dc)][_0x44b63c];for(let _0x1c2f4c=0x0;_0x1c2f4c<_0x314d3c[_0x28c504(0x1b3)][_0x28c504(0x2b6)];_0x1c2f4c++){let _0x3290e0=_0x314d3c[_0x28c504(0x1b3)][_0x1c2f4c];if(_0x3290e0[_0x28c504(0x22a)]==='timeVal'){_0x6c1b92['_waterParameters'][_0x3290e0[_0x28c504(0x22a)]]=_0x3290e0[_0x28c504(0x2ef)];break;}}for(let _0x1a4c9a=0x0;_0x1a4c9a<_0x314d3c['gpuConstants'][_0x28c504(0x2b6)];_0x1a4c9a++){let _0x7af471=_0x314d3c[_0x28c504(0x20d)][_0x1a4c9a],_0x4c0332=null;switch(_0x7af471[_0x28c504(0x2cd)]){case 0x1:_0x4c0332=_0x7af471[_0x28c504(0x222)][0x0];break;case 0x2:_0x4c0332=new Cesium[(_0x28c504(0x2d7))](),Cesium[_0x28c504(0x2d7)][_0x28c504(0x286)](_0x7af471[_0x28c504(0x222)],0x0,_0x4c0332);break;case 0x3:_0x4c0332=new Cesium[(_0x28c504(0x274))](),Cesium[_0x28c504(0x274)][_0x28c504(0x286)](_0x7af471[_0x28c504(0x222)],0x0,_0x4c0332);break;case 0x4:_0x4c0332=new Cesium[(_0x28c504(0x1a8))](),Cesium[_0x28c504(0x1a8)]['unpack'](_0x7af471['arrayFloat'],0x0,_0x4c0332);break;}if(!_0x4c0332)continue;_0x6c1b92['_waterParameters'][_0x7af471[_0x28c504(0x22a)]]=_0x4c0332;}}_0x6c1b92[_0x28c504(0x1e2)]+=_0x28c504(0x279);});}S3MTilesLayer[_0xfb644(0x1ee)][_0xfb644(0x27e)]=function(_0x98e0b2){const _0xbb6f7b=_0xfb644;let _0x5e9074=this;Cesium['when'](_0x98e0b2)['then'](function(_0x2cd5bb){const _0x2aa0d9=_0x211d;let _0x1f142f,_0x1b03ed=Cesium[_0x2aa0d9(0x2ed)][_0x2aa0d9(0x297)](_0x2cd5bb);_0x1f142f=_0x1b03ed[_0x2aa0d9(0x1e6)](!![]),_0x5e9074[_0x2aa0d9(0x2a5)]=_0x1b03ed[_0x2aa0d9(0x2f8)],_0x5e9074['_basePath']=_0x1f142f,_0x5e9074['_baseResource']=_0x1b03ed;if(_0x5e9074['_isS3MB']||_0x5e9074[_0x2aa0d9(0x246)])return _0x1b03ed[_0x2aa0d9(0x1b7)]();return _0x1b03ed[_0x2aa0d9(0x254)]();})['then'](function(_0x494589){const _0x24f9ee=_0x211d;if(_0x5e9074['_isS3MB']||_0x5e9074[_0x24f9ee(0x246)]){let _0x861142=_0x494589[_0x24f9ee(0x2be)];_0x5e9074[_0x24f9ee(0x1e2)]=_0x861142[_0x24f9ee(0x2cc)];let _0x347686=_0x494589[_0x24f9ee(0x29f)]['x'],_0x26ed62=_0x494589[_0x24f9ee(0x29f)]['y'],_0x454b79=_0x494589[_0x24f9ee(0x29f)]['z'],_0x5728a9=_0x494589[_0x24f9ee(0x29f)][_0x24f9ee(0x1c1)];if(_0x5e9074['_sceneMode']===Cesium[_0x24f9ee(0x1f1)][_0x24f9ee(0x2d2)])_0x5e9074[_0x24f9ee(0x206)]=Cesium['Cartesian3'][_0x24f9ee(0x1eb)](_0x347686,_0x26ed62,_0x454b79),_0x5e9074['modelMatrix']=Cesium[_0x24f9ee(0x242)]['eastNorthUpToFixedFrame'](_0x5e9074[_0x24f9ee(0x206)]),_0x5e9074['invModelMatrix']=Cesium['Matrix4'][_0x24f9ee(0x280)](_0x5e9074[_0x24f9ee(0x270)],_0x5e9074['invModelMatrix']);else {if(_0x347686>0xb4||_0x347686<-0xb4||_0x26ed62>0xb4||_0x26ed62<-0xb4||_0x5728a9===_0x24f9ee(0x2b1)){let _0x475a45=_0x347686,_0x4065ad=_0x26ed62;_0x5e9074[_0x24f9ee(0x206)]=new Cesium['Cartesian3'](_0x475a45,_0x4065ad,_0x454b79);}else {let _0x4fad56=new Cesium[(_0x24f9ee(0x24e))](),_0x2136d1=Cesium['Cartesian3'][_0x24f9ee(0x1eb)](_0x347686,_0x26ed62,_0x454b79),_0x350c01=_0x4fad56[_0x24f9ee(0x1d2)][_0x24f9ee(0x2b9)](_0x2136d1);_0x5e9074[_0x24f9ee(0x206)]=_0x4fad56[_0x24f9ee(0x1bd)](_0x350c01);}Cesium[_0x24f9ee(0x1da)]['fromTranslation'](_0x5e9074[_0x24f9ee(0x206)],_0x5e9074['modelMatrix']),Cesium['Matrix4'][_0x24f9ee(0x276)](transform_2d,_0x5e9074[_0x24f9ee(0x270)],_0x5e9074['modelMatrix']),_0x5e9074[_0x24f9ee(0x25d)]=Cesium[_0x24f9ee(0x1da)][_0x24f9ee(0x280)](_0x5e9074[_0x24f9ee(0x270)],_0x5e9074[_0x24f9ee(0x25d)]);}if(Cesium[_0x24f9ee(0x224)](_0x494589[_0x24f9ee(0x2ce)])){let _0x1b14b8=_0x494589['geoBounds'][_0x24f9ee(0x1e3)],_0x1d5ac7=_0x494589[_0x24f9ee(0x2ce)][_0x24f9ee(0x26f)],_0x29d866=_0x494589[_0x24f9ee(0x2ce)]['right'],_0x24a4f7=_0x494589[_0x24f9ee(0x2ce)][_0x24f9ee(0x24c)];_0x1b14b8>0xb4||_0x24a4f7>0xb4||_0x29d866>0xb4||_0x1d5ac7>0xb4?(_0x1b14b8/=0x615299,_0x24a4f7/=0x615299,_0x29d866/=0x615299,_0x1d5ac7/=0x615299,_0x5e9074[_0x24f9ee(0x1cb)]=new Cesium[(_0x24f9ee(0x253))](_0x1b14b8,_0x24a4f7,_0x29d866,_0x1d5ac7)):_0x5e9074[_0x24f9ee(0x1cb)]=Cesium['Rectangle'][_0x24f9ee(0x1eb)](_0x1b14b8,_0x24a4f7,_0x29d866,_0x1d5ac7);}_0x494589[_0x24f9ee(0x294)]&&(_0x5e9074['_minHeight']=_0x494589[_0x24f9ee(0x294)][_0x24f9ee(0x1dd)],_0x5e9074['_maxHeight']=_0x494589[_0x24f9ee(0x294)][_0x24f9ee(0x237)]);if(_0x494589[_0x24f9ee(0x249)]){let _0x5c2dd3=_0x494589[_0x24f9ee(0x249)][_0x24f9ee(0x2cb)];_0x5e9074[_0x24f9ee(0x220)]=_0x5c2dd3[_0x24f9ee(0x1dd)],_0x5e9074['_maxWValue']=_0x5c2dd3[_0x24f9ee(0x237)];}if(_0x494589[_0x24f9ee(0x1e1)]['length']>0x0){let _0x4b010d=Cesium[_0x24f9ee(0x1e0)](_0x494589['tiles'][0x0][_0x24f9ee(0x2f8)]);_0x4b010d==='s3mblock'&&(_0x5e9074[_0x24f9ee(0x246)]=!![]);}for(let _0x21a3e0=0x0,_0x11dc97=_0x494589['tiles'][_0x24f9ee(0x2b6)];_0x21a3e0<_0x11dc97;_0x21a3e0++){let _0x2db34d=_0x494589['tiles'][_0x21a3e0][_0x24f9ee(0x2f8)],_0x5aec4e={'box':_0x494589[_0x24f9ee(0x1e1)][_0x21a3e0][_0x24f9ee(0x233)]},_0x11218e=new S3MTile(_0x5e9074,undefined,_0x5aec4e,_0x2db34d);_0x11218e[_0x24f9ee(0x1c9)]=!![],_0x11218e[_0x24f9ee(0x2a1)]=_0x2db34d,_0x5e9074[_0x24f9ee(0x22d)][_0x24f9ee(0x304)](_0x11218e),_0x5e9074[_0x24f9ee(0x207)][_0x24f9ee(0x21f)](_0x11218e);}parseWaterParameters(_0x5e9074,_0x494589);}else {let _0x3b158d=_0x494589[_0x24f9ee(0x2c9)],_0x22e6a6=_0x3b158d[_0x24f9ee(0x29b)];_0x5e9074[_0x24f9ee(0x1e2)]=XMLParser[_0x24f9ee(0x1b0)](_0x3b158d,_0x24f9ee(0x26c),_0x22e6a6);let _0x164d72=XMLParser[_0x24f9ee(0x24f)](_0x3b158d,_0x24f9ee(0x221),_0x22e6a6),_0x48f68b=XMLParser[_0x24f9ee(0x1e8)](_0x164d72,'X',_0x22e6a6),_0x162dc1=XMLParser[_0x24f9ee(0x1e8)](_0x164d72,'Y',_0x22e6a6),_0x567908=XMLParser['queryNumericValue'](_0x164d72,'Z',_0x22e6a6);_0x5e9074[_0x24f9ee(0x206)]=Cesium[_0x24f9ee(0x274)]['fromDegrees'](_0x48f68b,_0x162dc1,_0x567908),_0x5e9074['modelMatrix']=Cesium[_0x24f9ee(0x242)]['eastNorthUpToFixedFrame'](_0x5e9074[_0x24f9ee(0x206)]),_0x5e9074[_0x24f9ee(0x25d)]=Cesium['Matrix4'][_0x24f9ee(0x280)](_0x5e9074['modelMatrix'],_0x5e9074[_0x24f9ee(0x25d)]);let _0x4f5c84=XMLParser['queryFirstNode'](_0x3b158d,_0x24f9ee(0x241),_0x22e6a6),_0x2454e4=XMLParser[_0x24f9ee(0x24f)](_0x3b158d,_0x24f9ee(0x2ad),_0x22e6a6);if(_0x4f5c84){let _0x492406=XMLParser[_0x24f9ee(0x1e8)](_0x4f5c84,_0x24f9ee(0x1c2),_0x22e6a6),_0xaef582=XMLParser[_0x24f9ee(0x1e8)](_0x4f5c84,_0x24f9ee(0x1c6),_0x22e6a6),_0x5c290f=XMLParser[_0x24f9ee(0x1e8)](_0x4f5c84,_0x24f9ee(0x1f6),_0x22e6a6),_0x4cad2b=XMLParser[_0x24f9ee(0x1e8)](_0x4f5c84,_0x24f9ee(0x2fd),_0x22e6a6);_0x5e9074[_0x24f9ee(0x1cb)]=Cesium['Rectangle'][_0x24f9ee(0x1eb)](_0x492406,_0x4cad2b,_0x5c290f,_0xaef582);}else {if(_0x2454e4){let _0x2513cd=XMLParser[_0x24f9ee(0x1e8)](_0x2454e4,_0x24f9ee(0x2f5),_0x22e6a6),_0x2177be=XMLParser[_0x24f9ee(0x1e8)](_0x2454e4,_0x24f9ee(0x2f2),_0x22e6a6),_0x5519ce=XMLParser[_0x24f9ee(0x1e8)](_0x2454e4,_0x24f9ee(0x284),_0x22e6a6),_0x218dd0=XMLParser['queryNumericValue'](_0x2454e4,_0x24f9ee(0x247),_0x22e6a6),_0x3c741c=XMLParser[_0x24f9ee(0x1e8)](_0x2454e4,'MaxY',_0x22e6a6),_0x4a0350=XMLParser[_0x24f9ee(0x1e8)](_0x2454e4,_0x24f9ee(0x2e7),_0x22e6a6);_0x2513cd=0xb4*Math[_0x24f9ee(0x2a9)](_0x2513cd)/(Math['PI']*0x615299),_0x2177be=0xb4*Math[_0x24f9ee(0x2a9)](_0x2177be)/(Math['PI']*0x615299),_0x218dd0=0xb4*Math[_0x24f9ee(0x2a9)](_0x218dd0)/(Math['PI']*0x615299),_0x3c741c=0xb4*Math[_0x24f9ee(0x2a9)](_0x3c741c)/(Math['PI']*0x615299),_0x5e9074['_rectangle']=Cesium['Rectangle'][_0x24f9ee(0x1eb)](_0x48f68b-_0x2513cd,_0x162dc1-_0x2177be,_0x48f68b+_0x218dd0,_0x162dc1+_0x3c741c);}}let _0x37c3b8=XMLParser['queryFirstNode'](_0x3b158d,'HeightRange',_0x22e6a6);_0x37c3b8&&(_0x5e9074[_0x24f9ee(0x2db)]=XMLParser[_0x24f9ee(0x1e8)](_0x37c3b8,_0x24f9ee(0x20b),_0x22e6a6),_0x5e9074[_0x24f9ee(0x1f8)]=XMLParser[_0x24f9ee(0x1e8)](_0x37c3b8,_0x24f9ee(0x2ea),_0x22e6a6));let _0x52d23f=XMLParser[_0x24f9ee(0x24f)](_0x3b158d,_0x24f9ee(0x1e4),_0x22e6a6);_0x52d23f&&(_0x5e9074['_maxWValue']=XMLParser[_0x24f9ee(0x1e8)](_0x52d23f,_0x24f9ee(0x2e5),_0x22e6a6),_0x5e9074[_0x24f9ee(0x220)]=XMLParser['queryNumericValue'](_0x52d23f,'MinCategory',_0x22e6a6));let _0x544372=/\\+/g,_0x8df93=XMLParser[_0x24f9ee(0x24f)](_0x3b158d,_0x24f9ee(0x1fe),_0x22e6a6),_0x1ea953=XMLParser[_0x24f9ee(0x2fc)](_0x8df93,'Files',_0x22e6a6);if(_0x1ea953[_0x24f9ee(0x2b6)]>0x0)for(let _0x419a90=0x0,_0x4ae476=_0x1ea953['length'];_0x419a90<_0x4ae476;_0x419a90++){let _0x5e417f=_0x1ea953[_0x419a90],_0x29fcac=XMLParser['queryStringValue'](_0x5e417f,_0x24f9ee(0x2d1),_0x22e6a6);_0x29fcac=_0x29fcac[_0x24f9ee(0x1d5)](_0x544372,'/'),_0x29fcac=_0x29fcac[_0x24f9ee(0x1d5)](/(\.osgb)/gi,_0x24f9ee(0x1f5));let _0xd4c3a0=XMLParser['queryFirstNode'](_0x5e417f,_0x24f9ee(0x202),_0x22e6a6),_0x251e06={'sphere':{'center':{'x':0x0,'y':0x0,'z':0x0},'radius':0x615299}};if(_0xd4c3a0&&_0xd4c3a0[_0x24f9ee(0x272)][_0x24f9ee(0x2b6)]){let _0x10c40f=XMLParser[_0x24f9ee(0x1e8)](_0xd4c3a0,_0x24f9ee(0x291),_0x22e6a6),_0x2e3eb2=XMLParser['queryNumericValue'](_0xd4c3a0,_0x24f9ee(0x2c2),_0x22e6a6),_0x587a68=XMLParser[_0x24f9ee(0x1e8)](_0xd4c3a0,_0x24f9ee(0x2de),_0x22e6a6),_0x255c83=XMLParser['queryNumericValue'](_0xd4c3a0,'Radius',_0x22e6a6);_0x251e06={'sphere':{'center':{'x':_0x10c40f,'y':_0x2e3eb2,'z':_0x587a68},'radius':_0x255c83}};}let _0x293d4b=new S3MTile(_0x5e9074,undefined,_0x251e06,_0x29fcac);_0x293d4b[_0x24f9ee(0x1c9)]=!![],_0x5e9074[_0x24f9ee(0x22d)][_0x24f9ee(0x304)](_0x293d4b),_0x5e9074['_rootTiles']['push'](_0x293d4b);}else {let _0x3a04e4=XMLParser[_0x24f9ee(0x2fc)](_0x8df93,_0x24f9ee(0x2d1),_0x22e6a6);for(let _0x5351a3=0x0,_0x4b54fe=_0x3a04e4['length'];_0x5351a3<_0x4b54fe;_0x5351a3++){let _0x712902=_0x3a04e4[_0x5351a3][_0x24f9ee(0x1d8)];_0x712902=_0x712902[_0x24f9ee(0x1d5)](_0x544372,'/'),_0x712902=_0x712902[_0x24f9ee(0x1d5)](/(\.osgb)/gi,_0x24f9ee(0x1f5));let _0x544540={'sphere':{'center':{'x':0x0,'y':0x0,'z':0x0},'radius':0x615299}},_0x530e11=new S3MTile(_0x5e9074,undefined,_0x544540,_0x712902);_0x530e11['isRootTile']=!![],_0x5e9074['_cache'][_0x24f9ee(0x304)](_0x530e11),_0x5e9074[_0x24f9ee(0x207)][_0x24f9ee(0x21f)](_0x530e11);}}}_0x5e9074['_readyPromise']['resolve'](_0x5e9074);})[_0xbb6f7b(0x240)](function(_0x439a21){const _0x3a318e=_0xbb6f7b;_0x5e9074['_readyPromise'][_0x3a318e(0x1af)](_0x439a21);});};function sortRequestByPriority(_0x4195ac,_0x566dd2){const _0x403b06=_0xfb644;return _0x4195ac[_0x403b06(0x211)]-_0x566dd2[_0x403b06(0x211)];}function requestTiles(_0x4ded7f){const _0x293cb3=_0xfb644;let _0x162530=_0x4ded7f[_0x293cb3(0x215)],_0x14e4e9=_0x162530[_0x293cb3(0x2b6)];_0x162530[_0x293cb3(0x2b3)](sortRequestByPriority);for(let _0x51c6a5=0x0;_0x51c6a5<_0x14e4e9;++_0x51c6a5){let _0x1d362c=_0x162530[_0x51c6a5];_0x1d362c[_0x293cb3(0x2fe)]();}}function processTiles(_0x38460e,_0x52d969){const _0x17fb41=_0xfb644;let _0x51e7f8=_0x38460e[_0x17fb41(0x1b4)],_0x3d4032=_0x51e7f8[_0x17fb41(0x2b6)];for(let _0x564c27=0x0;_0x564c27<_0x3d4032;++_0x564c27){let _0x33ef1f=_0x51e7f8[_0x564c27];_0x33ef1f['update'](_0x52d969,_0x38460e);}}function updateTiles(_0x498720,_0x4e8783){const _0x143492=_0xfb644;let _0x39a9df=_0x498720[_0x143492(0x2ee)],_0x100353=_0x39a9df['length'];for(let _0x59bebf=0x0;_0x59bebf<_0x100353;_0x59bebf++){_0x39a9df[_0x59bebf][_0x143492(0x28e)](_0x4e8783,_0x498720);}}function unloadTile(_0xe8a800,_0x149828){_0x149828['free']();}function freeResource(_0x39d0a7){const _0x435934=_0xfb644;_0x39d0a7[_0x435934(0x246)]?_0x39d0a7[_0x435934(0x22d)][_0x435934(0x2fb)](_0x39d0a7,unloadTile):_0x39d0a7[_0x435934(0x22d)][_0x435934(0x298)](_0x39d0a7,unloadTile);}S3MTilesLayer[_0xfb644(0x1ee)]['releaseSelection']=function(){const _0x24a699=_0xfb644;if(this[_0x24a699(0x1d7)]['length']<0x1)return;this[_0x24a699(0x2ae)](this['_selections'],_0x594bc2['SELECTED']),this[_0x24a699(0x1d7)][_0x24a699(0x2b6)]=0x0;},S3MTilesLayer['prototype'][_0xfb644(0x1e5)]=function(_0x1759eb){const _0x5d8e83=_0xfb644;this[_0x5d8e83(0x2c4)]=_0x1759eb;},S3MTilesLayer[_0xfb644(0x1ee)]['setSelection']=function(_0x2fb1d5){const _0x1a7594=_0xfb644;Cesium[_0x1a7594(0x252)]['defined'](_0x1a7594(0x266),_0x2fb1d5);if(!this[_0x1a7594(0x1ce)])return;!Array[_0x1a7594(0x1de)](_0x2fb1d5)&&(_0x2fb1d5=[_0x2fb1d5]),!this[_0x1a7594(0x24b)]&&this['releaseSelection'](),this['_selections']=this[_0x1a7594(0x1d7)]['concat'](_0x2fb1d5),this[_0x1a7594(0x30a)](_0x2fb1d5,_0x594bc2[_0x1a7594(0x289)]);},S3MTilesLayer[_0xfb644(0x1ee)]['getSelection']=function(){const _0x40a80e=_0xfb644;return []['concat'](this[_0x40a80e(0x1d7)]);},S3MTilesLayer['prototype'][_0xfb644(0x230)]=function(_0x2e6fe8,_0x240993){const _0x3eef69=_0xfb644;Cesium[_0x3eef69(0x252)]['defined'](_0x3eef69(0x1fa),_0x2e6fe8),Cesium[_0x3eef69(0x252)]['defined']('setObjsColor\x20color',_0x240993),Cesium[_0x3eef69(0x252)][_0x3eef69(0x265)]['object'](_0x3eef69(0x305),_0x240993);!Array[_0x3eef69(0x1de)](_0x2e6fe8)&&(_0x2e6fe8=[_0x2e6fe8]);let _0x108067={};for(let _0xace630=0x0,_0x8ae413=_0x2e6fe8[_0x3eef69(0x2b6)];_0xace630<_0x8ae413;_0xace630++){let _0x468348=_0x2e6fe8[_0xace630]+'';if(!Cesium[_0x3eef69(0x224)](_0x468348))continue;this[_0x3eef69(0x267)][_0x468348]=_0x240993,_0x108067[_0x468348]=_0x240993;}this[_0x3eef69(0x2b4)](_0x108067);},S3MTilesLayer['prototype']['removeObjsColor']=function(_0x22f9ce){const _0x4dd222=_0xfb644;Cesium[_0x4dd222(0x252)][_0x4dd222(0x224)]('removeObjsColor\x20ids',_0x22f9ce);!Array[_0x4dd222(0x1de)](_0x22f9ce)&&(_0x22f9ce=[_0x22f9ce]);let _0x304b49={};for(let _0x39fca8=0x0,_0x434489=_0x22f9ce[_0x4dd222(0x2b6)];_0x39fca8<_0x434489;_0x39fca8++){let _0x3a066f=_0x22f9ce[_0x39fca8];Cesium['defined'](this[_0x4dd222(0x267)][_0x3a066f])&&(_0x304b49[_0x3a066f]=Cesium[_0x4dd222(0x1f7)][_0x4dd222(0x28f)],delete this[_0x4dd222(0x267)][_0x3a066f]);}this[_0x4dd222(0x2ae)](_0x22f9ce,_0x594bc2['SetColor']),this[_0x4dd222(0x2b4)](_0x304b49);},S3MTilesLayer[_0xfb644(0x1ee)][_0xfb644(0x275)]=function(_0x58d6bb,_0x3d9add){const _0x32ba89=_0xfb644;Cesium[_0x32ba89(0x252)][_0x32ba89(0x224)](_0x32ba89(0x21b),_0x58d6bb),Cesium['Check']['typeOf'][_0x32ba89(0x261)](_0x32ba89(0x212),_0x3d9add);!Array[_0x32ba89(0x1de)](_0x58d6bb)&&(_0x58d6bb=[_0x58d6bb]);if(_0x58d6bb[_0x32ba89(0x2b6)]===0x0){this['_allObjsHide']=_0x3d9add,this[_0x32ba89(0x2df)][_0x32ba89(0x2e9)]();let _0x264223=Object['keys'](this['_objsHideList'][_0x32ba89(0x210)]);this[_0x32ba89(0x2ae)](_0x264223,_0x594bc2[_0x32ba89(0x1c8)]),this['_objsHideList'][_0x32ba89(0x2e9)](),this[_0x32ba89(0x1bb)](!_0x3d9add);return;}let _0x4324be=this['_objsVisibleList'],_0x1f99f6=this[_0x32ba89(0x299)],_0x4bd219=this[_0x32ba89(0x21e)];!_0x3d9add?(_0x58d6bb[_0x32ba89(0x248)](function(_0x4d4cd3){const _0x3e6cb2=_0x32ba89;_0x4324be[_0x3e6cb2(0x1ae)](_0x4d4cd3),_0x1f99f6[_0x3e6cb2(0x2e6)](_0x4d4cd3,!![]);}),this['_setObjsOperationType'](_0x58d6bb,_0x594bc2[_0x32ba89(0x1c8)])):(_0x58d6bb['map'](function(_0x3c65ad){const _0x5c30f2=_0x32ba89;_0x4324be['set'](_0x3c65ad,!![]),_0x1f99f6[_0x5c30f2(0x1ae)](_0x3c65ad);}),this['_removeObjsOperationType'](_0x58d6bb,_0x594bc2[_0x32ba89(0x1c8)]));},S3MTilesLayer[_0xfb644(0x1ee)]['setObjsVisible']=function(_0x3ce4ea,_0x5b5153){const _0x200683=_0xfb644;if(_0x3ce4ea[_0x200683(0x2b6)]===0x0){this['setOnlyObjsVisible']([],_0x5b5153);return;}this[_0x200683(0x275)]([],_0x5b5153),this[_0x200683(0x275)](_0x3ce4ea,_0x5b5153);};function createPlane(_0x1cb43f,_0x50e3a7,_0x59da96){const _0x572dfe=_0xfb644;let _0x9c5b05=new Cesium[(_0x572dfe(0x274))](),_0x1c3f81=new Cesium[(_0x572dfe(0x274))]();Cesium['Cartesian3'][_0x572dfe(0x234)](_0x50e3a7,_0x1cb43f,_0x9c5b05),Cesium[_0x572dfe(0x274)]['subtract'](_0x59da96,_0x1cb43f,_0x1c3f81);let _0x34474b=new Cesium[(_0x572dfe(0x274))]();Cesium[_0x572dfe(0x274)]['cross'](_0x9c5b05,_0x1c3f81,_0x34474b),Cesium[_0x572dfe(0x274)][_0x572dfe(0x29e)](_0x34474b,_0x34474b);let _0x36de21=-Cesium[_0x572dfe(0x274)][_0x572dfe(0x1f9)](_0x34474b,_0x1cb43f);return new Cesium[(_0x572dfe(0x1a8))](_0x34474b['x'],_0x34474b['y'],_0x34474b['z'],_0x36de21);}function clipCallback(_0x5c19ef,_0x173e29){_0x5c19ef['clip'](_0x173e29);}S3MTilesLayer['prototype'][_0xfb644(0x1cd)]=function(_0x43dda4,_0x17a54a,_0xf2d8fb,_0x2d0355){const _0x5f40db=_0xfb644;this['_oriClipPlane'][0x0]=createPlane(_0x43dda4,_0x17a54a,_0xf2d8fb),this[_0x5f40db(0x226)]=Cesium[_0x5f40db(0x1ad)](_0x2d0355,_0x251bf8[_0x5f40db(0x264)]),this[_0x5f40db(0x27d)]=!![],!this[_0x5f40db(0x27a)]&&this[_0x5f40db(0x1d4)]({'enable':!![]},clipCallback),this['_enableClip']=!![];},S3MTilesLayer['prototype'][_0xfb644(0x238)]=function(_0x4bf5de){const _0x581937=_0xfb644;_0x4bf5de=_0x4bf5de||{};if((!_0x4bf5de[_0x581937(0x1f2)]||!_0x4bf5de[_0x581937(0x29f)])&&(!_0x4bf5de[_0x581937(0x219)]||!_0x4bf5de[_0x581937(0x2dd)]))throw new Cesium[(_0x581937(0x21d))](_0x581937(0x2e2));this[_0x581937(0x226)]=_0x251bf8[_0x581937(0x264)];if(Cesium[_0x581937(0x224)](_0x4bf5de[_0x581937(0x23b)]))switch(_0x4bf5de[_0x581937(0x23b)]){case'clip_behind_any_plane':this[_0x581937(0x226)]=_0x251bf8['CLIP_BEHIND_ANY_PLANE'];break;case _0x581937(0x257):this['_clipMode']=_0x251bf8['CLIP_BEHIND_ALL_PLANE'];break;case'only_keep_line':this[_0x581937(0x226)]=_0x251bf8[_0x581937(0x290)];break;}if(_0x4bf5de[_0x581937(0x1f2)]){let _0x37c81b=new Cesium[(_0x581937(0x1da))](),_0x374305=_0x4bf5de[_0x581937(0x29f)],_0x45d251,_0x4cef59,_0x451b50;_0x45d251=_0x4bf5de[_0x581937(0x2eb)]||0x0,_0x4cef59=_0x4bf5de['pitch']||0x0,_0x451b50=_0x4bf5de[_0x581937(0x213)]||0x0;let _0x1fe6e2=new Cesium['HeadingPitchRoll'](_0x45d251,_0x4cef59,_0x451b50);_0x37c81b=Cesium['Transforms'][_0x581937(0x307)](_0x374305,_0x1fe6e2,Cesium[_0x581937(0x208)][_0x581937(0x1ac)]);let _0x3ee2a1=_0x4bf5de['dimensions']['x']*0.5,_0x2c7c8c=_0x4bf5de[_0x581937(0x1f2)]['y']*0.5,_0x160398=_0x4bf5de[_0x581937(0x1f2)]['z']*0.5,_0x26b73f=[];_0x26b73f[0x0]=new Cesium[(_0x581937(0x1a8))](-_0x3ee2a1,_0x2c7c8c,_0x160398,0x1),_0x26b73f[0x1]=new Cesium[(_0x581937(0x1a8))](_0x3ee2a1,_0x2c7c8c,_0x160398,0x1),_0x26b73f[0x2]=new Cesium[(_0x581937(0x1a8))](_0x3ee2a1,-_0x2c7c8c,_0x160398,0x1),_0x26b73f[0x3]=new Cesium['Cartesian4'](-_0x3ee2a1,-_0x2c7c8c,_0x160398,0x1),_0x26b73f[0x4]=new Cesium[(_0x581937(0x1a8))](-_0x3ee2a1,_0x2c7c8c,-_0x160398,0x1),_0x26b73f[0x5]=new Cesium[(_0x581937(0x1a8))](_0x3ee2a1,_0x2c7c8c,-_0x160398,0x1),_0x26b73f[0x6]=new Cesium['Cartesian4'](_0x3ee2a1,-_0x2c7c8c,-_0x160398,0x1),_0x26b73f[0x7]=new Cesium[(_0x581937(0x1a8))](-_0x3ee2a1,-_0x2c7c8c,-_0x160398,0x1);for(let _0x1127e7=0x0;_0x1127e7<0x8;_0x1127e7++){Cesium[_0x581937(0x1da)][_0x581937(0x214)](_0x37c81b,_0x26b73f[_0x1127e7],_0x26b73f[_0x1127e7]);}this[_0x581937(0x263)][0x0]=Cesium['Cartesian4'][_0x581937(0x217)](createPlane(_0x26b73f[0x0],_0x26b73f[0x1],_0x26b73f[0x2])),this[_0x581937(0x263)][0x1]=Cesium['Cartesian4']['clone'](createPlane(_0x26b73f[0x0],_0x26b73f[0x4],_0x26b73f[0x1])),this[_0x581937(0x263)][0x2]=Cesium[_0x581937(0x1a8)][_0x581937(0x217)](createPlane(_0x26b73f[0x0],_0x26b73f[0x3],_0x26b73f[0x4])),this[_0x581937(0x263)][0x3]=Cesium[_0x581937(0x1a8)][_0x581937(0x217)](createPlane(_0x26b73f[0x6],_0x26b73f[0x2],_0x26b73f[0x5])),this[_0x581937(0x263)][0x4]=Cesium[_0x581937(0x1a8)]['clone'](createPlane(_0x26b73f[0x6],_0x26b73f[0x7],_0x26b73f[0x2])),this['_oriClipPlane'][0x5]=Cesium[_0x581937(0x1a8)][_0x581937(0x217)](createPlane(_0x26b73f[0x6],_0x26b73f[0x5],_0x26b73f[0x7]));}else for(let _0x4c1374=0x0;_0x4c1374<_0x4bf5de['planePos'][_0x581937(0x2b6)];_0x4c1374++){let _0x2ef496=_0x4bf5de[_0x581937(0x219)][_0x4c1374],_0x2026e6=_0x4bf5de[_0x581937(0x2dd)][_0x4c1374];this[_0x581937(0x263)][_0x4c1374]['x']=_0x2026e6['x'],this[_0x581937(0x263)][_0x4c1374]['y']=_0x2026e6['y'],this[_0x581937(0x263)][_0x4c1374]['z']=_0x2026e6['z'],this['_oriClipPlane'][_0x4c1374]['w']=-Cesium['Cartesian3'][_0x581937(0x1f9)](_0x2ef496,_0x2026e6);}!this[_0x581937(0x27a)]&&this['_tranverseRenderEntity']({'enable':!![]},clipCallback),this[_0x581937(0x27a)]=!![];},S3MTilesLayer['prototype'][_0xfb644(0x29c)]=function(){const _0x56b864=_0xfb644;this[_0x56b864(0x27a)]=![],this[_0x56b864(0x27d)]=![],this['_tranverseRenderEntity']({'enable':![]},clipCallback);},S3MTilesLayer[_0xfb644(0x1ee)]['_tranverseRenderEntity']=function(_0x405745,_0x5cfae0){const _0x1957a6=_0xfb644;let _0x54c25e=[];for(let _0x271284=0x0,_0x16dbc6=this['_rootTiles'][_0x1957a6(0x2b6)];_0x271284<_0x16dbc6;_0x271284++){let _0x3eba36=this[_0x1957a6(0x207)][_0x271284];_0x54c25e[_0x1957a6(0x21f)](_0x3eba36);}while(_0x54c25e[_0x1957a6(0x2b6)]){let _0x5aa0cd=_0x54c25e[_0x1957a6(0x259)]();for(let _0x138bc4=0x0,_0x471b70=_0x5aa0cd[_0x1957a6(0x245)][_0x1957a6(0x2b6)];_0x138bc4<_0x471b70;_0x138bc4++){const _0x5e1def=_0x5aa0cd[_0x1957a6(0x245)][_0x138bc4];_0x5e1def[_0x1957a6(0x309)]&&_0x5cfae0(_0x5e1def,_0x405745);}for(let _0x54a978=0x0,_0x5bbc8f=_0x5aa0cd[_0x1957a6(0x302)]['length'];_0x54a978<_0x5bbc8f;_0x54a978++){_0x54c25e[_0x1957a6(0x21f)](_0x5aa0cd[_0x1957a6(0x302)][_0x54a978]);}}};function updateObjsOperationCallback(_0x5eab4b,_0x1250e0){const _0x3f2f39=_0xfb644;_0x5eab4b[_0x3f2f39(0x2b8)](_0x1250e0[_0x3f2f39(0x2ac)],_0x1250e0);}S3MTilesLayer[_0xfb644(0x1ee)][_0xfb644(0x288)]=function(_0x4d4aa1){this['_tranverseRenderEntity']({'ids':_0x4d4aa1},updateObjsOperationCallback);};function updateObjsColorCallback(_0x1b92a1,_0x580d1c){const _0x327852=_0xfb644;_0x1b92a1['updateObjsColor'](_0x580d1c[_0x327852(0x2ac)],_0x580d1c);}S3MTilesLayer[_0xfb644(0x1ee)][_0xfb644(0x2b4)]=function(_0xb2b754){const _0x309a8e=_0xfb644;this[_0x309a8e(0x1d4)]({'ids':_0xb2b754},updateObjsColorCallback);};function updateAllObjsVisibleCallback(_0x14e80d,_0x3193b9){const _0x43048f=_0xfb644;_0x14e80d[_0x43048f(0x22f)](_0x3193b9[_0x43048f(0x23d)]);}S3MTilesLayer[_0xfb644(0x1ee)][_0xfb644(0x1bb)]=function(_0x502df9){const _0x2cc76c=_0xfb644;this[_0x2cc76c(0x1d4)]({'isVisible':_0x502df9},updateAllObjsVisibleCallback);},S3MTilesLayer[_0xfb644(0x1ee)]['_setObjsOperationType']=function(_0x194cf3,_0x4a30ff){const _0x13cbba=_0xfb644;Cesium['Check'][_0x13cbba(0x224)](_0x13cbba(0x21c),_0x194cf3),Cesium[_0x13cbba(0x252)][_0x13cbba(0x224)](_0x13cbba(0x243),_0x4a30ff);!Array[_0x13cbba(0x1de)](_0x194cf3)&&(_0x194cf3=[_0x194cf3]);let _0x2fab4b=new Cesium['AssociativeArray'](),_0x126eec;for(let _0x518563=0x0,_0x3f73e6=_0x194cf3[_0x13cbba(0x2b6)];_0x518563<_0x3f73e6;_0x518563++){_0x126eec=_0x194cf3[_0x518563];if(!Cesium['defined'](_0x126eec))continue;let _0x553ea1=Cesium[_0x13cbba(0x1ad)](this['_objsOperationList'][_0x13cbba(0x256)](_0x126eec),0x0);if(_0x553ea1===_0x4a30ff)continue;_0x553ea1=_0x553ea1|_0x4a30ff,this[_0x13cbba(0x2e0)][_0x13cbba(0x2e6)](_0x126eec,_0x553ea1),_0x2fab4b[_0x13cbba(0x2e6)](_0x126eec,_0x553ea1);}_0x2fab4b[_0x13cbba(0x2b6)]>0x0&&this['_updateObjsOperation'](_0x2fab4b);},S3MTilesLayer[_0xfb644(0x1ee)][_0xfb644(0x2ae)]=function(_0x137ad5,_0x43b5dc){const _0xbb8b0e=_0xfb644;Cesium[_0xbb8b0e(0x252)][_0xbb8b0e(0x224)]('set\x20Objs\x20Operation\x20ids',_0x137ad5);!Array['isArray'](_0x137ad5)&&(_0x137ad5=[_0x137ad5]);let _0x35732d=_0x594bc2['ALL']^_0x43b5dc,_0x58dd5f=new Cesium['AssociativeArray'](),_0x203b38;for(let _0x3b8fdc=0x0,_0x259bab=_0x137ad5[_0xbb8b0e(0x2b6)];_0x3b8fdc<_0x259bab;_0x3b8fdc++){_0x203b38=_0x137ad5[_0x3b8fdc];let _0x4b1cbc=this[_0xbb8b0e(0x2e0)][_0xbb8b0e(0x256)](_0x203b38);if(!Cesium[_0xbb8b0e(0x224)](_0x4b1cbc))continue;_0x4b1cbc&=_0x35732d,_0x4b1cbc===_0x594bc2[_0xbb8b0e(0x2c7)]?this[_0xbb8b0e(0x2e0)]['remove'](_0x203b38):this[_0xbb8b0e(0x2e0)][_0xbb8b0e(0x2e6)](_0x203b38,_0x4b1cbc),_0x58dd5f[_0xbb8b0e(0x2e6)](_0x203b38,_0x4b1cbc);}_0x58dd5f[_0xbb8b0e(0x2b6)]>0x0&&this['_updateObjsOperation'](_0x58dd5f);},S3MTilesLayer[_0xfb644(0x1ee)][_0xfb644(0x1bc)]=function(_0x5e7db1){const _0x4f9c6c=_0xfb644;let _0x17dd3e=Cesium['Cartesian3'][_0x4f9c6c(0x1aa)](_0x5e7db1),_0x54dfb7=new Cesium[(_0x4f9c6c(0x200))]({'polygonHierarchy':{'positions':_0x17dd3e},'perPositionHeight':!![]}),_0x489243=Cesium[_0x4f9c6c(0x200)][_0x4f9c6c(0x2a8)](_0x54dfb7),_0x36c213=new RasterRegion();return _0x36c213[_0x4f9c6c(0x1db)](_0x489243,this[_0x4f9c6c(0x25d)]),_0x36c213[_0x4f9c6c(0x1e7)](_0x489243),_0x36c213;};function flattenCallback(_0x329a02,_0x42351a){_0x329a02['flatten'](_0x42351a);}S3MTilesLayer['prototype']['addFlattenRegion']=function(_0x40cf69){const _0x9f3fc8=_0xfb644;let _0xe943e5=_0x40cf69[_0x9f3fc8(0x22a)],_0x2531b4=_0x40cf69[_0x9f3fc8(0x29f)];if(!_0xe943e5||!_0x2531b4)return;let _0x542d25=this['_flattenPar'],_0x191c28=_0x542d25[_0x9f3fc8(0x231)];if(_0x191c28[_0x9f3fc8(0x22e)](_0xe943e5))return;!_0x542d25['texture']&&(_0x542d25[_0x9f3fc8(0x1fc)]=new Cesium[(_0x9f3fc8(0x2af))]({'context':this[_0x9f3fc8(0x278)],'width':_0x542d25[_0x9f3fc8(0x295)],'height':_0x542d25[_0x9f3fc8(0x2e4)],'pixelFormat':Cesium[_0x9f3fc8(0x24d)][_0x9f3fc8(0x2c8)]}));let _0x337130=this['_createRasterRegion'](_0x2531b4);_0x191c28[_0x9f3fc8(0x2e6)](_0xe943e5,_0x337130),_0x542d25[_0x9f3fc8(0x285)]=!![],_0x191c28[_0x9f3fc8(0x239)][_0x9f3fc8(0x2b6)]===0x1&&this[_0x9f3fc8(0x1d4)]({'enable':!![]},flattenCallback);};function hypsometricCallback(_0x73aa6d,_0x1f4aa9){const _0x44ef15=_0xfb644;_0x73aa6d[_0x44ef15(0x1cc)](_0x1f4aa9);}function swipeCallback(_0x10feb4,_0x2920aa){_0x10feb4['swipe'](_0x2920aa);}function combineRegionBounds(_0x4758b2){const _0x3a6777=_0xfb644;let _0x45c6ca=new Cesium[(_0x3a6777(0x1a8))](Number[_0x3a6777(0x21a)],Number[_0x3a6777(0x21a)],-Number[_0x3a6777(0x21a)],-Number[_0x3a6777(0x21a)]);for(let _0x5d0e93=0x0;_0x5d0e93<_0x4758b2[_0x3a6777(0x2b6)];_0x5d0e93++){const _0x205bfc=_0x4758b2[_0x5d0e93][_0x3a6777(0x2e3)];_0x45c6ca['x']=Math[_0x3a6777(0x1dd)](_0x205bfc['x'],_0x45c6ca['x']),_0x45c6ca['y']=Math['min'](_0x205bfc['y'],_0x45c6ca['y']),_0x45c6ca['z']=Math[_0x3a6777(0x237)](_0x205bfc['z'],_0x45c6ca['z']),_0x45c6ca['w']=Math[_0x3a6777(0x237)](_0x205bfc['w'],_0x45c6ca['w']);}return _0x45c6ca;}S3MTilesLayer[_0xfb644(0x1ee)][_0xfb644(0x1df)]=function(_0x4e417f){const _0x2f7075=_0xfb644;let _0x4de2a4=this[_0x2f7075(0x225)];if(!_0x4de2a4[_0x2f7075(0x285)])return;_0x4de2a4[_0x2f7075(0x285)]=![];let _0x445403=_0x4de2a4[_0x2f7075(0x231)],_0x53121d=_0x445403['values'][_0x2f7075(0x2b6)];_0x4de2a4[_0x2f7075(0x205)]=_0x53121d>0x0,_0x4de2a4[_0x2f7075(0x2e3)]=combineRegionBounds(_0x445403[_0x2f7075(0x239)]);let _0x4a9770=new Cesium[(_0x2f7075(0x2a6))]({'color':new Cesium['Color'](0x1,0x1,0x1,0x1),'depth':0x1});!_0x4de2a4[_0x2f7075(0x1fc)]&&(_0x4de2a4[_0x2f7075(0x1fc)]=new Cesium[(_0x2f7075(0x2af))]({'context':this[_0x2f7075(0x278)],'width':_0x4de2a4[_0x2f7075(0x295)],'height':_0x4de2a4[_0x2f7075(0x2e4)],'pixelFormat':Cesium[_0x2f7075(0x24d)][_0x2f7075(0x2c8)]}));!_0x4de2a4[_0x2f7075(0x22b)]&&(_0x4de2a4[_0x2f7075(0x22b)]=new Cesium[(_0x2f7075(0x203))]({'context':this['context'],'colorTextures':[_0x4de2a4['texture']],'destroyAttachments':![]}));_0x4a9770[_0x2f7075(0x27f)]=_0x4de2a4[_0x2f7075(0x22b)],_0x4a9770[_0x2f7075(0x1b9)]=Cesium[_0x2f7075(0x262)]['fromCache'](),_0x4a9770[_0x2f7075(0x2ba)](this[_0x2f7075(0x278)]);for(let _0x735a89=0x0;_0x735a89<_0x53121d;_0x735a89++){let _0x18f49f=_0x445403['values'][_0x735a89];_0x18f49f[_0x2f7075(0x2d9)](this[_0x2f7075(0x278)],_0x4de2a4[_0x2f7075(0x22b)]),_0x18f49f[_0x2f7075(0x1f4)][_0x2f7075(0x28c)]={'uRect':function(){const _0x175f84=_0x2f7075;return _0x4de2a4[_0x175f84(0x2e3)];}},_0x18f49f[_0x2f7075(0x1f4)][_0x2f7075(0x2ba)](this['context']);}},S3MTilesLayer[_0xfb644(0x1ee)][_0xfb644(0x1b1)]=function(_0x5bbb08,_0x529742){const _0x2db1a4=_0xfb644;if(_0x5bbb08>0x8)throw new Cesium[(_0x2db1a4(0x21d))](_0x2db1a4(0x216));_0x529742?this[_0x2db1a4(0x251)]=0x1<<_0x5bbb08|this[_0x2db1a4(0x251)]:this['_visibleViewport']=~(0x1<<_0x5bbb08)&this[_0x2db1a4(0x251)];},S3MTilesLayer['prototype'][_0xfb644(0x2a0)]=function(_0x2fdc98){const _0x460164=_0xfb644;if(_0x2fdc98>0x8)throw new Cesium[(_0x460164(0x21d))](_0x460164(0x232));return 0x1<<_0x2fdc98&this['_visibleViewport'];},S3MTilesLayer[_0xfb644(0x1ee)][_0xfb644(0x28b)]=function(){const _0x5078e3=_0xfb644;if(this[_0x5078e3(0x1fb)]===0x0){this[_0x5078e3(0x20c)]=0x0;return;}this[_0x5078e3(0x293)]=this[_0x5078e3(0x20c)]/this['_edgeCurrentCount']*0x28,this[_0x5078e3(0x20c)]=0x0,this[_0x5078e3(0x1fb)]=0x0;},S3MTilesLayer[_0xfb644(0x1ee)][_0xfb644(0x2ec)]=function(_0x2c3055,_0x39ff32){this['_edgeCurrentTotalLength']+=_0x2c3055,this['_edgeCurrentCount']+=_0x39ff32;};function updateWaterPlane(_0x13d468,_0x52cf3b){const _0x19dccf=_0xfb644;if(!_0x13d468[_0x19dccf(0x235)])return;let _0xbf885e=_0x13d468[_0x19dccf(0x235)];_0x52cf3b['curDis']===undefined&&(_0x52cf3b['curDis']=0x615299);_0x52cf3b[_0x19dccf(0x2d5)]===undefined&&(_0x52cf3b[_0x19dccf(0x2d5)]=0x0);let _0xdf2ac4=_0x52cf3b[_0x19dccf(0x2f4)][_0x19dccf(0x1ca)];for(let _0x422838 in _0xbf885e['_hash']){if(_0xbf885e[_0x19dccf(0x210)]['hasOwnProperty'](_0x422838)){let _0x353fff=_0xbf885e[_0x19dccf(0x256)](_0x422838),_0x43889a=_0x353fff['boundingVolume'];if(_0x52cf3b[_0x19dccf(0x23f)]['computeVisibility'](_0x43889a)===Cesium[_0x19dccf(0x250)][_0x19dccf(0x258)])continue;let _0x482b9d=Cesium['Cartesian3'][_0x19dccf(0x27c)](_0x43889a[_0x19dccf(0x282)],_0xdf2ac4)-_0x43889a[_0x19dccf(0x2ab)];_0x482b9d=_0x482b9d<0.01?0.01:_0x482b9d,_0x482b9d<_0x52cf3b[_0x19dccf(0x2f6)]&&(_0x52cf3b['curDis']=_0x482b9d,_0x52cf3b[_0x19dccf(0x2d5)]=_0x353fff['distance']);}}}S3MTilesLayer[_0xfb644(0x1ee)]['addWaterPlane']=function(_0x47ed56){const _0x1ca2df=_0xfb644;let _0x4a2ac0=this[_0x1ca2df(0x235)][_0x1ca2df(0x2b6)];return this[_0x1ca2df(0x235)]['set'](_0x4a2ac0,_0x47ed56),_0x4a2ac0;},S3MTilesLayer['prototype'][_0xfb644(0x25a)]=function(_0xacb149){const _0x14f720=_0xfb644;this[_0x14f720(0x235)][_0x14f720(0x1ae)](_0xacb149);},S3MTilesLayer[_0xfb644(0x1ee)]['prePassesUpdate']=function(_0x4e393b){const _0x2c38c6=_0xfb644;if(!this[_0x2c38c6(0x309)])return;_0x4e393b[_0x2c38c6(0x236)]&&(this[_0x2c38c6(0x22d)]['reset'](),this[_0x2c38c6(0x215)][_0x2c38c6(0x2b6)]=0x0,this[_0x2c38c6(0x1b4)][_0x2c38c6(0x2b6)]=0x0,this[_0x2c38c6(0x2ee)]['length']=0x0,Cesium[_0x2c38c6(0x224)](_0x4e393b[_0x2c38c6(0x271)])&&_0x4e393b['brdfLutGenerator']['update'](_0x4e393b),updateWaterPlane(this,_0x4e393b));};let scratchtTransposeViewMatrix=new Cesium['Matrix4']();S3MTilesLayer[_0xfb644(0x1ee)][_0xfb644(0x1ea)]=function(_0x257483){const _0x4a3eff=_0xfb644;if(!this[_0x4a3eff(0x309)])return;freeResource(this),this[_0x4a3eff(0x1df)](_0x257483),this[_0x4a3eff(0x28b)](),this[_0x4a3eff(0x1c3)]&&this['_subTextureManager'][_0x4a3eff(0x26a)](this['id']);};function isLayerVisible(_0x2ac6aa,_0x444a99){const _0x1983fb=_0xfb644;let _0x33cd17=_0x444a99[_0x1983fb(0x2f4)];if(_0x33cd17[_0x1983fb(0x2f0)][_0x1983fb(0x2dc)]<_0x2ac6aa[_0x1983fb(0x29a)]||_0x33cd17[_0x1983fb(0x2f0)][_0x1983fb(0x2dc)]>_0x2ac6aa[_0x1983fb(0x20f)])return ![];if(!_0x2ac6aa[_0x1983fb(0x2a0)](_0x444a99[_0x1983fb(0x1a7)]))return ![];return _0x2ac6aa[_0x1983fb(0x209)];}function updateClipPlanes(_0x142f2e,_0x21c4fa){const _0x462cf7=_0xfb644;if(_0x142f2e[_0x462cf7(0x27a)]){let _0x1c2d6f=_0x21c4fa[_0x462cf7(0x2f4)][_0x462cf7(0x300)];Cesium[_0x462cf7(0x1da)][_0x462cf7(0x2c6)](_0x1c2d6f,scratchtTransposeViewMatrix);for(let _0x54b610=0x0;_0x54b610<0x6;_0x54b610++){Cesium[_0x462cf7(0x1da)]['multiplyByVector'](scratchtTransposeViewMatrix,_0x142f2e[_0x462cf7(0x263)][_0x54b610],_0x142f2e[_0x462cf7(0x1cf)][_0x54b610]);}}}S3MTilesLayer[_0xfb644(0x1ee)][_0xfb644(0x28e)]=function(_0x1ec0de){const _0x4e6797=_0xfb644;if(!this[_0x4e6797(0x309)]||!isLayerVisible(this,_0x1ec0de))return;this[_0x4e6797(0x25b)]['schedule'](this,_0x1ec0de),requestTiles(this),processTiles(this,_0x1ec0de),updateTiles(this,_0x1ec0de),updateClipPlanes(this,_0x1ec0de);},S3MTilesLayer['prototype'][_0xfb644(0x1f0)]=function(){return ![];},S3MTilesLayer[_0xfb644(0x1ee)][_0xfb644(0x2c3)]=function(){const _0x539a9f=_0xfb644;return this[_0x539a9f(0x22d)][_0x539a9f(0x1ab)](),freeResource(this),this[_0x539a9f(0x207)][_0x539a9f(0x2b6)]=0x0,this['_requestTiles'][_0x539a9f(0x2b6)]=0x0,this[_0x539a9f(0x1b4)][_0x539a9f(0x2b6)]=0x0,this[_0x539a9f(0x2ee)][_0x539a9f(0x2b6)]=0x0,this[_0x539a9f(0x1d7)][_0x539a9f(0x2b6)]=0x0,this[_0x539a9f(0x2e0)][_0x539a9f(0x2e9)](),this['_objsVisibleList'][_0x539a9f(0x2e9)](),this[_0x539a9f(0x299)]['removeAll'](),this[_0x539a9f(0x21e)]={},this['_objsColorList']={},this[_0x539a9f(0x268)][_0x539a9f(0x2c3)](),this[_0x539a9f(0x225)][_0x539a9f(0x2c3)](),Cesium[_0x539a9f(0x281)](this);};

    var _0x1d9b13 = (function (globalObject) {

    /*
     *      bignumber.js v8.1.1
     *      A JavaScript library for arbitrary-precision arithmetic.
     *      https://github.com/MikeMcl/bignumber.js
     *      Copyright (c) 2019 Michael Mclaughlin <M8ch88l@gmail.com>
     *      MIT Licensed.
     *
     *      BigNumber.prototype methods     |  BigNumber methods
     *                                      |
     *      absoluteValue            abs    |  clone
     *      comparedTo                      |  config               set
     *      decimalPlaces            dp     |      DECIMAL_PLACES
     *      dividedBy                div    |      ROUNDING_MODE
     *      dividedToIntegerBy       idiv   |      EXPONENTIAL_AT
     *      exponentiatedBy          pow    |      RANGE
     *      integerValue                    |      CRYPTO
     *      isEqualTo                eq     |      MODULO_MODE
     *      isFinite                        |      POW_PRECISION
     *      isGreaterThan            gt     |      FORMAT
     *      isGreaterThanOrEqualTo   gte    |      ALPHABET
     *      isInteger                       |  isBigNumber
     *      isLessThan               lt     |  maximum              max
     *      isLessThanOrEqualTo      lte    |  minimum              min
     *      isNaN                           |  random
     *      isNegative                      |  sum
     *      isPositive                      |
     *      isZero                          |
     *      minus                           |
     *      modulo                   mod    |
     *      multipliedBy             times  |
     *      negated                         |
     *      plus                            |
     *      precision                sd     |
     *      shiftedBy                       |
     *      squareRoot               sqrt   |
     *      toExponential                   |
     *      toFixed                         |
     *      toFormat                        |
     *      toFraction                      |
     *      toJSON                          |
     *      toNumber                        |
     *      toPrecision                     |
     *      toString                        |
     *      valueOf                         |
     *
     */


      var BigNumber,
        isNumeric = /^-?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i,
        hasSymbol = typeof Symbol == 'function' && typeof Symbol.iterator == 'symbol',

        mathceil = Math.ceil,
        mathfloor = Math.floor,

        bignumberError = '[BigNumber Error] ',
        tooManyDigits = bignumberError + 'Number primitive has more than 15 significant digits: ',

        BASE = 1e14,
        LOG_BASE = 14,
        MAX_SAFE_INTEGER = 0x1fffffffffffff,         // 2^53 - 1
        // MAX_INT32 = 0x7fffffff,                   // 2^31 - 1
        POWS_TEN = [1, 10, 100, 1e3, 1e4, 1e5, 1e6, 1e7, 1e8, 1e9, 1e10, 1e11, 1e12, 1e13],
        SQRT_BASE = 1e7,

        // EDITABLE
        // The limit on the value of DECIMAL_PLACES, TO_EXP_NEG, TO_EXP_POS, MIN_EXP, MAX_EXP, and
        // the arguments to toExponential, toFixed, toFormat, and toPrecision.
        MAX = 1E9;                                   // 0 to MAX_INT32


      /*
       * Create and return a BigNumber constructor.
       */
      function clone(configObject) {
        var div, convertBase, parseNumeric,
          P = BigNumber.prototype = { constructor: BigNumber, toString: null, valueOf: null },
          ONE = new BigNumber(1),


          //----------------------------- EDITABLE CONFIG DEFAULTS -------------------------------


          // The default values below must be integers within the inclusive ranges stated.
          // The values can also be changed at run-time using BigNumber.set.

          // The maximum number of decimal places for operations involving division.
          DECIMAL_PLACES = 20,                     // 0 to MAX

          // The rounding mode used when rounding to the above decimal places, and when using
          // toExponential, toFixed, toFormat and toPrecision, and round (default value).
          // UP         0 Away from zero.
          // DOWN       1 Towards zero.
          // CEIL       2 Towards +Infinity.
          // FLOOR      3 Towards -Infinity.
          // HALF_UP    4 Towards nearest neighbour. If equidistant, up.
          // HALF_DOWN  5 Towards nearest neighbour. If equidistant, down.
          // HALF_EVEN  6 Towards nearest neighbour. If equidistant, towards even neighbour.
          // HALF_CEIL  7 Towards nearest neighbour. If equidistant, towards +Infinity.
          // HALF_FLOOR 8 Towards nearest neighbour. If equidistant, towards -Infinity.
          ROUNDING_MODE = 4,                       // 0 to 8

          // EXPONENTIAL_AT : [TO_EXP_NEG , TO_EXP_POS]

          // The exponent value at and beneath which toString returns exponential notation.
          // Number type: -7
          TO_EXP_NEG = -7,                         // 0 to -MAX

          // The exponent value at and above which toString returns exponential notation.
          // Number type: 21
          TO_EXP_POS = 21,                         // 0 to MAX

          // RANGE : [MIN_EXP, MAX_EXP]

          // The minimum exponent value, beneath which underflow to zero occurs.
          // Number type: -324  (5e-324)
          MIN_EXP = -1e7,                          // -1 to -MAX

          // The maximum exponent value, above which overflow to Infinity occurs.
          // Number type:  308  (1.7976931348623157e+308)
          // For MAX_EXP > 1e7, e.g. new BigNumber('1e100000000').plus(1) may be slow.
          MAX_EXP = 1e7,                           // 1 to MAX

          // Whether to use cryptographically-secure random number generation, if available.
          CRYPTO = false,                          // true or false

          // The modulo mode used when calculating the modulus: a mod n.
          // The quotient (q = a / n) is calculated according to the corresponding rounding mode.
          // The remainder (r) is calculated as: r = a - n * q.
          //
          // UP        0 The remainder is positive if the dividend is negative, else is negative.
          // DOWN      1 The remainder has the same sign as the dividend.
          //             This modulo mode is commonly known as 'truncated division' and is
          //             equivalent to (a % n) in JavaScript.
          // FLOOR     3 The remainder has the same sign as the divisor (Python %).
          // HALF_EVEN 6 This modulo mode implements the IEEE 754 remainder function.
          // EUCLID    9 Euclidian division. q = sign(n) * floor(a / abs(n)).
          //             The remainder is always positive.
          //
          // The truncated division, floored division, Euclidian division and IEEE 754 remainder
          // modes are commonly used for the modulus operation.
          // Although the other rounding modes can also be used, they may not give useful results.
          MODULO_MODE = 1,                         // 0 to 9

          // The maximum number of significant digits of the result of the exponentiatedBy operation.
          // If POW_PRECISION is 0, there will be unlimited significant digits.
          POW_PRECISION = 0,                    // 0 to MAX

          // The format specification used by the BigNumber.prototype.toFormat method.
          FORMAT = {
            prefix: '',
            groupSize: 3,
            secondaryGroupSize: 0,
            groupSeparator: ',',
            decimalSeparator: '.',
            fractionGroupSize: 0,
            fractionGroupSeparator: '\xA0',      // non-breaking space
            suffix: ''
          },

          // The alphabet used for base conversion. It must be at least 2 characters long, with no '+',
          // '-', '.', whitespace, or repeated character.
          // '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ$_'
          ALPHABET = '0123456789abcdefghijklmnopqrstuvwxyz';


        //------------------------------------------------------------------------------------------


        // CONSTRUCTOR


        /*
         * The BigNumber constructor and exported function.
         * Create and return a new instance of a BigNumber object.
         *
         * v {number|string|BigNumber} A numeric value.
         * [b] {number} The base of v. Integer, 2 to ALPHABET.length inclusive.
         */
        function BigNumber(v, b) {
          var alphabet, c, caseChanged, e, i, isNum, len, str,
            x = this;

          // Enable constructor call without `new`.
          if (!(x instanceof BigNumber)) return new BigNumber(v, b);

          if (b == null) {

            if (v && v._isBigNumber === true) {
              x.s = v.s;

              if (!v.c || v.e > MAX_EXP) {
                x.c = x.e = null;
              } else if (v.e < MIN_EXP) {
                x.c = [x.e = 0];
              } else {
                x.e = v.e;
                x.c = v.c.slice();
              }

              return;
            }

            if ((isNum = typeof v == 'number') && v * 0 == 0) {

              // Use `1 / n` to handle minus zero also.
              x.s = 1 / v < 0 ? (v = -v, -1) : 1;

              // Fast path for integers, where n < 2147483648 (2**31).
              if (v === ~~v) {
                for (e = 0, i = v; i >= 10; i /= 10, e++);

                if (e > MAX_EXP) {
                  x.c = x.e = null;
                } else {
                  x.e = e;
                  x.c = [v];
                }

                return;
              }

              str = String(v);
            } else {

              if (!isNumeric.test(str = String(v))) return parseNumeric(x, str, isNum);

              x.s = str.charCodeAt(0) == 45 ? (str = str.slice(1), -1) : 1;
            }

            // Decimal point?
            if ((e = str.indexOf('.')) > -1) str = str.replace('.', '');

            // Exponential form?
            if ((i = str.search(/e/i)) > 0) {

              // Determine exponent.
              if (e < 0) e = i;
              e += +str.slice(i + 1);
              str = str.substring(0, i);
            } else if (e < 0) {

              // Integer.
              e = str.length;
            }

          } else {

            // '[BigNumber Error] Base {not a primitive number|not an integer|out of range}: {b}'
            intCheck(b, 2, ALPHABET.length, 'Base');

            // Allow exponential notation to be used with base 10 argument, while
            // also rounding to DECIMAL_PLACES as with other bases.
            if (b == 10) {
              x = new BigNumber(v);
              return round(x, DECIMAL_PLACES + x.e + 1, ROUNDING_MODE);
            }

            str = String(v);

            if (isNum = typeof v == 'number') {

              // Avoid potential interpretation of Infinity and NaN as base 44+ values.
              if (v * 0 != 0) return parseNumeric(x, str, isNum, b);

              x.s = 1 / v < 0 ? (str = str.slice(1), -1) : 1;

              // '[BigNumber Error] Number primitive has more than 15 significant digits: {n}'
              if (BigNumber.DEBUG && str.replace(/^0\.0*|\./, '').length > 15) {
                throw Error
                 (tooManyDigits + v);
              }
            } else {
              x.s = str.charCodeAt(0) === 45 ? (str = str.slice(1), -1) : 1;
            }

            alphabet = ALPHABET.slice(0, b);
            e = i = 0;

            // Check that str is a valid base b number.
            // Don't use RegExp, so alphabet can contain special characters.
            for (len = str.length; i < len; i++) {
              if (alphabet.indexOf(c = str.charAt(i)) < 0) {
                if (c == '.') {

                  // If '.' is not the first character and it has not be found before.
                  if (i > e) {
                    e = len;
                    continue;
                  }
                } else if (!caseChanged) {

                  // Allow e.g. hexadecimal 'FF' as well as 'ff'.
                  if (str == str.toUpperCase() && (str = str.toLowerCase()) ||
                      str == str.toLowerCase() && (str = str.toUpperCase())) {
                    caseChanged = true;
                    i = -1;
                    e = 0;
                    continue;
                  }
                }

                return parseNumeric(x, String(v), isNum, b);
              }
            }

            // Prevent later check for length on converted number.
            isNum = false;
            str = convertBase(str, b, 10, x.s);

            // Decimal point?
            if ((e = str.indexOf('.')) > -1) str = str.replace('.', '');
            else e = str.length;
          }

          // Determine leading zeros.
          for (i = 0; str.charCodeAt(i) === 48; i++);

          // Determine trailing zeros.
          for (len = str.length; str.charCodeAt(--len) === 48;);

          if (str = str.slice(i, ++len)) {
            len -= i;

            // '[BigNumber Error] Number primitive has more than 15 significant digits: {n}'
            if (isNum && BigNumber.DEBUG &&
              len > 15 && (v > MAX_SAFE_INTEGER || v !== mathfloor(v))) {
                throw Error
                 (tooManyDigits + (x.s * v));
            }

             // Overflow?
            if ((e = e - i - 1) > MAX_EXP) {

              // Infinity.
              x.c = x.e = null;

            // Underflow?
            } else if (e < MIN_EXP) {

              // Zero.
              x.c = [x.e = 0];
            } else {
              x.e = e;
              x.c = [];

              // Transform base

              // e is the base 10 exponent.
              // i is where to slice str to get the first element of the coefficient array.
              i = (e + 1) % LOG_BASE;
              if (e < 0) i += LOG_BASE;  // i < 1

              if (i < len) {
                if (i) x.c.push(+str.slice(0, i));

                for (len -= LOG_BASE; i < len;) {
                  x.c.push(+str.slice(i, i += LOG_BASE));
                }

                i = LOG_BASE - (str = str.slice(i)).length;
              } else {
                i -= len;
              }

              for (; i--; str += '0');
              x.c.push(+str);
            }
          } else {

            // Zero.
            x.c = [x.e = 0];
          }
        }


        // CONSTRUCTOR PROPERTIES


        BigNumber.clone = clone;

        BigNumber.ROUND_UP = 0;
        BigNumber.ROUND_DOWN = 1;
        BigNumber.ROUND_CEIL = 2;
        BigNumber.ROUND_FLOOR = 3;
        BigNumber.ROUND_HALF_UP = 4;
        BigNumber.ROUND_HALF_DOWN = 5;
        BigNumber.ROUND_HALF_EVEN = 6;
        BigNumber.ROUND_HALF_CEIL = 7;
        BigNumber.ROUND_HALF_FLOOR = 8;
        BigNumber.EUCLID = 9;


        /*
         * Configure infrequently-changing library-wide settings.
         *
         * Accept an object with the following optional properties (if the value of a property is
         * a number, it must be an integer within the inclusive range stated):
         *
         *   DECIMAL_PLACES   {number}           0 to MAX
         *   ROUNDING_MODE    {number}           0 to 8
         *   EXPONENTIAL_AT   {number|number[]}  -MAX to MAX  or  [-MAX to 0, 0 to MAX]
         *   RANGE            {number|number[]}  -MAX to MAX (not zero)  or  [-MAX to -1, 1 to MAX]
         *   CRYPTO           {boolean}          true or false
         *   MODULO_MODE      {number}           0 to 9
         *   POW_PRECISION       {number}           0 to MAX
         *   ALPHABET         {string}           A string of two or more unique characters which does
         *                                       not contain '.'.
         *   FORMAT           {object}           An object with some of the following properties:
         *     prefix                 {string}
         *     groupSize              {number}
         *     secondaryGroupSize     {number}
         *     groupSeparator         {string}
         *     decimalSeparator       {string}
         *     fractionGroupSize      {number}
         *     fractionGroupSeparator {string}
         *     suffix                 {string}
         *
         * (The values assigned to the above FORMAT object properties are not checked for validity.)
         *
         * E.g.
         * BigNumber.config({ DECIMAL_PLACES : 20, ROUNDING_MODE : 4 })
         *
         * Ignore properties/parameters set to null or undefined, except for ALPHABET.
         *
         * Return an object with the properties current values.
         */
        BigNumber.config = BigNumber.set = function (obj) {
          var p, v;

          if (obj != null) {

            if (typeof obj == 'object') {

              // DECIMAL_PLACES {number} Integer, 0 to MAX inclusive.
              // '[BigNumber Error] DECIMAL_PLACES {not a primitive number|not an integer|out of range}: {v}'
              if (obj.hasOwnProperty(p = 'DECIMAL_PLACES')) {
                v = obj[p];
                intCheck(v, 0, MAX, p);
                DECIMAL_PLACES = v;
              }

              // ROUNDING_MODE {number} Integer, 0 to 8 inclusive.
              // '[BigNumber Error] ROUNDING_MODE {not a primitive number|not an integer|out of range}: {v}'
              if (obj.hasOwnProperty(p = 'ROUNDING_MODE')) {
                v = obj[p];
                intCheck(v, 0, 8, p);
                ROUNDING_MODE = v;
              }

              // EXPONENTIAL_AT {number|number[]}
              // Integer, -MAX to MAX inclusive or
              // [integer -MAX to 0 inclusive, 0 to MAX inclusive].
              // '[BigNumber Error] EXPONENTIAL_AT {not a primitive number|not an integer|out of range}: {v}'
              if (obj.hasOwnProperty(p = 'EXPONENTIAL_AT')) {
                v = obj[p];
                if (v && v.pop) {
                  intCheck(v[0], -MAX, 0, p);
                  intCheck(v[1], 0, MAX, p);
                  TO_EXP_NEG = v[0];
                  TO_EXP_POS = v[1];
                } else {
                  intCheck(v, -MAX, MAX, p);
                  TO_EXP_NEG = -(TO_EXP_POS = v < 0 ? -v : v);
                }
              }

              // RANGE {number|number[]} Non-zero integer, -MAX to MAX inclusive or
              // [integer -MAX to -1 inclusive, integer 1 to MAX inclusive].
              // '[BigNumber Error] RANGE {not a primitive number|not an integer|out of range|cannot be zero}: {v}'
              if (obj.hasOwnProperty(p = 'RANGE')) {
                v = obj[p];
                if (v && v.pop) {
                  intCheck(v[0], -MAX, -1, p);
                  intCheck(v[1], 1, MAX, p);
                  MIN_EXP = v[0];
                  MAX_EXP = v[1];
                } else {
                  intCheck(v, -MAX, MAX, p);
                  if (v) {
                    MIN_EXP = -(MAX_EXP = v < 0 ? -v : v);
                  } else {
                    throw Error
                     (bignumberError + p + ' cannot be zero: ' + v);
                  }
                }
              }

              // CRYPTO {boolean} true or false.
              // '[BigNumber Error] CRYPTO not true or false: {v}'
              // '[BigNumber Error] crypto unavailable'
              if (obj.hasOwnProperty(p = 'CRYPTO')) {
                v = obj[p];
                if (v === !!v) {
                  if (v) {
                    if (typeof crypto != 'undefined' && crypto &&
                     (crypto.getRandomValues || crypto.randomBytes)) {
                      CRYPTO = v;
                    } else {
                      CRYPTO = !v;
                      throw Error
                       (bignumberError + 'crypto unavailable');
                    }
                  } else {
                    CRYPTO = v;
                  }
                } else {
                  throw Error
                   (bignumberError + p + ' not true or false: ' + v);
                }
              }

              // MODULO_MODE {number} Integer, 0 to 9 inclusive.
              // '[BigNumber Error] MODULO_MODE {not a primitive number|not an integer|out of range}: {v}'
              if (obj.hasOwnProperty(p = 'MODULO_MODE')) {
                v = obj[p];
                intCheck(v, 0, 9, p);
                MODULO_MODE = v;
              }

              // POW_PRECISION {number} Integer, 0 to MAX inclusive.
              // '[BigNumber Error] POW_PRECISION {not a primitive number|not an integer|out of range}: {v}'
              if (obj.hasOwnProperty(p = 'POW_PRECISION')) {
                v = obj[p];
                intCheck(v, 0, MAX, p);
                POW_PRECISION = v;
              }

              // FORMAT {object}
              // '[BigNumber Error] FORMAT not an object: {v}'
              if (obj.hasOwnProperty(p = 'FORMAT')) {
                v = obj[p];
                if (typeof v == 'object') FORMAT = v;
                else throw Error
                 (bignumberError + p + ' not an object: ' + v);
              }

              // ALPHABET {string}
              // '[BigNumber Error] ALPHABET invalid: {v}'
              if (obj.hasOwnProperty(p = 'ALPHABET')) {
                v = obj[p];

                // Disallow if only one character,
                // or if it contains '+', '-', '.', whitespace, or a repeated character.
                if (typeof v == 'string' && !/^.$|[+-.\s]|(.).*\1/.test(v)) {
                  ALPHABET = v;
                } else {
                  throw Error
                   (bignumberError + p + ' invalid: ' + v);
                }
              }

            } else {

              // '[BigNumber Error] Object expected: {v}'
              throw Error
               (bignumberError + 'Object expected: ' + obj);
            }
          }

          return {
            DECIMAL_PLACES: DECIMAL_PLACES,
            ROUNDING_MODE: ROUNDING_MODE,
            EXPONENTIAL_AT: [TO_EXP_NEG, TO_EXP_POS],
            RANGE: [MIN_EXP, MAX_EXP],
            CRYPTO: CRYPTO,
            MODULO_MODE: MODULO_MODE,
            POW_PRECISION: POW_PRECISION,
            FORMAT: FORMAT,
            ALPHABET: ALPHABET
          };
        };


        /*
         * Return true if v is a BigNumber instance, otherwise return false.
         *
         * If BigNumber.DEBUG is true, throw if a BigNumber instance is not well-formed.
         *
         * v {any}
         *
         * '[BigNumber Error] Invalid BigNumber: {v}'
         */
        BigNumber.isBigNumber = function (v) {
          if (!v || v._isBigNumber !== true) return false;
          if (!BigNumber.DEBUG) return true;

          var i, n,
            c = v.c,
            e = v.e,
            s = v.s;

          out: if ({}.toString.call(c) == '[object Array]') {

            if ((s === 1 || s === -1) && e >= -MAX && e <= MAX && e === mathfloor(e)) {

              // If the first element is zero, the BigNumber value must be zero.
              if (c[0] === 0) {
                if (e === 0 && c.length === 1) return true;
                break out;
              }

              // Calculate number of digits that c[0] should have, based on the exponent.
              i = (e + 1) % LOG_BASE;
              if (i < 1) i += LOG_BASE;

              // Calculate number of digits of c[0].
              //if (Math.ceil(Math.log(c[0] + 1) / Math.LN10) == i) {
              if (String(c[0]).length == i) {

                for (i = 0; i < c.length; i++) {
                  n = c[i];
                  if (n < 0 || n >= BASE || n !== mathfloor(n)) break out;
                }

                // Last element cannot be zero, unless it is the only element.
                if (n !== 0) return true;
              }
            }

          // Infinity/NaN
          } else if (c === null && e === null && (s === null || s === 1 || s === -1)) {
            return true;
          }

          throw Error
            (bignumberError + 'Invalid BigNumber: ' + v);
        };


        /*
         * Return a new BigNumber whose value is the maximum of the arguments.
         *
         * arguments {number|string|BigNumber}
         */
        BigNumber.maximum = BigNumber.max = function () {
          return maxOrMin(arguments, P.lt);
        };


        /*
         * Return a new BigNumber whose value is the minimum of the arguments.
         *
         * arguments {number|string|BigNumber}
         */
        BigNumber.minimum = BigNumber.min = function () {
          return maxOrMin(arguments, P.gt);
        };


        /*
         * Return a new BigNumber with a random value equal to or greater than 0 and less than 1,
         * and with dp, or DECIMAL_PLACES if dp is omitted, decimal places (or less if trailing
         * zeros are produced).
         *
         * [dp] {number} Decimal places. Integer, 0 to MAX inclusive.
         *
         * '[BigNumber Error] Argument {not a primitive number|not an integer|out of range}: {dp}'
         * '[BigNumber Error] crypto unavailable'
         */
        BigNumber.random = (function () {
          var pow2_53 = 0x20000000000000;

          // Return a 53 bit integer n, where 0 <= n < 9007199254740992.
          // Check if Math.random() produces more than 32 bits of randomness.
          // If it does, assume at least 53 bits are produced, otherwise assume at least 30 bits.
          // 0x40000000 is 2^30, 0x800000 is 2^23, 0x1fffff is 2^21 - 1.
          var random53bitInt = (Math.random() * pow2_53) & 0x1fffff
           ? function () { return mathfloor(Math.random() * pow2_53); }
           : function () { return ((Math.random() * 0x40000000 | 0) * 0x800000) +
             (Math.random() * 0x800000 | 0); };

          return function (dp) {
            var a, b, e, k, v,
              i = 0,
              c = [],
              rand = new BigNumber(ONE);

            if (dp == null) dp = DECIMAL_PLACES;
            else intCheck(dp, 0, MAX);

            k = mathceil(dp / LOG_BASE);

            if (CRYPTO) {

              // Browsers supporting crypto.getRandomValues.
              if (crypto.getRandomValues) {

                a = crypto.getRandomValues(new Uint32Array(k *= 2));

                for (; i < k;) {

                  // 53 bits:
                  // ((Math.pow(2, 32) - 1) * Math.pow(2, 21)).toString(2)
                  // 11111 11111111 11111111 11111111 11100000 00000000 00000000
                  // ((Math.pow(2, 32) - 1) >>> 11).toString(2)
                  //                                     11111 11111111 11111111
                  // 0x20000 is 2^21.
                  v = a[i] * 0x20000 + (a[i + 1] >>> 11);

                  // Rejection sampling:
                  // 0 <= v < 9007199254740992
                  // Probability that v >= 9e15, is
                  // 7199254740992 / 9007199254740992 ~= 0.0008, i.e. 1 in 1251
                  if (v >= 9e15) {
                    b = crypto.getRandomValues(new Uint32Array(2));
                    a[i] = b[0];
                    a[i + 1] = b[1];
                  } else {

                    // 0 <= v <= 8999999999999999
                    // 0 <= (v % 1e14) <= 99999999999999
                    c.push(v % 1e14);
                    i += 2;
                  }
                }
                i = k / 2;

              // Node.js supporting crypto.randomBytes.
              } else if (crypto.randomBytes) {

                // buffer
                a = crypto.randomBytes(k *= 7);

                for (; i < k;) {

                  // 0x1000000000000 is 2^48, 0x10000000000 is 2^40
                  // 0x100000000 is 2^32, 0x1000000 is 2^24
                  // 11111 11111111 11111111 11111111 11111111 11111111 11111111
                  // 0 <= v < 9007199254740992
                  v = ((a[i] & 31) * 0x1000000000000) + (a[i + 1] * 0x10000000000) +
                     (a[i + 2] * 0x100000000) + (a[i + 3] * 0x1000000) +
                     (a[i + 4] << 16) + (a[i + 5] << 8) + a[i + 6];

                  if (v >= 9e15) {
                    crypto.randomBytes(7).copy(a, i);
                  } else {

                    // 0 <= (v % 1e14) <= 99999999999999
                    c.push(v % 1e14);
                    i += 7;
                  }
                }
                i = k / 7;
              } else {
                CRYPTO = false;
                throw Error
                 (bignumberError + 'crypto unavailable');
              }
            }

            // Use Math.random.
            if (!CRYPTO) {

              for (; i < k;) {
                v = random53bitInt();
                if (v < 9e15) c[i++] = v % 1e14;
              }
            }

            k = c[--i];
            dp %= LOG_BASE;

            // Convert trailing digits to zeros according to dp.
            if (k && dp) {
              v = POWS_TEN[LOG_BASE - dp];
              c[i] = mathfloor(k / v) * v;
            }

            // Remove trailing elements which are zero.
            for (; c[i] === 0; c.pop(), i--);

            // Zero?
            if (i < 0) {
              c = [e = 0];
            } else {

              // Remove leading elements which are zero and adjust exponent accordingly.
              for (e = -1 ; c[0] === 0; c.splice(0, 1), e -= LOG_BASE);

              // Count the digits of the first element of c to determine leading zeros, and...
              for (i = 1, v = c[0]; v >= 10; v /= 10, i++);

              // adjust the exponent accordingly.
              if (i < LOG_BASE) e -= LOG_BASE - i;
            }

            rand.e = e;
            rand.c = c;
            return rand;
          };
        })();


        /*
         * Return a BigNumber whose value is the sum of the arguments.
         *
         * arguments {number|string|BigNumber}
         */
        BigNumber.sum = function () {
          var i = 1,
            args = arguments,
            sum = new BigNumber(args[0]);
          for (; i < args.length;) sum = sum.plus(args[i++]);
          return sum;
        };


        // PRIVATE FUNCTIONS


        // Called by BigNumber and BigNumber.prototype.toString.
        convertBase = (function () {
          var decimal = '0123456789';

          /*
           * Convert string of baseIn to an array of numbers of baseOut.
           * Eg. toBaseOut('255', 10, 16) returns [15, 15].
           * Eg. toBaseOut('ff', 16, 10) returns [2, 5, 5].
           */
          function toBaseOut(str, baseIn, baseOut, alphabet) {
            var j,
              arr = [0],
              arrL,
              i = 0,
              len = str.length;

            for (; i < len;) {
              for (arrL = arr.length; arrL--; arr[arrL] *= baseIn);

              arr[0] += alphabet.indexOf(str.charAt(i++));

              for (j = 0; j < arr.length; j++) {

                if (arr[j] > baseOut - 1) {
                  if (arr[j + 1] == null) arr[j + 1] = 0;
                  arr[j + 1] += arr[j] / baseOut | 0;
                  arr[j] %= baseOut;
                }
              }
            }

            return arr.reverse();
          }

          // Convert a numeric string of baseIn to a numeric string of baseOut.
          // If the caller is toString, we are converting from base 10 to baseOut.
          // If the caller is BigNumber, we are converting from baseIn to base 10.
          return function (str, baseIn, baseOut, sign, callerIsToString) {
            var alphabet, d, e, k, r, x, xc, y,
              i = str.indexOf('.'),
              dp = DECIMAL_PLACES,
              rm = ROUNDING_MODE;

            // Non-integer.
            if (i >= 0) {
              k = POW_PRECISION;

              // Unlimited precision.
              POW_PRECISION = 0;
              str = str.replace('.', '');
              y = new BigNumber(baseIn);
              x = y.pow(str.length - i);
              POW_PRECISION = k;

              // Convert str as if an integer, then restore the fraction part by dividing the
              // result by its base raised to a power.

              y.c = toBaseOut(toFixedPoint(coeffToString(x.c), x.e, '0'),
               10, baseOut, decimal);
              y.e = y.c.length;
            }

            // Convert the number as integer.

            xc = toBaseOut(str, baseIn, baseOut, callerIsToString
             ? (alphabet = ALPHABET, decimal)
             : (alphabet = decimal, ALPHABET));

            // xc now represents str as an integer and converted to baseOut. e is the exponent.
            e = k = xc.length;

            // Remove trailing zeros.
            for (; xc[--k] == 0; xc.pop());

            // Zero?
            if (!xc[0]) return alphabet.charAt(0);

            // Does str represent an integer? If so, no need for the division.
            if (i < 0) {
              --e;
            } else {
              x.c = xc;
              x.e = e;

              // The sign is needed for correct rounding.
              x.s = sign;
              x = div(x, y, dp, rm, baseOut);
              xc = x.c;
              r = x.r;
              e = x.e;
            }

            // xc now represents str converted to baseOut.

            // THe index of the rounding digit.
            d = e + dp + 1;

            // The rounding digit: the digit to the right of the digit that may be rounded up.
            i = xc[d];

            // Look at the rounding digits and mode to determine whether to round up.

            k = baseOut / 2;
            r = r || d < 0 || xc[d + 1] != null;

            r = rm < 4 ? (i != null || r) && (rm == 0 || rm == (x.s < 0 ? 3 : 2))
                  : i > k || i == k &&(rm == 4 || r || rm == 6 && xc[d - 1] & 1 ||
                   rm == (x.s < 0 ? 8 : 7));

            // If the index of the rounding digit is not greater than zero, or xc represents
            // zero, then the result of the base conversion is zero or, if rounding up, a value
            // such as 0.00001.
            if (d < 1 || !xc[0]) {

              // 1^-dp or 0
              str = r ? toFixedPoint(alphabet.charAt(1), -dp, alphabet.charAt(0)) : alphabet.charAt(0);
            } else {

              // Truncate xc to the required number of decimal places.
              xc.length = d;

              // Round up?
              if (r) {

                // Rounding up may mean the previous digit has to be rounded up and so on.
                for (--baseOut; ++xc[--d] > baseOut;) {
                  xc[d] = 0;

                  if (!d) {
                    ++e;
                    xc = [1].concat(xc);
                  }
                }
              }

              // Determine trailing zeros.
              for (k = xc.length; !xc[--k];);

              // E.g. [4, 11, 15] becomes 4bf.
              for (i = 0, str = ''; i <= k; str += alphabet.charAt(xc[i++]));

              // Add leading zeros, decimal point and trailing zeros as required.
              str = toFixedPoint(str, e, alphabet.charAt(0));
            }

            // The caller will add the sign.
            return str;
          };
        })();


        // Perform division in the specified base. Called by div and convertBase.
        div = (function () {

          // Assume non-zero x and k.
          function multiply(x, k, base) {
            var m, temp, xlo, xhi,
              carry = 0,
              i = x.length,
              klo = k % SQRT_BASE,
              khi = k / SQRT_BASE | 0;

            for (x = x.slice(); i--;) {
              xlo = x[i] % SQRT_BASE;
              xhi = x[i] / SQRT_BASE | 0;
              m = khi * xlo + xhi * klo;
              temp = klo * xlo + ((m % SQRT_BASE) * SQRT_BASE) + carry;
              carry = (temp / base | 0) + (m / SQRT_BASE | 0) + khi * xhi;
              x[i] = temp % base;
            }

            if (carry) x = [carry].concat(x);

            return x;
          }

          function compare(a, b, aL, bL) {
            var i, cmp;

            if (aL != bL) {
              cmp = aL > bL ? 1 : -1;
            } else {

              for (i = cmp = 0; i < aL; i++) {

                if (a[i] != b[i]) {
                  cmp = a[i] > b[i] ? 1 : -1;
                  break;
                }
              }
            }

            return cmp;
          }

          function subtract(a, b, aL, base) {
            var i = 0;

            // Subtract b from a.
            for (; aL--;) {
              a[aL] -= i;
              i = a[aL] < b[aL] ? 1 : 0;
              a[aL] = i * base + a[aL] - b[aL];
            }

            // Remove leading zeros.
            for (; !a[0] && a.length > 1; a.splice(0, 1));
          }

          // x: dividend, y: divisor.
          return function (x, y, dp, rm, base) {
            var cmp, e, i, more, n, prod, prodL, q, qc, rem, remL, rem0, xi, xL, yc0,
              yL, yz,
              s = x.s == y.s ? 1 : -1,
              xc = x.c,
              yc = y.c;

            // Either NaN, Infinity or 0?
            if (!xc || !xc[0] || !yc || !yc[0]) {

              return new BigNumber(

               // Return NaN if either NaN, or both Infinity or 0.
               !x.s || !y.s || (xc ? yc && xc[0] == yc[0] : !yc) ? NaN :

                // Return ±0 if x is ±0 or y is ±Infinity, or return ±Infinity as y is ±0.
                xc && xc[0] == 0 || !yc ? s * 0 : s / 0
             );
            }

            q = new BigNumber(s);
            qc = q.c = [];
            e = x.e - y.e;
            s = dp + e + 1;

            if (!base) {
              base = BASE;
              e = bitFloor(x.e / LOG_BASE) - bitFloor(y.e / LOG_BASE);
              s = s / LOG_BASE | 0;
            }

            // Result exponent may be one less then the current value of e.
            // The coefficients of the BigNumbers from convertBase may have trailing zeros.
            for (i = 0; yc[i] == (xc[i] || 0); i++);

            if (yc[i] > (xc[i] || 0)) e--;

            if (s < 0) {
              qc.push(1);
              more = true;
            } else {
              xL = xc.length;
              yL = yc.length;
              i = 0;
              s += 2;

              // Normalise xc and yc so highest order digit of yc is >= base / 2.

              n = mathfloor(base / (yc[0] + 1));

              // Not necessary, but to handle odd bases where yc[0] == (base / 2) - 1.
              // if (n > 1 || n++ == 1 && yc[0] < base / 2) {
              if (n > 1) {
                yc = multiply(yc, n, base);
                xc = multiply(xc, n, base);
                yL = yc.length;
                xL = xc.length;
              }

              xi = yL;
              rem = xc.slice(0, yL);
              remL = rem.length;

              // Add zeros to make remainder as long as divisor.
              for (; remL < yL; rem[remL++] = 0);
              yz = yc.slice();
              yz = [0].concat(yz);
              yc0 = yc[0];
              if (yc[1] >= base / 2) yc0++;
              // Not necessary, but to prevent trial digit n > base, when using base 3.
              // else if (base == 3 && yc0 == 1) yc0 = 1 + 1e-15;

              do {
                n = 0;

                // Compare divisor and remainder.
                cmp = compare(yc, rem, yL, remL);

                // If divisor < remainder.
                if (cmp < 0) {

                  // Calculate trial digit, n.

                  rem0 = rem[0];
                  if (yL != remL) rem0 = rem0 * base + (rem[1] || 0);

                  // n is how many times the divisor goes into the current remainder.
                  n = mathfloor(rem0 / yc0);

                  //  Algorithm:
                  //  product = divisor multiplied by trial digit (n).
                  //  Compare product and remainder.
                  //  If product is greater than remainder:
                  //    Subtract divisor from product, decrement trial digit.
                  //  Subtract product from remainder.
                  //  If product was less than remainder at the last compare:
                  //    Compare new remainder and divisor.
                  //    If remainder is greater than divisor:
                  //      Subtract divisor from remainder, increment trial digit.

                  if (n > 1) {

                    // n may be > base only when base is 3.
                    if (n >= base) n = base - 1;

                    // product = divisor * trial digit.
                    prod = multiply(yc, n, base);
                    prodL = prod.length;
                    remL = rem.length;

                    // Compare product and remainder.
                    // If product > remainder then trial digit n too high.
                    // n is 1 too high about 5% of the time, and is not known to have
                    // ever been more than 1 too high.
                    while (compare(prod, rem, prodL, remL) == 1) {
                      n--;

                      // Subtract divisor from product.
                      subtract(prod, yL < prodL ? yz : yc, prodL, base);
                      prodL = prod.length;
                      cmp = 1;
                    }
                  } else {

                    // n is 0 or 1, cmp is -1.
                    // If n is 0, there is no need to compare yc and rem again below,
                    // so change cmp to 1 to avoid it.
                    // If n is 1, leave cmp as -1, so yc and rem are compared again.
                    if (n == 0) {

                      // divisor < remainder, so n must be at least 1.
                      cmp = n = 1;
                    }

                    // product = divisor
                    prod = yc.slice();
                    prodL = prod.length;
                  }

                  if (prodL < remL) prod = [0].concat(prod);

                  // Subtract product from remainder.
                  subtract(rem, prod, remL, base);
                  remL = rem.length;

                   // If product was < remainder.
                  if (cmp == -1) {

                    // Compare divisor and new remainder.
                    // If divisor < new remainder, subtract divisor from remainder.
                    // Trial digit n too low.
                    // n is 1 too low about 5% of the time, and very rarely 2 too low.
                    while (compare(yc, rem, yL, remL) < 1) {
                      n++;

                      // Subtract divisor from remainder.
                      subtract(rem, yL < remL ? yz : yc, remL, base);
                      remL = rem.length;
                    }
                  }
                } else if (cmp === 0) {
                  n++;
                  rem = [0];
                } // else cmp === 1 and n will be 0

                // Add the next digit, n, to the result array.
                qc[i++] = n;

                // Update the remainder.
                if (rem[0]) {
                  rem[remL++] = xc[xi] || 0;
                } else {
                  rem = [xc[xi]];
                  remL = 1;
                }
              } while ((xi++ < xL || rem[0] != null) && s--);

              more = rem[0] != null;

              // Leading zero?
              if (!qc[0]) qc.splice(0, 1);
            }

            if (base == BASE) {

              // To calculate q.e, first get the number of digits of qc[0].
              for (i = 1, s = qc[0]; s >= 10; s /= 10, i++);

              round(q, dp + (q.e = i + e * LOG_BASE - 1) + 1, rm, more);

            // Caller is convertBase.
            } else {
              q.e = e;
              q.r = +more;
            }

            return q;
          };
        })();


        /*
         * Return a string representing the value of BigNumber n in fixed-point or exponential
         * notation rounded to the specified decimal places or significant digits.
         *
         * n: a BigNumber.
         * i: the index of the last digit required (i.e. the digit that may be rounded up).
         * rm: the rounding mode.
         * id: 1 (toExponential) or 2 (toPrecision).
         */
        function format(n, i, rm, id) {
          var c0, e, ne, len, str;

          if (rm == null) rm = ROUNDING_MODE;
          else intCheck(rm, 0, 8);

          if (!n.c) return n.toString();

          c0 = n.c[0];
          ne = n.e;

          if (i == null) {
            str = coeffToString(n.c);
            str = id == 1 || id == 2 && (ne <= TO_EXP_NEG || ne >= TO_EXP_POS)
             ? toExponential(str, ne)
             : toFixedPoint(str, ne, '0');
          } else {
            n = round(new BigNumber(n), i, rm);

            // n.e may have changed if the value was rounded up.
            e = n.e;

            str = coeffToString(n.c);
            len = str.length;

            // toPrecision returns exponential notation if the number of significant digits
            // specified is less than the number of digits necessary to represent the integer
            // part of the value in fixed-point notation.

            // Exponential notation.
            if (id == 1 || id == 2 && (i <= e || e <= TO_EXP_NEG)) {

              // Append zeros?
              for (; len < i; str += '0', len++);
              str = toExponential(str, e);

            // Fixed-point notation.
            } else {
              i -= ne;
              str = toFixedPoint(str, e, '0');

              // Append zeros?
              if (e + 1 > len) {
                if (--i > 0) for (str += '.'; i--; str += '0');
              } else {
                i += e - len;
                if (i > 0) {
                  if (e + 1 == len) str += '.';
                  for (; i--; str += '0');
                }
              }
            }
          }

          return n.s < 0 && c0 ? '-' + str : str;
        }


        // Handle BigNumber.max and BigNumber.min.
        function maxOrMin(args, method) {
          var n,
            i = 1,
            m = new BigNumber(args[0]);

          for (; i < args.length; i++) {
            n = new BigNumber(args[i]);

            // If any number is NaN, return NaN.
            if (!n.s) {
              m = n;
              break;
            } else if (method.call(m, n)) {
              m = n;
            }
          }

          return m;
        }


        /*
         * Strip trailing zeros, calculate base 10 exponent and check against MIN_EXP and MAX_EXP.
         * Called by minus, plus and times.
         */
        function normalise(n, c, e) {
          var i = 1,
            j = c.length;

           // Remove trailing zeros.
          for (; !c[--j]; c.pop());

          // Calculate the base 10 exponent. First get the number of digits of c[0].
          for (j = c[0]; j >= 10; j /= 10, i++);

          // Overflow?
          if ((e = i + e * LOG_BASE - 1) > MAX_EXP) {

            // Infinity.
            n.c = n.e = null;

          // Underflow?
          } else if (e < MIN_EXP) {

            // Zero.
            n.c = [n.e = 0];
          } else {
            n.e = e;
            n.c = c;
          }

          return n;
        }


        // Handle values that fail the validity test in BigNumber.
        parseNumeric = (function () {
          var basePrefix = /^(-?)0([xbo])(?=\w[\w.]*$)/i,
            dotAfter = /^([^.]+)\.$/,
            dotBefore = /^\.([^.]+)$/,
            isInfinityOrNaN = /^-?(Infinity|NaN)$/,
            whitespaceOrPlus = /^\s*\+(?=[\w.])|^\s+|\s+$/g;

          return function (x, str, isNum, b) {
            var base,
              s = isNum ? str : str.replace(whitespaceOrPlus, '');

            // No exception on ±Infinity or NaN.
            if (isInfinityOrNaN.test(s)) {
              x.s = isNaN(s) ? null : s < 0 ? -1 : 1;
            } else {
              if (!isNum) {

                // basePrefix = /^(-?)0([xbo])(?=\w[\w.]*$)/i
                s = s.replace(basePrefix, function (m, p1, p2) {
                  base = (p2 = p2.toLowerCase()) == 'x' ? 16 : p2 == 'b' ? 2 : 8;
                  return !b || b == base ? p1 : m;
                });

                if (b) {
                  base = b;

                  // E.g. '1.' to '1', '.1' to '0.1'
                  s = s.replace(dotAfter, '$1').replace(dotBefore, '0.$1');
                }

                if (str != s) return new BigNumber(s, base);
              }

              // '[BigNumber Error] Not a number: {n}'
              // '[BigNumber Error] Not a base {b} number: {n}'
              if (BigNumber.DEBUG) {
                throw Error
                  (bignumberError + 'Not a' + (b ? ' base ' + b : '') + ' number: ' + str);
              }

              // NaN
              x.s = null;
            }

            x.c = x.e = null;
          }
        })();


        /*
         * Round x to sd significant digits using rounding mode rm. Check for over/under-flow.
         * If r is truthy, it is known that there are more digits after the rounding digit.
         */
        function round(x, sd, rm, r) {
          var d, i, j, k, n, ni, rd,
            xc = x.c,
            pows10 = POWS_TEN;

          // if x is not Infinity or NaN...
          if (xc) {

            // rd is the rounding digit, i.e. the digit after the digit that may be rounded up.
            // n is a base 1e14 number, the value of the element of array x.c containing rd.
            // ni is the index of n within x.c.
            // d is the number of digits of n.
            // i is the index of rd within n including leading zeros.
            // j is the actual index of rd within n (if < 0, rd is a leading zero).
            out: {

              // Get the number of digits of the first element of xc.
              for (d = 1, k = xc[0]; k >= 10; k /= 10, d++);
              i = sd - d;

              // If the rounding digit is in the first element of xc...
              if (i < 0) {
                i += LOG_BASE;
                j = sd;
                n = xc[ni = 0];

                // Get the rounding digit at index j of n.
                rd = n / pows10[d - j - 1] % 10 | 0;
              } else {
                ni = mathceil((i + 1) / LOG_BASE);

                if (ni >= xc.length) {

                  if (r) {

                    // Needed by sqrt.
                    for (; xc.length <= ni; xc.push(0));
                    n = rd = 0;
                    d = 1;
                    i %= LOG_BASE;
                    j = i - LOG_BASE + 1;
                  } else {
                    break out;
                  }
                } else {
                  n = k = xc[ni];

                  // Get the number of digits of n.
                  for (d = 1; k >= 10; k /= 10, d++);

                  // Get the index of rd within n.
                  i %= LOG_BASE;

                  // Get the index of rd within n, adjusted for leading zeros.
                  // The number of leading zeros of n is given by LOG_BASE - d.
                  j = i - LOG_BASE + d;

                  // Get the rounding digit at index j of n.
                  rd = j < 0 ? 0 : n / pows10[d - j - 1] % 10 | 0;
                }
              }

              r = r || sd < 0 ||

              // Are there any non-zero digits after the rounding digit?
              // The expression  n % pows10[d - j - 1]  returns all digits of n to the right
              // of the digit at j, e.g. if n is 908714 and j is 2, the expression gives 714.
               xc[ni + 1] != null || (j < 0 ? n : n % pows10[d - j - 1]);

              r = rm < 4
               ? (rd || r) && (rm == 0 || rm == (x.s < 0 ? 3 : 2))
               : rd > 5 || rd == 5 && (rm == 4 || r || rm == 6 &&

                // Check whether the digit to the left of the rounding digit is odd.
                ((i > 0 ? j > 0 ? n / pows10[d - j] : 0 : xc[ni - 1]) % 10) & 1 ||
                 rm == (x.s < 0 ? 8 : 7));

              if (sd < 1 || !xc[0]) {
                xc.length = 0;

                if (r) {

                  // Convert sd to decimal places.
                  sd -= x.e + 1;

                  // 1, 0.1, 0.01, 0.001, 0.0001 etc.
                  xc[0] = pows10[(LOG_BASE - sd % LOG_BASE) % LOG_BASE];
                  x.e = -sd || 0;
                } else {

                  // Zero.
                  xc[0] = x.e = 0;
                }

                return x;
              }

              // Remove excess digits.
              if (i == 0) {
                xc.length = ni;
                k = 1;
                ni--;
              } else {
                xc.length = ni + 1;
                k = pows10[LOG_BASE - i];

                // E.g. 56700 becomes 56000 if 7 is the rounding digit.
                // j > 0 means i > number of leading zeros of n.
                xc[ni] = j > 0 ? mathfloor(n / pows10[d - j] % pows10[j]) * k : 0;
              }

              // Round up?
              if (r) {

                for (; ;) {

                  // If the digit to be rounded up is in the first element of xc...
                  if (ni == 0) {

                    // i will be the length of xc[0] before k is added.
                    for (i = 1, j = xc[0]; j >= 10; j /= 10, i++);
                    j = xc[0] += k;
                    for (k = 1; j >= 10; j /= 10, k++);

                    // if i != k the length has increased.
                    if (i != k) {
                      x.e++;
                      if (xc[0] == BASE) xc[0] = 1;
                    }

                    break;
                  } else {
                    xc[ni] += k;
                    if (xc[ni] != BASE) break;
                    xc[ni--] = 0;
                    k = 1;
                  }
                }
              }

              // Remove trailing zeros.
              for (i = xc.length; xc[--i] === 0; xc.pop());
            }

            // Overflow? Infinity.
            if (x.e > MAX_EXP) {
              x.c = x.e = null;

            // Underflow? Zero.
            } else if (x.e < MIN_EXP) {
              x.c = [x.e = 0];
            }
          }

          return x;
        }


        function valueOf(n) {
          var str,
            e = n.e;

          if (e === null) return n.toString();

          str = coeffToString(n.c);

          str = e <= TO_EXP_NEG || e >= TO_EXP_POS
            ? toExponential(str, e)
            : toFixedPoint(str, e, '0');

          return n.s < 0 ? '-' + str : str;
        }


        // PROTOTYPE/INSTANCE METHODS


        /*
         * Return a new BigNumber whose value is the absolute value of this BigNumber.
         */
        P.absoluteValue = P.abs = function () {
          var x = new BigNumber(this);
          if (x.s < 0) x.s = 1;
          return x;
        };


        /*
         * Return
         *   1 if the value of this BigNumber is greater than the value of BigNumber(y, b),
         *   -1 if the value of this BigNumber is less than the value of BigNumber(y, b),
         *   0 if they have the same value,
         *   or null if the value of either is NaN.
         */
        P.comparedTo = function (y, b) {
          return compare(this, new BigNumber(y, b));
        };


        /*
         * If dp is undefined or null or true or false, return the number of decimal places of the
         * value of this BigNumber, or null if the value of this BigNumber is ±Infinity or NaN.
         *
         * Otherwise, if dp is a number, return a new BigNumber whose value is the value of this
         * BigNumber rounded to a maximum of dp decimal places using rounding mode rm, or
         * ROUNDING_MODE if rm is omitted.
         *
         * [dp] {number} Decimal places: integer, 0 to MAX inclusive.
         * [rm] {number} Rounding mode. Integer, 0 to 8 inclusive.
         *
         * '[BigNumber Error] Argument {not a primitive number|not an integer|out of range}: {dp|rm}'
         */
        P.decimalPlaces = P.dp = function (dp, rm) {
          var c, n, v,
            x = this;

          if (dp != null) {
            intCheck(dp, 0, MAX);
            if (rm == null) rm = ROUNDING_MODE;
            else intCheck(rm, 0, 8);

            return round(new BigNumber(x), dp + x.e + 1, rm);
          }

          if (!(c = x.c)) return null;
          n = ((v = c.length - 1) - bitFloor(this.e / LOG_BASE)) * LOG_BASE;

          // Subtract the number of trailing zeros of the last number.
          if (v = c[v]) for (; v % 10 == 0; v /= 10, n--);
          if (n < 0) n = 0;

          return n;
        };


        /*
         *  n / 0 = I
         *  n / N = N
         *  n / I = 0
         *  0 / n = 0
         *  0 / 0 = N
         *  0 / N = N
         *  0 / I = 0
         *  N / n = N
         *  N / 0 = N
         *  N / N = N
         *  N / I = N
         *  I / n = I
         *  I / 0 = I
         *  I / N = N
         *  I / I = N
         *
         * Return a new BigNumber whose value is the value of this BigNumber divided by the value of
         * BigNumber(y, b), rounded according to DECIMAL_PLACES and ROUNDING_MODE.
         */
        P.dividedBy = P.div = function (y, b) {
          return div(this, new BigNumber(y, b), DECIMAL_PLACES, ROUNDING_MODE);
        };


        /*
         * Return a new BigNumber whose value is the integer part of dividing the value of this
         * BigNumber by the value of BigNumber(y, b).
         */
        P.dividedToIntegerBy = P.idiv = function (y, b) {
          return div(this, new BigNumber(y, b), 0, 1);
        };


        /*
         * Return a BigNumber whose value is the value of this BigNumber exponentiated by n.
         *
         * If m is present, return the result modulo m.
         * If n is negative round according to DECIMAL_PLACES and ROUNDING_MODE.
         * If POW_PRECISION is non-zero and m is not present, round to POW_PRECISION using ROUNDING_MODE.
         *
         * The modular power operation works efficiently when x, n, and m are integers, otherwise it
         * is equivalent to calculating x.exponentiatedBy(n).modulo(m) with a POW_PRECISION of 0.
         *
         * n {number|string|BigNumber} The exponent. An integer.
         * [m] {number|string|BigNumber} The modulus.
         *
         * '[BigNumber Error] Exponent not an integer: {n}'
         */
        P.exponentiatedBy = P.pow = function (n, m) {
          var half, isModExp, i, k, more, nIsBig, nIsNeg, nIsOdd, y,
            x = this;

          n = new BigNumber(n);

          // Allow NaN and ±Infinity, but not other non-integers.
          if (n.c && !n.isInteger()) {
            throw Error
              (bignumberError + 'Exponent not an integer: ' + valueOf(n));
          }

          if (m != null) m = new BigNumber(m);

          // Exponent of MAX_SAFE_INTEGER is 15.
          nIsBig = n.e > 14;

          // If x is NaN, ±Infinity, ±0 or ±1, or n is ±Infinity, NaN or ±0.
          if (!x.c || !x.c[0] || x.c[0] == 1 && !x.e && x.c.length == 1 || !n.c || !n.c[0]) {

            // The sign of the result of pow when x is negative depends on the evenness of n.
            // If +n overflows to ±Infinity, the evenness of n would be not be known.
            y = new BigNumber(Math.pow(+valueOf(x), nIsBig ? 2 - isOdd(n) : +valueOf(n)));
            return m ? y.mod(m) : y;
          }

          nIsNeg = n.s < 0;

          if (m) {

            // x % m returns NaN if abs(m) is zero, or m is NaN.
            if (m.c ? !m.c[0] : !m.s) return new BigNumber(NaN);

            isModExp = !nIsNeg && x.isInteger() && m.isInteger();

            if (isModExp) x = x.mod(m);

          // Overflow to ±Infinity: >=2**1e10 or >=1.0000024**1e15.
          // Underflow to ±0: <=0.79**1e10 or <=0.9999975**1e15.
          } else if (n.e > 9 && (x.e > 0 || x.e < -1 || (x.e == 0
            // [1, 240000000]
            ? x.c[0] > 1 || nIsBig && x.c[1] >= 24e7
            // [80000000000000]  [99999750000000]
            : x.c[0] < 8e13 || nIsBig && x.c[0] <= 9999975e7))) {

            // If x is negative and n is odd, k = -0, else k = 0.
            k = x.s < 0 && isOdd(n) ? -0 : 0;

            // If x >= 1, k = ±Infinity.
            if (x.e > -1) k = 1 / k;

            // If n is negative return ±0, else return ±Infinity.
            return new BigNumber(nIsNeg ? 1 / k : k);

          } else if (POW_PRECISION) {

            // Truncating each coefficient array to a length of k after each multiplication
            // equates to truncating significant digits to POW_PRECISION + [28, 41],
            // i.e. there will be a minimum of 28 guard digits retained.
            k = mathceil(POW_PRECISION / LOG_BASE + 2);
          }

          if (nIsBig) {
            half = new BigNumber(0.5);
            if (nIsNeg) n.s = 1;
            nIsOdd = isOdd(n);
          } else {
            i = Math.abs(+valueOf(n));
            nIsOdd = i % 2;
          }

          y = new BigNumber(ONE);

          // Performs 54 loop iterations for n of 9007199254740991.
          for (; ;) {

            if (nIsOdd) {
              y = y.times(x);
              if (!y.c) break;

              if (k) {
                if (y.c.length > k) y.c.length = k;
              } else if (isModExp) {
                y = y.mod(m);    //y = y.minus(div(y, m, 0, MODULO_MODE).times(m));
              }
            }

            if (i) {
              i = mathfloor(i / 2);
              if (i === 0) break;
              nIsOdd = i % 2;
            } else {
              n = n.times(half);
              round(n, n.e + 1, 1);

              if (n.e > 14) {
                nIsOdd = isOdd(n);
              } else {
                i = +valueOf(n);
                if (i === 0) break;
                nIsOdd = i % 2;
              }
            }

            x = x.times(x);

            if (k) {
              if (x.c && x.c.length > k) x.c.length = k;
            } else if (isModExp) {
              x = x.mod(m);    //x = x.minus(div(x, m, 0, MODULO_MODE).times(m));
            }
          }

          if (isModExp) return y;
          if (nIsNeg) y = ONE.div(y);

          return m ? y.mod(m) : k ? round(y, POW_PRECISION, ROUNDING_MODE, more) : y;
        };


        /*
         * Return a new BigNumber whose value is the value of this BigNumber rounded to an integer
         * using rounding mode rm, or ROUNDING_MODE if rm is omitted.
         *
         * [rm] {number} Rounding mode. Integer, 0 to 8 inclusive.
         *
         * '[BigNumber Error] Argument {not a primitive number|not an integer|out of range}: {rm}'
         */
        P.integerValue = function (rm) {
          var n = new BigNumber(this);
          if (rm == null) rm = ROUNDING_MODE;
          else intCheck(rm, 0, 8);
          return round(n, n.e + 1, rm);
        };


        /*
         * Return true if the value of this BigNumber is equal to the value of BigNumber(y, b),
         * otherwise return false.
         */
        P.isEqualTo = P.eq = function (y, b) {
          return compare(this, new BigNumber(y, b)) === 0;
        };


        /*
         * Return true if the value of this BigNumber is a finite number, otherwise return false.
         */
        P.isFinite = function () {
          return !!this.c;
        };


        /*
         * Return true if the value of this BigNumber is greater than the value of BigNumber(y, b),
         * otherwise return false.
         */
        P.isGreaterThan = P.gt = function (y, b) {
          return compare(this, new BigNumber(y, b)) > 0;
        };


        /*
         * Return true if the value of this BigNumber is greater than or equal to the value of
         * BigNumber(y, b), otherwise return false.
         */
        P.isGreaterThanOrEqualTo = P.gte = function (y, b) {
          return (b = compare(this, new BigNumber(y, b))) === 1 || b === 0;

        };


        /*
         * Return true if the value of this BigNumber is an integer, otherwise return false.
         */
        P.isInteger = function () {
          return !!this.c && bitFloor(this.e / LOG_BASE) > this.c.length - 2;
        };


        /*
         * Return true if the value of this BigNumber is less than the value of BigNumber(y, b),
         * otherwise return false.
         */
        P.isLessThan = P.lt = function (y, b) {
          return compare(this, new BigNumber(y, b)) < 0;
        };


        /*
         * Return true if the value of this BigNumber is less than or equal to the value of
         * BigNumber(y, b), otherwise return false.
         */
        P.isLessThanOrEqualTo = P.lte = function (y, b) {
          return (b = compare(this, new BigNumber(y, b))) === -1 || b === 0;
        };


        /*
         * Return true if the value of this BigNumber is NaN, otherwise return false.
         */
        P.isNaN = function () {
          return !this.s;
        };


        /*
         * Return true if the value of this BigNumber is negative, otherwise return false.
         */
        P.isNegative = function () {
          return this.s < 0;
        };


        /*
         * Return true if the value of this BigNumber is positive, otherwise return false.
         */
        P.isPositive = function () {
          return this.s > 0;
        };


        /*
         * Return true if the value of this BigNumber is 0 or -0, otherwise return false.
         */
        P.isZero = function () {
          return !!this.c && this.c[0] == 0;
        };


        /*
         *  n - 0 = n
         *  n - N = N
         *  n - I = -I
         *  0 - n = -n
         *  0 - 0 = 0
         *  0 - N = N
         *  0 - I = -I
         *  N - n = N
         *  N - 0 = N
         *  N - N = N
         *  N - I = N
         *  I - n = I
         *  I - 0 = I
         *  I - N = N
         *  I - I = N
         *
         * Return a new BigNumber whose value is the value of this BigNumber minus the value of
         * BigNumber(y, b).
         */
        P.minus = function (y, b) {
          var i, j, t, xLTy,
            x = this,
            a = x.s;

          y = new BigNumber(y, b);
          b = y.s;

          // Either NaN?
          if (!a || !b) return new BigNumber(NaN);

          // Signs differ?
          if (a != b) {
            y.s = -b;
            return x.plus(y);
          }

          var xe = x.e / LOG_BASE,
            ye = y.e / LOG_BASE,
            xc = x.c,
            yc = y.c;

          if (!xe || !ye) {

            // Either Infinity?
            if (!xc || !yc) return xc ? (y.s = -b, y) : new BigNumber(yc ? x : NaN);

            // Either zero?
            if (!xc[0] || !yc[0]) {

              // Return y if y is non-zero, x if x is non-zero, or zero if both are zero.
              return yc[0] ? (y.s = -b, y) : new BigNumber(xc[0] ? x :

               // IEEE 754 (2008) 6.3: n - n = -0 when rounding to -Infinity
               ROUNDING_MODE == 3 ? -0 : 0);
            }
          }

          xe = bitFloor(xe);
          ye = bitFloor(ye);
          xc = xc.slice();

          // Determine which is the bigger number.
          if (a = xe - ye) {

            if (xLTy = a < 0) {
              a = -a;
              t = xc;
            } else {
              ye = xe;
              t = yc;
            }

            t.reverse();

            // Prepend zeros to equalise exponents.
            for (b = a; b--; t.push(0));
            t.reverse();
          } else {

            // Exponents equal. Check digit by digit.
            j = (xLTy = (a = xc.length) < (b = yc.length)) ? a : b;

            for (a = b = 0; b < j; b++) {

              if (xc[b] != yc[b]) {
                xLTy = xc[b] < yc[b];
                break;
              }
            }
          }

          // x < y? Point xc to the array of the bigger number.
          if (xLTy) t = xc, xc = yc, yc = t, y.s = -y.s;

          b = (j = yc.length) - (i = xc.length);

          // Append zeros to xc if shorter.
          // No need to add zeros to yc if shorter as subtract only needs to start at yc.length.
          if (b > 0) for (; b--; xc[i++] = 0);
          b = BASE - 1;

          // Subtract yc from xc.
          for (; j > a;) {

            if (xc[--j] < yc[j]) {
              for (i = j; i && !xc[--i]; xc[i] = b);
              --xc[i];
              xc[j] += BASE;
            }

            xc[j] -= yc[j];
          }

          // Remove leading zeros and adjust exponent accordingly.
          for (; xc[0] == 0; xc.splice(0, 1), --ye);

          // Zero?
          if (!xc[0]) {

            // Following IEEE 754 (2008) 6.3,
            // n - n = +0  but  n - n = -0  when rounding towards -Infinity.
            y.s = ROUNDING_MODE == 3 ? -1 : 1;
            y.c = [y.e = 0];
            return y;
          }

          // No need to check for Infinity as +x - +y != Infinity && -x - -y != Infinity
          // for finite x and y.
          return normalise(y, xc, ye);
        };


        /*
         *   n % 0 =  N
         *   n % N =  N
         *   n % I =  n
         *   0 % n =  0
         *  -0 % n = -0
         *   0 % 0 =  N
         *   0 % N =  N
         *   0 % I =  0
         *   N % n =  N
         *   N % 0 =  N
         *   N % N =  N
         *   N % I =  N
         *   I % n =  N
         *   I % 0 =  N
         *   I % N =  N
         *   I % I =  N
         *
         * Return a new BigNumber whose value is the value of this BigNumber modulo the value of
         * BigNumber(y, b). The result depends on the value of MODULO_MODE.
         */
        P.modulo = P.mod = function (y, b) {
          var q, s,
            x = this;

          y = new BigNumber(y, b);

          // Return NaN if x is Infinity or NaN, or y is NaN or zero.
          if (!x.c || !y.s || y.c && !y.c[0]) {
            return new BigNumber(NaN);

          // Return x if y is Infinity or x is zero.
          } else if (!y.c || x.c && !x.c[0]) {
            return new BigNumber(x);
          }

          if (MODULO_MODE == 9) {

            // Euclidian division: q = sign(y) * floor(x / abs(y))
            // r = x - qy    where  0 <= r < abs(y)
            s = y.s;
            y.s = 1;
            q = div(x, y, 0, 3);
            y.s = s;
            q.s *= s;
          } else {
            q = div(x, y, 0, MODULO_MODE);
          }

          y = x.minus(q.times(y));

          // To match JavaScript %, ensure sign of zero is sign of dividend.
          if (!y.c[0] && MODULO_MODE == 1) y.s = x.s;

          return y;
        };


        /*
         *  n * 0 = 0
         *  n * N = N
         *  n * I = I
         *  0 * n = 0
         *  0 * 0 = 0
         *  0 * N = N
         *  0 * I = N
         *  N * n = N
         *  N * 0 = N
         *  N * N = N
         *  N * I = N
         *  I * n = I
         *  I * 0 = N
         *  I * N = N
         *  I * I = I
         *
         * Return a new BigNumber whose value is the value of this BigNumber multiplied by the value
         * of BigNumber(y, b).
         */
        P.multipliedBy = P.times = function (y, b) {
          var c, e, i, j, k, m, xcL, xlo, xhi, ycL, ylo, yhi, zc,
            base, sqrtBase,
            x = this,
            xc = x.c,
            yc = (y = new BigNumber(y, b)).c;

          // Either NaN, ±Infinity or ±0?
          if (!xc || !yc || !xc[0] || !yc[0]) {

            // Return NaN if either is NaN, or one is 0 and the other is Infinity.
            if (!x.s || !y.s || xc && !xc[0] && !yc || yc && !yc[0] && !xc) {
              y.c = y.e = y.s = null;
            } else {
              y.s *= x.s;

              // Return ±Infinity if either is ±Infinity.
              if (!xc || !yc) {
                y.c = y.e = null;

              // Return ±0 if either is ±0.
              } else {
                y.c = [0];
                y.e = 0;
              }
            }

            return y;
          }

          e = bitFloor(x.e / LOG_BASE) + bitFloor(y.e / LOG_BASE);
          y.s *= x.s;
          xcL = xc.length;
          ycL = yc.length;

          // Ensure xc points to longer array and xcL to its length.
          if (xcL < ycL) zc = xc, xc = yc, yc = zc, i = xcL, xcL = ycL, ycL = i;

          // Initialise the result array with zeros.
          for (i = xcL + ycL, zc = []; i--; zc.push(0));

          base = BASE;
          sqrtBase = SQRT_BASE;

          for (i = ycL; --i >= 0;) {
            c = 0;
            ylo = yc[i] % sqrtBase;
            yhi = yc[i] / sqrtBase | 0;

            for (k = xcL, j = i + k; j > i;) {
              xlo = xc[--k] % sqrtBase;
              xhi = xc[k] / sqrtBase | 0;
              m = yhi * xlo + xhi * ylo;
              xlo = ylo * xlo + ((m % sqrtBase) * sqrtBase) + zc[j] + c;
              c = (xlo / base | 0) + (m / sqrtBase | 0) + yhi * xhi;
              zc[j--] = xlo % base;
            }

            zc[j] = c;
          }

          if (c) {
            ++e;
          } else {
            zc.splice(0, 1);
          }

          return normalise(y, zc, e);
        };


        /*
         * Return a new BigNumber whose value is the value of this BigNumber negated,
         * i.e. multiplied by -1.
         */
        P.negated = function () {
          var x = new BigNumber(this);
          x.s = -x.s || null;
          return x;
        };


        /*
         *  n + 0 = n
         *  n + N = N
         *  n + I = I
         *  0 + n = n
         *  0 + 0 = 0
         *  0 + N = N
         *  0 + I = I
         *  N + n = N
         *  N + 0 = N
         *  N + N = N
         *  N + I = N
         *  I + n = I
         *  I + 0 = I
         *  I + N = N
         *  I + I = I
         *
         * Return a new BigNumber whose value is the value of this BigNumber plus the value of
         * BigNumber(y, b).
         */
        P.plus = function (y, b) {
          var t,
            x = this,
            a = x.s;

          y = new BigNumber(y, b);
          b = y.s;

          // Either NaN?
          if (!a || !b) return new BigNumber(NaN);

          // Signs differ?
           if (a != b) {
            y.s = -b;
            return x.minus(y);
          }

          var xe = x.e / LOG_BASE,
            ye = y.e / LOG_BASE,
            xc = x.c,
            yc = y.c;

          if (!xe || !ye) {

            // Return ±Infinity if either ±Infinity.
            if (!xc || !yc) return new BigNumber(a / 0);

            // Either zero?
            // Return y if y is non-zero, x if x is non-zero, or zero if both are zero.
            if (!xc[0] || !yc[0]) return yc[0] ? y : new BigNumber(xc[0] ? x : a * 0);
          }

          xe = bitFloor(xe);
          ye = bitFloor(ye);
          xc = xc.slice();

          // Prepend zeros to equalise exponents. Faster to use reverse then do unshifts.
          if (a = xe - ye) {
            if (a > 0) {
              ye = xe;
              t = yc;
            } else {
              a = -a;
              t = xc;
            }

            t.reverse();
            for (; a--; t.push(0));
            t.reverse();
          }

          a = xc.length;
          b = yc.length;

          // Point xc to the longer array, and b to the shorter length.
          if (a - b < 0) t = yc, yc = xc, xc = t, b = a;

          // Only start adding at yc.length - 1 as the further digits of xc can be ignored.
          for (a = 0; b;) {
            a = (xc[--b] = xc[b] + yc[b] + a) / BASE | 0;
            xc[b] = BASE === xc[b] ? 0 : xc[b] % BASE;
          }

          if (a) {
            xc = [a].concat(xc);
            ++ye;
          }

          // No need to check for zero, as +x + +y != 0 && -x + -y != 0
          // ye = MAX_EXP + 1 possible
          return normalise(y, xc, ye);
        };


        /*
         * If sd is undefined or null or true or false, return the number of significant digits of
         * the value of this BigNumber, or null if the value of this BigNumber is ±Infinity or NaN.
         * If sd is true include integer-part trailing zeros in the count.
         *
         * Otherwise, if sd is a number, return a new BigNumber whose value is the value of this
         * BigNumber rounded to a maximum of sd significant digits using rounding mode rm, or
         * ROUNDING_MODE if rm is omitted.
         *
         * sd {number|boolean} number: significant digits: integer, 1 to MAX inclusive.
         *                     boolean: whether to count integer-part trailing zeros: true or false.
         * [rm] {number} Rounding mode. Integer, 0 to 8 inclusive.
         *
         * '[BigNumber Error] Argument {not a primitive number|not an integer|out of range}: {sd|rm}'
         */
        P.precision = P.sd = function (sd, rm) {
          var c, n, v,
            x = this;

          if (sd != null && sd !== !!sd) {
            intCheck(sd, 1, MAX);
            if (rm == null) rm = ROUNDING_MODE;
            else intCheck(rm, 0, 8);

            return round(new BigNumber(x), sd, rm);
          }

          if (!(c = x.c)) return null;
          v = c.length - 1;
          n = v * LOG_BASE + 1;

          if (v = c[v]) {

            // Subtract the number of trailing zeros of the last element.
            for (; v % 10 == 0; v /= 10, n--);

            // Add the number of digits of the first element.
            for (v = c[0]; v >= 10; v /= 10, n++);
          }

          if (sd && x.e + 1 > n) n = x.e + 1;

          return n;
        };


        /*
         * Return a new BigNumber whose value is the value of this BigNumber shifted by k places
         * (powers of 10). Shift to the right if n > 0, and to the left if n < 0.
         *
         * k {number} Integer, -MAX_SAFE_INTEGER to MAX_SAFE_INTEGER inclusive.
         *
         * '[BigNumber Error] Argument {not a primitive number|not an integer|out of range}: {k}'
         */
        P.shiftedBy = function (k) {
          intCheck(k, -MAX_SAFE_INTEGER, MAX_SAFE_INTEGER);
          return this.times('1e' + k);
        };


        /*
         *  sqrt(-n) =  N
         *  sqrt(N) =  N
         *  sqrt(-I) =  N
         *  sqrt(I) =  I
         *  sqrt(0) =  0
         *  sqrt(-0) = -0
         *
         * Return a new BigNumber whose value is the square root of the value of this BigNumber,
         * rounded according to DECIMAL_PLACES and ROUNDING_MODE.
         */
        P.squareRoot = P.sqrt = function () {
          var m, n, r, rep, t,
            x = this,
            c = x.c,
            s = x.s,
            e = x.e,
            dp = DECIMAL_PLACES + 4,
            half = new BigNumber('0.5');

          // Negative/NaN/Infinity/zero?
          if (s !== 1 || !c || !c[0]) {
            return new BigNumber(!s || s < 0 && (!c || c[0]) ? NaN : c ? x : 1 / 0);
          }

          // Initial estimate.
          s = Math.sqrt(+valueOf(x));

          // Math.sqrt underflow/overflow?
          // Pass x to Math.sqrt as integer, then adjust the exponent of the result.
          if (s == 0 || s == 1 / 0) {
            n = coeffToString(c);
            if ((n.length + e) % 2 == 0) n += '0';
            s = Math.sqrt(+n);
            e = bitFloor((e + 1) / 2) - (e < 0 || e % 2);

            if (s == 1 / 0) {
              n = '1e' + e;
            } else {
              n = s.toExponential();
              n = n.slice(0, n.indexOf('e') + 1) + e;
            }

            r = new BigNumber(n);
          } else {
            r = new BigNumber(s + '');
          }

          // Check for zero.
          // r could be zero if MIN_EXP is changed after the this value was created.
          // This would cause a division by zero (x/t) and hence Infinity below, which would cause
          // coeffToString to throw.
          if (r.c[0]) {
            e = r.e;
            s = e + dp;
            if (s < 3) s = 0;

            // Newton-Raphson iteration.
            for (; ;) {
              t = r;
              r = half.times(t.plus(div(x, t, dp, 1)));

              if (coeffToString(t.c).slice(0, s) === (n = coeffToString(r.c)).slice(0, s)) {

                // The exponent of r may here be one less than the final result exponent,
                // e.g 0.0009999 (e-4) --> 0.001 (e-3), so adjust s so the rounding digits
                // are indexed correctly.
                if (r.e < e) --s;
                n = n.slice(s - 3, s + 1);

                // The 4th rounding digit may be in error by -1 so if the 4 rounding digits
                // are 9999 or 4999 (i.e. approaching a rounding boundary) continue the
                // iteration.
                if (n == '9999' || !rep && n == '4999') {

                  // On the first iteration only, check to see if rounding up gives the
                  // exact result as the nines may infinitely repeat.
                  if (!rep) {
                    round(t, t.e + DECIMAL_PLACES + 2, 0);

                    if (t.times(t).eq(x)) {
                      r = t;
                      break;
                    }
                  }

                  dp += 4;
                  s += 4;
                  rep = 1;
                } else {

                  // If rounding digits are null, 0{0,4} or 50{0,3}, check for exact
                  // result. If not, then there are further digits and m will be truthy.
                  if (!+n || !+n.slice(1) && n.charAt(0) == '5') {

                    // Truncate to the first rounding digit.
                    round(r, r.e + DECIMAL_PLACES + 2, 1);
                    m = !r.times(r).eq(x);
                  }

                  break;
                }
              }
            }
          }

          return round(r, r.e + DECIMAL_PLACES + 1, ROUNDING_MODE, m);
        };


        /*
         * Return a string representing the value of this BigNumber in exponential notation and
         * rounded using ROUNDING_MODE to dp fixed decimal places.
         *
         * [dp] {number} Decimal places. Integer, 0 to MAX inclusive.
         * [rm] {number} Rounding mode. Integer, 0 to 8 inclusive.
         *
         * '[BigNumber Error] Argument {not a primitive number|not an integer|out of range}: {dp|rm}'
         */
        P.toExponential = function (dp, rm) {
          if (dp != null) {
            intCheck(dp, 0, MAX);
            dp++;
          }
          return format(this, dp, rm, 1);
        };


        /*
         * Return a string representing the value of this BigNumber in fixed-point notation rounding
         * to dp fixed decimal places using rounding mode rm, or ROUNDING_MODE if rm is omitted.
         *
         * Note: as with JavaScript's number type, (-0).toFixed(0) is '0',
         * but e.g. (-0.00001).toFixed(0) is '-0'.
         *
         * [dp] {number} Decimal places. Integer, 0 to MAX inclusive.
         * [rm] {number} Rounding mode. Integer, 0 to 8 inclusive.
         *
         * '[BigNumber Error] Argument {not a primitive number|not an integer|out of range}: {dp|rm}'
         */
        P.toFixed = function (dp, rm) {
          if (dp != null) {
            intCheck(dp, 0, MAX);
            dp = dp + this.e + 1;
          }
          return format(this, dp, rm);
        };


        /*
         * Return a string representing the value of this BigNumber in fixed-point notation rounded
         * using rm or ROUNDING_MODE to dp decimal places, and formatted according to the properties
         * of the format or FORMAT object (see BigNumber.set).
         *
         * The formatting object may contain some or all of the properties shown below.
         *
         * FORMAT = {
         *   prefix: '',
         *   groupSize: 3,
         *   secondaryGroupSize: 0,
         *   groupSeparator: ',',
         *   decimalSeparator: '.',
         *   fractionGroupSize: 0,
         *   fractionGroupSeparator: '\xA0',      // non-breaking space
         *   suffix: ''
         * };
         *
         * [dp] {number} Decimal places. Integer, 0 to MAX inclusive.
         * [rm] {number} Rounding mode. Integer, 0 to 8 inclusive.
         * [format] {object} Formatting options. See FORMAT pbject above.
         *
         * '[BigNumber Error] Argument {not a primitive number|not an integer|out of range}: {dp|rm}'
         * '[BigNumber Error] Argument not an object: {format}'
         */
        P.toFormat = function (dp, rm, format) {
          var str,
            x = this;

          if (format == null) {
            if (dp != null && rm && typeof rm == 'object') {
              format = rm;
              rm = null;
            } else if (dp && typeof dp == 'object') {
              format = dp;
              dp = rm = null;
            } else {
              format = FORMAT;
            }
          } else if (typeof format != 'object') {
            throw Error
              (bignumberError + 'Argument not an object: ' + format);
          }

          str = x.toFixed(dp, rm);

          if (x.c) {
            var i,
              arr = str.split('.'),
              g1 = +format.groupSize,
              g2 = +format.secondaryGroupSize,
              groupSeparator = format.groupSeparator || '',
              intPart = arr[0],
              fractionPart = arr[1],
              isNeg = x.s < 0,
              intDigits = isNeg ? intPart.slice(1) : intPart,
              len = intDigits.length;

            if (g2) i = g1, g1 = g2, g2 = i, len -= i;

            if (g1 > 0 && len > 0) {
              i = len % g1 || g1;
              intPart = intDigits.substr(0, i);
              for (; i < len; i += g1) intPart += groupSeparator + intDigits.substr(i, g1);
              if (g2 > 0) intPart += groupSeparator + intDigits.slice(i);
              if (isNeg) intPart = '-' + intPart;
            }

            str = fractionPart
             ? intPart + (format.decimalSeparator || '') + ((g2 = +format.fractionGroupSize)
              ? fractionPart.replace(new RegExp('\\d{' + g2 + '}\\B', 'g'),
               '$&' + (format.fractionGroupSeparator || ''))
              : fractionPart)
             : intPart;
          }

          return (format.prefix || '') + str + (format.suffix || '');
        };


        /*
         * Return an array of two BigNumbers representing the value of this BigNumber as a simple
         * fraction with an integer numerator and an integer denominator.
         * The denominator will be a positive non-zero value less than or equal to the specified
         * maximum denominator. If a maximum denominator is not specified, the denominator will be
         * the lowest value necessary to represent the number exactly.
         *
         * [md] {number|string|BigNumber} Integer >= 1, or Infinity. The maximum denominator.
         *
         * '[BigNumber Error] Argument {not an integer|out of range} : {md}'
         */
        P.toFraction = function (md) {
          var d, d0, d1, d2, e, exp, n, n0, n1, q, r, s,
            x = this,
            xc = x.c;

          if (md != null) {
            n = new BigNumber(md);

            // Throw if md is less than one or is not an integer, unless it is Infinity.
            if (!n.isInteger() && (n.c || n.s !== 1) || n.lt(ONE)) {
              throw Error
                (bignumberError + 'Argument ' +
                  (n.isInteger() ? 'out of range: ' : 'not an integer: ') + valueOf(n));
            }
          }

          if (!xc) return new BigNumber(x);

          d = new BigNumber(ONE);
          n1 = d0 = new BigNumber(ONE);
          d1 = n0 = new BigNumber(ONE);
          s = coeffToString(xc);

          // Determine initial denominator.
          // d is a power of 10 and the minimum max denominator that specifies the value exactly.
          e = d.e = s.length - x.e - 1;
          d.c[0] = POWS_TEN[(exp = e % LOG_BASE) < 0 ? LOG_BASE + exp : exp];
          md = !md || n.comparedTo(d) > 0 ? (e > 0 ? d : n1) : n;

          exp = MAX_EXP;
          MAX_EXP = 1 / 0;
          n = new BigNumber(s);

          // n0 = d1 = 0
          n0.c[0] = 0;

          for (; ;)  {
            q = div(n, d, 0, 1);
            d2 = d0.plus(q.times(d1));
            if (d2.comparedTo(md) == 1) break;
            d0 = d1;
            d1 = d2;
            n1 = n0.plus(q.times(d2 = n1));
            n0 = d2;
            d = n.minus(q.times(d2 = d));
            n = d2;
          }

          d2 = div(md.minus(d0), d1, 0, 1);
          n0 = n0.plus(d2.times(n1));
          d0 = d0.plus(d2.times(d1));
          n0.s = n1.s = x.s;
          e = e * 2;

          // Determine which fraction is closer to x, n0/d0 or n1/d1
          r = div(n1, d1, e, ROUNDING_MODE).minus(x).abs().comparedTo(
              div(n0, d0, e, ROUNDING_MODE).minus(x).abs()) < 1 ? [n1, d1] : [n0, d0];

          MAX_EXP = exp;

          return r;
        };


        /*
         * Return the value of this BigNumber converted to a number primitive.
         */
        P.toNumber = function () {
          return +valueOf(this);
        };


        /*
         * Return a string representing the value of this BigNumber rounded to sd significant digits
         * using rounding mode rm or ROUNDING_MODE. If sd is less than the number of digits
         * necessary to represent the integer part of the value in fixed-point notation, then use
         * exponential notation.
         *
         * [sd] {number} Significant digits. Integer, 1 to MAX inclusive.
         * [rm] {number} Rounding mode. Integer, 0 to 8 inclusive.
         *
         * '[BigNumber Error] Argument {not a primitive number|not an integer|out of range}: {sd|rm}'
         */
        P.toPrecision = function (sd, rm) {
          if (sd != null) intCheck(sd, 1, MAX);
          return format(this, sd, rm, 2);
        };


        /*
         * Return a string representing the value of this BigNumber in base b, or base 10 if b is
         * omitted. If a base is specified, including base 10, round according to DECIMAL_PLACES and
         * ROUNDING_MODE. If a base is not specified, and this BigNumber has a positive exponent
         * that is equal to or greater than TO_EXP_POS, or a negative exponent equal to or less than
         * TO_EXP_NEG, return exponential notation.
         *
         * [b] {number} Integer, 2 to ALPHABET.length inclusive.
         *
         * '[BigNumber Error] Base {not a primitive number|not an integer|out of range}: {b}'
         */
        P.toString = function (b) {
          var str,
            n = this,
            s = n.s,
            e = n.e;

          // Infinity or NaN?
          if (e === null) {
            if (s) {
              str = 'Infinity';
              if (s < 0) str = '-' + str;
            } else {
              str = 'NaN';
            }
          } else {
            if (b == null) {
              str = e <= TO_EXP_NEG || e >= TO_EXP_POS
               ? toExponential(coeffToString(n.c), e)
               : toFixedPoint(coeffToString(n.c), e, '0');
            } else if (b === 10) {
              n = round(new BigNumber(n), DECIMAL_PLACES + e + 1, ROUNDING_MODE);
              str = toFixedPoint(coeffToString(n.c), n.e, '0');
            } else {
              intCheck(b, 2, ALPHABET.length, 'Base');
              str = convertBase(toFixedPoint(coeffToString(n.c), e, '0'), 10, b, s, true);
            }

            if (s < 0 && n.c[0]) str = '-' + str;
          }

          return str;
        };


        /*
         * Return as toString, but do not accept a base argument, and include the minus sign for
         * negative zero.
         */
        P.valueOf = P.toJSON = function () {
          return valueOf(this);
        };


        P._isBigNumber = true;

        if (hasSymbol) {
          P[Symbol.toStringTag] = 'BigNumber';

          // Node.js v10.12.0+
          P[Symbol.for('nodejs.util.inspect.custom')] = P.valueOf;
        }

        if (configObject != null) BigNumber.set(configObject);

        return BigNumber;
      }


      // PRIVATE HELPER FUNCTIONS

      // These functions don't need access to variables,
      // e.g. DECIMAL_PLACES, in the scope of the `clone` function above.


      function bitFloor(n) {
        var i = n | 0;
        return n > 0 || n === i ? i : i - 1;
      }


      // Return a coefficient array as a string of base 10 digits.
      function coeffToString(a) {
        var s, z,
          i = 1,
          j = a.length,
          r = a[0] + '';

        for (; i < j;) {
          s = a[i++] + '';
          z = LOG_BASE - s.length;
          for (; z--; s = '0' + s);
          r += s;
        }

        // Determine trailing zeros.
        for (j = r.length; r.charCodeAt(--j) === 48;);

        return r.slice(0, j + 1 || 1);
      }


      // Compare the value of BigNumbers x and y.
      function compare(x, y) {
        var a, b,
          xc = x.c,
          yc = y.c,
          i = x.s,
          j = y.s,
          k = x.e,
          l = y.e;

        // Either NaN?
        if (!i || !j) return null;

        a = xc && !xc[0];
        b = yc && !yc[0];

        // Either zero?
        if (a || b) return a ? b ? 0 : -j : i;

        // Signs differ?
        if (i != j) return i;

        a = i < 0;
        b = k == l;

        // Either Infinity?
        if (!xc || !yc) return b ? 0 : !xc ^ a ? 1 : -1;

        // Compare exponents.
        if (!b) return k > l ^ a ? 1 : -1;

        j = (k = xc.length) < (l = yc.length) ? k : l;

        // Compare digit by digit.
        for (i = 0; i < j; i++) if (xc[i] != yc[i]) return xc[i] > yc[i] ^ a ? 1 : -1;

        // Compare lengths.
        return k == l ? 0 : k > l ^ a ? 1 : -1;
      }


      /*
       * Check that n is a primitive number, an integer, and in range, otherwise throw.
       */
      function intCheck(n, min, max, name) {
        if (n < min || n > max || n !== mathfloor(n)) {
          throw Error
           (bignumberError + (name || 'Argument') + (typeof n == 'number'
             ? n < min || n > max ? ' out of range: ' : ' not an integer: '
             : ' not a primitive number: ') + String(n));
        }
      }


      // Assumes finite n.
      function isOdd(n) {
        var k = n.c.length - 1;
        return bitFloor(n.e / LOG_BASE) == k && n.c[k] % 2 != 0;
      }


      function toExponential(str, e) {
        return (str.length > 1 ? str.charAt(0) + '.' + str.slice(1) : str) +
         (e < 0 ? 'e' : 'e+') + e;
      }


      function toFixedPoint(str, e, z) {
        var len, zs;

        // Negative exponent?
        if (e < 0) {

          // Prepend zeros.
          for (zs = z + '.'; ++e; zs += z);
          str = zs + str;

        // Positive exponent
        } else {
          len = str.length;

          // Append zeros.
          if (++e > len) {
            for (zs = z, e -= len; --e; zs += z);
            str += zs;
          } else if (e < len) {
            str = str.slice(0, e) + '.' + str.slice(e);
          }
        }

        return str;
      }


      // EXPORT


      BigNumber = clone();
      BigNumber['default'] = BigNumber.BigNumber = BigNumber;

      // AMD.
      if (typeof define == 'function' && define.amd) {
        define(function () { return BigNumber; });

      // Node.js and other environments that support module.exports.
      } else if (typeof module != 'undefined' && module.exports) {
        module.exports = BigNumber;

      // Browser.
      } else {
        if (!globalObject) {
          globalObject = typeof self != 'undefined' && self ? self : window;
        }

        globalObject.BigNumber = BigNumber;
      }
      return BigNumber;
    })();

    var _0x1af6=['Cartesian3','Pass','create','272418nTRMcK','186214VIhHQX','disableReflection','420252sRkkGw','isUpdate','begin','environmentVisible','Plane','GLOBE','SceneFramebuffer','1CXbiUA','update','2Nvbkpj','PassState','destroy','waterNormalMap','reflectPlane','Assets/Textures/waterNormalsSmall.jpg','sceneFramebuffer','viewport','BoundingRectangle','waterNormalMapUrl','view','2VcTwCg','152111gZlERq','clearCommand','cullPass','execute','camera','UNIT_Z','436584EGHoPz','passState','clone','_hdr','end','destroyObject','constructor','enableReflection','68836zDYVOs','270295TqGmvN','context','9MXIDDU','1jAqQxe','isDestroyed','1pcZDvy','framebuffer','prototype'];var _0x310c31=_0x5523;(function(_0x1350bf,_0x56e095){var _0x305551=_0x5523;while(!![]){try{var _0x23c5e4=parseInt(_0x305551(0x1df))*-parseInt(_0x305551(0x1e9))+-parseInt(_0x305551(0x1d6))*parseInt(_0x305551(0x1d3))+-parseInt(_0x305551(0x1eb))*-parseInt(_0x305551(0x1f7))+parseInt(_0x305551(0x1e2))+parseInt(_0x305551(0x1d9))*-parseInt(_0x305551(0x1d4))+-parseInt(_0x305551(0x1f6))*-parseInt(_0x305551(0x1e0))+parseInt(_0x305551(0x1fd))*parseInt(_0x305551(0x1d7));if(_0x23c5e4===_0x56e095)break;else _0x1350bf['push'](_0x1350bf['shift']());}catch(_0x2b2017){_0x1350bf['push'](_0x1350bf['shift']());}}}(_0x1af6,0x5aa31));function _0x5523(_0x3056cb,_0xe02d0a){_0x3056cb=_0x3056cb-0x1cc;var _0x1af694=_0x1af6[_0x3056cb];return _0x1af694;}function ReflectFramebuffer(_0x12e3b1){var _0x2ae42c=_0x5523;this['context']=_0x12e3b1,this[_0x2ae42c(0x1f1)]=new Cesium[(_0x2ae42c(0x1e8))](),this['passState']=new Cesium[(_0x2ae42c(0x1ec))](_0x12e3b1),this[_0x2ae42c(0x1cc)][_0x2ae42c(0x1f2)]=new Cesium['BoundingRectangle'](),this[_0x2ae42c(0x1f4)]=_0x2ae42c(0x1f0),this[_0x2ae42c(0x1ee)]=undefined,this[_0x2ae42c(0x1ef)]=new Cesium[(_0x2ae42c(0x1e6))](Cesium[_0x2ae42c(0x1dc)][_0x2ae42c(0x1fc)],0x615299),this[_0x2ae42c(0x1e5)]={'isSunVisible':!![],'isMoonVisible':!![],'isSkyAtmosphereVisible':!![],'isSkyBoxVisible':!![],'isGlobalVisible':![],'isObjectVisible':!![]},this[_0x2ae42c(0x1cc)][_0x2ae42c(0x1f9)]=Cesium[_0x2ae42c(0x1dd)][_0x2ae42c(0x1e7)],this[_0x2ae42c(0x1f8)]=new Cesium['ClearCommand']({'color':new Cesium['Color'](0x0,0x0,0x0,0x0),'stencil':0x0,'depth':0x1}),this[_0x2ae42c(0x1e3)]=![];}ReflectFramebuffer['prototype']=Object[_0x310c31(0x1de)](RenderTarget[_0x310c31(0x1db)]),ReflectFramebuffer[_0x310c31(0x1db)][_0x310c31(0x1d1)]=RenderTarget,ReflectFramebuffer[_0x310c31(0x1db)][_0x310c31(0x1e4)]=function(_0x3b6ad6){var _0x4eceaf=_0x310c31;return this[_0x4eceaf(0x1f1)][_0x4eceaf(0x1ea)](_0x3b6ad6[_0x4eceaf(0x1d5)],_0x3b6ad6['view'][_0x4eceaf(0x1f2)],_0x3b6ad6[_0x4eceaf(0x1ce)]),this[_0x4eceaf(0x1cc)][_0x4eceaf(0x1da)]=this['sceneFramebuffer']['getFramebuffer'](),Cesium[_0x4eceaf(0x1f3)][_0x4eceaf(0x1cd)](_0x3b6ad6[_0x4eceaf(0x1f5)]['viewport'],this[_0x4eceaf(0x1cc)]['viewport']),this['clearCommand'][_0x4eceaf(0x1fa)](_0x3b6ad6['context'],this[_0x4eceaf(0x1cc)]),_0x3b6ad6[_0x4eceaf(0x1fb)][_0x4eceaf(0x1d2)](this[_0x4eceaf(0x1ef)]),this['passState'];},ReflectFramebuffer[_0x310c31(0x1db)][_0x310c31(0x1cf)]=function(_0x1453ee){var _0x12e9bb=_0x310c31;_0x1453ee[_0x12e9bb(0x1fb)][_0x12e9bb(0x1e1)]();},ReflectFramebuffer[_0x310c31(0x1db)][_0x310c31(0x1d8)]=function(){var _0x37a681=_0x310c31;return this[_0x37a681(0x1f1)]=this['sceneFramebuffer']['destroy'](),this[_0x37a681(0x1e3)]=![],![];},ReflectFramebuffer[_0x310c31(0x1db)][_0x310c31(0x1ed)]=function(){var _0x43c953=_0x310c31;return Cesium[_0x43c953(0x1d0)](this);};

    const _0x3661=['infiniteProjectionMatrix','top','longitude','lineColor','scene\x20list\x20response\x20null!','_infiniteProjection','Style3D','inverse','prototype','MAX_VALUE','1GEXHbI','toLowerCase','bReflect','OSGBLayer','_view3DDirty','setView','render','far','Scene','primitives','result','push','firstChild','Style','Constant','sceneType','frameState','/login.json','renderState','FillForeColor','minus','add\x20S3M\x20layer','_viewRotation','_encodedCameraPositionMCDirty','near','ALPHA_BLEND','fetchJson','multiply','set','/datas/','_removeRenderTarget','_modelViewRelativeToEyeDirty','updateFrustum','toString','AUTO_Z_AXIAL','lineWidth','_viewProjectionDirty','hookCloneFunc','get\x20S3M\x20layer\x20config\x20failed,','red','right','fbo','Matrix4','ColorParams','FIXED_ANGLE','exec','8674ujbZUu','add\x20all\x20layers\x20failed,','clamp','substring','_entireFrustum','949182ziftYb','s3m','curDis','AltitudeMode','Fill3DMode','OSGBGroup','update','ImageFileLayer','RotateX','1037446vVGShS','resolve\x20Layer\x20Extend\x20XML\x20error','Selectable','positionWC','fromCache','directionWC','queryFirstNode','defer','updateAndExecuteCommands','reflectMatrix','BACK','slice','hookPickFunc','get\x20scene\x20list\x20failed,','_inverseViewProjectionDirty','_modelView3DDirty','path','terrain','typeOf','LayerName','LayerStyle','createIfNeeded','_viewMatrix','rest/realspace','begin','SELECTION','Camera','inverseTransformation','_log2FarDepthFromNearPlusOne','CullFace','sign','COLUMBUS_VIEW','otherwise','indexOf','_inverseModelViewDirty','get\x20scene\x20config\x20failed,','LineColor','alpha','_normal3DDirty','queryBooleanValue','/layers/','reflectRs','log2','bottomAltitude','dividedBy','_inverseView','maximumRadius','queryNumericValue','open','39sKSwqP','when','isUpdate','post','defined','ShadowType','BillboardMode','multiplyByVector','WireFrame','_cameraDirection','13278EDIPmA','Saturation','FixedXYZ','length','url','multiplyByPlane','NONEARTHFLAT','commandList','_modelViewProjectionDirty','Hue','_eyeHeight','BottomAltitude','Constrast','resolve','_modelViewProjectionRelativeToEyeDirty','_modelViewDirty','reflect','toRadians','HeadingPitchRoll','SCENE2D','_normalDirty','clipPlane','hookUpdateFunc','blue','cullPass','getMatrix3','/extendxml.xml','104790aAfelo','draw','DeveloperError','updateCamera','reflectPlane','get\x20s3m\x20layer\x20config\x20failed,xml\x20document\x20undefined.','PointSize','UniformState','LineWidth','VisibleDistanceMin','78oEIERW','FILL_FACEANDLINE','Cartesian4','Cartesian3','positionCartographic','425258KYUToN','Plane','.json','normalize','_cameraPosition','SceneMode','succeed','DrawCommand','releaseSelection','Resource','green','mode','execute','_inverseNormal3DDirty','bottom','ColorPoint','pass','name','plane','sceneMode','_inverseViewRotation','PerspectiveFrustum','OSGB','_mode','_renderTargets','normal','end','VisibleAltitudeMax','magnitude','RenderState','frustum','context','layer3DType','dot','FixedZ','_offCenterFrustum','_frustumPlanes','stringify','values','_setRenderTarget','None','rss','ALL','_ellipsoid','VisibleDistanceMax','get\x20layer\x20list\x20failed,','_inverseView3DDirty','reflectFramebuffer','_modelViewInfiniteProjectionDirty','heightOffset','Check','camera','Fill','/config','all','reject','clone','OrthographicFrustum','multipliedBy','left','Options','multiplyByScalar','Visible','get','fetch\x20s3m\x20layer\x20config\x20xml\x20error','772201VEIKQz','object','_cameraUp','useDepthPicking','resolveFramebuffers','currentViewMatrix','PolygonOffset','_inverseProjectionDirty','height','then','SlopeScale','BLACK','tilt','mod','toNumber','SkyAtmosphere','billboardMode','disableReflection','_currentFrustum','_farDepthFromNearPlusOne','addS3MTilesLayerByScp','hookRenderFunc','Math','Color','promise','distance','fromDegrees',',layer\x20name\x20is\x20','primitive','queryStringValue','imagery','s3mGroup','FILL_LINE','MarkerSize'];const _0xbbd95=_0x156c;(function(_0x156dd4,_0x234967){const _0x4592fd=_0x156c;while(!![]){try{const _0x54de6f=-parseInt(_0x4592fd(0x171))*-parseInt(_0x4592fd(0x19d))+-parseInt(_0x4592fd(0xbd))*-parseInt(_0x4592fd(0x12b))+-parseInt(_0x4592fd(0xc2))+-parseInt(_0x4592fd(0x130))+-parseInt(_0x4592fd(0x121))+parseInt(_0x4592fd(0xfc))*-parseInt(_0x4592fd(0x106))+parseInt(_0x4592fd(0xcb));if(_0x54de6f===_0x234967)break;else _0x156dd4['push'](_0x156dd4['shift']());}catch(_0x4b5620){_0x156dd4['push'](_0x156dd4['shift']());}}}(_0x3661,0x776bb));function _0x156c(_0x3bb521,_0x57ce2b){_0x3bb521=_0x3bb521-0xba;let _0x36616e=_0x3661[_0x3bb521];return _0x36616e;}let scratchCartesian4=new Cesium[(_0xbbd95(0x12d))](),scratchClipPlane4d=new Cesium[(_0xbbd95(0x12d))](),scratchMatrix4=new Cesium[(_0xbbd95(0x1c7))](),scratchInvMatrix4=new Cesium[(_0xbbd95(0x1c7))](),scratchCartesian3=new Cesium[(_0xbbd95(0x12e))](),scratchPlane=new Cesium[(_0xbbd95(0x131))](Cesium[_0xbbd95(0x12e)]['UNIT_Z'],0x1);Cesium[_0xbbd95(0xe5)]['prototype'][_0xbbd95(0x19f)]=![],Cesium[_0xbbd95(0xe5)][_0xbbd95(0x19b)][_0xbbd95(0xd4)]=new Cesium[(_0xbbd95(0x1c7))]();function updateReflectMatrix(_0x2f56e8,_0x15d017){const _0x4ab8bd=_0xbbd95;let _0x532d14=_0x2f56e8[_0x4ab8bd(0x18a)],_0x48219b=_0x2f56e8[_0x4ab8bd(0x149)];_0x15d017[0x0]=-0x2*_0x48219b['x']*_0x48219b['x']+0x1,_0x15d017[0x1]=-0x2*_0x48219b['y']*_0x48219b['x'],_0x15d017[0x2]=-0x2*_0x48219b['z']*_0x48219b['x'],_0x15d017[0x3]=0x0,_0x15d017[0x4]=-0x2*_0x48219b['x']*_0x48219b['y'],_0x15d017[0x5]=-0x2*_0x48219b['y']*_0x48219b['y']+0x1,_0x15d017[0x6]=-0x2*_0x48219b['z']*_0x48219b['y'],_0x15d017[0x7]=0x0,_0x15d017[0x8]=-0x2*_0x48219b['x']*_0x48219b['z'],_0x15d017[0x9]=-0x2*_0x48219b['y']*_0x48219b['z'],_0x15d017[0xa]=-0x2*_0x48219b['z']*_0x48219b['z']+0x1,_0x15d017[0xb]=0x0,_0x15d017[0xc]=-0x2*_0x48219b['x']*_0x532d14,_0x15d017[0xd]=-0x2*_0x48219b['y']*_0x532d14,_0x15d017[0xe]=-0x2*_0x48219b['z']*_0x532d14,_0x15d017[0xf]=0x1;}Cesium['Camera'][_0xbbd95(0x19b)]['enableReflection']=function(_0x2d7d93){const _0x547bdc=_0xbbd95;this[_0x547bdc(0x19f)]=!![],updateReflectMatrix(_0x2d7d93,this[_0x547bdc(0xd4)]),this[_0x547bdc(0x14e)][_0x547bdc(0x116)]=!![],this[_0x547bdc(0x14e)][_0x547bdc(0x11b)]=_0x2d7d93;let _0x577b04=Cesium[_0x547bdc(0x1c7)][_0x547bdc(0x1b8)](this[_0x547bdc(0xe1)],this[_0x547bdc(0xd4)],scratchMatrix4);this[_0x547bdc(0x14e)][_0x547bdc(0x176)]=_0x577b04;},Cesium[_0xbbd95(0xe5)][_0xbbd95(0x19b)][_0xbbd95(0x182)]=function(){const _0x202bc4=_0xbbd95;this[_0x202bc4(0x19f)]=![],this[_0x202bc4(0x14e)][_0x202bc4(0x116)]=![];},Cesium[_0xbbd95(0x137)]['prototype'][_0xbbd95(0x13c)]=function(_0xd76414,_0x2040ef){const _0x5035e8=_0xbbd95;if(Cesium[_0x5035e8(0x100)](_0x2040ef)&&Cesium[_0x5035e8(0x100)](_0x2040ef[_0x5035e8(0x11e)])&&this[_0x5035e8(0x140)]===_0x2040ef[_0x5035e8(0x11e)])return;_0xd76414[_0x5035e8(0x122)](this,_0x2040ef);},Cesium[_0xbbd95(0x1c7)][_0xbbd95(0x10b)]=function(_0x3e1e,_0xddbded,_0x4e8618){const _0x35a5c7=_0xbbd95;Cesium[_0x35a5c7(0x162)][_0x35a5c7(0xdd)][_0x35a5c7(0x172)]('matrix',_0x3e1e),Cesium[_0x35a5c7(0x162)][_0x35a5c7(0xdd)][_0x35a5c7(0x172)](_0x35a5c7(0x142),_0xddbded),Cesium['Check'][_0x35a5c7(0xdd)][_0x35a5c7(0x172)](_0x35a5c7(0x1a7),_0x4e8618),Cesium['Matrix4'][_0x35a5c7(0x19a)](_0x3e1e,scratchMatrix4),Cesium[_0x35a5c7(0x1c7)]['transpose'](scratchMatrix4,scratchMatrix4),scratchCartesian4['x']=_0xddbded['normal']['x'],scratchCartesian4['y']=_0xddbded['normal']['y'],scratchCartesian4['z']=_0xddbded[_0x35a5c7(0x149)]['z'],scratchCartesian4['w']=_0xddbded[_0x35a5c7(0x18a)],Cesium[_0x35a5c7(0x1c7)][_0x35a5c7(0x103)](scratchMatrix4,scratchCartesian4,scratchCartesian4),_0x4e8618[_0x35a5c7(0x149)]['x']=scratchCartesian4['x'],_0x4e8618[_0x35a5c7(0x149)]['y']=scratchCartesian4['y'],_0x4e8618[_0x35a5c7(0x149)]['z']=scratchCartesian4['z'];let _0x29aba4=Cesium[_0x35a5c7(0x12e)][_0x35a5c7(0x14c)](_0x4e8618['normal']);return Cesium[_0x35a5c7(0x12e)][_0x35a5c7(0x133)](_0x4e8618[_0x35a5c7(0x149)],_0x4e8618[_0x35a5c7(0x149)]),_0x4e8618[_0x35a5c7(0x18a)]=scratchCartesian4['w']/_0x29aba4,_0x4e8618;},Cesium[_0xbbd95(0x145)]['prototype'][_0xbbd95(0x1c2)]=Cesium['PerspectiveFrustum'][_0xbbd95(0x19b)][_0xbbd95(0x168)],Cesium[_0xbbd95(0x145)][_0xbbd95(0x19b)][_0xbbd95(0x168)]=function(_0x282cb6){const _0x4b1cee=_0xbbd95;let _0x36f922=this[_0x4b1cee(0x1c2)](_0x282cb6);return _0x36f922['reflect']=this[_0x4b1cee(0x116)],_0x36f922[_0x4b1cee(0x11b)]=this['clipPlane'],_0x36f922[_0x4b1cee(0x176)]=this[_0x4b1cee(0x176)],_0x36f922;};function getSceneList(_0x143800){const _0xa5fd4a=_0xbbd95;let _0x32dda9=Cesium[_0xa5fd4a(0x139)]['createIfNeeded'](_0x143800);return _0x32dda9['fetchJson'](_0x143800)[_0xa5fd4a(0x17a)](function(_0x49f367){const _0xea11e=_0xa5fd4a;if(_0x49f367[_0xea11e(0x109)]<0x1)return undefined;let _0x26feb4=_0x49f367[0x0];return {'name':_0x26feb4[_0xea11e(0x141)],'path':_0x26feb4[_0xea11e(0xdb)]};});}function getSceneConfig(_0x4fffac){const _0x23275f=_0xbbd95;let _0x24120d=Cesium[_0x23275f(0x139)][_0x23275f(0xe0)](_0x4fffac);return _0x24120d[_0x23275f(0x1b7)](_0x4fffac)['then'](function(_0x48603e){return _0x48603e;});}function getLayerList(_0x50551c){const _0x21f6de=_0xbbd95;let _0x33d0e0=_0x50551c+'/layers.json',_0x225221=Cesium['Resource']['createIfNeeded'](_0x33d0e0);return _0x225221[_0x21f6de(0x1b7)]()['then'](function(_0x524ead){const _0x4403c4=_0x21f6de;let _0x32ae6f={'s3m':[],'imagery':[],'s3mGroup':[],'terrain':undefined};for(let _0x3a35aa=0x0,_0x5914ee=_0x524ead[_0x4403c4(0x109)];_0x3a35aa<_0x5914ee;_0x3a35aa++){let _0x4108f4=_0x524ead[_0x3a35aa],_0x1367f=_0x4108f4[_0x4403c4(0x150)];if(_0x1367f===_0x4403c4(0x1a0))_0x32ae6f[_0x4403c4(0xc3)][_0x4403c4(0x1a8)](_0x4108f4);else {if(_0x1367f===_0x4403c4(0xc9))_0x32ae6f['imagery'][_0x4403c4(0x1a8)](_0x4108f4);else {if(_0x1367f==='TerrainFileLayer')_0x32ae6f['terrain']=_0x4108f4;else _0x1367f===_0x4403c4(0xc7)&&_0x32ae6f[_0x4403c4(0x190)][_0x4403c4(0x1a8)](_0x4108f4);}}}return _0x32ae6f;});}const rgbMatcher=/^rgba?\(\s*([0-9.]+%?)\s*,\s*([0-9.]+%?)\s*,\s*([0-9.]+%?)(?:\s*,\s*([0-9.]+))?\s*\)$/i,rgbaMatcher2=/^rgba?\(\s*([0-9.]+%?)\s*,\s*([0-9.]+%?)\s*,\s*([0-9.]+%?)(?:\s*,\s*([0-9.]+))?\s*\)*$/i;function resolveLayerExtendXML(_0x2ec908){const _0x1342c1=_0xbbd95;if(!_0x2ec908)throw new Cesium[(_0x1342c1(0x123))](_0x1342c1(0x126));let _0x2deb6b=_0x2ec908[_0x1342c1(0x1a9)],_0x3104fe=_0x2deb6b['namespaceURI'],_0x2faca4=XMLParser[_0x1342c1(0x18e)](_0x2deb6b,_0x1342c1(0xde),_0x3104fe),_0x13da4d=XMLParser[_0x1342c1(0xd1)](_0x2deb6b,_0x1342c1(0x16c),_0x3104fe),_0x27a86e=XMLParser['queryStringValue'](_0x2deb6b,'WithinLayer3DGroup',_0x3104fe),_0xaa519=XMLParser[_0x1342c1(0xf2)](_0x13da4d,_0x1342c1(0xcd),_0x3104fe),_0x14568b=XMLParser[_0x1342c1(0xf2)](_0x13da4d,_0x1342c1(0x16e),_0x3104fe),_0x601b2a=XMLParser['queryNumericValue'](_0x13da4d,'VisibleAltitudeMin',_0x3104fe),_0x2b0c71=XMLParser[_0x1342c1(0xfa)](_0x13da4d,_0x1342c1(0x14b),_0x3104fe);_0x2b0c71=_0x2b0c71===0x0?Number[_0x1342c1(0x19c)]:_0x2b0c71;let _0x2eae14=XMLParser[_0x1342c1(0xfa)](_0x13da4d,_0x1342c1(0x12a),_0x3104fe),_0x274867=XMLParser[_0x1342c1(0xfa)](_0x13da4d,_0x1342c1(0x15c),_0x3104fe),_0xc6604a=XMLParser['queryStringValue'](_0x13da4d,_0x1342c1(0x101),_0x3104fe),_0x3f1d21=0x0;if(_0xc6604a===_0x1342c1(0xe4))_0x3f1d21=0x1;else _0xc6604a===_0x1342c1(0x15a)&&(_0x3f1d21=0x2);let _0x212d1a=XMLParser['queryStringValue'](_0x2deb6b,'CacheFileType',_0x3104fe),_0x1f8958=_0x212d1a==='S3MB',_0xbb651d=_0x212d1a==='S3M',_0x1eda6c=_0x212d1a===_0x1342c1(0x146),_0x4acd2c=XMLParser['queryFirstNode'](_0x2deb6b,_0x1342c1(0x1aa),_0x3104fe);if(!_0x4acd2c){let _0xfa00cb=XMLParser['queryFirstNode'](_0x2deb6b,_0x1342c1(0xdf),_0x3104fe);if(_0xfa00cb){_0x4acd2c=XMLParser[_0x1342c1(0xd1)](_0xfa00cb,_0x1342c1(0x1aa),_0x3104fe);if(!_0x4acd2c)throw new Cesium[(_0x1342c1(0x123))]('get\x20s3m\x20layer\x20config\x20failed,extendxml.xml\x20foamat\x20error,layer\x20name\x20is\x20'+_0x2faca4);}}let _0x183760=XMLParser['queryNumericValue'](_0x4acd2c,_0x1342c1(0x129),_0x3104fe),_0x587922=XMLParser[_0x1342c1(0x18e)](_0x4acd2c,_0x1342c1(0x1b0),_0x3104fe),_0x371525=rgbMatcher[_0x1342c1(0xbc)](_0x587922[_0x1342c1(0x19e)]()),_0x2a6e13=new Cesium['Color']();if(_0x371525!==null){let _0x11ac1d=parseFloat(_0x371525[0x1]);_0x11ac1d=_0x11ac1d===0xbd?0xff:_0x11ac1d;let _0x1ac59e=parseFloat(_0x371525[0x2]);_0x1ac59e=_0x1ac59e===0xeb?0xff:_0x1ac59e,_0x2a6e13[_0x1342c1(0x1c4)]=Cesium[_0x1342c1(0x187)][_0x1342c1(0xbf)](_0x11ac1d/0xff,0x0,0x1),_0x2a6e13[_0x1342c1(0x13a)]=Cesium[_0x1342c1(0x187)][_0x1342c1(0xbf)](_0x1ac59e/0xff,0x0,0x1),_0x2a6e13[_0x1342c1(0x11d)]=Cesium[_0x1342c1(0x187)]['clamp'](parseFloat(_0x371525[0x3])%0x100/0xff,0x0,0x1),_0x2a6e13['alpha']=Cesium[_0x1342c1(0x187)][_0x1342c1(0xbf)](parseFloat(_0x371525[0x3])%0x10000/0x100/0xff,0x0,0x1);}let _0x141abe=XMLParser[_0x1342c1(0xd1)](_0x4acd2c,_0x1342c1(0x199),_0x3104fe),_0x1f0e1d=new Style3D();if(_0x141abe){let _0xa42667=XMLParser[_0x1342c1(0x18e)](_0x141abe,_0x1342c1(0xc6),_0x3104fe),_0x31925f=_0x1b29d4[_0x1342c1(0x164)];if(_0xa42667===_0x1342c1(0x191))_0x31925f=_0x1b29d4[_0x1342c1(0x104)];else _0xa42667===_0x1342c1(0x12c)&&(_0x31925f=_0x1b29d4['Fill_And_WireFrame']);let _0x5e3071=XMLParser[_0x1342c1(0xfa)](_0x141abe,_0x1342c1(0x127),_0x3104fe),_0x149661=XMLParser[_0x1342c1(0x18e)](_0x141abe,_0x1342c1(0xef),_0x3104fe),_0x4ed08f=rgbaMatcher2[_0x1342c1(0xbc)](_0x149661['toLowerCase']()),_0x2faf54=new Cesium[(_0x1342c1(0x188))]();_0x4ed08f!==null&&(_0x2faf54['red']=Cesium[_0x1342c1(0x187)][_0x1342c1(0xbf)](parseFloat(_0x4ed08f[0x1]),0x0,0x1),_0x2faf54[_0x1342c1(0x13a)]=Cesium[_0x1342c1(0x187)]['clamp'](parseFloat(_0x4ed08f[0x2]),0x0,0x1),_0x2faf54[_0x1342c1(0x11d)]=Cesium['Math'][_0x1342c1(0xbf)](parseFloat(_0x4ed08f[0x3]),0x0,0x1),_0x2faf54[_0x1342c1(0xf0)]=Cesium[_0x1342c1(0x187)][_0x1342c1(0xbf)](parseFloat(_0x4ed08f[0x4]),0x0,0x1));let _0x44d88c=XMLParser[_0x1342c1(0xfa)](_0x4acd2c,_0x1342c1(0x192),_0x3104fe)||0x0;_0x5e3071=Math['max'](_0x5e3071,_0x44d88c);let _0x22377c=XMLParser['queryStringValue'](_0x141abe,_0x1342c1(0x13f),_0x3104fe);_0x4ed08f=rgbaMatcher2[_0x1342c1(0xbc)](_0x22377c['toLowerCase']());let _0x5305ad=new Cesium[(_0x1342c1(0x188))]();_0x4ed08f!==null&&(_0x5305ad['red']=Cesium[_0x1342c1(0x187)][_0x1342c1(0xbf)](parseFloat(_0x4ed08f[0x1]),0x0,0x1),_0x5305ad[_0x1342c1(0x13a)]=Cesium[_0x1342c1(0x187)][_0x1342c1(0xbf)](parseFloat(_0x4ed08f[0x2]),0x0,0x1),_0x5305ad[_0x1342c1(0x11d)]=Cesium[_0x1342c1(0x187)][_0x1342c1(0xbf)](parseFloat(_0x4ed08f[0x3]),0x0,0x1),_0x5305ad['alpha']=Cesium[_0x1342c1(0x187)][_0x1342c1(0xbf)](parseFloat(_0x4ed08f[0x4]),0x0,0x1));let _0x4aafb3=XMLParser[_0x1342c1(0xfa)](_0x141abe,_0x1342c1(0x111),_0x3104fe),_0xf15cb5=XMLParser[_0x1342c1(0x18e)](_0x141abe,_0x1342c1(0xc5),_0x3104fe),_0xf7cad0=XMLParser['queryStringValue'](_0x141abe,_0x1342c1(0x102),_0x3104fe);if(_0xf7cad0===_0x1342c1(0x1bf))_0xf7cad0=_0x46b65c[_0x1342c1(0x152)];else _0xf7cad0===_0x1342c1(0xbb)?_0xf7cad0=_0x46b65c[_0x1342c1(0x108)]:_0xf7cad0=_0x46b65c[_0x1342c1(0x158)];let _0x43129a=Cesium[_0x1342c1(0x187)]['toRadians'](XMLParser['queryNumericValue'](_0x141abe,_0x1342c1(0xca),_0x3104fe)),_0x1adb8e=Cesium['Math'][_0x1342c1(0x117)](XMLParser[_0x1342c1(0xfa)](_0x141abe,'RotateY',_0x3104fe)),_0xc3612f=Cesium[_0x1342c1(0x187)][_0x1342c1(0x117)](XMLParser[_0x1342c1(0xfa)](_0x141abe,'RotateZ',_0x3104fe)),_0x522c47=new Cesium[(_0x1342c1(0x118))](_0x43129a,_0x1adb8e,_0xc3612f);_0x1f0e1d['fillForeColor']=_0x2a6e13,_0x1f0e1d[_0x1342c1(0xf6)]=_0x4aafb3,_0x1f0e1d[_0x1342c1(0x1c0)]=_0x183760,_0x1f0e1d[_0x1342c1(0x196)]=_0x2faf54,_0x1f0e1d['pointSize']=_0x5e3071,_0x1f0e1d['pointColor']=_0x5305ad,_0x1f0e1d['fillStyle']=_0x31925f,_0x1f0e1d[_0x1342c1(0x181)]=_0xf7cad0;}let _0x4a3cc9=XMLParser[_0x1342c1(0xfa)](_0x2deb6b,'LODRangeScale',_0x3104fe),_0x303e7e=XMLParser[_0x1342c1(0xd1)](_0x2deb6b,_0x1342c1(0x177),_0x3104fe),_0xe3b95a=XMLParser[_0x1342c1(0xfa)](_0x303e7e,_0x1342c1(0x1ab),_0x3104fe),_0x593012=XMLParser[_0x1342c1(0xfa)](_0x303e7e,_0x1342c1(0x17b),_0x3104fe),_0x2bd471=_0xe3b95a!==0x0&&_0x593012!==0x0,_0x210b90=XMLParser[_0x1342c1(0xd1)](_0x2deb6b,_0x1342c1(0xba),_0x3104fe),_0x3a5de0=XMLParser[_0x1342c1(0xfa)](_0x210b90,'Brightness',_0x3104fe),_0x5e7dd8=XMLParser[_0x1342c1(0xfa)](_0x210b90,_0x1342c1(0x112),_0x3104fe),_0x5764a4=XMLParser[_0x1342c1(0xfa)](_0x210b90,_0x1342c1(0x10f),_0x3104fe),_0x5e22de=XMLParser[_0x1342c1(0xfa)](_0x210b90,_0x1342c1(0x107),_0x3104fe),_0x5e0405=XMLParser['queryNumericValue'](_0x210b90,'Gamma',_0x3104fe);return {'name':_0x2faca4,'groupName':_0x27a86e,'isS3MB':_0x1f8958,'isS3MBlock':_0x1eda6c,'isS3M':_0xbb651d,'style3D':_0x1f0e1d,'selectEnable':_0xaa519,'isVisible':_0x14568b,'minVisibleAltitude':_0x601b2a,'maxVisibleAltitude':_0x2b0c71,'minVisibleDistance':_0x2eae14,'maxVisibleDistance':_0x274867,'shadowType':_0x3f1d21,'lodRangeScale':_0x4a3cc9,'polygonOffset':{'enabled':_0x2bd471,'units':_0xe3b95a,'factor':_0x593012},'brightness':_0x3a5de0,'constrast':_0x5e7dd8,'hue':_0x5764a4,'saturation':_0x5e22de,'gamma':_0x5e0405};}function getS3MLayerConfig(_0xe33781){const _0x388f83=_0xbbd95;let _0x1ee2d3=Cesium[_0x388f83(0x139)][_0x388f83(0xe0)](_0xe33781),_0x5e32a9=Cesium['when'][_0x388f83(0xd2)]();return _0x1ee2d3['fetchXML']()[_0x388f83(0x17a)](function(_0x39010a){const _0x39282b=_0x388f83;try{let _0x336744=resolveLayerExtendXML(_0x39010a);_0x5e32a9[_0x39282b(0x113)](_0x336744);}catch(_0x1648c2){_0x5e32a9['reject'](_0x39282b(0xcc));}})[_0x388f83(0xeb)](function(){const _0x1fc6c1=_0x388f83;_0x5e32a9['reject'](_0x1fc6c1(0x170));}),_0x5e32a9[_0x388f83(0x189)];}Cesium[_0xbbd95(0x1a5)]['prototype'][_0xbbd95(0xfb)]=function(_0x197ce0){const _0x8fa71c=_0xbbd95;if(_0x197ce0[_0x8fa71c(0xd6)](-0x9)!=='realspace')throw new Cesium['DeveloperError']('open\x20scene\x20url\x20error!');let _0x2b43ea=_0x197ce0+'/scenes.json',_0x1ae9c0=this,_0x54ec1b=this[_0x8fa71c(0x163)],_0x59a1eb=Cesium[_0x8fa71c(0xfd)][_0x8fa71c(0xd2)]();return getSceneList(_0x2b43ea)[_0x8fa71c(0x17a)](function(_0x1a888e){const _0xff6f79=_0x8fa71c;if(!_0x1a888e){_0x59a1eb[_0xff6f79(0x167)](_0xff6f79(0x197));return;}let _0x12bc2e=_0x1a888e[_0xff6f79(0xdb)]+_0xff6f79(0x132);getSceneConfig(_0x12bc2e)[_0xff6f79(0x17a)](function(_0x55b430){const _0x160a71=_0xff6f79;let _0x11b996;_0x55b430[_0x160a71(0x1ac)]===_0x160a71(0x10c)?(_0x1ae9c0[_0x160a71(0x13b)]=Cesium['SceneMode'][_0x160a71(0xea)],_0x55b430[_0x160a71(0x163)][_0x160a71(0x17d)]-=Math['PI'],_0x11b996=new Cesium['Cartesian3'](_0x55b430[_0x160a71(0x163)][_0x160a71(0x195)],_0x55b430[_0x160a71(0x163)]['latitude'],_0x55b430[_0x160a71(0x163)]['altitude']),_0x54ec1b['setView']({'destination':_0x11b996,'orientation':{'heading':_0x55b430[_0x160a71(0x163)]['heading'],'pitch':_0x55b430[_0x160a71(0x163)][_0x160a71(0x17d)],'roll':0x0},'convert':![]})):(_0x55b430[_0x160a71(0x163)][_0x160a71(0x17d)]-=0x5a,_0x11b996=Cesium['Cartesian3'][_0x160a71(0x18b)](_0x55b430['camera'][_0x160a71(0x195)],_0x55b430[_0x160a71(0x163)]['latitude'],_0x55b430[_0x160a71(0x163)]['altitude']),_0x54ec1b[_0x160a71(0x1a2)]({'destination':_0x11b996,'orientation':{'heading':Cesium[_0x160a71(0x187)][_0x160a71(0x117)](_0x55b430['camera']['heading']),'pitch':Cesium[_0x160a71(0x187)][_0x160a71(0x117)](_0x55b430[_0x160a71(0x163)][_0x160a71(0x17d)]),'roll':0x0},'convert':![]}));})[_0xff6f79(0xeb)](function(_0x53b950){const _0x10b7db=_0xff6f79;_0x59a1eb[_0x10b7db(0x167)](_0x10b7db(0xee)+_0x53b950);});let _0x3f3b06=_0x1a888e[_0xff6f79(0xdb)];getLayerList(_0x3f3b06)[_0xff6f79(0x17a)](function(_0x2ed406){const _0x2bb641=_0xff6f79;let _0x31ee65=_0x2ed406[_0x2bb641(0xc3)],_0x4a7833=_0x2ed406[_0x2bb641(0x18f)],_0x3221c0=_0x2ed406[_0x2bb641(0xdc)],_0x4687e8=_0x2ed406[_0x2bb641(0x190)],_0x21a312=_0x1a888e[_0x2bb641(0xdb)]+_0x2bb641(0xf3),_0xb2e10c=[],_0x31a17b=_0x31ee65[_0x2bb641(0x109)]-0x1;for(let _0x537540=_0x31a17b;_0x537540>=0x0;_0x537540--){let _0x1b3715=_0x31ee65[_0x537540],_0x2880e8=_0x21a312+encodeURIComponent(_0x1b3715[_0x2bb641(0x141)])+_0x2bb641(0x120);(function(_0x224316){const _0x3a8621=_0x2bb641;let _0x3a4378=getS3MLayerConfig(_0x2880e8)['then'](function(_0x426092){const _0x20f235=_0x156c;try{let _0x9630bf=_0x197ce0+_0x20f235(0x1ba)+encodeURIComponent(_0x426092[_0x20f235(0x141)])+_0x20f235(0x165);return _0x1ae9c0[_0x20f235(0x185)](_0x9630bf,_0x426092);}catch(_0x579500){_0x59a1eb[_0x20f235(0x167)](_0x20f235(0x1b2)+_0x426092[_0x20f235(0x141)]+'\x20failed,'+_0x579500);}})[_0x3a8621(0xeb)](function(_0x1c55eb){const _0x2894fe=_0x3a8621;_0x59a1eb['reject'](_0x2894fe(0x1c3)+_0x1c55eb+_0x2894fe(0x18c)+_0x1b3715[_0x2894fe(0x141)]);});_0xb2e10c['push'](_0x3a4378);}());}Cesium[_0x2bb641(0xfd)][_0x2bb641(0x166)](_0xb2e10c,function(_0x2649ad){const _0x307649=_0x2bb641;_0x59a1eb[_0x307649(0x113)](_0x2649ad);},function(_0x402279){const _0x1b085c=_0x2bb641;_0x59a1eb[_0x1b085c(0x167)](_0x1b085c(0xbe)+_0x402279);});})[_0xff6f79(0xeb)](function(_0x17b66b){const _0x3e8ecd=_0xff6f79;_0x59a1eb[_0x3e8ecd(0x167)](_0x3e8ecd(0x15d)+_0x17b66b);});})[_0x8fa71c(0xeb)](function(_0x41c259){const _0x4ec8d5=_0x8fa71c;_0x59a1eb['reject'](_0x4ec8d5(0xd8)+_0x41c259);}),_0x59a1eb[_0x8fa71c(0x189)];};function ModExp(_0x8150f6,_0x1f89fb,_0x6a0852){const _0x3f73e5=_0xbbd95;let _0x228024=new _0x1d9b13(_0x8150f6),_0x45bf49=new _0x1d9b13(_0x1f89fb),_0x12e5d9=new _0x1d9b13(0x1),_0x18082c=new _0x1d9b13(0x2),_0x546d93=new _0x1d9b13(0x1);while(_0x45bf49[_0x3f73e5(0x17f)]()>0x0){_0x45bf49['mod'](_0x18082c)[_0x3f73e5(0x17f)]()===0x0?(_0x45bf49=_0x45bf49[_0x3f73e5(0xf7)](_0x18082c),_0x228024=_0x228024[_0x3f73e5(0x16a)](_0x228024)[_0x3f73e5(0x17e)](_0x6a0852)):(_0x45bf49=_0x45bf49[_0x3f73e5(0x1b1)](_0x546d93),_0x12e5d9=_0x12e5d9[_0x3f73e5(0x16a)](_0x228024)[_0x3f73e5(0x17e)](_0x6a0852));}return _0x12e5d9[_0x3f73e5(0x17f)]();}let _rssCache={};function RSAAuthentication(_0x578324){const _0x3fd317=_0xbbd95;let _0x13b8ea=Cesium[_0x3fd317(0xfd)][_0x3fd317(0xd2)]();if(_rssCache[_0x578324])return _rssCache[_0x578324];let _0x2b4e7c=Cesium[_0x3fd317(0x139)][_0x3fd317(0xe0)](_0x578324+_0x3fd317(0x1ae));return _rssCache[_0x578324]=_0x13b8ea['promise'],_0x2b4e7c['fetchJson']()[_0x3fd317(0x17a)](_0x3743a2=>{const _0x2234b7=_0x3fd317;let _0x13adec=Number(_0x3743a2['jsessionID']),_0x2a3cf1=Number(_0x3743a2['random']),_0x5cf603=0x8f461e7bf61d5,_0x583ec3=0x1694ad7fce84d,_0x119aa3=ModExp(_0x2a3cf1,_0x583ec3,_0x5cf603),_0x309670=JSON[_0x2234b7(0x155)]({'jsessionID':_0x13adec[_0x2234b7(0x1be)](),'random':_0x119aa3[_0x2234b7(0x1be)]()});Cesium[_0x2234b7(0x139)][_0x2234b7(0xff)]({'url':_0x578324+'/login.json','data':_0x309670,'responseType':'json'})[_0x2234b7(0x17a)](_0x111bc0=>{const _0x35c12c=_0x2234b7;_0x111bc0[_0x35c12c(0x136)]===!![]?(_0x13b8ea[_0x35c12c(0x113)](_0x119aa3),_rssCache[_0x578324]=_0x119aa3):_0x13b8ea[_0x35c12c(0x167)](![]);})[_0x2234b7(0xeb)](_0x27a51d=>{_0x13b8ea['reject'](_0x27a51d);});})[_0x3fd317(0xeb)](_0x53b3b6=>{_0x13b8ea['reject'](_0x53b3b6);}),_0x13b8ea[_0x3fd317(0x189)];}Cesium['Scene']['prototype']['addS3MTilesLayerByScp']=function(_0xb99e18,_0x2a3cb9,_0x5da3fc){const _0x4fb28a=_0xbbd95;_0x2a3cb9=_0x2a3cb9||{};let _0x46296f=Cesium[_0x4fb28a(0xfd)][_0x4fb28a(0xd2)](),_0x1b3481=_0xb99e18[_0x4fb28a(0xec)](_0x4fb28a(0xe2));if(_0x1b3481===-0x1)return _0x46296f['reject'](![]);let _0x2d1d1c=_0xb99e18[_0x4fb28a(0xc0)](0x0,_0x1b3481+0xe),_0x171b69=this;return Cesium[_0x4fb28a(0xfd)](RSAAuthentication(_0x2d1d1c),function(_0x33f69c){const _0x86731a=_0x4fb28a;_0x2a3cb9[_0x86731a(0x10a)]=_0xb99e18,_0x2a3cb9[_0x86731a(0x14f)]=_0x171b69[_0x86731a(0x14f)],_0x2a3cb9[_0x86731a(0x159)]=_0x33f69c,_0x2a3cb9[_0x86731a(0x143)]=_0x171b69[_0x86731a(0x147)];let _0x349d37=new S3MTilesLayer(_0x2a3cb9);_0x171b69[_0x86731a(0x1a6)]['add'](_0x349d37,_0x5da3fc),!_0x171b69[_0x86731a(0x14f)][_0x86731a(0x15f)]&&(_0x171b69[_0x86731a(0x14f)][_0x86731a(0x15f)]=new ReflectFramebuffer(_0x171b69[_0x86731a(0x14f)]),_0x171b69[_0x86731a(0x148)][_0x86731a(0x1b9)](_0x86731a(0x116),_0x171b69[_0x86731a(0x14f)][_0x86731a(0x15f)])),_0x46296f[_0x86731a(0x113)](_0x349d37);},function(_0x542d3a){_0x46296f['reject'](_0x542d3a);}),_0x46296f[_0x4fb28a(0x189)];},Cesium[_0xbbd95(0x1a5)]['prototype'][_0xbbd95(0xd7)]=Cesium['Scene']['prototype']['pick'],Cesium['Scene']['prototype']['pick']=function(_0x3d7dd4,_0x5dcc0f,_0x4e59f8){const _0x4c864c=_0xbbd95;let _0x569fcf=this[_0x4c864c(0xd7)](_0x3d7dd4,_0x5dcc0f,_0x4e59f8);if(_0x569fcf){let _0x24dc15=_0x569fcf[_0x4c864c(0x18d)]&&_0x569fcf['primitive']instanceof S3MTilesLayer;_0x24dc15&&_0x569fcf[_0x4c864c(0x18d)]['setSelection'](_0x569fcf['id']);}else for(let _0x32e7c0=0x0,_0x58d6c9=this['primitives'][_0x4c864c(0x109)];_0x32e7c0<_0x58d6c9;_0x32e7c0++){let _0x24a177=this[_0x4c864c(0x1a6)][_0x4c864c(0x16f)](_0x32e7c0);_0x24a177 instanceof S3MTilesLayer&&_0x24a177[_0x4c864c(0x138)]();}return _0x569fcf;},Cesium[_0xbbd95(0x1a5)][_0xbbd95(0x19b)]['_renderTargets']=new Cesium['AssociativeArray'](),Cesium[_0xbbd95(0x1a5)][_0xbbd95(0x19b)][_0xbbd95(0x157)]=function(_0x1e0771,_0x5a00a0){const _0x3a1a13=_0xbbd95;this[_0x3a1a13(0x148)][_0x3a1a13(0x1b9)](_0x1e0771,_0x5a00a0);},Cesium[_0xbbd95(0x1a5)][_0xbbd95(0x19b)][_0xbbd95(0x1bb)]=function(_0x9770a0){const _0x383bf1=_0xbbd95;this[_0x383bf1(0x148)]['remove'](_0x9770a0);},Cesium[_0xbbd95(0x1a5)][_0xbbd95(0x19b)][_0xbbd95(0x186)]=Cesium[_0xbbd95(0x1a5)]['prototype']['render'],Cesium[_0xbbd95(0x1a5)][_0xbbd95(0x19b)][_0xbbd95(0x1a3)]=function(_0x38695e){const _0xd129ee=_0xbbd95;this[_0xd129ee(0x186)](_0x38695e),this[_0xd129ee(0x1ad)][_0xd129ee(0x10d)][_0xd129ee(0x109)]=0x0;if(this['_renderTargets']['length'])for(let _0x528710=0x0,_0x24dfd8=this[_0xd129ee(0x148)][_0xd129ee(0x109)];_0x528710<_0x24dfd8;_0x528710++){let _0x3cf842=this[_0xd129ee(0x148)][_0xd129ee(0x156)][_0x528710];if(!_0x3cf842[_0xd129ee(0xfe)])continue;this['frameState'][_0xd129ee(0x1c6)]=!![],this['useDepthPicking']=![];let _0x895d5f=_0x3cf842[_0xd129ee(0xe3)](this);this['updateEnvironment'](),this[_0xd129ee(0xd3)](_0x895d5f,Cesium[_0xd129ee(0x188)][_0xd129ee(0x17c)]),this[_0xd129ee(0x175)](_0x895d5f),_0x3cf842[_0xd129ee(0x14a)](this[_0xd129ee(0x1ad)],_0x895d5f),this[_0xd129ee(0x1ad)][_0xd129ee(0x1c6)]=![],this[_0xd129ee(0x174)]=!![];}if(this['context'][_0xd129ee(0x15f)]&&this['frameState'][_0xd129ee(0xc4)]!==undefined){if(this[_0xd129ee(0x1ad)][_0xd129ee(0xc4)]>0xc350)this[_0xd129ee(0x14f)][_0xd129ee(0x15f)][_0xd129ee(0xfe)]=![];else {let _0x1eafa7=this[_0xd129ee(0x1ad)]['heightOffset'],_0x18568d=this[_0xd129ee(0x163)][_0xd129ee(0xce)],_0x1fb586=this[_0xd129ee(0x14f)][_0xd129ee(0x15f)][_0xd129ee(0x125)],_0x3c49f3=Cesium[_0xd129ee(0x12e)][_0xd129ee(0x14c)](_0x18568d)-this[_0xd129ee(0x163)][_0xd129ee(0x12f)][_0xd129ee(0x179)];_0x1eafa7+=_0x3c49f3,Cesium[_0xd129ee(0x12e)][_0xd129ee(0x133)](_0x18568d,_0x1fb586[_0xd129ee(0x149)]),_0x1fb586[_0xd129ee(0x149)][_0xd129ee(0x168)](scratchCartesian3),Cesium['Cartesian3'][_0xd129ee(0x16d)](scratchCartesian3,_0x1eafa7,scratchCartesian3),_0x1fb586[_0xd129ee(0x18a)]=-Cesium[_0xd129ee(0x12e)][_0xd129ee(0x151)](scratchCartesian3,_0x1fb586['normal']),this['context'][_0xd129ee(0x15f)][_0xd129ee(0xfe)]=!![];}this['frameState'][_0xd129ee(0x161)]=0x0;}},Cesium[_0xbbd95(0x180)][_0xbbd95(0x19b)][_0xbbd95(0x11c)]=Cesium[_0xbbd95(0x180)]['prototype'][_0xbbd95(0xc8)],Cesium[_0xbbd95(0x180)][_0xbbd95(0x19b)]['update']=function(_0x51c29f,_0xf0cfdb){const _0x3b5a9f=_0xbbd95;let _0x4aed53=this['hookUpdateFunc'](_0x51c29f,_0xf0cfdb);return _0x4aed53&&_0x51c29f['camera'][_0x3b5a9f(0x19f)]&&(!this[_0x3b5a9f(0xf4)]&&(this[_0x3b5a9f(0xf4)]=Cesium[_0x3b5a9f(0x14d)][_0x3b5a9f(0xcf)]({'cull':{'enabled':!![],'face':Cesium[_0x3b5a9f(0xe8)][_0x3b5a9f(0xd5)]},'blending':Cesium['BlendingState'][_0x3b5a9f(0x1b6)],'depthMask':![]})),_0x4aed53[_0x3b5a9f(0x1af)]=this[_0x3b5a9f(0xf4)]),_0x4aed53;};function setView(_0x267f79,_0x2fab13){const _0x229c0b=_0xbbd95;Cesium[_0x229c0b(0x1c7)][_0x229c0b(0x168)](_0x2fab13,_0x267f79['_view']),Cesium[_0x229c0b(0x1c7)][_0x229c0b(0x11f)](_0x2fab13,_0x267f79[_0x229c0b(0x1b3)]),_0x267f79[_0x229c0b(0x1a1)]=!![],_0x267f79[_0x229c0b(0x15e)]=!![],_0x267f79[_0x229c0b(0x115)]=!![],_0x267f79[_0x229c0b(0xda)]=!![],_0x267f79[_0x229c0b(0x1bc)]=!![],_0x267f79[_0x229c0b(0xed)]=!![],_0x267f79['_inverseModelView3DDirty']=!![],_0x267f79[_0x229c0b(0x1c1)]=!![],_0x267f79[_0x229c0b(0xd9)]=!![],_0x267f79[_0x229c0b(0x10e)]=!![],_0x267f79[_0x229c0b(0x114)]=!![],_0x267f79[_0x229c0b(0x160)]=!![],_0x267f79[_0x229c0b(0x11a)]=!![],_0x267f79['_inverseNormalDirty']=!![],_0x267f79[_0x229c0b(0xf1)]=!![],_0x267f79[_0x229c0b(0x13d)]=!![];}function setInverseView(_0x140c74,_0x22b4cc){const _0x3aa74b=_0xbbd95;Cesium['Matrix4'][_0x3aa74b(0x168)](_0x22b4cc,_0x140c74[_0x3aa74b(0xf8)]),Cesium[_0x3aa74b(0x1c7)]['getMatrix3'](_0x22b4cc,_0x140c74[_0x3aa74b(0x144)]);}function setCamera(_0x2c4392,_0x5f0e9f){const _0x4093d1=_0xbbd95;Cesium[_0x4093d1(0x12e)][_0x4093d1(0x168)](_0x5f0e9f[_0x4093d1(0xce)],_0x2c4392[_0x4093d1(0x134)]),Cesium['Cartesian3'][_0x4093d1(0x168)](_0x5f0e9f[_0x4093d1(0xd0)],_0x2c4392[_0x4093d1(0x105)]),Cesium[_0x4093d1(0x12e)][_0x4093d1(0x168)](_0x5f0e9f['rightWC'],_0x2c4392['_cameraRight']),Cesium['Cartesian3'][_0x4093d1(0x168)](_0x5f0e9f['upWC'],_0x2c4392[_0x4093d1(0x173)]);let _0x4ea137=_0x5f0e9f['positionCartographic'];!Cesium[_0x4093d1(0x100)](_0x4ea137)?_0x2c4392[_0x4093d1(0x110)]=-_0x2c4392[_0x4093d1(0x15b)][_0x4093d1(0xf9)]:_0x2c4392['_eyeHeight']=_0x4ea137['height'],_0x2c4392[_0x4093d1(0x1b4)]=!![];}Cesium[_0xbbd95(0x128)]['prototype'][_0xbbd95(0x124)]=function(_0x21a983){const _0x3a86b5=_0xbbd95;let _0x49a11f=_0x21a983['viewMatrix'],_0x306596=_0x21a983['inverseViewMatrix'];_0x21a983[_0x3a86b5(0x19f)]?(Cesium[_0x3a86b5(0x1c7)][_0x3a86b5(0x1b8)](_0x49a11f,_0x21a983['reflectMatrix'],scratchMatrix4),Cesium[_0x3a86b5(0x1c7)][_0x3a86b5(0xe6)](scratchMatrix4,scratchInvMatrix4),setView(this,scratchMatrix4),setInverseView(this,scratchInvMatrix4)):(setView(this,_0x49a11f),setInverseView(this,_0x306596)),setCamera(this,_0x21a983),this[_0x3a86b5(0xc1)]['x']=_0x21a983[_0x3a86b5(0x14e)][_0x3a86b5(0x1b5)],this[_0x3a86b5(0xc1)]['y']=_0x21a983[_0x3a86b5(0x14e)][_0x3a86b5(0x1a4)],this[_0x3a86b5(0x1bd)](_0x21a983['frustum']),this['_orthographicIn3D']=this[_0x3a86b5(0x147)]!==Cesium[_0x3a86b5(0x135)][_0x3a86b5(0x119)]&&_0x21a983[_0x3a86b5(0x14e)]instanceof Cesium[_0x3a86b5(0x169)];};function modifyProjectionMatrix(_0x2835f4,_0x4c086f){const _0x21a0c2=_0xbbd95;if(!_0x2835f4[_0x21a0c2(0x11b)]||!_0x2835f4[_0x21a0c2(0x176)]||!_0x2835f4[_0x21a0c2(0x116)])return;let _0x183897=_0x2835f4['currentViewMatrix'];Cesium[_0x21a0c2(0x1c7)][_0x21a0c2(0x10b)](_0x183897,_0x2835f4[_0x21a0c2(0x11b)],scratchPlane),scratchCartesian4['x']=(Cesium[_0x21a0c2(0x187)]['sign'](scratchPlane[_0x21a0c2(0x149)]['x'])+_0x4c086f[0x8])/_0x4c086f[0x0],scratchCartesian4['y']=(Cesium[_0x21a0c2(0x187)][_0x21a0c2(0xe9)](scratchPlane[_0x21a0c2(0x149)]['y'])+_0x4c086f[0x9])/_0x4c086f[0x5],scratchCartesian4['z']=-0x1,scratchCartesian4['w']=(0x1+_0x4c086f[0xa])/_0x4c086f[0xe],scratchClipPlane4d['x']=scratchPlane[_0x21a0c2(0x149)]['x'],scratchClipPlane4d['y']=scratchPlane['normal']['y'],scratchClipPlane4d['z']=scratchPlane[_0x21a0c2(0x149)]['z'],scratchClipPlane4d['w']=scratchPlane['distance'],Cesium['Cartesian4'][_0x21a0c2(0x16d)](scratchClipPlane4d,0x2/Cesium[_0x21a0c2(0x12d)][_0x21a0c2(0x151)](scratchClipPlane4d,scratchCartesian4),scratchCartesian4),_0x4c086f[0x2]=scratchCartesian4['x'],_0x4c086f[0x6]=scratchCartesian4['y'],_0x4c086f[0xa]=scratchCartesian4['z']+0x1,_0x4c086f[0xe]=scratchCartesian4['w'];}function setProjection(_0x3f415a,_0x754517){const _0x3c84b7=_0xbbd95;Cesium[_0x3c84b7(0x1c7)][_0x3c84b7(0x168)](_0x754517,_0x3f415a['_projection']),_0x3f415a[_0x3c84b7(0x178)]=!![],_0x3f415a[_0x3c84b7(0x1c1)]=!![],_0x3f415a[_0x3c84b7(0xd9)]=!![],_0x3f415a[_0x3c84b7(0x10e)]=!![],_0x3f415a['_modelViewProjectionRelativeToEyeDirty']=!![];}function setInfiniteProjection(_0x5d5ac4,_0xa8ec8b){const _0x3700b2=_0xbbd95;Cesium[_0x3700b2(0x1c7)][_0x3700b2(0x168)](_0xa8ec8b,_0x5d5ac4[_0x3700b2(0x198)]),_0x5d5ac4[_0x3700b2(0x160)]=!![];}Cesium['UniformState'][_0xbbd95(0x19b)][_0xbbd95(0x1bd)]=function(_0x13afef){const _0x4277f6=_0xbbd95;let _0x2e0663=_0x13afef['projectionMatrix'];Cesium['Matrix4'][_0x4277f6(0x168)](_0x2e0663,scratchMatrix4),modifyProjectionMatrix(_0x13afef,scratchMatrix4),setProjection(this,scratchMatrix4),Cesium[_0x4277f6(0x100)](_0x13afef['infiniteProjectionMatrix'])&&setInfiniteProjection(this,_0x13afef[_0x4277f6(0x193)]),this[_0x4277f6(0x183)]['x']=_0x13afef[_0x4277f6(0x1b5)],this[_0x4277f6(0x183)]['y']=_0x13afef[_0x4277f6(0x1a4)],this[_0x4277f6(0x184)]=_0x13afef[_0x4277f6(0x1a4)]-_0x13afef[_0x4277f6(0x1b5)]+0x1,this[_0x4277f6(0xe7)]=Cesium[_0x4277f6(0x187)][_0x4277f6(0xf5)](this[_0x4277f6(0x184)]),this['_oneOverLog2FarDepthFromNearPlusOne']=0x1/this[_0x4277f6(0xe7)],Cesium['defined'](_0x13afef[_0x4277f6(0x153)])&&(_0x13afef=_0x13afef[_0x4277f6(0x153)]),this['_frustumPlanes']['x']=_0x13afef[_0x4277f6(0x194)],this[_0x4277f6(0x154)]['y']=_0x13afef[_0x4277f6(0x13e)],this[_0x4277f6(0x154)]['z']=_0x13afef[_0x4277f6(0x16b)],this['_frustumPlanes']['w']=_0x13afef[_0x4277f6(0x1c5)];};var CesiumExt = {};

    const _0x3bca=['405146JfBGpl','1ngWicf','284209DNvVHV','169612McYgnN','freeze','110228oyptCD','628434wGTMnE','382408CMqVBh','293416ieGOIg'];const _0x232d09=_0x3091;function _0x3091(_0x5771e5,_0x1a618f){_0x5771e5=_0x5771e5-0x14c;let _0x3bcac8=_0x3bca[_0x5771e5];return _0x3bcac8;}(function(_0x3d612f,_0x421238){const _0x41319c=_0x3091;while(!![]){try{const _0x468ba1=-parseInt(_0x41319c(0x150))+-parseInt(_0x41319c(0x152))+-parseInt(_0x41319c(0x14f))*parseInt(_0x41319c(0x14e))+parseInt(_0x41319c(0x153))+parseInt(_0x41319c(0x14c))+parseInt(_0x41319c(0x154))+-parseInt(_0x41319c(0x14d));if(_0x468ba1===_0x421238)break;else _0x3d612f['push'](_0x3d612f['shift']());}catch(_0x44f059){_0x3d612f['push'](_0x3d612f['shift']());}}}(_0x3bca,0x51cd7));const ClampMode={'Space':0x0,'Ground':0x1,'S3mModel':0x2,'Raster':0x3};var _0x5b8764 = Object[_0x232d09(0x151)](ClampMode);

    const _0x36b6=['741410sFLRRM','246201MbjkyF','1EHItLe','1CjdOoN','394067GmdTjo','2053kdabMs','963155rtvuTI','201bbcWjX','7GIqmCd','512268GvHJHP','52019fQBFJT'];function _0xa297(_0x3c451d,_0x1451ac){_0x3c451d=_0x3c451d-0xb7;let _0x36b6d6=_0x36b6[_0x3c451d];return _0x36b6d6;}(function(_0x1b241f,_0x36a15c){const _0x4c99d6=_0xa297;while(!![]){try{const _0x445856=parseInt(_0x4c99d6(0xbf))*-parseInt(_0x4c99d6(0xc1))+-parseInt(_0x4c99d6(0xc0))*-parseInt(_0x4c99d6(0xbd))+parseInt(_0x4c99d6(0xbc))*-parseInt(_0x4c99d6(0xbe))+parseInt(_0x4c99d6(0xbb))+-parseInt(_0x4c99d6(0xba))+parseInt(_0x4c99d6(0xb7))*parseInt(_0x4c99d6(0xb9))+parseInt(_0x4c99d6(0xb8));if(_0x445856===_0x36a15c)break;else _0x1b241f['push'](_0x1b241f['shift']());}catch(_0x36ebc8){_0x1b241f['push'](_0x1b241f['shift']());}}}(_0x36b6,0x8341b));const DrawMode={'Point':0x0,'Line':0x1,'Polygon':0x2};var _0xb0c8b2 = Object['freeze'](DrawMode);

    const _0x4f52=['active','Ground','mode','ColorType','ScreenSpaceEventType','MOUSE_MOVE','Color','1gtUmGC','clampToGroundPolylines','pickPosition','concat','1213544TPLPbw','ORANGE','slice','PolylineCollection','viewer','remove','positions','hierarchy','log','fromType','removeInputAction','Event','polyline','clear','drawEvt','push','setInputAction','Point','fromCssColorString','Line','defaultValue','#51ff00','DeveloperError','1793531QkYiRE','activate','942411UnFClY','polyline-','S3mModel','isDrawing','_clampMode','movingEvt','points','LEFT_CLICK','entities','length','Space','your\x20browser\x20not\x20supported\x20pickPosition!','1842872HOWmud','clone','1rHQStw','1438740vimKyR','_activeEvt','position','defineProperties','Cartesian2','polygon','canvas','Material','primitives','endPosition','point','handler','deactivate','prototype','pickPositionSupported','PointPrimitiveCollection','RIGHT_CLICK','polylines','removeAll','raiseEvent','Polygon','784794iwmSHr','1827619OSZORQ','scene','1dGITso','show','_drawEvt','add','withAlpha','Cartesian3'];const _0x592d0b=_0x121c;(function(_0x1facce,_0x1b8c0b){const _0x4f6f04=_0x121c;while(!![]){try{const _0x4186ba=parseInt(_0x4f6f04(0x1fb))+parseInt(_0x4f6f04(0x1fd))*parseInt(_0x4f6f04(0x1ef))+-parseInt(_0x4f6f04(0x216))*parseInt(_0x4f6f04(0x1ed))+-parseInt(_0x4f6f04(0x223))*parseInt(_0x4f6f04(0x227))+parseInt(_0x4f6f04(0x214))+-parseInt(_0x4f6f04(0x1fe))+parseInt(_0x4f6f04(0x213));if(_0x4186ba===_0x1b8c0b)break;else _0x1facce['push'](_0x1facce['shift']());}catch(_0xc7a9b3){_0x1facce['push'](_0x1facce['shift']());}}}(_0x4f52,0xe8649));let DrawHandler=function(_0x4be9ab,_0x374955,_0x59cdd7){const _0x4f0256=_0x121c;if(!_0x4be9ab||_0x374955===undefined)throw new Cesium[(_0x4f0256(0x1ec))]('viewer\x20and\x20mode\x20is\x20required!');this['handler']=new Cesium['ScreenSpaceEventHandler'](_0x4be9ab[_0x4f0256(0x215)][_0x4f0256(0x204)]),this[_0x4f0256(0x22b)]=_0x4be9ab,this[_0x4f0256(0x21e)]=_0x374955,this[_0x4f0256(0x1f3)]=Cesium[_0x4f0256(0x1ea)](_0x59cdd7,_0x5b8764[_0x4f0256(0x1f9)]),this[_0x4f0256(0x1f2)]=![],this[_0x4f0256(0x21c)]=![],this[_0x4f0256(0x218)]=new Cesium['Event'](),this[_0x4f0256(0x1ff)]=new Cesium[(_0x4f0256(0x1e1))](),this['movingEvt']=new Cesium[(_0x4f0256(0x1e1))](),this['polylines']=undefined,this['polyline']=undefined,this['polygon']=undefined,this[_0x4f0256(0x1f5)]=undefined,this[_0x4f0256(0x208)]=undefined;};Object[_0x592d0b(0x201)](DrawHandler[_0x592d0b(0x20b)],{'drawEvt':{'get':function(){return this['_drawEvt'];}},'activeEvt':{'get':function(){return this['_activeEvt'];}}}),DrawHandler['prototype'][_0x592d0b(0x1ee)]=function(){const _0x21f8e6=_0x592d0b;if(this[_0x21f8e6(0x21c)]===!![])return;this['active']=!![];let _0x5f0bcc=this;this['handler'][_0x21f8e6(0x1e6)](function(_0x17913b){clickHandler(_0x17913b,_0x5f0bcc);},Cesium[_0x21f8e6(0x220)]['LEFT_CLICK']),this['handler']['setInputAction'](function(_0x354e02){moveHandler(_0x354e02,_0x5f0bcc);},Cesium[_0x21f8e6(0x220)][_0x21f8e6(0x221)]),this[_0x21f8e6(0x209)][_0x21f8e6(0x1e6)](function(_0x230421){rclkHandler(_0x230421,_0x5f0bcc);},Cesium[_0x21f8e6(0x220)]['RIGHT_CLICK']),this['activeEvt']['raiseEvent'](!![]);},DrawHandler[_0x592d0b(0x20b)]['deactivate']=function(){const _0x29ac38=_0x592d0b;this['active']=![],this[_0x29ac38(0x1f2)]=![],this[_0x29ac38(0x209)]['removeInputAction'](Cesium[_0x29ac38(0x220)][_0x29ac38(0x1f6)]),this['handler'][_0x29ac38(0x231)](Cesium[_0x29ac38(0x220)]['MOUSE_MOVE']),this[_0x29ac38(0x209)][_0x29ac38(0x231)](Cesium[_0x29ac38(0x220)][_0x29ac38(0x20e)]),this['activeEvt'][_0x29ac38(0x211)](![]);},DrawHandler[_0x592d0b(0x20b)][_0x592d0b(0x1e3)]=function(){const _0x2ee00c=_0x592d0b;this[_0x2ee00c(0x20a)](),this[_0x2ee00c(0x20f)]&&(this[_0x2ee00c(0x20f)][_0x2ee00c(0x210)](),this[_0x2ee00c(0x22b)][_0x2ee00c(0x215)][_0x2ee00c(0x206)][_0x2ee00c(0x22c)](this[_0x2ee00c(0x20f)]),this[_0x2ee00c(0x20f)]=undefined),this[_0x2ee00c(0x203)]&&(this[_0x2ee00c(0x22b)]['entities'][_0x2ee00c(0x22c)](this[_0x2ee00c(0x203)]),this['polygon']=undefined),this[_0x2ee00c(0x1f5)]&&(this[_0x2ee00c(0x1f5)][_0x2ee00c(0x210)](),this[_0x2ee00c(0x22b)][_0x2ee00c(0x215)][_0x2ee00c(0x206)][_0x2ee00c(0x22c)](this['points']),this['points']=undefined);};function clickHandler(_0x2795ac,_0x424ab7){const _0x2e5405=_0x592d0b;let _0x5a8d09=_0x424ab7;if(_0x5a8d09&&_0x5a8d09[_0x2e5405(0x21c)]){let _0x166ab0=_0x5a8d09[_0x2e5405(0x22b)]['scene'];if(!_0x166ab0[_0x2e5405(0x20c)]){console[_0x2e5405(0x22f)](_0x2e5405(0x1fa));return;}let _0x4dccd0=_0x166ab0[_0x2e5405(0x225)](_0x2795ac['position']);if(_0x4dccd0){if(!_0x5a8d09[_0x2e5405(0x1f2)]){_0x5a8d09[_0x2e5405(0x1f2)]=!![];switch(_0x5a8d09['mode']){case _0xb0c8b2[_0x2e5405(0x1e7)]:startDrawPoint(_0x4dccd0,_0x5a8d09);break;case _0xb0c8b2[_0x2e5405(0x1e9)]:startDrawLine(_0x4dccd0,_0x5a8d09);break;case _0xb0c8b2[_0x2e5405(0x212)]:startDrawPolygon(_0x4dccd0,_0x5a8d09);break;}}else {let _0x4d8316=new Cesium[(_0x2e5405(0x202))](_0x2795ac[_0x2e5405(0x200)]['x'],_0x2795ac['position']['y']);switch(_0x5a8d09[_0x2e5405(0x21e)]){case _0xb0c8b2[_0x2e5405(0x1e9)]:processLine(_0x4d8316,_0x5a8d09,!![]);break;case _0xb0c8b2[_0x2e5405(0x212)]:processPolygon(_0x4d8316,_0x5a8d09,!![]);break;}}}}}function startDrawPoint(_0x156952,_0x563598){const _0x351865=_0x592d0b;let _0x3d0ab9=_0x563598;!_0x3d0ab9[_0x351865(0x1f5)]?(_0x3d0ab9[_0x351865(0x1f5)]=new Cesium[(_0x351865(0x20d))](),_0x3d0ab9[_0x351865(0x208)]=_0x3d0ab9[_0x351865(0x1f5)][_0x351865(0x219)]({'position':_0x156952,'pixelSize':0xa,'color':Cesium[_0x351865(0x222)]['WHITE']}),_0x3d0ab9[_0x351865(0x22b)][_0x351865(0x215)][_0x351865(0x206)]['add'](_0x3d0ab9[_0x351865(0x1f5)])):_0x3d0ab9[_0x351865(0x208)][_0x351865(0x200)]=_0x156952,_0x3d0ab9['deactivate'](),_0x3d0ab9[_0x351865(0x1e4)][_0x351865(0x211)]({'object':_0x3d0ab9[_0x351865(0x208)]});}function startDrawLine(_0x5ad8c9,_0x51a6df){const _0x4fdfb3=_0x592d0b;let _0x55e30a=_0x51a6df;!_0x55e30a[_0x4fdfb3(0x20f)]?(_0x55e30a[_0x4fdfb3(0x20f)]=new Cesium[(_0x4fdfb3(0x22a))](),_0x55e30a[_0x4fdfb3(0x1e2)]=_0x55e30a[_0x4fdfb3(0x20f)][_0x4fdfb3(0x219)]({'width':0x2,'positions':[_0x5ad8c9,_0x5ad8c9],'material':Cesium[_0x4fdfb3(0x205)]['fromType'](Cesium['Material']['ColorType'],{'color':Cesium[_0x4fdfb3(0x222)]['fromCssColorString'](_0x4fdfb3(0x1eb))})}),_0x55e30a[_0x4fdfb3(0x22b)][_0x4fdfb3(0x215)][_0x4fdfb3(0x206)]['add'](_0x55e30a[_0x4fdfb3(0x20f)])):(_0x55e30a[_0x4fdfb3(0x1e2)]['show']=!![],_0x55e30a['polyline'][_0x4fdfb3(0x22d)]=[_0x5ad8c9,_0x5ad8c9]);}function startDrawPolygon(_0x5de360,_0x24ac59){const _0x45c399=_0x592d0b;let _0x237692=_0x24ac59;!_0x237692['polylines']?(_0x237692['polylines']=new Cesium[(_0x45c399(0x22a))](),_0x237692[_0x45c399(0x1e2)]=_0x237692[_0x45c399(0x20f)]['add']({'id':_0x45c399(0x1f0)+Math['random'](),'width':0x2,'positions':[_0x5de360,_0x5de360],'material':Cesium[_0x45c399(0x205)][_0x45c399(0x230)](Cesium['Material'][_0x45c399(0x21f)],{'color':Cesium['Color'][_0x45c399(0x1e8)](_0x45c399(0x1eb))}),'loop':!![]}),_0x237692[_0x45c399(0x22b)]['scene']['primitives'][_0x45c399(0x219)](_0x237692[_0x45c399(0x20f)])):(_0x237692[_0x45c399(0x1e2)][_0x45c399(0x217)]=!![],_0x237692['polyline'][_0x45c399(0x22d)]=[_0x5de360,_0x5de360],_0x237692[_0x45c399(0x203)]&&(_0x237692[_0x45c399(0x203)][_0x45c399(0x217)]=![]));}function _0x121c(_0x2784e7,_0x377078){_0x2784e7=_0x2784e7-0x1e1;let _0x4f52f3=_0x4f52[_0x2784e7];return _0x4f52f3;}function moveHandler(_0x4d7d7a,_0x476fac){const _0x380d5b=_0x592d0b;let _0x3aaefb=_0x476fac;if(_0x3aaefb&&_0x3aaefb[_0x380d5b(0x21c)]&&_0x3aaefb[_0x380d5b(0x1f2)]){let _0x2317a9=new Cesium[(_0x380d5b(0x202))](_0x4d7d7a[_0x380d5b(0x207)]['x'],_0x4d7d7a['endPosition']['y']);switch(_0x3aaefb['mode']){case _0xb0c8b2[_0x380d5b(0x1e9)]:processLine(_0x2317a9,_0x3aaefb,![]);break;case _0xb0c8b2['Polygon']:processPolygon(_0x2317a9,_0x3aaefb,![]);break;}}_0x3aaefb[_0x380d5b(0x1f4)][_0x380d5b(0x211)](new Cesium[(_0x380d5b(0x202))](_0x4d7d7a[_0x380d5b(0x207)]['x'],_0x4d7d7a[_0x380d5b(0x207)]['y']));}function processLine(_0x319088,_0x13a81f,_0x1e6573){const _0x46c309=_0x592d0b;let _0x4a194e=_0x13a81f,_0x110e1b=_0x4a194e[_0x46c309(0x22b)][_0x46c309(0x215)],_0xe4aba9=_0x110e1b[_0x46c309(0x225)](_0x319088);if(!_0xe4aba9)return;let _0x7b7b03=_0x4a194e['polyline'][_0x46c309(0x22d)],_0x4e1846=_0x7b7b03[_0x46c309(0x1f8)];_0x1e6573?_0x7b7b03[_0x4e1846]=_0xe4aba9:_0x7b7b03[_0x4e1846-0x1]=_0xe4aba9,_0x4a194e[_0x46c309(0x1e2)][_0x46c309(0x22d)]=_0x7b7b03;}function processPolygon(_0x9fbc31,_0x642aa3,_0x599ac4){const _0x5ae899=_0x592d0b;let _0x288ad5=_0x642aa3,_0x1a860f=_0x288ad5[_0x5ae899(0x22b)][_0x5ae899(0x215)],_0x26a569=_0x1a860f[_0x5ae899(0x225)](_0x9fbc31);if(!_0x26a569)return;let _0x20c762=_0x288ad5[_0x5ae899(0x1e2)][_0x5ae899(0x22d)],_0x26da84=_0x20c762[_0x5ae899(0x1f8)];_0x599ac4?_0x20c762[_0x26da84]=_0x26a569:_0x20c762[_0x26da84-0x1]=_0x26a569,_0x288ad5[_0x5ae899(0x1e2)][_0x5ae899(0x22d)]=_0x20c762;}function rclkHandler(_0x7dd09b,_0x547157){const _0x435200=_0x592d0b;let _0x56f340=_0x547157;if(_0x56f340&&_0x56f340[_0x435200(0x21c)]&&_0x56f340[_0x435200(0x1f2)]){_0x56f340[_0x435200(0x20a)]();if(!_0x56f340['polyline'])return;_0x56f340['polyline'][_0x435200(0x22d)]=_0x56f340[_0x435200(0x1e2)]['positions'][_0x435200(0x229)](0x0,_0x56f340[_0x435200(0x1e2)]['positions'][_0x435200(0x1f8)]-0x1);if(_0x56f340[_0x435200(0x21e)]===_0xb0c8b2[_0x435200(0x212)]){if(_0x56f340[_0x435200(0x1e2)][_0x435200(0x22d)][_0x435200(0x1f8)]<0x3){_0x56f340['polyline'][_0x435200(0x22d)][_0x435200(0x1f8)]=0x0;return;}let _0x171850=[][_0x435200(0x226)](_0x56f340[_0x435200(0x1e2)][_0x435200(0x22d)]);!_0x56f340[_0x435200(0x203)]&&(_0x56f340['polygon']=_0x56f340[_0x435200(0x22b)]['entities'][_0x435200(0x219)]({'polygon':{'hierarchy':{'positions':_0x171850},'material':Cesium[_0x435200(0x222)][_0x435200(0x228)][_0x435200(0x21a)](0.5),'perPositionHeight':_0x5b8764[_0x435200(0x1f9)]===_0x56f340[_0x435200(0x1f3)]}})),_0x56f340[_0x435200(0x203)][_0x435200(0x203)][_0x435200(0x22e)]=_0x171850,_0x56f340['polygon']['positions']=_0x171850,_0x56f340[_0x435200(0x203)][_0x435200(0x217)]=!![],_0x56f340[_0x435200(0x1e4)][_0x435200(0x211)]({'object':_0x56f340[_0x435200(0x203)]});}else {if(_0x56f340[_0x435200(0x21e)]===_0xb0c8b2[_0x435200(0x1e9)]){let _0x54aa0c=[];for(let _0x37dda8=0x0,_0x5834f7=_0x56f340[_0x435200(0x1e2)][_0x435200(0x22d)][_0x435200(0x1f8)];_0x37dda8<_0x5834f7;_0x37dda8++){_0x54aa0c['push'](Cesium[_0x435200(0x21b)][_0x435200(0x1fc)](_0x56f340['polyline'][_0x435200(0x22d)][_0x37dda8]));}(_0x56f340[_0x435200(0x1f3)]===_0x5b8764[_0x435200(0x1f1)]||_0x56f340[_0x435200(0x1f3)]===_0x5b8764[_0x435200(0x21d)])&&(!_0x56f340[_0x435200(0x224)]&&(_0x56f340[_0x435200(0x224)]=[]),_0x56f340['clampToGroundPolylines'][_0x435200(0x1e5)](_0x56f340[_0x435200(0x22b)][_0x435200(0x1f7)]['add']({'polyline':{'positions':_0x54aa0c,'width':0x5,'material':Cesium['Color'][_0x435200(0x1e8)](_0x435200(0x1eb)),'clampToGround':!![]}})),_0x56f340['polyline'][_0x435200(0x217)]=![]),_0x56f340[_0x435200(0x1e4)]['raiseEvent']({'object':_0x56f340['polyline']});}}}}

    const _0x35b3=['102vnsWPf','1644560LbAiYL','12403ZrSFDD','1424261nzTgnG','9GVKVpn','2GwKGpW','50603qeYfsx','223013EAhilH','255730wsvKhj','5aLASfG','288323GZyWVW'];(function(_0x5791ef,_0x224f37){const _0xea8c55=_0x8b54;while(!![]){try{const _0xa0114c=parseInt(_0xea8c55(0x1dd))*-parseInt(_0xea8c55(0x1df))+-parseInt(_0xea8c55(0x1e5))+parseInt(_0xea8c55(0x1dc))+-parseInt(_0xea8c55(0x1e1))+parseInt(_0xea8c55(0x1e3))*-parseInt(_0xea8c55(0x1de))+-parseInt(_0xea8c55(0x1e6))*-parseInt(_0xea8c55(0x1e4))+parseInt(_0xea8c55(0x1e0))*parseInt(_0xea8c55(0x1e2));if(_0xa0114c===_0x224f37)break;else _0x5791ef['push'](_0x5791ef['shift']());}catch(_0x11a0c3){_0x5791ef['push'](_0x5791ef['shift']());}}}(_0x35b3,0xd4e85));const MeasureMode={'Distance':0x0,'Area':0x1,'DVH':0x2};function _0x8b54(_0x25d5a2,_0x275115){_0x25d5a2=_0x25d5a2-0x1dc;let _0x35b33=_0x35b3[_0x25d5a2];return _0x35b33;}var _0x30b699 = Object['freeze'](MeasureMode);

    const _0x15c6=['NON_OCCLUDED','_accumulationDis','corridor','globe','lineDisplayType','plane','startPoint','Cartographic','unpackArray','MAX_VALUE','primitives','canvas','positions','Check','ORANGE','concat','indices','viewer\x20and\x20mode\x20is\x20required!','_currentArea','MOUSE_MOVE','PolylineCollection','_measureEvt','_vLabel','_dblclickListener','_labelPixelOffsetScaleByDistance','BLUE','DVH','HorizontalOrigin','distance','35491HuDNtQ','fromCssColorString','Cartesian2','negate','activate','entities','spEntity','clone','normal','endPoint','values','Area','_lineDisplayType','max','createGeometry','Space','defineProperties','normalize','Material','subtract','clampToGroundPolyline','measureEvt','ColorType','_areaLabel','add','Math','_activeEvt','WHITE','cross','verticalPolyline','show','Cartesian3','_showMeasureResult','longitude','_hLabel','PolygonGeometryLibrary','prototype','rayPlane','hierarchy','PolygonPipeline','319868deboZI','length','37078SrcQtf','RIGHT_CLICK','typeOf','LabelStyle','_accumulationPositions','removeInputAction','magnitude','horizontalPolyline','LEFT_CLICK','Ray','209901tcdVSJ','_clampMode','greaterThanOrEquals','LabelCollection','slice','labels','position','BLACK','_labelPixelOffset','_capturePointSize','fromType','Event','19KjfpZl','dirPolyline','FILL_AND_OUTLINE','MeasureHandler.lineDisplayType','clampToGroundPolylinePositions','active','100\x2020px\x20SimSun','fromCartesian','294399MJDpvX','deactivate','attributes','PolygonGeometry','toFixed','isDrawing','NearFarScalar','_accumulationArea','_enableDepthTest','polygon','polyline','defaultValue','S3mModel','angleBetween','clampToGroundPolygonPositions','getHeight','computeArea','2GKJvqq','fromRadians','number','remove','scene','_value','rgba(38,\x2038,\x2038,\x200.85)','52719XhDXMl','fpEntity','push','487488urSGYZ','lessThanOrEquals','mode','removeAll','Plane','fromPointNormal','Distance','latitude','DeveloperError','#51ff00','startHeight','Ground','clear','lerp','_position','raiseEvent','CallbackProperty','IntersectionTests','polylines','endPosition','tmpEntities','ScreenSpaceEventType','_currentDis','fromCache','_lineColor','1RZKyBz','epEntity','500\x2016px\x20sans-serif','negateNormal','defined','Color','handler','setInputAction','subdivideLine','activeEvt','_lineWidth','fromPositions','LEFT','pickPosition','viewer','toCartesian','#ffe500','_disLabel','_capturePointColor','_labelBackgroundColor','_fillColor'];const _0x5ce439=_0x2729;(function(_0x48447a,_0x4bad78){const _0x2f8ff0=_0x2729;while(!![]){try{const _0x55e1bc=parseInt(_0x2f8ff0(0x1f8))+parseInt(_0x2f8ff0(0x1ce))*-parseInt(_0x2f8ff0(0x19c))+-parseInt(_0x2f8ff0(0x168))+-parseInt(_0x2f8ff0(0x154))+parseInt(_0x2f8ff0(0x183))+-parseInt(_0x2f8ff0(0x179))*parseInt(_0x2f8ff0(0x1f6))+parseInt(_0x2f8ff0(0x180))*parseInt(_0x2f8ff0(0x160));if(_0x55e1bc===_0x4bad78)break;else _0x48447a['push'](_0x48447a['shift']());}catch(_0xcd8b46){_0x48447a['push'](_0x48447a['shift']());}}}(_0x15c6,0x54a4c));function MeasureHandler(_0x49034d,_0x5bdf51,_0x1f4159,_0x354d75){const _0x757325=_0x2729;if(!_0x49034d||!Cesium[_0x757325(0x1a0)](_0x5bdf51))throw new Cesium[(_0x757325(0x18b))](_0x757325(0x1c2));this['handler']=new Cesium['ScreenSpaceEventHandler'](_0x49034d[_0x757325(0x17d)][_0x757325(0x1bc)]),this[_0x757325(0x1aa)]=_0x49034d,this[_0x757325(0x155)]=Cesium[_0x757325(0x173)](_0x1f4159,_0x5b8764[_0x757325(0x1dd)]),this[_0x757325(0x185)]=_0x5bdf51,this['isDrawing']=![],this['active']=![],this['tmpEntities']=[],this[_0x757325(0x1e5)]=undefined,this[_0x757325(0x1ad)]=undefined,this[_0x757325(0x1c7)]=undefined,this[_0x757325(0x1f0)]=undefined,this[_0x757325(0x1c6)]=new Cesium[(_0x757325(0x15f))](),this[_0x757325(0x1e8)]=new Cesium['Event'](),this['_enableDepthTest']=![],this[_0x757325(0x1af)]=Cesium[_0x757325(0x1a1)][_0x757325(0x1cf)](_0x757325(0x17f)),this[_0x757325(0x1c9)]=new Cesium[(_0x757325(0x16e))](0x96,0x3,0xe4e1c0,0.5),this[_0x757325(0x15c)]=new Cesium[(_0x757325(0x1d0))](0xf,0x0),this['_lineColor']=Cesium[_0x757325(0x1a1)][_0x757325(0x1cf)](_0x757325(0x18c)),this[_0x757325(0x1b0)]=Cesium[_0x757325(0x1a1)][_0x757325(0x1bf)]['withAlpha'](0.5),this[_0x757325(0x1a6)]=0x2,this[_0x757325(0x1c8)]=undefined,this['_showMeasureResult']=Cesium[_0x757325(0x173)](_0x354d75,!![]),this[_0x757325(0x1da)]=LineDisplayType[_0x757325(0x1b1)];}Object[_0x5ce439(0x1de)](MeasureHandler[_0x5ce439(0x1f2)],{'activeEvt':{'get':function(){return this['_activeEvt'];}},'measureEvt':{'get':function(){const _0x2f0e83=_0x5ce439;return this[_0x2f0e83(0x1c6)];}},'disLabel':{'get':function(){const _0x3f48c0=_0x5ce439;return this[_0x3f48c0(0x1ad)];}},'areaLabel':{'get':function(){return this['_areaLabel'];}},'hLabel':{'get':function(){const _0x1060e4=_0x5ce439;return this[_0x1060e4(0x1f0)];}},'vLabel':{'get':function(){const _0x131699=_0x5ce439;return this[_0x131699(0x1c7)];}},'capturePointSize':{'get':function(){const _0x530268=_0x5ce439;return this[_0x530268(0x1aa)]['_capturePointSize'];},'set':function(_0x48061f){const _0x3119e6=_0x5ce439;this[_0x3119e6(0x1aa)][_0x3119e6(0x15d)]=_0x48061f;}},'capturePointColor':{'get':function(){const _0x26c656=_0x5ce439;return this[_0x26c656(0x1aa)][_0x26c656(0x1ae)];},'set':function(_0x25ff94){const _0x575848=_0x5ce439;this['viewer'][_0x575848(0x1ae)]=_0x25ff94;}},'lineColor':{'get':function(){const _0x4f2125=_0x5ce439;return this[_0x4f2125(0x19b)];},'set':function(_0x5cfeba){this['_lineColor']=_0x5cfeba;}},'fillColor':{'get':function(){const _0x388e7f=_0x5ce439;return this[_0x388e7f(0x1b0)];},'set':function(_0x5114fc){const _0x370fb8=_0x5ce439;this[_0x370fb8(0x1b0)]=_0x5114fc;}},'lineWidth':{'get':function(){const _0x175334=_0x5ce439;return this[_0x175334(0x1a6)];},'set':function(_0xc8d5d1){const _0x8ea990=_0x5ce439;this[_0x8ea990(0x1a6)]=_0xc8d5d1;}},'lineDisplayType':{'get':function(){const _0x15d383=_0x5ce439;return this[_0x15d383(0x1da)];},'set':function(_0x57b49b){const _0x20ad85=_0x5ce439;Cesium['Check'][_0x20ad85(0x1fa)][_0x20ad85(0x17b)][_0x20ad85(0x156)](_0x20ad85(0x163),_0x57b49b,0x0),Cesium[_0x20ad85(0x1be)][_0x20ad85(0x1fa)][_0x20ad85(0x17b)][_0x20ad85(0x184)](_0x20ad85(0x163),_0x57b49b,0x2),this['_lineDisplayType']=_0x57b49b,this[_0x20ad85(0x195)]&&(this[_0x20ad85(0x195)][_0x20ad85(0x1b5)]=_0x57b49b);}}}),MeasureHandler['prototype'][_0x5ce439(0x1d2)]=function(){const _0x4e0404=_0x5ce439;this[_0x4e0404(0x18f)]();if(this[_0x4e0404(0x165)])return;this[_0x4e0404(0x165)]=!![];let _0x533906=this;this[_0x4e0404(0x1a2)][_0x4e0404(0x1a3)](function(_0x2ea4e8){clickHandler$1(_0x2ea4e8,_0x533906);},Cesium['ScreenSpaceEventType']['LEFT_CLICK']),this['handler'][_0x4e0404(0x1a3)](function(_0x104e7a){moveHandler$1(_0x104e7a,_0x533906);},Cesium[_0x4e0404(0x198)][_0x4e0404(0x1c4)]),this[_0x4e0404(0x1a2)][_0x4e0404(0x1a3)](function(_0x1afab3){rclkHandler$1(_0x1afab3,_0x533906);},Cesium['ScreenSpaceEventType'][_0x4e0404(0x1f9)]),this['activeEvt']['raiseEvent'](!![]);},MeasureHandler[_0x5ce439(0x1f2)][_0x5ce439(0x169)]=function(){const _0x15de93=_0x5ce439;this[_0x15de93(0x165)]&&this[_0x15de93(0x1a5)][_0x15de93(0x192)](![]),this[_0x15de93(0x165)]=![],this['isDrawing']=![],this[_0x15de93(0x1a2)][_0x15de93(0x14f)](Cesium['ScreenSpaceEventType'][_0x15de93(0x152)]),this[_0x15de93(0x1a2)][_0x15de93(0x14f)](Cesium['ScreenSpaceEventType'][_0x15de93(0x1c4)]),this[_0x15de93(0x1a2)][_0x15de93(0x14f)](Cesium[_0x15de93(0x198)][_0x15de93(0x1f9)]);},MeasureHandler[_0x5ce439(0x1f2)]['clear']=function(){const _0x14598a=_0x5ce439;this[_0x14598a(0x169)]();for(let _0x1c48f5=0x0,_0x4b6544=this[_0x14598a(0x197)][_0x14598a(0x1f7)];_0x1c48f5<_0x4b6544;_0x1c48f5++){this['viewer']['entities']['remove'](this[_0x14598a(0x197)][_0x1c48f5]);}this[_0x14598a(0x1e2)]&&(this[_0x14598a(0x1aa)][_0x14598a(0x1d3)][_0x14598a(0x17c)](this[_0x14598a(0x1e2)]),this[_0x14598a(0x1e2)]=null);this[_0x14598a(0x197)][_0x14598a(0x1f7)]=0x0;this['polylines']&&(this['polylines'][_0x14598a(0x186)](),this[_0x14598a(0x1aa)][_0x14598a(0x17d)]['primitives'][_0x14598a(0x17c)](this[_0x14598a(0x195)]),this[_0x14598a(0x195)]=undefined);this[_0x14598a(0x1d4)]&&(this[_0x14598a(0x1aa)][_0x14598a(0x1d3)][_0x14598a(0x17c)](this[_0x14598a(0x1d4)]),this[_0x14598a(0x1d4)]=undefined);this[_0x14598a(0x19d)]&&(this[_0x14598a(0x1aa)][_0x14598a(0x1d3)]['remove'](this['epEntity']),this[_0x14598a(0x19d)]=undefined);this[_0x14598a(0x181)]&&(this[_0x14598a(0x1aa)][_0x14598a(0x1d3)]['remove'](this[_0x14598a(0x181)]),this[_0x14598a(0x181)]=undefined);if(this['labels'])switch(this['mode']){case _0x30b699[_0x14598a(0x189)]:this[_0x14598a(0x159)][_0x14598a(0x17c)](this[_0x14598a(0x1ad)]);break;case _0x30b699[_0x14598a(0x1d9)]:this[_0x14598a(0x159)]['remove'](this['_areaLabel']);break;case _0x30b699[_0x14598a(0x1cb)]:this['labels'][_0x14598a(0x17c)](this[_0x14598a(0x1ad)]),this[_0x14598a(0x159)][_0x14598a(0x17c)](this[_0x14598a(0x1f0)]),this[_0x14598a(0x159)][_0x14598a(0x17c)](this[_0x14598a(0x1c7)]);break;}this[_0x14598a(0x171)]&&(this[_0x14598a(0x1aa)][_0x14598a(0x1d3)]['remove'](this[_0x14598a(0x171)]),this[_0x14598a(0x171)]=undefined),this[_0x14598a(0x1b3)]&&(this[_0x14598a(0x1aa)][_0x14598a(0x1d3)]['remove'](this['corridor']),this['corridor']=undefined);};function clickHandler$1(_0x194f6c,_0x2f9e92){const _0x5b1376=_0x5ce439;let _0x700697=_0x2f9e92;if(_0x700697&&_0x700697[_0x5b1376(0x165)]){let _0x2019ed=_0x700697[_0x5b1376(0x1aa)][_0x5b1376(0x17d)],_0x5367b0=_0x2019ed[_0x5b1376(0x1a9)](_0x194f6c[_0x5b1376(0x15a)]);if(_0x5367b0){if(!_0x700697['isDrawing']){_0x700697[_0x5b1376(0x16d)]=!![];switch(_0x700697[_0x5b1376(0x185)]){case _0x30b699[_0x5b1376(0x189)]:startMeasureDis(_0x5367b0,_0x700697);break;case _0x30b699[_0x5b1376(0x1d9)]:startMeasureArea(_0x5367b0,_0x700697);break;case _0x30b699['DVH']:startMeasureDVH(_0x5367b0,_0x700697);break;}}else _0x700697[_0x5b1376(0x185)]==_0x30b699['DVH']?_0x700697[_0x5b1376(0x169)]():processClk(_0x5367b0,_0x700697);}}}function moveHandler$1(_0x1909b4,_0x238f2d){const _0x404337=_0x5ce439;let _0x36823f=_0x238f2d,_0x2eba97=_0x36823f[_0x404337(0x1aa)]['scene'],_0x1482b7=_0x2eba97['pickPosition'](_0x1909b4[_0x404337(0x196)]);if(_0x36823f&&_0x36823f['active']&&_0x36823f[_0x404337(0x16d)]&&_0x1482b7)switch(_0x36823f[_0x404337(0x185)]){case _0x30b699['Distance']:processDistance(_0x1482b7,_0x36823f);break;case _0x30b699[_0x404337(0x1d9)]:processArea(_0x1482b7,_0x36823f);break;case _0x30b699[_0x404337(0x1cb)]:processDVH(_0x1482b7,_0x36823f);break;}}function rclkHandler$1(_0x5822a2,_0xb388d4){const _0x3a17dc=_0x5ce439;let _0x52f769=_0xb388d4;if(_0x52f769&&_0x52f769[_0x3a17dc(0x165)]&&_0x52f769[_0x3a17dc(0x16d)]){_0x52f769['deactivate']();let _0xab1246;if(_0x52f769[_0x3a17dc(0x172)]){_0x52f769[_0x3a17dc(0x185)]===_0x30b699['Distance']?(_0x52f769['polylines'][_0x3a17dc(0x17c)](_0x52f769[_0x3a17dc(0x172)]),_0xab1246=_0x52f769['_accumulationPositions'],_0x52f769[_0x3a17dc(0x195)][_0x3a17dc(0x1f7)]===0x0&&_0x52f769['viewer'][_0x3a17dc(0x1d3)][_0x3a17dc(0x17c)](_0x52f769[_0x3a17dc(0x1d4)])):(_0x52f769['polyline'][_0x3a17dc(0x1bd)]=_0x52f769['polyline'][_0x3a17dc(0x1bd)][_0x3a17dc(0x158)](0x0,_0x52f769['polyline']['positions'][_0x3a17dc(0x1f7)]-0x1),_0x52f769[_0x3a17dc(0x172)][_0x3a17dc(0x1bd)][_0x3a17dc(0x1f7)]===0x1&&_0x52f769[_0x3a17dc(0x1aa)][_0x3a17dc(0x1d3)][_0x3a17dc(0x17c)](_0x52f769[_0x3a17dc(0x1d4)]),_0xab1246=_0x52f769[_0x3a17dc(0x172)]['positions']);_0x52f769['viewer'][_0x3a17dc(0x1d3)][_0x3a17dc(0x17c)](_0x52f769[_0x3a17dc(0x19d)]);if(!_0x52f769[_0x3a17dc(0x171)]){(_0x52f769[_0x3a17dc(0x155)]===_0x5b8764[_0x3a17dc(0x18e)]||_0x52f769[_0x3a17dc(0x155)]===_0x5b8764['S3mModel'])&&(_0x52f769[_0x3a17dc(0x164)]=_0xab1246,_0x52f769['polyline'][_0x3a17dc(0x1ec)]=![]);_0x52f769[_0x3a17dc(0x1ad)][_0x3a17dc(0x15a)]=_0xab1246[_0xab1246[_0x3a17dc(0x1f7)]-0x1];let _0x33e156=0x0;if(_0xb388d4[_0x3a17dc(0x155)]===_0x5b8764['Ground'])_0x33e156=computeClampDistance(_0x52f769[_0x3a17dc(0x1aa)][_0x3a17dc(0x17d)],_0x52f769[_0x3a17dc(0x14e)]);else for(let _0x5512fd=0x0,_0x48d98e=_0xab1246[_0x3a17dc(0x1f7)]-0x1;_0x5512fd<_0x48d98e;_0x5512fd++){_0x33e156+=Cesium[_0x3a17dc(0x1ed)]['distance'](_0xab1246[_0x5512fd],_0xab1246[_0x5512fd+0x1]);}_0x52f769['_disLabel'][_0x3a17dc(0x1ec)]=_0x33e156!==0x0,_0x52f769[_0x3a17dc(0x1e3)]['raiseEvent']({'distance':_0x33e156['toFixed'](0x8),'positions':_0xab1246});}}if(_0x52f769[_0x3a17dc(0x171)]){if(_0xab1246['length']<0x3){_0x52f769[_0x3a17dc(0x1e5)]['show']=![],_0x52f769[_0x3a17dc(0x1aa)]['entities'][_0x3a17dc(0x17c)](_0x52f769['spEntity']);for(let _0x58d4af=0x0,_0x56e2b6=_0x52f769[_0x3a17dc(0x197)][_0x3a17dc(0x1f7)];_0x58d4af<_0x56e2b6;_0x58d4af++){_0x52f769[_0x3a17dc(0x1aa)]['entities']['remove'](_0x52f769[_0x3a17dc(0x197)][_0x58d4af]);}_0x52f769['tmpEntities']['length']=0x0,_0x52f769[_0x3a17dc(0x1aa)][_0x3a17dc(0x1d3)][_0x3a17dc(0x17c)](_0x52f769[_0x3a17dc(0x19d)]),_0x52f769[_0x3a17dc(0x172)][_0x3a17dc(0x1bd)][_0x3a17dc(0x1f7)]=0x0;}_0x52f769[_0x3a17dc(0x1e5)]['show']=!![];(_0x52f769[_0x3a17dc(0x155)]==_0x5b8764[_0x3a17dc(0x18e)]||_0x52f769[_0x3a17dc(0x155)]==_0x5b8764[_0x3a17dc(0x174)])&&(_0x52f769[_0x3a17dc(0x172)]['show']=![]);_0x52f769[_0x3a17dc(0x176)]=_0x52f769[_0x3a17dc(0x172)][_0x3a17dc(0x1bd)],_0x52f769[_0x3a17dc(0x171)][_0x3a17dc(0x1ec)]=!![];if(_0xab1246[_0x3a17dc(0x1f7)]>0x2){if(_0x52f769[_0x3a17dc(0x155)]!==_0x5b8764[_0x3a17dc(0x18e)])_0x52f769[_0x3a17dc(0x1e5)]['position']=_0x52f769[_0x3a17dc(0x172)]['positions'][_0x52f769['polyline'][_0x3a17dc(0x1bd)][_0x3a17dc(0x1f7)]-0x1];else {let _0xfaa7b2=_0x52f769[_0x3a17dc(0x197)][_0x52f769['tmpEntities'][_0x3a17dc(0x1f7)]-0x1],_0xe6c0f4=_0xfaa7b2[_0x3a17dc(0x191)][_0x3a17dc(0x17e)];_0x52f769[_0x3a17dc(0x1e5)][_0x3a17dc(0x15a)]=_0xe6c0f4;}if(_0x52f769['_clampMode']===_0x5b8764[_0x3a17dc(0x18e)]){let _0x4362d3=computeClampArea(_0x52f769['viewer'][_0x3a17dc(0x17d)],_0x52f769[_0x3a17dc(0x172)]['positions']);_0x52f769[_0x3a17dc(0x1e3)]['raiseEvent']({'area':_0x4362d3['toFixed'](0x8),'positions':_0xab1246});return;}let _0x16bf18=Cesium[_0x3a17dc(0x1f5)]['triangulate'](_0xab1246),_0x2c0e8f=_0x16bf18[_0x3a17dc(0x1f7)]/0x3,_0x45dfe3,_0x41f68f,_0x16b4e8,_0x476d56=0x0;for(let _0x106e8e=0x0;_0x106e8e<_0x2c0e8f;_0x106e8e++){_0x45dfe3=_0xab1246[_0x16bf18[_0x106e8e*0x3]],_0x41f68f=_0xab1246[_0x16bf18[_0x106e8e*0x3+0x1]],_0x16b4e8=_0xab1246[_0x16bf18[_0x106e8e*0x3+0x2]],v12Scratch=Cesium[_0x3a17dc(0x1ed)][_0x3a17dc(0x1e1)](_0x41f68f,_0x45dfe3,v12Scratch),v13Scratch=Cesium[_0x3a17dc(0x1ed)][_0x3a17dc(0x1e1)](_0x16b4e8,_0x45dfe3,v13Scratch),crossScratch=Cesium['Cartesian3'][_0x3a17dc(0x1ea)](v12Scratch,v13Scratch,crossScratch),_0x476d56+=0.5*Cesium[_0x3a17dc(0x1ed)][_0x3a17dc(0x150)](crossScratch);}_0x52f769[_0x3a17dc(0x1e3)]['raiseEvent']({'area':_0x476d56['toFixed'](0x8),'positions':_0xab1246});}}}}function processClk(_0x2373cf,_0x44108d){const _0x1af4b7=_0x5ce439;let _0x247343=_0x44108d;_0x247343['mode']===_0x30b699['Distance']?(_0x247343[_0x1af4b7(0x172)]=_0x247343['polylines'][_0x1af4b7(0x1e6)]({'width':_0x247343[_0x1af4b7(0x1a6)],'show':_0x247343[_0x1af4b7(0x1ee)],'positions':[_0x2373cf,_0x2373cf],'material':Cesium[_0x1af4b7(0x1e0)][_0x1af4b7(0x15e)](Cesium[_0x1af4b7(0x1e0)]['ColorType'],{'color':_0x247343[_0x1af4b7(0x19b)]}),'clampToGround':!![]}),_0x44108d[_0x1af4b7(0x155)]===_0x5b8764[_0x1af4b7(0x18e)]&&(_0x247343[_0x1af4b7(0x172)][_0x1af4b7(0x1ec)]=![],_0x247343['_accumulationDis']=_0x247343[_0x1af4b7(0x199)]),_0x247343['_accumulationPositions']['push'](_0x2373cf)):(_0x247343[_0x1af4b7(0x185)]===_0x30b699[_0x1af4b7(0x1d9)]&&(_0x247343[_0x1af4b7(0x16f)]=_0x247343[_0x1af4b7(0x1c3)]),_0x247343['polyline']['positions'][_0x1af4b7(0x182)](_0x2373cf)),_0x247343[_0x1af4b7(0x171)]&&(_0x44108d[_0x1af4b7(0x155)]!==_0x5b8764['Ground']&&(_0x247343[_0x1af4b7(0x171)]['_polygon'][_0x1af4b7(0x1f4)]=_0x247343[_0x1af4b7(0x172)][_0x1af4b7(0x1bd)])),_0x247343[_0x1af4b7(0x197)]['push'](_0x247343[_0x1af4b7(0x1aa)][_0x1af4b7(0x1d3)][_0x1af4b7(0x1e6)]({'show':_0x247343[_0x1af4b7(0x1ee)],'position':_0x2373cf,'point':{'pixelSize':0x8,'color':Cesium[_0x1af4b7(0x1a1)][_0x1af4b7(0x1cf)]('#ffe500')}}));}let v12Scratch=new Cesium[(_0x5ce439(0x1ed))](),v13Scratch=new Cesium[(_0x5ce439(0x1ed))](),crossScratch=new Cesium['Cartesian3']();function processArea(_0x5c2e7d,_0x37a5ba){const _0x3cc57b=_0x5ce439;let _0x521719=_0x37a5ba,_0x1ee6e0=_0x521719['viewer']['scene'];if(!_0x5c2e7d)return;_0x521719[_0x3cc57b(0x1d7)]=_0x5c2e7d;let _0x507714=_0x521719[_0x3cc57b(0x172)][_0x3cc57b(0x1bd)],_0x235993=_0x507714[_0x3cc57b(0x1f7)];_0x507714[_0x235993-0x1]=_0x5c2e7d;_0x235993>0x2&&(_0x521719[_0x3cc57b(0x1e5)]&&(_0x521719[_0x3cc57b(0x1e5)][_0x3cc57b(0x1ec)]=!![]),_0x521719[_0x3cc57b(0x176)]=_0x507714);_0x521719[_0x3cc57b(0x172)]['positions']=_0x507714;if(_0x507714[_0x3cc57b(0x1f7)]>0x2){_0x521719[_0x3cc57b(0x19d)]['position']=_0x5c2e7d,_0x521719['_areaLabel'][_0x3cc57b(0x15a)]=_0x5c2e7d,_0x521719['_areaLabel'][_0x3cc57b(0x1ec)]=_0x37a5ba['_clampMode']!==_0x5b8764[_0x3cc57b(0x18e)];let _0x1c2a9e;if(_0x37a5ba[_0x3cc57b(0x155)]===_0x5b8764['Ground'])return;_0x1c2a9e=MeasureHandler[_0x3cc57b(0x178)](_0x507714),_0x521719[_0x3cc57b(0x1e3)]['raiseEvent']({'area':_0x1c2a9e[_0x3cc57b(0x16c)](0x8),'positions':_0x507714});}}function startMeasureArea(_0x218289,_0x35fd95){const _0x449958=_0x5ce439;let _0x276dc5=_0x35fd95;_0x276dc5[_0x449958(0x176)]=[],_0x276dc5[_0x449958(0x197)][_0x449958(0x1f7)]=0x0;let _0x28ea48=_0x276dc5['_enableDepthTest'];_0x276dc5[_0x449958(0x195)]=new Cesium[(_0x449958(0x1c5))](),_0x276dc5[_0x449958(0x172)]=_0x276dc5['polylines'][_0x449958(0x1e6)]({'width':_0x276dc5['_lineWidth'],'positions':[_0x218289,_0x218289],'material':Cesium[_0x449958(0x1e0)][_0x449958(0x15e)](Cesium[_0x449958(0x1e0)][_0x449958(0x1e4)],{'color':_0x276dc5[_0x449958(0x19b)]}),'loop':!![]}),_0x276dc5[_0x449958(0x1aa)][_0x449958(0x17d)][_0x449958(0x1bb)][_0x449958(0x1e6)](_0x276dc5[_0x449958(0x195)]),_0x276dc5[_0x449958(0x1d4)]=_0x276dc5['viewer'][_0x449958(0x1d3)][_0x449958(0x1e6)]({'position':_0x218289,'point':{'pixelSize':0x8,'color':Cesium['Color'][_0x449958(0x1cf)](_0x449958(0x1ac))}}),_0x276dc5[_0x449958(0x19d)]=_0x276dc5[_0x449958(0x1aa)]['entities'][_0x449958(0x1e6)]({'position':_0x218289,'point':{'pixelSize':0x8,'color':Cesium[_0x449958(0x1a1)]['fromCssColorString'](_0x449958(0x1ac))}});let _0x114ef0=_0x276dc5[_0x449958(0x1aa)][_0x449958(0x17d)][_0x449958(0x1bb)][_0x449958(0x1e6)](new Cesium['LabelCollection']({'depthTestEnable':![]}));_0x276dc5['_areaLabel']=_0x114ef0[_0x449958(0x1e6)]({'position':_0x218289,'font':_0x449958(0x166),'fillColor':Cesium[_0x449958(0x1a1)]['WHITE'],'style':Cesium[_0x449958(0x14d)][_0x449958(0x162)],'showBackground':!![],'outlineWidth':0x1,'outlineColor':Cesium['Color'][_0x449958(0x1ca)],'pixelOffset':_0x276dc5[_0x449958(0x15c)],'text':'','show':_0x276dc5[_0x449958(0x1ee)],'horizontalOrigin':Cesium['HorizontalOrigin'][_0x449958(0x1a8)]});let _0x98e918=_0x276dc5['_clampMode'],_0x3e0ef7=_0x98e918===_0x5b8764[_0x449958(0x1dd)];_0x276dc5[_0x449958(0x171)]=_0x276dc5[_0x449958(0x1aa)][_0x449958(0x1d3)][_0x449958(0x1e6)]({'polygon':{'hierarchy':new Cesium['CallbackProperty'](function(){const _0x33699a=_0x449958;return {'positions':_0x276dc5[_0x33699a(0x176)],'holes':[]};},![]),'material':_0x276dc5[_0x449958(0x1b0)],'perPositionHeight':_0x3e0ef7},'show':![]}),_0x276dc5[_0x449958(0x159)]=_0x114ef0,_0x35fd95[_0x449958(0x155)]===_0x5b8764[_0x449958(0x18e)]&&(_0x276dc5[_0x449958(0x172)][_0x449958(0x1ec)]=![],_0x276dc5['polygon'][_0x449958(0x1ec)]=!![]),_0x276dc5['_areaLabel'][_0x449958(0x1ec)]=![];}function _0x2729(_0x43076f,_0x505392){_0x43076f=_0x43076f-0x14d;let _0x15c61f=_0x15c6[_0x43076f];return _0x15c61f;}function startMeasureDis(_0x43c0e3,_0x560cfc){const _0x43c9f9=_0x5ce439;let _0x56776b=_0x560cfc;_0x560cfc[_0x43c9f9(0x155)]===_0x5b8764[_0x43c9f9(0x18e)]&&(_0x56776b[_0x43c9f9(0x164)]=[],_0x56776b[_0x43c9f9(0x1e2)]=_0x56776b[_0x43c9f9(0x1aa)]['entities'][_0x43c9f9(0x1e6)]({'polyline':{'positions':new Cesium[(_0x43c9f9(0x193))](function(){const _0x4ce277=_0x43c9f9;return _0x56776b[_0x4ce277(0x164)];},![]),'width':_0x56776b['_lineWidth'],'material':_0x56776b['_lineColor'],'clampToGround':!![]}}));_0x56776b['tmpEntities']['length']=0x0;if(!_0x56776b[_0x43c9f9(0x195)]){let _0x243e0b=_0x56776b[_0x43c9f9(0x170)];_0x56776b[_0x43c9f9(0x195)]=new Cesium[(_0x43c9f9(0x1c5))]({'opaqueRS':RenderState[_0x43c9f9(0x19a)]({'depthMask':_0x243e0b,'depthTest':{'enabled':_0x243e0b}}),'translucentRS':RenderState[_0x43c9f9(0x19a)]({'depthMask':_0x243e0b,'depthTest':{'enabled':_0x243e0b}}),'lineDisplayType':_0x56776b[_0x43c9f9(0x155)]===_0x5b8764[_0x43c9f9(0x18e)]?LineDisplayType['OCCLUDED']:_0x56776b[_0x43c9f9(0x1da)]}),_0x56776b['polyline']=_0x56776b['polylines'][_0x43c9f9(0x1e6)]({'width':_0x56776b['_lineWidth'],'show':_0x56776b[_0x43c9f9(0x1ee)],'positions':[_0x43c0e3,_0x43c0e3],'material':Cesium[_0x43c9f9(0x1e0)][_0x43c9f9(0x15e)](Cesium[_0x43c9f9(0x1e0)][_0x43c9f9(0x1e4)],{'color':_0x56776b[_0x43c9f9(0x19b)]}),'clampToGround':!![]}),_0x56776b[_0x43c9f9(0x1aa)][_0x43c9f9(0x17d)]['primitives']['add'](_0x56776b[_0x43c9f9(0x195)]),_0x56776b[_0x43c9f9(0x14e)]=[_0x43c0e3],_0x56776b[_0x43c9f9(0x1b2)]=0x0,_0x56776b[_0x43c9f9(0x199)]=0x0,_0x56776b[_0x43c9f9(0x1d4)]=_0x56776b[_0x43c9f9(0x1aa)][_0x43c9f9(0x1d3)][_0x43c9f9(0x1e6)]({'position':_0x43c0e3,'show':_0x56776b[_0x43c9f9(0x1ee)],'point':{'pixelSize':0x8,'color':Cesium[_0x43c9f9(0x1a1)][_0x43c9f9(0x1cf)]('#ffe500')}}),_0x56776b[_0x43c9f9(0x19d)]=_0x56776b['viewer'][_0x43c9f9(0x1d3)][_0x43c9f9(0x1e6)]({'position':_0x43c0e3,'show':_0x56776b['_showMeasureResult'],'point':{'pixelSize':0x8,'color':Cesium['Color'][_0x43c9f9(0x1cf)](_0x43c9f9(0x1ac))}});let _0x52291c=_0x56776b[_0x43c9f9(0x1aa)][_0x43c9f9(0x17d)][_0x43c9f9(0x1bb)]['add'](new Cesium[(_0x43c9f9(0x157))]({'depthTestEnable':![]}));_0x56776b[_0x43c9f9(0x1ad)]=_0x52291c[_0x43c9f9(0x1e6)]({'position':_0x43c0e3,'font':_0x43c9f9(0x166),'fillColor':Cesium[_0x43c9f9(0x1a1)][_0x43c9f9(0x1e9)],'style':Cesium[_0x43c9f9(0x14d)][_0x43c9f9(0x162)],'showBackground':!![],'backgroundColor':_0x56776b[_0x43c9f9(0x1af)],'outlineWidth':0x1,'outlineColor':Cesium['Color'][_0x43c9f9(0x1ca)],'pixelOffset':_0x56776b[_0x43c9f9(0x15c)],'text':'','show':_0x56776b['_showMeasureResult'],'horizontalOrigin':Cesium[_0x43c9f9(0x1cc)]['LEFT']}),_0x56776b[_0x43c9f9(0x159)]=_0x52291c;let _0x36f334=_0x56776b['_clampMode']==_0x5b8764[_0x43c9f9(0x174)]?!![]:![],_0x152943=Cesium[_0x43c9f9(0x1ed)]['clone'](_0x43c0e3);_0x56776b[_0x43c9f9(0x1b3)]=_0x56776b[_0x43c9f9(0x1aa)][_0x43c9f9(0x1d3)][_0x43c9f9(0x1e6)]({'corridor':{'positions':[_0x152943,_0x152943],'width':0x14,'material':Cesium[_0x43c9f9(0x1a1)]['fromCssColorString']('#51ff00')},'clampToS3M':_0x36f334,'show':![]});}_0x560cfc[_0x43c9f9(0x155)]===_0x5b8764['Ground']&&(_0x56776b[_0x43c9f9(0x172)]['show']=![]);}function processDistance(_0x4efe97,_0x58bd30){const _0x551452=_0x5ce439;let _0x4f78ec=_0x58bd30,_0x1166a6=_0x4f78ec[_0x551452(0x1aa)]['scene'];_0x4f78ec[_0x551452(0x1d7)]=_0x4efe97;let _0x1bcfc7=_0x4f78ec[_0x551452(0x172)][_0x551452(0x1bd)],_0x1386e5=_0x1bcfc7[_0x551452(0x1f7)];_0x58bd30[_0x551452(0x155)]===_0x5b8764[_0x551452(0x18e)]&&(_0x4f78ec[_0x551452(0x185)]===_0x30b699[_0x551452(0x189)]?_0x4f78ec[_0x551452(0x164)]=_0x4f78ec['_accumulationPositions']['concat']([_0x4efe97]):_0x4f78ec[_0x551452(0x164)]=_0x1bcfc7);_0x1bcfc7[_0x1386e5-0x1]=_0x4efe97,_0x4f78ec[_0x551452(0x172)]['positions']=_0x1bcfc7,_0x4f78ec[_0x551452(0x19d)]['position']=_0x4efe97;let _0x270c59=0x0,_0x5ad696=_0x4f78ec[_0x551452(0x14e)][_0x551452(0x1c0)]([_0x4efe97]);_0x4f78ec[_0x551452(0x172)]['_distance']=_0x270c59,_0x4f78ec[_0x551452(0x1ad)]['position']=_0x4efe97,_0x4f78ec['_disLabel'][_0x551452(0x1ec)]=_0x58bd30[_0x551452(0x155)]!==_0x5b8764[_0x551452(0x18e)];if(_0x58bd30[_0x551452(0x155)]===_0x5b8764[_0x551452(0x18e)])return;else for(let _0xe88b18=0x0,_0x314da1=_0x5ad696['length']-0x1;_0xe88b18<_0x314da1;_0xe88b18++){_0x270c59+=Cesium['Cartesian3']['distance'](_0x5ad696[_0xe88b18],_0x5ad696[_0xe88b18+0x1]);}_0x4f78ec[_0x551452(0x1e3)][_0x551452(0x192)]({'distance':_0x270c59[_0x551452(0x16c)](0x8),'positions':_0x5ad696});}function startMeasureDVH(_0x1e180b,_0x2d126d){const _0x407170=_0x5ce439;let _0x2b5112=_0x2d126d;if(!_0x2b5112['polylines']){let _0x2acca8=_0x2b5112[_0x407170(0x170)];_0x2b5112[_0x407170(0x195)]=new Cesium[(_0x407170(0x1c5))]({'opaqueRS':RenderState['fromCache']({'depthMask':_0x2acca8,'depthTest':{'enabled':_0x2acca8}}),'lineDisplayType':_0x2b5112[_0x407170(0x1da)]}),_0x2b5112[_0x407170(0x151)]=_0x2b5112['polylines'][_0x407170(0x1e6)]({'width':0x2,'show':_0x2b5112[_0x407170(0x1ee)],'positions':[_0x1e180b,_0x1e180b],'material':Cesium[_0x407170(0x1e0)][_0x407170(0x15e)](Cesium[_0x407170(0x1e0)][_0x407170(0x1e4)],{'color':_0x2b5112[_0x407170(0x19b)]})}),_0x2b5112[_0x407170(0x1eb)]=_0x2b5112[_0x407170(0x195)][_0x407170(0x1e6)]({'width':0x2,'show':_0x2b5112['_showMeasureResult'],'positions':[_0x1e180b,_0x1e180b],'material':Cesium[_0x407170(0x1e0)][_0x407170(0x15e)](Cesium[_0x407170(0x1e0)][_0x407170(0x1e4)],{'color':_0x2b5112[_0x407170(0x19b)]})}),_0x2b5112[_0x407170(0x161)]=_0x2b5112[_0x407170(0x195)][_0x407170(0x1e6)]({'width':0x2,'show':_0x2b5112[_0x407170(0x1ee)],'positions':[_0x1e180b,_0x1e180b],'material':Cesium[_0x407170(0x1e0)][_0x407170(0x15e)](Cesium[_0x407170(0x1e0)]['ColorType'],{'color':_0x2b5112['_lineColor']})}),_0x2b5112[_0x407170(0x1aa)][_0x407170(0x17d)][_0x407170(0x1bb)][_0x407170(0x1e6)](_0x2b5112[_0x407170(0x195)]),_0x2b5112[_0x407170(0x1d4)]=_0x2b5112[_0x407170(0x1aa)][_0x407170(0x1d3)][_0x407170(0x1e6)]({'position':_0x1e180b,'show':_0x2b5112[_0x407170(0x1ee)],'point':{'pixelSize':0x8,'color':Cesium[_0x407170(0x1a1)][_0x407170(0x1cf)](_0x407170(0x1ac))}}),_0x2b5112[_0x407170(0x19d)]=_0x2b5112[_0x407170(0x1aa)]['entities'][_0x407170(0x1e6)]({'position':_0x1e180b,'show':_0x2b5112[_0x407170(0x1ee)],'point':{'pixelSize':0x8,'color':Cesium['Color'][_0x407170(0x1cf)]('#ffe500')}}),_0x2b5112[_0x407170(0x181)]=_0x2b5112[_0x407170(0x1aa)][_0x407170(0x1d3)][_0x407170(0x1e6)]({'position':_0x1e180b,'show':_0x2b5112[_0x407170(0x1ee)],'point':{'pixelSize':0x8,'color':Cesium[_0x407170(0x1a1)][_0x407170(0x1cf)](_0x407170(0x1ac))}});let _0x5bef69=_0x2b5112['viewer'][_0x407170(0x17d)][_0x407170(0x1bb)][_0x407170(0x1e6)](new Cesium[(_0x407170(0x157))]({'depthTestEnable':![]}));_0x2b5112[_0x407170(0x1ad)]=_0x5bef69['add']({'position':_0x1e180b,'font':_0x407170(0x19e),'style':Cesium['LabelStyle'][_0x407170(0x162)],'outlineWidth':0x1,'outlineColor':Cesium[_0x407170(0x1a1)][_0x407170(0x15b)],'showBackground':!![],'backgroundColor':_0x2b5112[_0x407170(0x1af)],'pixelOffset':_0x2b5112[_0x407170(0x15c)],'pixelOffsetScaleByDistance':_0x2b5112[_0x407170(0x1c9)],'text':'','show':_0x2b5112[_0x407170(0x1ee)],'horizontalOrigin':Cesium[_0x407170(0x1cc)][_0x407170(0x1a8)]}),_0x2b5112['_vLabel']=_0x5bef69['add']({'position':_0x1e180b,'font':'500\x2016px\x20sans-serif','style':Cesium[_0x407170(0x14d)][_0x407170(0x162)],'outlineWidth':0x1,'outlineColor':Cesium[_0x407170(0x1a1)]['BLACK'],'showBackground':!![],'backgroundColor':_0x2b5112[_0x407170(0x1af)],'pixelOffset':_0x2b5112[_0x407170(0x15c)],'pixelOffsetScaleByDistance':_0x2b5112[_0x407170(0x1c9)],'text':'','show':_0x2b5112[_0x407170(0x1ee)],'horizontalOrigin':Cesium['HorizontalOrigin'][_0x407170(0x1a8)]}),_0x2b5112[_0x407170(0x1f0)]=_0x5bef69[_0x407170(0x1e6)]({'position':_0x1e180b,'font':'500\x2016px\x20sans-serif','style':Cesium[_0x407170(0x14d)]['FILL_AND_OUTLINE'],'outlineWidth':0x1,'outlineColor':Cesium[_0x407170(0x1a1)][_0x407170(0x15b)],'showBackground':!![],'backgroundColor':_0x2b5112[_0x407170(0x1af)],'pixelOffset':_0x2b5112[_0x407170(0x15c)],'pixelOffsetScaleByDistance':_0x2b5112['_labelPixelOffsetScaleByDistance'],'text':'','show':_0x2b5112[_0x407170(0x1ee)],'horizontalOrigin':Cesium['HorizontalOrigin'][_0x407170(0x1a8)]}),_0x2b5112[_0x407170(0x159)]=_0x5bef69;}let _0x39de7f=new Cesium[(_0x407170(0x1ed))]();Cesium['Cartesian3'][_0x407170(0x1df)](_0x1e180b,_0x39de7f),_0x2b5112[_0x407170(0x1b6)]=Cesium[_0x407170(0x187)][_0x407170(0x188)](_0x1e180b,_0x39de7f),_0x2b5112[_0x407170(0x1b7)]=_0x1e180b,_0x2b5112[_0x407170(0x18d)]=Cesium['Cartographic'][_0x407170(0x167)](_0x1e180b)['height'],_0x2b5112[_0x407170(0x1d6)]=_0x39de7f;let _0x180ee5=new Cesium['Cartesian3']();Cesium[_0x407170(0x1ed)][_0x407170(0x1d1)](_0x39de7f,_0x180ee5),_0x2b5112[_0x407170(0x19f)]=_0x180ee5,_0x2b5112[_0x407170(0x1d4)][_0x407170(0x15a)]=_0x1e180b;}function processDVH(_0x5415a1,_0x40661b){const _0x59e543=_0x5ce439;let _0x1ab2d7=_0x40661b,_0x481cb8=_0x1ab2d7['viewer'][_0x59e543(0x17d)];if(!_0x5415a1)return;_0x1ab2d7[_0x59e543(0x1d7)]=_0x5415a1;let _0x466188=Cesium[_0x59e543(0x1b8)]['fromCartesian'](_0x5415a1)['height'],_0x1c0a2d,_0x271207;_0x466188>_0x1ab2d7['startHeight']?(_0x1c0a2d=Cesium[_0x59e543(0x187)][_0x59e543(0x188)](_0x5415a1,_0x1ab2d7[_0x59e543(0x1d6)]),_0x271207=new Cesium[(_0x59e543(0x153))](_0x1ab2d7[_0x59e543(0x1b7)],_0x1ab2d7['normal'])):(_0x1c0a2d=_0x1ab2d7[_0x59e543(0x1b6)],_0x271207=new Cesium['Ray'](_0x5415a1,_0x1ab2d7[_0x59e543(0x1d6)]));let _0xd5ba4f=Cesium['IntersectionTests'][_0x59e543(0x1f3)](_0x271207,_0x1c0a2d);if(!_0xd5ba4f){_0x271207=new Cesium[(_0x59e543(0x153))](_0x5415a1,_0x1ab2d7[_0x59e543(0x1d6)]),_0xd5ba4f=Cesium[_0x59e543(0x194)][_0x59e543(0x1f3)](_0x271207,_0x1ab2d7['plane']);if(!_0xd5ba4f)return;}_0x1ab2d7[_0x59e543(0x151)]['positions']=[_0x1ab2d7[_0x59e543(0x1b7)],_0xd5ba4f],_0x1ab2d7['dirPolyline'][_0x59e543(0x1bd)]=[_0x1ab2d7[_0x59e543(0x1b7)],_0x5415a1],_0x1ab2d7[_0x59e543(0x1eb)][_0x59e543(0x1bd)]=[_0x5415a1,_0xd5ba4f],_0x1ab2d7['epEntity'][_0x59e543(0x15a)]=_0x5415a1,_0x1ab2d7['fpEntity'][_0x59e543(0x15a)]=_0xd5ba4f;let _0xafcb7f=Cesium['Cartesian3'][_0x59e543(0x1cd)](_0x1ab2d7[_0x59e543(0x1b7)],_0x5415a1)[_0x59e543(0x16c)](0x8),_0x361e15=Cesium['Cartesian3'][_0x59e543(0x1cd)](_0x1ab2d7[_0x59e543(0x1b7)],_0xd5ba4f)['toFixed'](0x8),_0x597e55=Cesium['Cartesian3'][_0x59e543(0x1cd)](_0x5415a1,_0xd5ba4f)['toFixed'](0x8);_0x466188>_0x1ab2d7[_0x59e543(0x18d)]?(Cesium['Cartesian3'][_0x59e543(0x190)](_0x1ab2d7[_0x59e543(0x1b7)],_0x5415a1,0.5,_0x1ab2d7['_disLabel'][_0x59e543(0x15a)]),Cesium[_0x59e543(0x1ed)][_0x59e543(0x190)](_0x1ab2d7[_0x59e543(0x1b7)],_0xd5ba4f,0.5,_0x1ab2d7[_0x59e543(0x1c7)][_0x59e543(0x15a)]),Cesium[_0x59e543(0x1ed)]['lerp'](_0x5415a1,_0xd5ba4f,0.5,_0x1ab2d7['_hLabel'][_0x59e543(0x15a)])):(Cesium[_0x59e543(0x1ed)][_0x59e543(0x190)](_0x1ab2d7['startPoint'],_0x5415a1,0.5,_0x1ab2d7[_0x59e543(0x1ad)][_0x59e543(0x15a)]),Cesium['Cartesian3'][_0x59e543(0x190)](_0x5415a1,_0xd5ba4f,0.5,_0x1ab2d7[_0x59e543(0x1c7)][_0x59e543(0x15a)]),Cesium['Cartesian3'][_0x59e543(0x190)](_0x1ab2d7['startPoint'],_0xd5ba4f,0.5,_0x1ab2d7[_0x59e543(0x1f0)][_0x59e543(0x15a)]),_0x361e15=Cesium[_0x59e543(0x1ed)][_0x59e543(0x1cd)](_0x5415a1,_0xd5ba4f)[_0x59e543(0x16c)](0x8),_0x597e55=Cesium[_0x59e543(0x1ed)][_0x59e543(0x1cd)](_0x1ab2d7[_0x59e543(0x1b7)],_0xd5ba4f)[_0x59e543(0x16c)](0x8)),_0x1ab2d7['measureEvt'][_0x59e543(0x192)]({'distance':_0xafcb7f,'directionalPositions':_0x1ab2d7[_0x59e543(0x161)][_0x59e543(0x1bd)],'verticalHeight':_0x361e15,'verticalPositions':_0x1ab2d7[_0x59e543(0x1eb)][_0x59e543(0x1bd)],'horizontalDistance':_0x597e55,'horizontalPositions':_0x1ab2d7[_0x59e543(0x151)][_0x59e543(0x1bd)]});}MeasureHandler['computeArea']=function(_0x1a0007){const _0x173592=_0x5ce439;let _0x442b2f=Cesium[_0x173592(0x1f5)]['triangulate'](_0x1a0007),_0x5e91f5=_0x442b2f[_0x173592(0x1f7)]/0x3,_0x5ad181,_0x292a69,_0x26d92c,_0xce80ea=0x0;for(let _0x64f97b=0x0;_0x64f97b<_0x5e91f5;_0x64f97b++){_0x5ad181=_0x1a0007[_0x442b2f[_0x64f97b*0x3]],_0x292a69=_0x1a0007[_0x442b2f[_0x64f97b*0x3+0x1]],_0x26d92c=_0x1a0007[_0x442b2f[_0x64f97b*0x3+0x2]],v12Scratch=Cesium[_0x173592(0x1ed)][_0x173592(0x1e1)](_0x292a69,_0x5ad181,v12Scratch),v13Scratch=Cesium[_0x173592(0x1ed)]['subtract'](_0x26d92c,_0x5ad181,v13Scratch),crossScratch=Cesium[_0x173592(0x1ed)][_0x173592(0x1ea)](v12Scratch,v13Scratch,crossScratch),_0xce80ea+=0.5*Cesium[_0x173592(0x1ed)][_0x173592(0x150)](crossScratch);}return _0xce80ea;};function computeClampArea(_0x5a7fe1,_0x144bd4){const _0x5e5f7f=_0x5ce439;let _0x43a5b1=Number[_0x5e5f7f(0x1ba)],_0x433b2b=-Number[_0x5e5f7f(0x1ba)],_0x2ba822=Number[_0x5e5f7f(0x1ba)],_0x393a77=-Number[_0x5e5f7f(0x1ba)];for(let _0x37bbbd=0x0;_0x37bbbd<_0x144bd4[_0x5e5f7f(0x1f7)];_0x37bbbd++){let _0x2d5121=Cesium[_0x5e5f7f(0x1b8)]['fromCartesian'](_0x144bd4[_0x37bbbd]);_0x43a5b1=Math['min'](_0x2d5121[_0x5e5f7f(0x1ef)],_0x43a5b1),_0x433b2b=Math['max'](_0x2d5121['longitude'],_0x433b2b),_0x2ba822=Math['min'](_0x2d5121[_0x5e5f7f(0x18a)],_0x2ba822),_0x393a77=Math[_0x5e5f7f(0x1db)](_0x2d5121[_0x5e5f7f(0x18a)],_0x393a77);}let _0x1eed54=Cesium[_0x5e5f7f(0x1b8)]['toCartesian'](new Cesium[(_0x5e5f7f(0x1b8))](_0x43a5b1,_0x2ba822,0x0)),_0x5ecfef=Cesium['Cartographic'][_0x5e5f7f(0x1ab)](new Cesium[(_0x5e5f7f(0x1b8))](_0x433b2b,_0x393a77,0x0)),_0x4a70d5=Cesium[_0x5e5f7f(0x1ed)][_0x5e5f7f(0x175)](_0x1eed54,_0x5ecfef),_0x581435=Cesium['PolygonGeometry'][_0x5e5f7f(0x1a7)]({'positions':_0x144bd4,'granularity':_0x4a70d5/0x20}),_0x5f0a24=Cesium[_0x5e5f7f(0x16b)][_0x5e5f7f(0x1dc)](_0x581435),_0x288006=0x0,_0x95b0de={};for(let _0x3bb535=0x0;_0x3bb535<_0x5f0a24[_0x5e5f7f(0x1c1)]['length'];_0x3bb535+=0x3){let _0x142038=_0x5f0a24['indices'][_0x3bb535],_0x25471c;if(!_0x95b0de[_0x142038]){let _0x1c5959=_0x5f0a24[_0x5e5f7f(0x16a)]['position'][_0x5e5f7f(0x1d8)][_0x142038*0x3],_0x3cd427=_0x5f0a24['attributes']['position'][_0x5e5f7f(0x1d8)][_0x142038*0x3+0x1],_0x46bc33=_0x5f0a24[_0x5e5f7f(0x16a)][_0x5e5f7f(0x15a)][_0x5e5f7f(0x1d8)][_0x142038*0x3+0x2];_0x25471c=new Cesium[(_0x5e5f7f(0x1ed))](_0x1c5959,_0x3cd427,_0x46bc33);let _0x52ac89=Cesium['Cartographic'][_0x5e5f7f(0x167)](_0x25471c),_0x36a9c6=_0x5a7fe1[_0x5e5f7f(0x1b4)][_0x5e5f7f(0x177)](_0x52ac89);if(!_0x36a9c6)continue;_0x52ac89=Cesium['Cartographic']['fromRadians'](_0x52ac89[_0x5e5f7f(0x1ef)],_0x52ac89[_0x5e5f7f(0x18a)],_0x36a9c6),_0x25471c=Cesium[_0x5e5f7f(0x1b8)]['toCartesian'](_0x52ac89),_0x95b0de[_0x142038]=Cesium[_0x5e5f7f(0x1ed)][_0x5e5f7f(0x1d5)](_0x25471c);}else _0x25471c=_0x95b0de[_0x142038];let _0x1f2250=_0x5f0a24[_0x5e5f7f(0x1c1)][_0x3bb535+0x1],_0x5356e2;if(!_0x95b0de[_0x1f2250]){let _0x20e52e=_0x5f0a24[_0x5e5f7f(0x16a)][_0x5e5f7f(0x15a)][_0x5e5f7f(0x1d8)][_0x1f2250*0x3],_0x52690c=_0x5f0a24[_0x5e5f7f(0x16a)][_0x5e5f7f(0x15a)][_0x5e5f7f(0x1d8)][_0x1f2250*0x3+0x1],_0x25fd58=_0x5f0a24[_0x5e5f7f(0x16a)]['position']['values'][_0x1f2250*0x3+0x2];_0x5356e2=new Cesium['Cartesian3'](_0x20e52e,_0x52690c,_0x25fd58);let _0xfe9c17=Cesium['Cartographic'][_0x5e5f7f(0x167)](_0x5356e2),_0x4f3ea6=_0x5a7fe1[_0x5e5f7f(0x1b4)]['getHeight'](_0xfe9c17);if(!_0x4f3ea6)continue;_0xfe9c17=Cesium[_0x5e5f7f(0x1b8)][_0x5e5f7f(0x17a)](_0xfe9c17[_0x5e5f7f(0x1ef)],_0xfe9c17[_0x5e5f7f(0x18a)],_0x4f3ea6),_0x5356e2=Cesium[_0x5e5f7f(0x1b8)]['toCartesian'](_0xfe9c17),_0x95b0de[_0x1f2250]=Cesium['Cartesian3'][_0x5e5f7f(0x1d5)](_0x5356e2);}else _0x5356e2=_0x95b0de[_0x1f2250];let _0x4ad540=_0x5f0a24['indices'][_0x3bb535+0x2],_0x1a0752;if(!_0x95b0de[_0x4ad540]){let _0x4ab7f6=_0x5f0a24['attributes'][_0x5e5f7f(0x15a)][_0x5e5f7f(0x1d8)][_0x4ad540*0x3],_0x5ddc8c=_0x5f0a24['attributes'][_0x5e5f7f(0x15a)]['values'][_0x4ad540*0x3+0x1],_0x28b3d6=_0x5f0a24[_0x5e5f7f(0x16a)][_0x5e5f7f(0x15a)][_0x5e5f7f(0x1d8)][_0x4ad540*0x3+0x2];_0x1a0752=new Cesium[(_0x5e5f7f(0x1ed))](_0x4ab7f6,_0x5ddc8c,_0x28b3d6);let _0x833809=Cesium[_0x5e5f7f(0x1b8)][_0x5e5f7f(0x167)](_0x1a0752),_0xd4624=_0x5a7fe1[_0x5e5f7f(0x1b4)][_0x5e5f7f(0x177)](_0x833809);if(!_0xd4624)continue;_0x833809=Cesium[_0x5e5f7f(0x1b8)][_0x5e5f7f(0x17a)](_0x833809[_0x5e5f7f(0x1ef)],_0x833809[_0x5e5f7f(0x18a)],_0xd4624),_0x1a0752=Cesium[_0x5e5f7f(0x1b8)][_0x5e5f7f(0x1ab)](_0x833809),_0x95b0de[_0x4ad540]=Cesium['Cartesian3']['clone'](_0x1a0752);}else _0x1a0752=_0x95b0de[_0x4ad540];v12Scratch=Cesium['Cartesian3'][_0x5e5f7f(0x1e1)](_0x5356e2,_0x25471c,v12Scratch),v13Scratch=Cesium[_0x5e5f7f(0x1ed)][_0x5e5f7f(0x1e1)](_0x1a0752,_0x25471c,v13Scratch),crossScratch=Cesium[_0x5e5f7f(0x1ed)][_0x5e5f7f(0x1ea)](v12Scratch,v13Scratch,crossScratch),_0x288006+=0.5*Cesium[_0x5e5f7f(0x1ed)][_0x5e5f7f(0x150)](crossScratch);}return _0x288006;}function computeClampDistance(_0x5376ec,_0x77681b){const _0x3b34ee=_0x5ce439;let _0x2887ca=0x0,_0x14f930=[],_0x37a7d0=_0x77681b[_0x3b34ee(0x1f7)]-0x1;for(let _0x3af7d2=0x0;_0x3af7d2<_0x37a7d0;_0x3af7d2++){let _0x1cbb09=_0x77681b[_0x3af7d2],_0xca782c=_0x77681b[_0x3af7d2+0x1],_0x2eb450=Cesium[_0x3b34ee(0x1ed)][_0x3b34ee(0x175)](_0x1cbb09,_0xca782c),_0x1feeba=_0x2eb450/0x40,_0x24acd6=Cesium[_0x3b34ee(0x1e7)]['chordLength'](_0x1feeba,0x615299),_0xc84574=Cesium[_0x3b34ee(0x1f1)][_0x3b34ee(0x1a4)](_0x1cbb09,_0xca782c,_0x24acd6,_0x14f930),_0x291bfe=Cesium[_0x3b34ee(0x1ed)][_0x3b34ee(0x1b9)](_0xc84574),_0x4d0170=_0x291bfe[_0x3b34ee(0x1f7)]-0x1;for(let _0xd4c7e2=0x0;_0xd4c7e2<_0x4d0170;_0xd4c7e2++){let _0x1a0f03=_0x291bfe[_0xd4c7e2],_0x4fc5b1=Cesium['Cartographic'][_0x3b34ee(0x167)](_0x1a0f03),_0x4a56fa=_0x5376ec['globe'][_0x3b34ee(0x177)](_0x4fc5b1);_0x4fc5b1=Cesium[_0x3b34ee(0x1b8)]['fromRadians'](_0x4fc5b1['longitude'],_0x4fc5b1[_0x3b34ee(0x18a)],_0x4a56fa);let _0x39f018=Cesium['Cartographic'][_0x3b34ee(0x1ab)](_0x4fc5b1),_0x130ec6=_0x291bfe[_0xd4c7e2+0x1];_0x4fc5b1=Cesium[_0x3b34ee(0x1b8)][_0x3b34ee(0x167)](_0x130ec6),_0x4a56fa=_0x5376ec[_0x3b34ee(0x1b4)]['getHeight'](_0x4fc5b1),_0x4fc5b1=Cesium[_0x3b34ee(0x1b8)][_0x3b34ee(0x17a)](_0x4fc5b1[_0x3b34ee(0x1ef)],_0x4fc5b1['latitude'],_0x4a56fa);let _0x2dba4f=Cesium['Cartographic'][_0x3b34ee(0x1ab)](_0x4fc5b1);_0x2887ca+=Cesium[_0x3b34ee(0x1ed)]['distance'](_0x39f018,_0x2dba4f);}}return _0x2887ca;}

    const _0x158b=['_rectangleNortheastInMeters','72904lOvyzp','_numberOfLevelZeroTilesY','GeographicProjection','positionToTileXY','east','145549YHTUiN','tileXYToRectangle','Cartesian2','south','prototype','_projection','project','_rectangleSouthwestInMeters','defaultValue','973712dypNXI','west','latitude','ellipsoid','EMPTY_OBJECT','defineProperties','Ellipsoid','unproject','contains','longitude','tileXYToNativeRectangle','southwest','17HrJPQa','north','numberOfLevelZeroTilesX','getNumberOfYTilesAtLevel','60UaeuIM','rectangleSouthwestInMeters','173595fUsYHt','maximumRadius','342KyMlpe','_rectangle','33059SGJffq','Rectangle','northeast','6793pvUPZy','defined','3NCgNdV','4044jcZRoh','rectangleNortheastInMeters','numberOfLevelZeroTilesY','_ellipsoid','_numberOfLevelZeroTilesX'];const _0x17bb05=_0x49ab;(function(_0x497bce,_0x364514){const _0x4276cb=_0x49ab;while(!![]){try{const _0x134c51=parseInt(_0x4276cb(0xf0))*parseInt(_0x4276cb(0xe4))+-parseInt(_0x4276cb(0x104))+-parseInt(_0x4276cb(0xef))*parseInt(_0x4276cb(0xfb))+-parseInt(_0x4276cb(0xea))*parseInt(_0x4276cb(0xe0))+-parseInt(_0x4276cb(0xe6))+parseInt(_0x4276cb(0xf6))+parseInt(_0x4276cb(0xe8))*parseInt(_0x4276cb(0xed));if(_0x134c51===_0x364514)break;else _0x497bce['push'](_0x497bce['shift']());}catch(_0x4bd4e0){_0x497bce['push'](_0x497bce['shift']());}}}(_0x158b,0x784f9));function _0x49ab(_0x27fa20,_0x29c165){_0x27fa20=_0x27fa20-0xe0;let _0x158b03=_0x158b[_0x27fa20];return _0x158b03;}function CustomTilingScheme(_0x243aaa){const _0x253010=_0x49ab;_0x243aaa=Cesium['defaultValue'](_0x243aaa,Cesium[_0x253010(0x103)][_0x253010(0x108)]),this[_0x253010(0xf3)]=Cesium[_0x253010(0x103)](_0x243aaa[_0x253010(0x107)],Cesium[_0x253010(0x10a)]['WGS84']),this[_0x253010(0xf4)]=Cesium['defaultValue'](_0x243aaa[_0x253010(0xe2)],0x1),this[_0x253010(0xf7)]=Cesium[_0x253010(0x103)](_0x243aaa[_0x253010(0xf2)],0x1),this[_0x253010(0x100)]=new Cesium[(_0x253010(0xf8))](this['_ellipsoid']);if(Cesium[_0x253010(0xee)](_0x243aaa[_0x253010(0xe5)])&&Cesium[_0x253010(0xee)](_0x243aaa[_0x253010(0xf1)]))this[_0x253010(0x102)]=_0x243aaa[_0x253010(0xe5)],this['_rectangleNortheastInMeters']=_0x243aaa['rectangleNortheastInMeters'];else {let _0x540813=this[_0x253010(0xf3)][_0x253010(0xe7)]*Math['PI'];this[_0x253010(0x102)]=new Cesium[(_0x253010(0xfd))](-_0x540813,-_0x540813),this[_0x253010(0xf5)]=new Cesium[(_0x253010(0xfd))](_0x540813,_0x540813);}let _0x20388a=this['_projection'][_0x253010(0x10b)](this['_rectangleSouthwestInMeters']),_0x500625=this[_0x253010(0x100)][_0x253010(0x10b)](this[_0x253010(0xf5)]);this[_0x253010(0xe9)]=new Cesium[(_0x253010(0xeb))](_0x20388a[_0x253010(0x10d)],_0x20388a[_0x253010(0x106)],_0x500625['longitude'],_0x500625[_0x253010(0x106)]);}Object[_0x17bb05(0x109)](CustomTilingScheme[_0x17bb05(0xff)],{'ellipsoid':{'get':function(){const _0x5f55e1=_0x17bb05;return this[_0x5f55e1(0xf3)];}},'rectangle':{'get':function(){const _0x275b28=_0x17bb05;return this[_0x275b28(0xe9)];}},'projection':{'get':function(){const _0x4874fd=_0x17bb05;return this[_0x4874fd(0x100)];}}}),CustomTilingScheme['prototype']['getNumberOfXTilesAtLevel']=function(_0x2a1888){const _0x4fbc96=_0x17bb05;return this[_0x4fbc96(0xf4)]<<_0x2a1888;},CustomTilingScheme[_0x17bb05(0xff)][_0x17bb05(0xe3)]=function(_0x3d4c29){return this['_numberOfLevelZeroTilesY']<<_0x3d4c29;},CustomTilingScheme['prototype']['rectangleToNativeRectangle']=function(_0x64e3bd,_0x508535){const _0x351a70=_0x17bb05;let _0xe5599d=this[_0x351a70(0x100)],_0x1316fe=_0xe5599d[_0x351a70(0x101)](Cesium[_0x351a70(0xeb)][_0x351a70(0x10f)](_0x64e3bd)),_0x113d41=_0xe5599d['project'](Cesium[_0x351a70(0xeb)][_0x351a70(0xec)](_0x64e3bd));if(!Cesium[_0x351a70(0xee)](_0x508535))return new Cesium['Rectangle'](_0x1316fe['x'],_0x1316fe['y'],_0x113d41['x'],_0x113d41['y']);return _0x508535['west']=_0x1316fe['x'],_0x508535[_0x351a70(0xfe)]=_0x1316fe['y'],_0x508535['east']=_0x113d41['x'],_0x508535[_0x351a70(0xe1)]=_0x113d41['y'],_0x508535;},CustomTilingScheme['prototype'][_0x17bb05(0x10e)]=function(_0x54eea6,_0x5b0797,_0x41552a,_0x115470){const _0x40c8f7=_0x17bb05;let _0xc14a37=this['getNumberOfXTilesAtLevel'](_0x41552a),_0x451262=this[_0x40c8f7(0xe3)](_0x41552a),_0x1ec37d=(this[_0x40c8f7(0xf5)]['x']-this['_rectangleSouthwestInMeters']['x'])/_0xc14a37,_0x308efb=this[_0x40c8f7(0x102)]['x']+_0x54eea6*_0x1ec37d,_0x5bc318=this[_0x40c8f7(0x102)]['x']+(_0x54eea6+0x1)*_0x1ec37d,_0x22d8b1=(this['_rectangleNortheastInMeters']['y']-this[_0x40c8f7(0x102)]['y'])/_0x451262,_0x1f9ec3=this[_0x40c8f7(0xf5)]['y']-_0x5b0797*_0x22d8b1,_0x5d06ef=this[_0x40c8f7(0xf5)]['y']-(_0x5b0797+0x1)*_0x22d8b1;if(!Cesium[_0x40c8f7(0xee)](_0x115470))return new Cesium[(_0x40c8f7(0xeb))](_0x308efb,_0x5d06ef,_0x5bc318,_0x1f9ec3);return _0x115470[_0x40c8f7(0x105)]=_0x308efb,_0x115470['south']=_0x5d06ef,_0x115470['east']=_0x5bc318,_0x115470[_0x40c8f7(0xe1)]=_0x1f9ec3,_0x115470;},CustomTilingScheme[_0x17bb05(0xff)][_0x17bb05(0xfc)]=function(_0x4d5a74,_0x806680,_0xe4f93f,_0x543886){const _0xc5bedd=_0x17bb05;let _0x4211cd=this[_0xc5bedd(0x10e)](_0x4d5a74,_0x806680,_0xe4f93f,_0x543886),_0x296b1d=this[_0xc5bedd(0x100)],_0x2c6f83=_0x296b1d[_0xc5bedd(0x10b)](new Cesium[(_0xc5bedd(0xfd))](_0x4211cd[_0xc5bedd(0x105)],_0x4211cd['south'])),_0x2605fa=_0x296b1d[_0xc5bedd(0x10b)](new Cesium[(_0xc5bedd(0xfd))](_0x4211cd[_0xc5bedd(0xfa)],_0x4211cd[_0xc5bedd(0xe1)]));return _0x4211cd[_0xc5bedd(0x105)]=_0x2c6f83[_0xc5bedd(0x10d)],_0x4211cd[_0xc5bedd(0xfe)]=_0x2c6f83[_0xc5bedd(0x106)],_0x4211cd[_0xc5bedd(0xfa)]=_0x2605fa[_0xc5bedd(0x10d)],_0x4211cd['north']=_0x2605fa[_0xc5bedd(0x106)],_0x4211cd;},CustomTilingScheme['prototype'][_0x17bb05(0xf9)]=function(_0x48fb75,_0x8ad46a,_0x2f7103){const _0x314769=_0x17bb05;let _0x2e53b6=this['_rectangle'];if(!Cesium['Rectangle'][_0x314769(0x10c)](_0x2e53b6,_0x48fb75))return undefined;let _0x514e0c=this['getNumberOfXTilesAtLevel'](_0x8ad46a),_0xd49304=this[_0x314769(0xe3)](_0x8ad46a),_0x233fb3=this[_0x314769(0xf5)]['x']-this[_0x314769(0x102)]['x'],_0x34290a=_0x233fb3/_0x514e0c,_0x110776=this[_0x314769(0xf5)]['y']-this[_0x314769(0x102)]['y'],_0x1840a9=_0x110776/_0xd49304,_0x2f05b0=this[_0x314769(0x100)],_0x3e3e81=_0x2f05b0['project'](_0x48fb75),_0x1d4435=_0x3e3e81['x']-this[_0x314769(0x102)]['x'],_0x112c4a=this[_0x314769(0xf5)]['y']-_0x3e3e81['y'],_0x4bcfd0=_0x1d4435/_0x34290a|0x0;_0x4bcfd0>=_0x514e0c&&(_0x4bcfd0=_0x514e0c-0x1);let _0x49f533=_0x112c4a/_0x1840a9|0x0;_0x49f533>=_0xd49304&&(_0x49f533=_0xd49304-0x1);if(!Cesium[_0x314769(0xee)](_0x2f7103))return new Cesium['Cartesian2'](_0x4bcfd0,_0x49f533);return _0x2f7103['x']=_0x4bcfd0,_0x2f7103['y']=_0x49f533,_0x2f7103;};

    const _0x5c36=['DEGREE','north','2vhdBOV','east','_resource','defer','_tileDiscardPolicy',',\x22y\x22:','textContent','1eTcAJL','defaultValue','getTileCredits','ceil','coordUnit','longitude','projection','41cGglYf','maximumLevel\x20must\x20not\x20be\x20called\x20before\x20the\x20imagery\x20provider\x20is\x20ready.','getDerivedResource','appendForwardSlash','Left','equalsEpsilon','Right','_readyPromise','338966VDJfnE','unproject','EPSILON5','reject','minimumLevel\x20must\x20not\x20be\x20called\x20before\x20the\x20imagery\x20provider\x20is\x20ready.','GeographicProjection','Rectangle','Bounds','left','right','Cartesian3','_credit','tileImage.','rest/maps','bottom','viewer','height','latitude','_ready','prototype','164877PRasQt','7eMRqUi','push','config','481890xkGJbe','clamp','Resource','3CzGhEV','_errorEvent','_rectangle','visibleScales','defined','FileExtentName','1179723wsmkZU','_isTileMap','south','requestImage','resolution','Event','CellHeight','northeast','fromDegrees','1026693zKirox','queryStringValue','_urlTemplate','tilingScheme\x20must\x20not\x20be\x20called\x20before\x20the\x20imagery\x20provider\x20is\x20ready.','createIfNeeded','positionToTileXY','DeveloperError','options.url\x20is\x20error','129205lbwrNJ','Bottom','rest/realspace','toRadians','rectangle\x20must\x20not\x20be\x20called\x20before\x20the\x20imagery\x20provider\x20is\x20ready.','_tilingScheme','.json','fetchXML','queryFirstNode','queryNumericValue','_isSci3D','_scales','_tileHeight','tilingScheme','dpi','data/index/{y}/{x}.{fileExtension}?level={level}','_minimumLevel','tileHeight\x20must\x20not\x20be\x20called\x20before\x20the\x20imagery\x20provider\x20is\x20ready.','An\x20error\x20occurred\x20while\x20accessing\x20','tileDiscardPolicy','indexOf','bounds','EPSILON7','_maximumLevel','_url','_tileWidth','fetchImage','16589NIWyuI','abs','tileWidth\x20must\x20not\x20be\x20called\x20before\x20the\x20imagery\x20provider\x20is\x20ready.','Level','requestImage\x20must\x20not\x20be\x20called\x20before\x20the\x20imagery\x20provider\x20is\x20ready.','_tileFormat','PRJ_TRANSVERSE_MERCATOR','prjCoordSys','RuntimeError','Math','credit','?x={x}&y={y}&scale={scale}&origin={\x22x\x22:-180,\x22y\x22:90}','url','?x={x}&y={y}&scale={scale}&origin={\x22x\x22:','_coordUnit','top','CellWidth','west','Top','defineProperties','resolve','Credit','length','png','rectangle','type','GeographicTilingScheme'];const _0x1dba81=_0x3d61;(function(_0x5a7843,_0x1a7ba1){const _0x4bec5f=_0x3d61;while(!![]){try{const _0x40eef5=parseInt(_0x4bec5f(0x1b4))+-parseInt(_0x4bec5f(0x1bc))*-parseInt(_0x4bec5f(0x19f))+parseInt(_0x4bec5f(0x1a2))*-parseInt(_0x4bec5f(0x1f4))+-parseInt(_0x4bec5f(0x19e))*-parseInt(_0x4bec5f(0x1a5))+-parseInt(_0x4bec5f(0x20a))+parseInt(_0x4bec5f(0x1fb))*-parseInt(_0x4bec5f(0x1ab))+parseInt(_0x4bec5f(0x1d7))*parseInt(_0x4bec5f(0x202));if(_0x40eef5===_0x1a7ba1)break;else _0x5a7843['push'](_0x5a7843['shift']());}catch(_0x4576db){_0x5a7843['push'](_0x5a7843['shift']());}}}(_0x5c36,0x9834f));function _0x3d61(_0x10729c,_0xf3dc3){_0x10729c=_0x10729c-0x196;let _0x5c36ff=_0x5c36[_0x10729c];return _0x5c36ff;}function metadataSuccessForXml(_0x4c5dc8,_0x2a34a6){const _0xc65fd4=_0x3d61;let _0x4e260b='http://www.supermap.com/SuperMapCache/sci3d',_0x22c672=_0x2a34a6['documentElement'],_0x2abf5d=XMLParser['queryFirstNode'](_0x22c672,_0xc65fd4(0x211),_0x4e260b),_0x5d1933=XMLParser[_0xc65fd4(0x1c5)](_0x2abf5d,_0xc65fd4(0x206),_0x4e260b),_0x4c4b50=XMLParser[_0xc65fd4(0x1c5)](_0x2abf5d,_0xc65fd4(0x208),_0x4e260b),_0x25cbe5=XMLParser[_0xc65fd4(0x1c5)](_0x2abf5d,_0xc65fd4(0x1e9),_0x4e260b),_0x419e1d=XMLParser['queryNumericValue'](_0x2abf5d,_0xc65fd4(0x1bd),_0x4e260b),_0x58f176=XMLParser[_0xc65fd4(0x1b5)](_0x22c672,_0xc65fd4(0x1aa),_0x4e260b),_0x473a8b=XMLParser[_0xc65fd4(0x1c5)](_0x22c672,_0xc65fd4(0x1e7),_0x4e260b),_0xe2db59=XMLParser[_0xc65fd4(0x1c5)](_0x22c672,_0xc65fd4(0x1b1),_0x4e260b),_0xe00e71=XMLParser[_0xc65fd4(0x1c4)](_0x22c672,'Levels',_0x4e260b),_0x4f3de6=XMLParser['queryNodes'](_0xe00e71,_0xc65fd4(0x1da),_0x4e260b),_0x1d7d4a=[];for(let _0x45c623=0x0,_0x25cc5e=_0x4f3de6[_0xc65fd4(0x1ed)];_0x45c623<_0x25cc5e;_0x45c623++){_0x1d7d4a[_0xc65fd4(0x1a0)](parseInt(_0x4f3de6[_0x45c623][_0xc65fd4(0x1fa)],0xa));}_0x4c5dc8[_0xc65fd4(0x1dc)]=Cesium['defaultValue'](_0x58f176,_0xc65fd4(0x1ee)),_0x4c5dc8[_0xc65fd4(0x1d5)]=Cesium[_0xc65fd4(0x1fc)](_0x473a8b,0x100),_0x4c5dc8[_0xc65fd4(0x1c8)]=Cesium[_0xc65fd4(0x1fc)](_0xe2db59,0x100);let _0x51506d=_0x1d7d4a['length'];_0x4c5dc8[_0xc65fd4(0x1cc)]=Cesium[_0xc65fd4(0x1fc)](_0x1d7d4a[0x0],0x0),_0x4c5dc8[_0xc65fd4(0x1d3)]=Cesium[_0xc65fd4(0x1fc)](_0x4c5dc8[_0xc65fd4(0x1d3)],_0x1d7d4a[_0x51506d-0x1]);!_0x4c5dc8[_0xc65fd4(0x1c1)]&&(_0x4c5dc8[_0xc65fd4(0x1c1)]=new Cesium[(_0xc65fd4(0x1f1))]());let _0x2578f5=_0x4c5dc8['_tilingScheme'];!_0x4c5dc8[_0xc65fd4(0x1a7)]&&_0x5d1933&&_0x4c4b50&&_0x25cbe5&&_0x419e1d&&(_0x4c5dc8[_0xc65fd4(0x1a7)]=new Cesium[(_0xc65fd4(0x210))](Cesium[_0xc65fd4(0x1e0)][_0xc65fd4(0x1bf)](_0x5d1933),Cesium[_0xc65fd4(0x1e0)]['toRadians'](_0x419e1d),Cesium['Math'][_0xc65fd4(0x1bf)](_0x4c4b50),Cesium[_0xc65fd4(0x1e0)][_0xc65fd4(0x1bf)](_0x25cbe5)));_0x4c5dc8[_0xc65fd4(0x1a7)][_0xc65fd4(0x1e8)]<_0x2578f5['rectangle'][_0xc65fd4(0x1e8)]&&(_0x4c5dc8[_0xc65fd4(0x1a7)][_0xc65fd4(0x1e8)]=_0x2578f5[_0xc65fd4(0x1ef)][_0xc65fd4(0x1e8)]);_0x4c5dc8['_rectangle'][_0xc65fd4(0x1f5)]>_0x2578f5[_0xc65fd4(0x1ef)][_0xc65fd4(0x1f5)]&&(_0x4c5dc8['_rectangle'][_0xc65fd4(0x1f5)]=_0x2578f5['rectangle']['east']);_0x4c5dc8['_rectangle']['south']<_0x2578f5['rectangle'][_0xc65fd4(0x1ad)]&&(_0x4c5dc8[_0xc65fd4(0x1a7)][_0xc65fd4(0x1ad)]=_0x2578f5[_0xc65fd4(0x1ef)][_0xc65fd4(0x1ad)]);_0x4c5dc8[_0xc65fd4(0x1a7)][_0xc65fd4(0x1f3)]>_0x2578f5[_0xc65fd4(0x1ef)][_0xc65fd4(0x1f3)]&&(_0x4c5dc8[_0xc65fd4(0x1a7)][_0xc65fd4(0x1f3)]=_0x2578f5[_0xc65fd4(0x1ef)][_0xc65fd4(0x1f3)]);let _0x1a7cf2=_0x2578f5['positionToTileXY'](Cesium['Rectangle']['southwest'](_0x4c5dc8[_0xc65fd4(0x1a7)]),_0x4c5dc8[_0xc65fd4(0x1cc)]),_0x4aeda8=_0x2578f5[_0xc65fd4(0x1b9)](Cesium[_0xc65fd4(0x210)][_0xc65fd4(0x1b2)](_0x4c5dc8['_rectangle']),_0x4c5dc8[_0xc65fd4(0x1cc)]),_0x4d6df0=(Math[_0xc65fd4(0x1d8)](_0x4aeda8['x']-_0x1a7cf2['x'])+0x1)*(Math[_0xc65fd4(0x1d8)](_0x4aeda8['y']-_0x1a7cf2['y'])+0x1);_0x4d6df0>0x4&&(_0x4c5dc8[_0xc65fd4(0x1cc)]=0x0),_0x4c5dc8[_0xc65fd4(0x1b6)]=_0x4c5dc8[_0xc65fd4(0x1d4)]+_0xc65fd4(0x1cb),_0x4c5dc8[_0xc65fd4(0x19c)]=!![],_0x4c5dc8[_0xc65fd4(0x209)][_0xc65fd4(0x1eb)](!![]);}function metadataSuccessForJson(_0x571267,_0x3f0f5a){const _0x375b16=_0x3d61;let _0x3d3b69=_0x3f0f5a['prjCoordSys'][_0x375b16(0x1ff)],_0x17996f=_0x3f0f5a[_0x375b16(0x1d1)],_0xffc6b=_0x3f0f5a[_0x375b16(0x1a8)],_0x2c118c=_0xffc6b[_0x375b16(0x1ed)]===0x0;_0x571267['_coordUnit']=_0x3d3b69;if(_0x3d3b69===_0x375b16(0x1f2)){_0x571267[_0x375b16(0x1c1)]=new Cesium['GeographicTilingScheme'](),_0x17996f['left']=Cesium[_0x375b16(0x1e0)][_0x375b16(0x1a3)](_0x17996f['left'],-0xb4,0xb4),_0x17996f[_0x375b16(0x198)]=Cesium[_0x375b16(0x1e0)]['clamp'](_0x17996f['bottom'],-0x5a,0x5a),_0x17996f[_0x375b16(0x213)]=Cesium['Math']['clamp'](_0x17996f[_0x375b16(0x213)],-0xb4,0xb4),_0x17996f['top']=Cesium[_0x375b16(0x1e0)][_0x375b16(0x1a3)](_0x17996f['top'],-0x5a,0x5a);Cesium['Math'][_0x375b16(0x207)](_0x17996f['left'],_0x17996f[_0x375b16(0x213)],Cesium[_0x375b16(0x1e0)][_0x375b16(0x1d2)])&&(_0x17996f['right']+=Cesium[_0x375b16(0x1e0)][_0x375b16(0x20c)]);Cesium[_0x375b16(0x1e0)][_0x375b16(0x207)](_0x17996f[_0x375b16(0x1e6)],_0x17996f[_0x375b16(0x198)],Cesium[_0x375b16(0x1e0)][_0x375b16(0x1d2)])&&(_0x17996f['top']+=Cesium[_0x375b16(0x1e0)][_0x375b16(0x20c)]);_0x571267[_0x375b16(0x1a7)]=Cesium['Rectangle'][_0x375b16(0x1b3)](_0x17996f[_0x375b16(0x212)],_0x17996f['bottom'],_0x17996f['right'],_0x17996f['top']),_0x571267['_urlTemplate']=_0x571267[_0x375b16(0x1d4)]+_0x375b16(0x196)+_0x571267[_0x375b16(0x1dc)]+_0x375b16(0x1e2),_0x571267[_0x375b16(0x1d3)]=Cesium[_0x375b16(0x1fc)](_0x571267[_0x375b16(0x1d3)],_0x571267[_0x375b16(0x1c7)][_0x375b16(0x1ed)]),_0x571267['_ready']=!![],_0x571267[_0x375b16(0x209)]['resolve'](!![]);return;}let _0x4d5155=new Cesium[(_0x375b16(0x214))](_0x17996f[_0x375b16(0x212)],_0x17996f[_0x375b16(0x198)],0x0),_0xd27e8=new Cesium['Cartesian3'](_0x17996f['right'],_0x17996f[_0x375b16(0x1e6)],0x0);if(!Cesium[_0x375b16(0x1a9)](_0x571267[_0x375b16(0x1c1)])){let _0x3443e1=Cesium[_0x375b16(0x1a9)](_0x3f0f5a['prjCoordSys'])&&Cesium[_0x375b16(0x1a9)](_0x3f0f5a['prjCoordSys'][_0x375b16(0x201)])&&(_0x3f0f5a[_0x375b16(0x1de)][_0x375b16(0x201)][_0x375b16(0x1f0)]==='PRJ_SPHERE_MERCATOR'||_0x3f0f5a[_0x375b16(0x1de)]['projection'][_0x375b16(0x1f0)]===_0x375b16(0x1dd)),_0x4fd104=_0x3443e1?new Cesium['WebMercatorProjection']():new Cesium[(_0x375b16(0x20f))](),_0xef29c5=_0x4fd104[_0x375b16(0x20b)](_0x4d5155),_0x471881=_0x4fd104[_0x375b16(0x20b)](_0xd27e8),_0x203a6b=new Cesium[(_0x375b16(0x210))](_0xef29c5[_0x375b16(0x200)],_0xef29c5['latitude'],_0x471881[_0x375b16(0x200)],_0x471881[_0x375b16(0x19b)]),_0x510f9f,_0x300fc8;if(!_0x2c118c){let _0x111d1c=_0xffc6b[0x0],_0x26d055=0.0254/(_0x3f0f5a[_0x375b16(0x1ca)]*_0x111d1c);_0x510f9f=Math[_0x375b16(0x1fe)]((_0xd27e8['x']-_0x4d5155['x'])/_0x26d055/_0x3f0f5a[_0x375b16(0x199)]['width']),_0x300fc8=Math[_0x375b16(0x1fe)]((_0xd27e8['y']-_0x4d5155['y'])/_0x26d055/_0x3f0f5a['viewer'][_0x375b16(0x19a)]),_0x571267[_0x375b16(0x1c7)]=_0xffc6b;}_0x571267[_0x375b16(0x1c1)]=_0x3443e1?new Cesium['WebMercatorTilingScheme']({'numberOfLevelZeroTilesX':_0x510f9f,'numberOfLevelZeroTilesY':_0x300fc8,'rectangleSouthwestInMeters':_0x2c118c?undefined:_0x4d5155,'rectangleNortheastInMeters':_0x2c118c?undefined:_0xd27e8}):_0x2c118c?new CustomTilingScheme({'projection':_0x4fd104}):new Cesium['GeographicTilingScheme']({'numberOfLevelZeroTilesX':_0x510f9f,'numberOfLevelZeroTilesY':_0x300fc8,'rectangle':_0x2c118c?undefined:_0x203a6b}),_0x571267[_0x375b16(0x1a7)]=_0x203a6b;}let _0xb2e970=_0x2c118c?-20037508.342789248:_0x17996f[_0x375b16(0x212)],_0x40cd8c=_0x2c118c?20037508.342789095:_0x17996f[_0x375b16(0x1e6)];_0x571267[_0x375b16(0x1b6)]=_0x571267[_0x375b16(0x1d4)]+'tileImage.'+_0x571267[_0x375b16(0x1dc)]+_0x375b16(0x1e4)+_0xb2e970+_0x375b16(0x1f9)+_0x40cd8c+'}',_0x571267[_0x375b16(0x1d3)]=Cesium[_0x375b16(0x1fc)](_0x571267[_0x375b16(0x1d3)],_0x571267[_0x375b16(0x1c7)][_0x375b16(0x1ed)]),_0x571267[_0x375b16(0x19c)]=!![],_0x571267[_0x375b16(0x209)]['resolve'](!![]);}const SCALES=[1.690163571602655e-9,3.3803271432053056e-9,6.760654286410611e-9,1.3521308572821242e-8,2.7042617145642484e-8,5.408523429128511e-8,1.0817046858256998e-7,2.1634093716513974e-7,4.3268187433028044e-7,8.653637486605571e-7,0.0000017307274973211203,0.0000034614549946422405,0.0000069229099892844565,0.000013845819978568952,0.000027691639957137904,0.0000553832799142758,0.0001107665598285516,0.0002215331196571032,0.0004430662393142064,0.0008861324786284128,0.001772264957256826,0.003544529914513652];function SuperMapImageryProvider(_0x9c8343){const _0x4951e8=_0x3d61;_0x9c8343=Cesium['defaultValue'](_0x9c8343,{});if(!_0x9c8343['url'])throw new Cesium[(_0x4951e8(0x1ba))]('options.url\x20is\x20required.');this[_0x4951e8(0x1d4)]=Cesium[_0x4951e8(0x205)](_0x9c8343[_0x4951e8(0x1e3)]),this[_0x4951e8(0x1f6)]=Cesium[_0x4951e8(0x1a4)][_0x4951e8(0x1b8)](this['_url']),this[_0x4951e8(0x1ac)]=_0x9c8343[_0x4951e8(0x1e3)][_0x4951e8(0x1d0)](_0x4951e8(0x197))>-0x1,this[_0x4951e8(0x1c6)]=_0x9c8343[_0x4951e8(0x1e3)][_0x4951e8(0x1d0)](_0x4951e8(0x1be))>-0x1;if(!this['_isTileMap']&&!this['_isSci3D'])throw new Cesium['DeveloperError'](_0x4951e8(0x1bb));this[_0x4951e8(0x1b6)]=undefined,this['_errorEvent']=new Cesium[(_0x4951e8(0x1b0))](),this[_0x4951e8(0x1d5)]=0x100,this[_0x4951e8(0x1c8)]=0x100,this['_tileFormat']=Cesium[_0x4951e8(0x1fc)](_0x9c8343['tileFormat'],'png'),this[_0x4951e8(0x1cc)]=Cesium[_0x4951e8(0x1fc)](_0x9c8343['minimumLevel'],0x0),this['_maximumLevel']=_0x9c8343['maximumLevel'],this[_0x4951e8(0x1a7)]=undefined,this[_0x4951e8(0x1c1)]=_0x9c8343[_0x4951e8(0x1c9)],this[_0x4951e8(0x1e5)]=undefined,this[_0x4951e8(0x1c7)]=SCALES,this[_0x4951e8(0x1f8)]=_0x9c8343[_0x4951e8(0x1cf)];let _0x4d4386=Cesium[_0x4951e8(0x1fc)](_0x9c8343[_0x4951e8(0x1e1)],'');typeof _0x4d4386==='string'&&(_0x4d4386=new Cesium[(_0x4951e8(0x1ec))](_0x4d4386));this[_0x4951e8(0x215)]=_0x4d4386,this[_0x4951e8(0x19c)]=![],this[_0x4951e8(0x209)]=Cesium['when'][_0x4951e8(0x1f7)]();let _0x5f018a=this;function _0x4c7435(_0x3cfa66){const _0x19892f=_0x4951e8;if(_0x5f018a[_0x19892f(0x1c6)])metadataSuccessForXml(_0x5f018a,_0x3cfa66);else _0x5f018a[_0x19892f(0x1ac)]&&metadataSuccessForJson(_0x5f018a,_0x3cfa66);}function _0x3c0a50(_0x3b63dc){const _0x3254a5=_0x4951e8;let _0xcb5682=_0x3254a5(0x1ce)+_0x5f018a[_0x3254a5(0x1d4)]+'.';_0x5f018a[_0x3254a5(0x209)][_0x3254a5(0x20d)](new Cesium[(_0x3254a5(0x1df))](_0xcb5682));}let _0x2a4884,_0x1e25a1;this['_isSci3D']?(_0x2a4884=this['_resource'][_0x4951e8(0x204)]({'url':_0x4951e8(0x1a1)}),_0x1e25a1=_0x2a4884[_0x4951e8(0x1c3)]()):(_0x2a4884=Cesium[_0x4951e8(0x1a4)][_0x4951e8(0x1b8)](_0x9c8343[_0x4951e8(0x1e3)]+_0x4951e8(0x1c2)),_0x1e25a1=_0x2a4884['fetchJson']()),Cesium['when'](_0x1e25a1,_0x4c7435,_0x3c0a50);}Object[_0x1dba81(0x1ea)](SuperMapImageryProvider[_0x1dba81(0x19d)],{'url':{'get':function(){const _0x27835a=_0x1dba81;return this[_0x27835a(0x1d4)];}},'tileWidth':{'get':function(){const _0xc1b9bc=_0x1dba81;if(!this[_0xc1b9bc(0x19c)])throw new DeveloperError(_0xc1b9bc(0x1d9));return this['_tileWidth'];}},'tileHeight':{'get':function(){const _0x252515=_0x1dba81;if(!this[_0x252515(0x19c)])throw new DeveloperError(_0x252515(0x1cd));return this['_tileHeight'];}},'tileFormat':{'get':function(){const _0x3ec64b=_0x1dba81;return this[_0x3ec64b(0x1dc)];}},'maximumLevel':{'get':function(){const _0x58ca8c=_0x1dba81;if(!this[_0x58ca8c(0x19c)])throw new DeveloperError(_0x58ca8c(0x203));return this[_0x58ca8c(0x1af)]===0x1?this[_0x58ca8c(0x1d3)]:this[_0x58ca8c(0x1d3)]-0x1;}},'minimumLevel':{'get':function(){const _0x5e5232=_0x1dba81;if(!this[_0x5e5232(0x19c)])throw new DeveloperError(_0x5e5232(0x20e));return this[_0x5e5232(0x1cc)];}},'tilingScheme':{'get':function(){const _0x1fa466=_0x1dba81;if(!this[_0x1fa466(0x19c)])throw new DeveloperError(_0x1fa466(0x1b7));return this[_0x1fa466(0x1c1)];}},'rectangle':{'get':function(){const _0x59e445=_0x1dba81;if(!this[_0x59e445(0x19c)])throw new DeveloperError(_0x59e445(0x1c0));return this[_0x59e445(0x1a7)];}},'errorEvent':{'get':function(){const _0x192a9d=_0x1dba81;return this[_0x192a9d(0x1a6)];}},'ready':{'get':function(){const _0x4d5a83=_0x1dba81;return this[_0x4d5a83(0x19c)];}},'credit':{'get':function(){return this['_credit'];}},'hasAlphaChannel':{'get':function(){return !![];}},'readyPromise':{'get':function(){const _0x4cfb5a=_0x1dba81;return this[_0x4cfb5a(0x209)];}},'tileDiscardPolicy':{'get':function(){const _0x1d6641=_0x1dba81;return this[_0x1d6641(0x1f8)];}}}),SuperMapImageryProvider['prototype'][_0x1dba81(0x1fd)]=function(_0x3d96ca,_0x273475,_0x38c7ed){return undefined;};function loadImage(_0xa26302,_0x37a47a){const _0x4e8a77=_0x1dba81;let _0x102907=Cesium[_0x4e8a77(0x1a4)][_0x4e8a77(0x1b8)](_0x37a47a);if(_0xa26302[_0x4e8a77(0x1cf)])return _0x102907['fetchImage']({'preferBlob':!![],'preferImageBitmap':!![],'flipY':!![]});return _0x102907[_0x4e8a77(0x1d6)]();}SuperMapImageryProvider[_0x1dba81(0x19d)][_0x1dba81(0x1ae)]=function(_0x4db12f,_0x1282cf,_0x48a8eb,_0x14e40b){const _0x5f778a=_0x1dba81;if(!this[_0x5f778a(0x19c)])throw new Cesium[(_0x5f778a(0x1ba))](_0x5f778a(0x1db));let _0xbb10c1;if(this[_0x5f778a(0x1c6)])_0xbb10c1=this[_0x5f778a(0x1f6)]['getDerivedResource']({'url':this['_urlTemplate'],'request':_0x14e40b,'templateValues':{'x':_0x4db12f,'y':_0x1282cf,'level':_0x48a8eb,'fileExtension':this['_tileFormat']}});else {let _0x110f5b=this[_0x5f778a(0x1e5)]==='DEGREE'?this['_scales'][_0x48a8eb+0x1]:this[_0x5f778a(0x1c7)][_0x48a8eb];_0xbb10c1=this[_0x5f778a(0x1f6)][_0x5f778a(0x204)]({'url':this[_0x5f778a(0x1b6)],'request':_0x14e40b,'templateValues':{'x':_0x4db12f,'y':_0x1282cf,'scale':_0x110f5b},'queryParameters':{'transparent':!![],'cacheEnabled':!![],'_cache':!![],'width':0x100,'height':0x100,'redirect':![],'overlapDisplayed':![]}});}return loadImage(this,_0xbb10c1);},SuperMapImageryProvider[_0x1dba81(0x19d)]['pickFeatures']=function(){return undefined;};

    const _0x5e55=['1yfTefd','_heightmapStructure','requestWaterMask','hasWaterMask','addAvailableTileRange','config','availability','fetchXML','3ONFhYL','buffer','createTypedArrayFromArrayBuffer','requestTileGeometry\x20must\x20not\x20be\x20called\x20before\x20the\x20terrain\x20provider\x20is\x20ready.','hasVertexNormals\x20must\x20not\x20be\x20called\x20before\x20the\x20terrain\x20provider\x20is\x20ready.','level','prototype','fromDegrees','60279fiWwps','_tilingScheme','credit','otherwise','Cartesian3','tileUrlTemplates','endY','getUint8','_heightmapWidth','defineProperties','Bottom','StartRow','tms','_ready','getTileDataAvailable','data/path/{z}/{x}/{y}.terrainz?v={version}','_layers','getEstimatedLevelZeroGeometricErrorForAHeightmap','textContent','_tileCredits','isTileAvailable','538280BGhHLe','getUint32','AttributeCompression','_errorEvent','defaultValue','_requestVertexNormals','Right','loadTileDataAvailability','2.1.0','url','getNumberOfXTilesAtLevel','createIfNeeded','ellipsoid','reject','_hasWaterMask','156787KqqzRF','hasVertexNormals','floor','queryNumericValue','getStringFromTypedArray','Top','Left','IndexDatatype','_requestWaterMask','getFloat64','when','zigZagDeltaDecode','defined','Credit','queryChildNodes','QuantizedMeshTerrainData','push','requestTileGeometry','_credit','getNumberOfYTilesAtLevel','_hasVertexNormals','availability\x20must\x20not\x20be\x20called\x20before\x20the\x20terrain\x20provider\x20is\x20ready.','subarray','startX','_hasMetadata','Level','_levels','intersection','appendForwardSlash','tilingScheme\x20must\x20not\x20be\x20called\x20before\x20the\x20terrain\x20provider\x20is\x20ready.','TilesBounds','hasMetadata\x20must\x20not\x20be\x20called\x20before\x20the\x20terrain\x20provider\x20is\x20ready.','Rectangle','string','DeveloperError','getLevelMaximumGeometricError','hasMetadata','availabilityTilesLoaded','1HFXBRt','1agzgog','version','getFloat32','Bounds','EndCol','752372JoJdle','statusCode','endX','defer','_scheme','littleEndianExtensionSize','requestVertexNormals','BoundingSphere','Resource','isHeightmap','availabilityLevels','inflate','GeographicTilingScheme','500969yKrGJR','_availability','resolve','TileAvailability','application/vnd.quantized-mesh,application/octet-stream;q=0.9,*/*;q=0.01','options.url\x20is\x20required.','credit\x20must\x20not\x20be\x20called\x20before\x20the\x20terrain\x20provider\x20is\x20ready.','_requestMetadata','TerrainProvider','EndRow','291891knDjFq','OrientedBoundingBox','length','resource','queryFirstNode','_readyPromise','available','byteLength','getDerivedResource','then','BYTES_PER_ELEMENT','Event','_ellipsoid','tileXYToRectangle','263661mQYzYN','hasWaterMask\x20must\x20not\x20be\x20called\x20before\x20the\x20terrain\x20provider\x20is\x20ready.','StartCol','1.0.0'];const _0x484027=_0x38b9;(function(_0x1f5379,_0x1c8f4a){const _0x12e5b9=_0x38b9;while(!![]){try{const _0x323cd1=parseInt(_0x12e5b9(0xaa))*parseInt(_0x12e5b9(0xc6))+-parseInt(_0x12e5b9(0xfd))+parseInt(_0x12e5b9(0xbc))+parseInt(_0x12e5b9(0xd8))*parseInt(_0x12e5b9(0xaf))+-parseInt(_0x12e5b9(0xd4))+parseInt(_0x12e5b9(0xa9))*-parseInt(_0x12e5b9(0x83))+-parseInt(_0x12e5b9(0xe0))*parseInt(_0x12e5b9(0xe8));if(_0x323cd1===_0x1c8f4a)break;else _0x1f5379['push'](_0x1f5379['shift']());}catch(_0xa08b23){_0x1f5379['push'](_0x1f5379['shift']());}}}(_0x5e55,0x630a3));function LayerInformation(_0x152e05){const _0x56ed17=_0x38b9;this[_0x56ed17(0xc9)]=_0x152e05['resource'],this[_0x56ed17(0xab)]=_0x152e05['version'],this[_0x56ed17(0xb8)]=_0x152e05[_0x56ed17(0xb8)],this[_0x56ed17(0xed)]=_0x152e05[_0x56ed17(0xed)],this[_0x56ed17(0xde)]=_0x152e05[_0x56ed17(0xde)],this[_0x56ed17(0x84)]=_0x152e05[_0x56ed17(0x84)],this[_0x56ed17(0xdb)]=_0x152e05['hasWaterMask'],this[_0x56ed17(0xa7)]=_0x152e05[_0x56ed17(0xa7)],this[_0x56ed17(0xb9)]=_0x152e05[_0x56ed17(0xb9)],this[_0x56ed17(0xa8)]=_0x152e05[_0x56ed17(0xa8)],this[_0x56ed17(0xb4)]=_0x152e05[_0x56ed17(0xb4)],this[_0x56ed17(0xa8)]=_0x152e05[_0x56ed17(0xa8)],this['availabilityPromiseCache']={};}function _0x38b9(_0x5ac8ac,_0x19d553){_0x5ac8ac=_0x5ac8ac-0x80;let _0x5e552d=_0x5e55[_0x5ac8ac];return _0x5e552d;}let QuantizedMeshExtensionIds={'OCT_VERTEX_NORMALS':0x1,'WATER_MASK':0x2,'METADATA':0x4};function SuperMapTerrainProvider(_0x480594){const _0x415c64=_0x38b9;if(!Cesium[_0x415c64(0x8f)](_0x480594)||!Cesium[_0x415c64(0x8f)](_0x480594[_0x415c64(0x106)]))throw new Cesium[(_0x415c64(0xa5))](_0x415c64(0xc1));this[_0x415c64(0xf0)]=0x41,this[_0x415c64(0xd9)]=undefined,this[_0x415c64(0x82)]=![],this[_0x415c64(0x97)]=![],this[_0x415c64(0xd2)]=_0x480594[_0x415c64(0x80)],this[_0x415c64(0x102)]=Cesium[_0x415c64(0x101)](_0x480594[_0x415c64(0xb5)],![]),this[_0x415c64(0x8b)]=Cesium[_0x415c64(0x101)](_0x480594[_0x415c64(0xda)],![]),this[_0x415c64(0xc3)]=Cesium['defaultValue'](_0x480594['requestMetadata'],!![]),this[_0x415c64(0x100)]=new Cesium[(_0x415c64(0xd1))]();let _0xafd9d3=_0x480594[_0x415c64(0xea)];typeof _0xafd9d3===_0x415c64(0xa4)&&(_0xafd9d3=new Cesium[(_0x415c64(0x90))](_0xafd9d3));this[_0x415c64(0x95)]=_0xafd9d3,this[_0x415c64(0xb3)]=_0x415c64(0xf4),this[_0x415c64(0xbd)]=undefined;let _0x35d675=Cesium[_0x415c64(0x8d)][_0x415c64(0xb2)]();this[_0x415c64(0xf5)]=![],this[_0x415c64(0xcb)]=_0x35d675,this[_0x415c64(0xfb)]=undefined;let _0x4d41a6=this,_0xd487e5,_0x276a51=this[_0x415c64(0xf8)]=[],_0x55121e=[],_0x223f87=0x0;Cesium[_0x415c64(0x8d)](_0x480594[_0x415c64(0x106)])[_0x415c64(0xcf)](function(_0x23b06c){const _0x2f4cf0=_0x415c64;_0xd487e5=Cesium[_0x2f4cf0(0xb7)][_0x2f4cf0(0x108)](_0x23b06c),_0xd487e5[_0x2f4cf0(0x9f)]();let _0x3bd4d2=_0xd487e5[_0x2f4cf0(0xce)]({'url':_0x2f4cf0(0xdd)});_0x3bd4d2[_0x2f4cf0(0xdf)]()[_0x2f4cf0(0xcf)](_0x3d621e)[_0x2f4cf0(0xeb)](_0x3f7055);})[_0x415c64(0xeb)](function(_0x505449){const _0x1651d4=_0x415c64;_0x35d675[_0x1651d4(0x81)](_0x505449);});function _0x3d621e(_0x2727cd){const _0x54a937=_0x415c64;let _0x44f0cb=_0x2727cd['documentElement'],_0x1c1eb7=_0x54a937(0xf7);_0x4d41a6[_0x54a937(0xe9)]=new Cesium[(_0x54a937(0xbb))]({'numberOfLevelZeroTilesX':0x2,'numberOfLevelZeroTilesY':0x1,'ellipsoid':_0x4d41a6['_ellipsoid']}),_0x4d41a6['_levelZeroMaximumGeometricError']=Cesium[_0x54a937(0xc4)][_0x54a937(0xf9)](_0x4d41a6[_0x54a937(0xe9)][_0x54a937(0x80)],_0x4d41a6[_0x54a937(0xf0)],_0x4d41a6[_0x54a937(0xe9)][_0x54a937(0x107)](0x0));let _0x4442f6=XMLParser[_0x54a937(0xca)](_0x44f0cb,_0x54a937(0xad),undefined),_0x468280=XMLParser['queryNumericValue'](_0x4442f6,_0x54a937(0x89),undefined),_0xe3267b=XMLParser[_0x54a937(0x86)](_0x4442f6,_0x54a937(0x103),undefined),_0x3d290f=XMLParser['queryNumericValue'](_0x4442f6,_0x54a937(0xf2),undefined),_0x419169=XMLParser[_0x54a937(0x86)](_0x4442f6,_0x54a937(0x88),undefined);Cesium['defined'](_0x468280)&&Cesium[_0x54a937(0x8f)](_0xe3267b)&&Cesium[_0x54a937(0x8f)](_0x3d290f)&&Cesium[_0x54a937(0x8f)](_0x419169)&&(_0x4d41a6['_rectangle']=Cesium[_0x54a937(0xa3)][_0x54a937(0xe7)](_0x468280,_0x3d290f,_0xe3267b,_0x419169));let _0x3314c5=XMLParser[_0x54a937(0xca)](_0x44f0cb,'Levels',undefined),_0x53b2a9=XMLParser[_0x54a937(0x91)](_0x3314c5,_0x54a937(0x9c),undefined),_0x523bb5=[];for(let _0x1f577e=0x0,_0x521c10=_0x53b2a9[_0x54a937(0xc8)];_0x1f577e<_0x521c10;_0x1f577e++){let _0x2634eb=parseInt(_0x53b2a9[_0x1f577e][_0x54a937(0xfa)]);_0x523bb5[_0x54a937(0x93)](_0x2634eb);}let _0x4bb50e=_0x523bb5[0x0],_0x2ee4ed=_0x523bb5[_0x523bb5[_0x54a937(0xc8)]-0x1];_0x4d41a6[_0x54a937(0x9d)]=_0x523bb5;let _0x3e04d7=XMLParser['queryFirstNode'](_0x44f0cb,'Available',undefined);if(_0x3e04d7){let _0x5aa3ea=XMLParser[_0x54a937(0x91)](_0x3e04d7,_0x54a937(0xa1),undefined),_0x3b55b6=_0x4bb50e>0x0?_0x523bb5[_0x54a937(0xc8)]+0x1:_0x523bb5[_0x54a937(0xc8)],_0x2a6870=new Array(_0x3b55b6);for(let _0x2f7e5d=0x0;_0x2f7e5d<_0x4bb50e;_0x2f7e5d++){_0x2a6870[_0x2f7e5d]=[];}for(let _0x30c927=0x0,_0x39398c=_0x5aa3ea[_0x54a937(0xc8)];_0x30c927<_0x39398c;_0x30c927++){let _0x476532=_0x5aa3ea[_0x30c927],_0xab4955=XMLParser['queryNumericAttribute'](_0x476532,_0x54a937(0xe5),undefined),_0x394155=[];_0x2a6870[_0xab4955]=_0x394155;let _0x5b95aa=XMLParser[_0x54a937(0x91)](_0x476532,'TileBounds',undefined);for(let _0x39162d=0x0,_0x36ac8b=_0x5b95aa[_0x54a937(0xc8)];_0x39162d<_0x36ac8b;_0x39162d++){let _0x27438f=_0x5b95aa[_0x39162d],_0x258cdc=XMLParser[_0x54a937(0x86)](_0x27438f,_0x54a937(0xd6),undefined),_0x2da4bd=XMLParser[_0x54a937(0x86)](_0x27438f,_0x54a937(0xf3),undefined),_0x556229=XMLParser[_0x54a937(0x86)](_0x27438f,_0x54a937(0xae),undefined),_0x50fbd8=XMLParser['queryNumericValue'](_0x27438f,_0x54a937(0xc5),undefined);_0x394155[_0x54a937(0x93)]({'startX':_0x258cdc,'startY':_0x2da4bd,'endX':_0x556229,'endY':_0x50fbd8});}}_0x2a6870[0x0]=[{'startX':0x0,'startY':0x0,'endX':0x1,'endY':0x1}];let _0x5df635=new Cesium[(_0x54a937(0xbf))](_0x4d41a6[_0x54a937(0xe9)],_0x2ee4ed);for(let _0x2e3e22=0x0;_0x2e3e22<_0x2a6870[_0x54a937(0xc8)];++_0x2e3e22){let _0x2f33d6=_0x2a6870[_0x2e3e22],_0x4b9ffa=_0x4d41a6[_0x54a937(0xe9)][_0x54a937(0x96)](_0x2e3e22);!Cesium[_0x54a937(0x8f)](_0x55121e[_0x2e3e22])&&(_0x55121e[_0x2e3e22]=[]);if(Cesium[_0x54a937(0x8f)](_0x2f33d6))for(let _0x38316e=0x0;_0x38316e<_0x2f33d6[_0x54a937(0xc8)];++_0x38316e){let _0x18653e=_0x2f33d6[_0x38316e],_0x2c0a5a=_0x4b9ffa-_0x18653e[_0x54a937(0xee)]-0x1,_0xc34fad=_0x4b9ffa-_0x18653e['startY']-0x1;_0x55121e[_0x2e3e22][_0x54a937(0x93)]([_0x18653e[_0x54a937(0x9a)],_0x2c0a5a,_0x18653e['endX'],_0xc34fad]),_0x5df635[_0x54a937(0xdc)](_0x2e3e22,_0x18653e[_0x54a937(0x9a)],_0x2c0a5a,_0x18653e[_0x54a937(0xb1)],_0xc34fad);}}_0x4d41a6[_0x54a937(0xbd)]=_0x5df635;}_0x276a51['push'](new LayerInformation({'resource':_0xd487e5,'version':'1.0.0','isHeightmap':![],'tileUrlTemplates':_0x1c1eb7,'availability':undefined,'hasVertexNormals':![],'hasWaterMask':![],'hasMetadata':![],'availabilityLevels':0x0,'availabilityTilesLoaded':![],'littleEndianExtensionSize':!![]}));let _0x411c4b=_0x55121e[_0x54a937(0xc8)];if(_0x411c4b>0x0){let _0x21bfc0=_0x4d41a6[_0x54a937(0xbd)]=new Cesium[(_0x54a937(0xbf))](_0x4d41a6['_tilingScheme'],_0x223f87);for(let _0x112e9a=0x0;_0x112e9a<_0x411c4b;++_0x112e9a){let _0x3680c6=_0x55121e[_0x112e9a];for(let _0x1b26da=0x0;_0x1b26da<_0x3680c6[_0x54a937(0xc8)];++_0x1b26da){let _0x124655=_0x3680c6[_0x1b26da];_0x21bfc0['addAvailableTileRange'](_0x112e9a,_0x124655[0x0],_0x124655[0x1],_0x124655[0x2],_0x124655[0x3]);}}}_0x4d41a6[_0x54a937(0xf5)]=!![],_0x4d41a6[_0x54a937(0xcb)][_0x54a937(0xbe)](!![]);}function _0x3f7055(_0x3c2418){const _0x441ab9=_0x415c64;Cesium[_0x441ab9(0x8f)](_0x3c2418)&&_0x3c2418[_0x441ab9(0xb0)]===0x194&&_0x3d621e({'tilejson':_0x441ab9(0x105),'format':'quantized-mesh-1.0','version':_0x441ab9(0xd7),'scheme':_0x441ab9(0xf4),'tiles':[_0x441ab9(0xf7)]});}}Object[_0x484027(0xf1)](SuperMapTerrainProvider[_0x484027(0xe6)],{'errorEvent':{'get':function(){return this['_errorEvent'];}},'credit':{'get':function(){const _0x34991a=_0x484027;if(!this['_ready'])throw new Cesium[(_0x34991a(0xa5))](_0x34991a(0xc2));return this[_0x34991a(0x95)];}},'tilingScheme':{'get':function(){const _0x333000=_0x484027;if(!this['_ready'])throw new Cesium[(_0x333000(0xa5))](_0x333000(0xa0));return this[_0x333000(0xe9)];}},'ready':{'get':function(){const _0xc4bc33=_0x484027;return this[_0xc4bc33(0xf5)];}},'readyPromise':{'get':function(){const _0x3e4a41=_0x484027;return this[_0x3e4a41(0xcb)]['promise'];}},'hasWaterMask':{'get':function(){const _0x1d44ae=_0x484027;if(!this[_0x1d44ae(0xf5)])throw new Cesium['DeveloperError'](_0x1d44ae(0xd5));return this[_0x1d44ae(0x82)]&&this[_0x1d44ae(0x8b)];}},'hasVertexNormals':{'get':function(){const _0x58e713=_0x484027;if(!this[_0x58e713(0xf5)])throw new Cesium[(_0x58e713(0xa5))](_0x58e713(0xe4));return this[_0x58e713(0x97)]&&this[_0x58e713(0x102)];}},'hasMetadata':{'get':function(){const _0xacb6c6=_0x484027;if(!this[_0xacb6c6(0xf5)])throw new Cesium[(_0xacb6c6(0xa5))](_0xacb6c6(0xa2));return this[_0xacb6c6(0x9b)]&&this['_requestMetadata'];}},'requestVertexNormals':{'get':function(){const _0xfcca4b=_0x484027;return this[_0xfcca4b(0x102)];}},'requestWaterMask':{'get':function(){const _0x2b316c=_0x484027;return this[_0x2b316c(0x8b)];}},'requestMetadata':{'get':function(){const _0x199c19=_0x484027;return this[_0x199c19(0xc3)];}},'availability':{'get':function(){const _0x208d29=_0x484027;if(!this[_0x208d29(0xf5)])throw new Cesium[(_0x208d29(0xa5))](_0x208d29(0x98));return this['_availability'];}}});function createQuantizedMeshTerrainData(_0x3acbc4,_0x46fb8c,_0x18ee09,_0x3b515a,_0x4b7b12,_0x32990c){const _0x49bdc1=_0x484027;let _0x4f357f=_0x32990c[_0x49bdc1(0xb4)],_0x3f9f2a=0x0,_0x1fdb4e=0x3,_0x21076e=_0x1fdb4e+0x1,_0x4f9798=Float64Array[_0x49bdc1(0xd0)]*_0x1fdb4e,_0x539d2a=Float64Array[_0x49bdc1(0xd0)]*_0x21076e,_0x32af2b=0x3,_0x2610ea=Uint16Array[_0x49bdc1(0xd0)]*_0x32af2b,_0x5babeb=0x3,_0x21e12f=Uint16Array['BYTES_PER_ELEMENT'],_0x4ee08f=_0x21e12f*_0x5babeb,_0x37ca37=new DataView(_0x46fb8c),_0x4960c5=new Cesium[(_0x49bdc1(0xec))](_0x37ca37[_0x49bdc1(0x8c)](_0x3f9f2a,!![]),_0x37ca37[_0x49bdc1(0x8c)](_0x3f9f2a+0x8,!![]),_0x37ca37[_0x49bdc1(0x8c)](_0x3f9f2a+0x10,!![]));_0x3f9f2a+=_0x4f9798;let _0x3fe35a=_0x37ca37[_0x49bdc1(0xac)](_0x3f9f2a,!![]);_0x3f9f2a+=Float32Array[_0x49bdc1(0xd0)];let _0x1c9aa2=_0x37ca37[_0x49bdc1(0xac)](_0x3f9f2a,!![]);_0x3f9f2a+=Float32Array[_0x49bdc1(0xd0)];let _0x13b256=new Cesium[(_0x49bdc1(0xb6))](new Cesium[(_0x49bdc1(0xec))](_0x37ca37['getFloat64'](_0x3f9f2a,!![]),_0x37ca37[_0x49bdc1(0x8c)](_0x3f9f2a+0x8,!![]),_0x37ca37[_0x49bdc1(0x8c)](_0x3f9f2a+0x10,!![])),_0x37ca37[_0x49bdc1(0x8c)](_0x3f9f2a+_0x4f9798,!![]));_0x3f9f2a+=_0x539d2a;let _0x76626b=new Cesium['Cartesian3'](_0x37ca37[_0x49bdc1(0x8c)](_0x3f9f2a,!![]),_0x37ca37[_0x49bdc1(0x8c)](_0x3f9f2a+0x8,!![]),_0x37ca37[_0x49bdc1(0x8c)](_0x3f9f2a+0x10,!![]));_0x3f9f2a+=_0x4f9798;let _0x2121e7=_0x37ca37['getUint32'](_0x3f9f2a,!![]);_0x3f9f2a+=Uint32Array['BYTES_PER_ELEMENT'];let _0x58a041=new Uint16Array(_0x46fb8c,_0x3f9f2a,_0x2121e7*0x3);_0x3f9f2a+=_0x2121e7*_0x2610ea;_0x2121e7>0x40*0x400&&(_0x21e12f=Uint32Array[_0x49bdc1(0xd0)],_0x4ee08f=_0x21e12f*_0x5babeb);let _0x5bead5=_0x58a041[_0x49bdc1(0x99)](0x0,_0x2121e7),_0x86f49=_0x58a041[_0x49bdc1(0x99)](_0x2121e7,0x2*_0x2121e7),_0x507760=_0x58a041['subarray'](_0x2121e7*0x2,0x3*_0x2121e7);Cesium[_0x49bdc1(0xff)][_0x49bdc1(0x8e)](_0x5bead5,_0x86f49,_0x507760);_0x3f9f2a%_0x21e12f!==0x0&&(_0x3f9f2a+=_0x21e12f-_0x3f9f2a%_0x21e12f);let _0xa1aa42=_0x37ca37[_0x49bdc1(0xfe)](_0x3f9f2a,!![]);_0x3f9f2a+=Uint32Array[_0x49bdc1(0xd0)];let _0x198aab=Cesium[_0x49bdc1(0x8a)][_0x49bdc1(0xe2)](_0x2121e7,_0x46fb8c,_0x3f9f2a,_0xa1aa42*_0x5babeb);_0x3f9f2a+=_0xa1aa42*_0x4ee08f;let _0x407615=0x0,_0x349163=_0x198aab[_0x49bdc1(0xc8)];for(let _0x501f32=0x0;_0x501f32<_0x349163;++_0x501f32){let _0x417d2a=_0x198aab[_0x501f32];_0x198aab[_0x501f32]=_0x407615-_0x417d2a,_0x417d2a===0x0&&++_0x407615;}let _0x398a2a=_0x37ca37[_0x49bdc1(0xfe)](_0x3f9f2a,!![]);_0x3f9f2a+=Uint32Array[_0x49bdc1(0xd0)];let _0x5dfdb3=Cesium[_0x49bdc1(0x8a)][_0x49bdc1(0xe2)](_0x2121e7,_0x46fb8c,_0x3f9f2a,_0x398a2a);_0x3f9f2a+=_0x398a2a*_0x21e12f;let _0x28ad56=_0x37ca37[_0x49bdc1(0xfe)](_0x3f9f2a,!![]);_0x3f9f2a+=Uint32Array[_0x49bdc1(0xd0)];let _0x5c06a2=Cesium[_0x49bdc1(0x8a)]['createTypedArrayFromArrayBuffer'](_0x2121e7,_0x46fb8c,_0x3f9f2a,_0x28ad56);_0x3f9f2a+=_0x28ad56*_0x21e12f;let _0x17e837=_0x37ca37[_0x49bdc1(0xfe)](_0x3f9f2a,!![]);_0x3f9f2a+=Uint32Array[_0x49bdc1(0xd0)];let _0x1172e7=Cesium[_0x49bdc1(0x8a)][_0x49bdc1(0xe2)](_0x2121e7,_0x46fb8c,_0x3f9f2a,_0x17e837);_0x3f9f2a+=_0x17e837*_0x21e12f;let _0xe86664=_0x37ca37['getUint32'](_0x3f9f2a,!![]);_0x3f9f2a+=Uint32Array['BYTES_PER_ELEMENT'];let _0x294de1=Cesium[_0x49bdc1(0x8a)][_0x49bdc1(0xe2)](_0x2121e7,_0x46fb8c,_0x3f9f2a,_0xe86664);_0x3f9f2a+=_0xe86664*_0x21e12f;let _0x44b41e,_0x173f44;while(_0x3f9f2a<_0x37ca37[_0x49bdc1(0xcd)]){let _0x1c95b3=_0x37ca37[_0x49bdc1(0xef)](_0x3f9f2a,!![]);_0x3f9f2a+=Uint8Array[_0x49bdc1(0xd0)];let _0x4a5e5e=_0x37ca37[_0x49bdc1(0xfe)](_0x3f9f2a,_0x4f357f);_0x3f9f2a+=Uint32Array[_0x49bdc1(0xd0)];if(_0x1c95b3===QuantizedMeshExtensionIds['OCT_VERTEX_NORMALS']&&_0x3acbc4[_0x49bdc1(0x102)])_0x44b41e=new Uint8Array(_0x46fb8c,_0x3f9f2a,_0x2121e7*0x2);else {if(_0x1c95b3===QuantizedMeshExtensionIds['WATER_MASK']&&_0x3acbc4[_0x49bdc1(0x8b)])_0x173f44=new Uint8Array(_0x46fb8c,_0x3f9f2a,_0x4a5e5e);else {if(_0x1c95b3===QuantizedMeshExtensionIds['METADATA']&&_0x3acbc4[_0x49bdc1(0xc3)]){let _0xca7b9a=_0x37ca37['getUint32'](_0x3f9f2a,!![]);if(_0xca7b9a>0x0){let _0x12ce36=Cesium[_0x49bdc1(0x87)](new Uint8Array(_0x46fb8c),_0x3f9f2a+Uint32Array[_0x49bdc1(0xd0)],_0xca7b9a),_0x4900fa=JSON['parse'](_0x12ce36),_0x164a11=_0x4900fa[_0x49bdc1(0xcc)];if(Cesium['defined'](_0x164a11))for(let _0x4527ec=0x0;_0x4527ec<_0x164a11[_0x49bdc1(0xc8)];++_0x4527ec){let _0x18fbee=_0x18ee09+_0x4527ec+0x1,_0x322a65=_0x164a11[_0x4527ec],_0x4058ea=_0x3acbc4['_tilingScheme'][_0x49bdc1(0x96)](_0x18fbee);for(let _0x37e47a=0x0;_0x37e47a<_0x322a65[_0x49bdc1(0xc8)];++_0x37e47a){let _0x14a819=_0x322a65[_0x37e47a],_0x41a1c1=_0x4058ea-_0x14a819[_0x49bdc1(0xee)]-0x1,_0x4d440e=_0x4058ea-_0x14a819['startY']-0x1;_0x3acbc4[_0x49bdc1(0xde)][_0x49bdc1(0xdc)](_0x18fbee,_0x14a819[_0x49bdc1(0x9a)],_0x41a1c1,_0x14a819['endX'],_0x4d440e),_0x32990c[_0x49bdc1(0xde)][_0x49bdc1(0xdc)](_0x18fbee,_0x14a819['startX'],_0x41a1c1,_0x14a819[_0x49bdc1(0xb1)],_0x4d440e);}}}_0x32990c[_0x49bdc1(0xa8)][_0x49bdc1(0xdc)](_0x18ee09,_0x3b515a,_0x4b7b12,_0x3b515a,_0x4b7b12);}}}_0x3f9f2a+=_0x4a5e5e;}let _0x323983=_0x3acbc4[_0x49bdc1(0xa6)](_0x18ee09)*0x5,_0x5c8027=_0x3acbc4[_0x49bdc1(0xe9)]['tileXYToRectangle'](_0x3b515a,_0x4b7b12,_0x18ee09),_0x5aae14=Cesium[_0x49bdc1(0xc7)]['fromRectangle'](_0x5c8027,_0x3fe35a,_0x1c9aa2,_0x3acbc4[_0x49bdc1(0xe9)][_0x49bdc1(0x80)]);return new Cesium[(_0x49bdc1(0x92))]({'center':_0x4960c5,'minimumHeight':_0x3fe35a,'maximumHeight':_0x1c9aa2,'boundingSphere':_0x13b256,'orientedBoundingBox':_0x5aae14,'horizonOcclusionPoint':_0x76626b,'quantizedVertices':_0x58a041,'encodedNormals':_0x44b41e,'indices':_0x198aab,'westIndices':_0x5dfdb3,'southIndices':_0x5c06a2,'eastIndices':_0x1172e7,'northIndices':_0x294de1,'westSkirtHeight':_0x323983,'southSkirtHeight':_0x323983,'eastSkirtHeight':_0x323983,'northSkirtHeight':_0x323983,'childTileMask':0xf,'waterMask':_0x173f44,'credits':_0x3acbc4[_0x49bdc1(0xfb)]});}SuperMapTerrainProvider['prototype'][_0x484027(0x94)]=function(_0xf11e7c,_0xf92588,_0x526bd4,_0x1b272c){const _0x1adb70=_0x484027;if(!this['_ready'])throw new Cesium[(_0x1adb70(0xa5))](_0x1adb70(0xe3));if(_0x526bd4===0x0){let _0x29d76c=new Uint16Array(0x40*0x40*0x3);for(let _0x552677=0x0;_0x552677<0x40;_0x552677++){for(let _0x5cec40=0x0;_0x5cec40<0x40;_0x5cec40++){_0x29d76c[_0x552677*0x40+_0x5cec40]=Math[_0x1adb70(0x85)](_0x552677*0x7fff/0x3f),_0x29d76c[0x40*0x40+_0x552677*0x40+_0x5cec40]=Math[_0x1adb70(0x85)](_0x5cec40*0x7fff/0x3f),_0x29d76c[0x2*0x40*0x40+_0x552677*0x40+_0x5cec40]=0x0;}}let _0x514f52=new Uint16Array(0x3f*0x3f*0x6);for(let _0x150dda=0x0;_0x150dda<0x3f;_0x150dda++){for(let _0x53f575=0x0;_0x53f575<0x3f;_0x53f575++){_0x514f52[0x6*(_0x150dda*0x3f+_0x53f575)]=_0x150dda*0x40+_0x53f575,_0x514f52[0x6*(_0x150dda*0x3f+_0x53f575)+0x1]=(_0x150dda+0x1)*0x40+_0x53f575+0x1,_0x514f52[0x6*(_0x150dda*0x3f+_0x53f575)+0x2]=_0x150dda*0x40+_0x53f575+0x1,_0x514f52[0x6*(_0x150dda*0x3f+_0x53f575)+0x3]=(_0x150dda+0x1)*0x40+_0x53f575,_0x514f52[0x6*(_0x150dda*0x3f+_0x53f575)+0x4]=(_0x150dda+0x1)*0x40+_0x53f575+0x1,_0x514f52[0x6*(_0x150dda*0x3f+_0x53f575)+0x5]=_0x150dda*0x40+_0x53f575;}}let _0x25b0bd=new Uint16Array(0x0),_0x55be4f=new Cesium['Cartesian3'](NaN,-Infinity,NaN),_0x6db278=new Cesium['Cartesian3'](0x0,-3189068.5,0x0);return _0xf11e7c===0x1&&(_0x6db278['y']=3189068.5,_0x55be4f['y']=Infinity),Cesium[_0x1adb70(0x8d)][_0x1adb70(0xbe)](new Cesium[(_0x1adb70(0x92))]({'center':_0x6db278,'minimumHeight':0x0,'maximumHeight':0x0,'boundingSphere':new Cesium[(_0x1adb70(0xb6))](_0x6db278,9567205.5),'horizonOcclusionPoint':_0x55be4f,'quantizedVertices':_0x29d76c,'indices':_0x514f52,'westIndices':_0x25b0bd,'southIndices':_0x25b0bd,'eastIndices':_0x25b0bd,'northIndices':_0x25b0bd,'westSkirtHeight':0x0,'southSkirtHeight':0x0,'eastSkirtHeight':0x0,'northSkirtHeight':0x0,'childTileMask':0xf,'invalid':![],'hasInvalid':![]}));}let _0x3d9864=this[_0x1adb70(0xf8)],_0x21a802,_0x2194a6=_0x3d9864['length'];if(_0x2194a6===0x1)_0x21a802=_0x3d9864[0x0];else for(let _0x53ee8a=0x0;_0x53ee8a<_0x2194a6;++_0x53ee8a){let _0x2a6e84=_0x3d9864[_0x53ee8a];if(!Cesium[_0x1adb70(0x8f)](_0x2a6e84[_0x1adb70(0xde)])||_0x2a6e84[_0x1adb70(0xde)][_0x1adb70(0xfc)](_0x526bd4,_0xf11e7c,_0xf92588)){_0x21a802=_0x2a6e84;break;}}return requestTileGeometry(this,_0xf11e7c,_0xf92588,_0x526bd4,_0x21a802,_0x1b272c);};function requestTileGeometry(_0x20dd7f,_0xf3ce9c,_0x4b5a89,_0x3f9224,_0x7646f0,_0x536b62){const _0x69f2cc=_0x484027;let _0x35b194=_0x7646f0[_0x69f2cc(0xed)],_0xc6fcb3;if(!_0x20dd7f['_scheme']||_0x20dd7f[_0x69f2cc(0xb3)]===_0x69f2cc(0xf4)){let _0x5c5bea=_0x20dd7f[_0x69f2cc(0xe9)][_0x69f2cc(0x96)](_0x3f9224);_0xc6fcb3=_0x5c5bea-_0x4b5a89-0x1;}else _0xc6fcb3=_0x4b5a89;let _0x155616=_0x35b194,_0x78c329=_0x7646f0['resource'],_0x8f7d04={'Accept':_0x69f2cc(0xc0)},_0x3c2b0a=_0x78c329[_0x69f2cc(0xce)]({'url':_0x155616,'templateValues':{'version':_0x7646f0[_0x69f2cc(0xab)],'z':_0x3f9224,'x':_0xf3ce9c,'y':_0xc6fcb3},'headers':_0x8f7d04,'request':_0x536b62})['fetchArrayBuffer']();if(!Cesium[_0x69f2cc(0x8f)](_0x3c2b0a))return undefined;return _0x3c2b0a[_0x69f2cc(0xcf)](function(_0x5c34fe){const _0x25c58e=_0x69f2cc;return _0x5c34fe=_0x1a0f6f[_0x25c58e(0xba)](new Uint8Array(_0x5c34fe))[_0x25c58e(0xe1)],createQuantizedMeshTerrainData(_0x20dd7f,_0x5c34fe,_0x3f9224,_0xf3ce9c,_0x4b5a89,_0x7646f0);});}SuperMapTerrainProvider['prototype'][_0x484027(0xa6)]=function(_0x551f85){return this['_levelZeroMaximumGeometricError']/(0x1<<_0x551f85);};let rectangleScratch=new Cesium['Rectangle']();SuperMapTerrainProvider[_0x484027(0xe6)][_0x484027(0xf6)]=function(_0x2fe6e9,_0x701f49,_0xbba39c){const _0x4036f7=_0x484027;if(_0xbba39c!==0x0){if(this[_0x4036f7(0x9d)]['indexOf'](_0xbba39c)!==-0x1){let _0x5e7b31=this['_tilingScheme'][_0x4036f7(0xd3)](_0x2fe6e9,_0x701f49,_0xbba39c),_0x1a51e8=Cesium['Rectangle'][_0x4036f7(0x9e)](this['_rectangle'],_0x5e7b31,rectangleScratch);return Cesium[_0x4036f7(0x8f)](_0x1a51e8);}return ![];}if(!Cesium[_0x4036f7(0x8f)](this[_0x4036f7(0xbd)]))return undefined;if(_0xbba39c>this['_availability']['_maximumLevel'])return ![];if(this[_0x4036f7(0xbd)][_0x4036f7(0xfc)](_0xbba39c,_0x2fe6e9,_0x701f49))return !![];if(!this[_0x4036f7(0x9b)])return ![];return ![];},SuperMapTerrainProvider['prototype'][_0x484027(0x104)]=function(_0x4bcbe4,_0x75c526,_0xd21a2c){};

    const _0x197f=['_imageBuffer','864898OHfgbw','value','631190bnruAE','AssociativeArray','removeAll','sort','75043RUQNiO','29291WTDdZw','210783HrZpDW','beginPath','abs','_hash','height','1zCrjIO','getContext','getColor','rect','_dictTable','data','width','addColorStop','push','clone','prototype','count','fillStyle','createLinearGradient','clear','set','243177bWCcGI','getItem','770887uDnxjM','_sortKey','get','toCssColorString','values','color','remove','length','1CxZzTQ','canvas','fill','Color'];const _0x11f69f=_0x2072;function _0x2072(_0x2bf774,_0x2e41f3){_0x2bf774=_0x2bf774-0xae;let _0x197fba=_0x197f[_0x2bf774];return _0x197fba;}(function(_0xc50681,_0x179e1a){const _0x38572b=_0x2072;while(!![]){try{const _0x3553dd=parseInt(_0x38572b(0xae))+parseInt(_0x38572b(0xc9))+-parseInt(_0x38572b(0xb2))+parseInt(_0x38572b(0xcb))+-parseInt(_0x38572b(0xb9))*-parseInt(_0x38572b(0xb3))+parseInt(_0x38572b(0xd3))*-parseInt(_0x38572b(0xd8))+-parseInt(_0x38572b(0xb4));if(_0x3553dd===_0x179e1a)break;else _0xc50681['push'](_0xc50681['shift']());}catch(_0x81c950){_0xc50681['push'](_0xc50681['shift']());}}}(_0x197f,0x7fe2d));function ColorTable(){const _0x5ad21f=_0x2072;this[_0x5ad21f(0xbd)]=new Cesium[(_0x5ad21f(0xaf))](),this[_0x5ad21f(0xd7)]=new Uint8Array(0x4*0x40*0x400),this[_0x5ad21f(0xcc)]=[];}function sortNumber(_0x909248,_0x5d31c8){return _0x909248-_0x5d31c8;}ColorTable[_0x11f69f(0xc3)][_0x11f69f(0xca)]=function(_0xa5016d){const _0x318e92=_0x11f69f;if(_0xa5016d>this[_0x318e92(0xbd)][_0x318e92(0xcf)]['length']-0x1)return null;let _0x3a9dd8=_0xa5016d;for(let _0x1427c5 in this[_0x318e92(0xbd)][_0x318e92(0xb7)]){if(_0x3a9dd8>0x0){_0x3a9dd8--;continue;}if(!_0x1427c5)break;return {'altitude':_0x1427c5,'color':this[_0x318e92(0xbd)]['get'](_0x1427c5)};}return null;},ColorTable['prototype'][_0x11f69f(0xc4)]=function(){const _0x542359=_0x11f69f;return this[_0x542359(0xbd)][_0x542359(0xcf)][_0x542359(0xd2)];},ColorTable['prototype']['insert']=function(_0x5956e4,_0x396502){const _0x34e540=_0x11f69f;let _0x55cffd=this[_0x34e540(0xbd)][_0x34e540(0xcd)](_0x5956e4);if(_0x55cffd)return;let _0x361c8b=Cesium[_0x34e540(0xd6)][_0x34e540(0xc2)](_0x396502,new Cesium[(_0x34e540(0xd6))]());this['_dictTable'][_0x34e540(0xc8)](_0x5956e4,_0x361c8b);},ColorTable[_0x11f69f(0xc3)][_0x11f69f(0xd1)]=function(_0x4a02f2){const _0x5f5123=_0x11f69f;return this[_0x5f5123(0xbd)][_0x5f5123(0xd1)](_0x4a02f2);},ColorTable[_0x11f69f(0xc3)][_0x11f69f(0xc7)]=function(){const _0x39ee41=_0x11f69f;this[_0x39ee41(0xbd)][_0x39ee41(0xb0)]();},ColorTable[_0x11f69f(0xc3)]['generateBuffer']=function(){const _0x8f4d92=_0x11f69f;let _0x4d68c5=[];for(let _0x501e2f in this[_0x8f4d92(0xbd)][_0x8f4d92(0xb7)]){if(!_0x501e2f)continue;let _0x4f8701=this['_dictTable'][_0x8f4d92(0xcd)](_0x501e2f);_0x4d68c5[_0x8f4d92(0xc1)]({'value':parseFloat(_0x501e2f),'color':_0x4f8701});}if(_0x4d68c5[_0x8f4d92(0xd2)]<0x2)return;for(let _0x57973c=0x0,_0x5b3d1f=_0x4d68c5['length']-0x1;_0x57973c<_0x5b3d1f;_0x57973c++){let _0x43a913=_0x4d68c5[_0x57973c];for(let _0x78d3f6=_0x57973c+0x1;_0x78d3f6<_0x4d68c5[_0x8f4d92(0xd2)];_0x78d3f6++){let _0x59f558=_0x4d68c5[_0x78d3f6];if(_0x43a913[_0x8f4d92(0xd9)]>_0x59f558[_0x8f4d92(0xd9)]){let _0x28741a=Cesium[_0x8f4d92(0xc2)](_0x4d68c5[_0x57973c],!![]);_0x4d68c5[_0x57973c]=Cesium[_0x8f4d92(0xc2)](_0x4d68c5[_0x78d3f6],!![]),_0x4d68c5[_0x78d3f6]=_0x28741a,_0x43a913=_0x4d68c5[_0x57973c];}}}let _0x380825=_0x4d68c5[0x0][_0x8f4d92(0xd9)],_0x33d09d=_0x4d68c5[_0x4d68c5[_0x8f4d92(0xd2)]-0x1][_0x8f4d92(0xd9)],_0x34f526=_0x33d09d-_0x380825,_0x6600d0=document['createElement'](_0x8f4d92(0xd4));_0x6600d0[_0x8f4d92(0xbf)]=0x400*0x10,_0x6600d0[_0x8f4d92(0xb8)]=0x1;let _0x242d13=_0x6600d0[_0x8f4d92(0xba)]('2d');_0x242d13[_0x8f4d92(0xb5)]();let _0x57cfd6=_0x242d13[_0x8f4d92(0xc6)](0x0,0x0,0x400*0x10,0x0);for(let _0x441de8=0x0,_0x237f58=_0x4d68c5[_0x8f4d92(0xd2)];_0x441de8<_0x237f58;_0x441de8++){_0x57cfd6[_0x8f4d92(0xc0)]((_0x4d68c5[_0x441de8][_0x8f4d92(0xd9)]-_0x380825)/_0x34f526,_0x4d68c5[_0x441de8][_0x8f4d92(0xd0)][_0x8f4d92(0xce)]());}_0x242d13[_0x8f4d92(0xc5)]=_0x57cfd6,_0x242d13[_0x8f4d92(0xbc)](0x0,0x0,_0x6600d0[_0x8f4d92(0xbf)],_0x6600d0[_0x8f4d92(0xb8)]),_0x242d13[_0x8f4d92(0xd5)]();let _0x181d42=_0x242d13['getImageData'](0x0,0x0,_0x6600d0['width'],0x1)[_0x8f4d92(0xbe)];for(let _0x11b2d8=0x0;_0x11b2d8<0x10;_0x11b2d8++){for(let _0x32962f=0x0;_0x32962f<0x400*0x4;_0x32962f++){this['_imageBuffer'][_0x32962f+_0x11b2d8*0x400*0x4*0x4]=_0x181d42[_0x32962f+_0x11b2d8*0x400*0x4],this['_imageBuffer'][_0x32962f+_0x11b2d8*0x400*0x4*0x4+0x400*0x4]=_0x181d42[_0x32962f+_0x11b2d8*0x400*0x4],this[_0x8f4d92(0xd7)][_0x32962f+_0x11b2d8*0x400*0x4*0x4+0x400*0x4*0x2]=_0x181d42[_0x32962f+_0x11b2d8*0x400*0x4],this[_0x8f4d92(0xd7)][_0x32962f+_0x11b2d8*0x400*0x4*0x4+0x400*0x4*0x3]=_0x181d42[_0x32962f+_0x11b2d8*0x400*0x4];}}for(let _0x3162dc in this['_dictTable'][_0x8f4d92(0xb7)]){this[_0x8f4d92(0xcc)]['push'](parseFloat(_0x3162dc));}return this[_0x8f4d92(0xcc)][_0x8f4d92(0xb1)](sortNumber),_0x6600d0;},ColorTable[_0x11f69f(0xc3)][_0x11f69f(0xbb)]=function(_0x5c5e4d){const _0x57ae3c=_0x11f69f;for(let _0xacc315=0x0,_0x357fc1=this[_0x57ae3c(0xcc)][_0x57ae3c(0xd2)];_0xacc315<_0x357fc1;_0xacc315++){if(this[_0x57ae3c(0xcc)][_0xacc315]>=_0x5c5e4d||Math[_0x57ae3c(0xb6)](this[_0x57ae3c(0xcc)][_0xacc315]-_0x5c5e4d)<Cesium['Math']['EPSILON6'])return this[_0x57ae3c(0xbd)][_0x57ae3c(0xcd)](this[_0x57ae3c(0xcc)][_0xacc315]);}return undefined;},ColorTable[_0x11f69f(0xc3)]['destroy']=function(){const _0x57020f=_0x11f69f;this[_0x57020f(0xbd)][_0x57020f(0xb0)](),this[_0x57020f(0xd7)]=null,this[_0x57020f(0xcc)]=null;};

    exports.BillboardMode = _0x46b65c;
    exports.CesiumExt = CesiumExt;
    exports.ClampMode = _0x5b8764;
    exports.ColorTable = ColorTable;
    exports.ContentState = _0x1acc80;
    exports.CustomTilingScheme = CustomTilingScheme;
    exports.DDSTexture = DDSTexture;
    exports.DepthFramebuffer = DepthFramebuffer;
    exports.DrawHandler = DrawHandler;
    exports.DrawMode = _0xb0c8b2;
    exports.FillStyle = _0x1b29d4;
    exports.Flatten = Flatten;
    exports.FresnelFp = _0x6129f3;
    exports.FresnelVp = _0x2e55b9;
    exports.Hypsometric = Hypsometric;
    exports.HypsometricSetting = HypsometricSetting;
    exports.HypsometricSettingEnum = _0x44d4e8;
    exports.InstanceMode = _0x526c05;
    exports.MaterialExt = MaterialExt;
    exports.MaterialManager = MaterialManager;
    exports.MaterialPass = MaterialPass;
    exports.MeasureHandler = MeasureHandler;
    exports.MeasureMode = _0x30b699;
    exports.ModelEdgeFp = _0x16f8f5;
    exports.ModelEdgeVp = _0x524135;
    exports.NoLightNoTextureFS = _0x2f5c96;
    exports.NoLightNoTextureVS = _0x521c0a;
    exports.OperationType = _0x594bc2;
    exports.PLANECLIPMODE = _0x251bf8;
    exports.ProgramDefines = _0x3ec161;
    exports.RangeMode = _0x54aefd;
    exports.RasterRegion = RasterRegion;
    exports.RasterRegionFS = _0x17fba5;
    exports.RasterRegionVS = _0x3cfe46;
    exports.ReflectFramebuffer = ReflectFramebuffer;
    exports.RenderEntity = RenderEntity;
    exports.RenderTarget = RenderTarget;
    exports.S3MBlockCache = S3MBlockCache;
    exports.S3MBlockContentParser = S3MBlockContentParser;
    exports.S3MBlockParser = S3MBlockParser;
    exports.S3MCacheFileRenderEntity = S3MCacheFileRenderEntity;
    exports.S3MCompressType = S3MCompressType$1;
    exports.S3MContentFactory = S3MContentFactory;
    exports.S3MContentParser = S3MContentParser;
    exports.S3MCreateIndexJob = S3MCreateIndexBufferJob;
    exports.S3MCreateShaderProgramJob = S3MCreateShaderProgramJob;
    exports.S3MCreateVertexJob = S3MCreateVertexJob;
    exports.S3MEdgeProcessor = S3MEdgeProcessor;
    exports.S3MLayerCache = S3MLayerCache;
    exports.S3MLayerScheduler = S3MLayerScheduler;
    exports.S3MObliqueRenderEntity = S3MObliqueRenderEntity;
    exports.S3MPixelFormat = _0xaa1cd8;
    exports.S3MPointCloudFS = _0x54129d;
    exports.S3MPointCloudRenderEntity = S3MPointCloudRenderEntity;
    exports.S3MPointCloudVS = _0x28d577;
    exports.S3MTile = S3MTile;
    exports.S3MTilesFS = _0x5c0b8e;
    exports.S3MTilesLayer = S3MTilesLayer;
    exports.S3MTilesNoLightFS = _0x6b1656;
    exports.S3MTilesNoLightVS = _0x56dd48;
    exports.S3MTilesVS = _0x5ab4ab;
    exports.S3MWaterRenderEntity = S3MWaterRenderEntity;
    exports.S3ModelOldParser = S3ModelOldParser;
    exports.S3ModelParser = S3ModelParser;
    exports.Style3D = Style3D;
    exports.SubTextureManager = SubTextureManager;
    exports.SubTextureUploadJob = SubTextureUploadJob;
    exports.SuperMapImageryProvider = SuperMapImageryProvider;
    exports.SuperMapTerrainProvider = SuperMapTerrainProvider;
    exports.TextureManager = TextureManager;
    exports.VertexCompressOption = _0x6ea6a9;
    exports.ViewShed3D = ViewShed3D;
    exports.ViewShedAnalysisFS = _0x4b05a7;
    exports.ViewShedAnalysisVS = _0x27a0be;
    exports.XmlParser = XMLParser;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
